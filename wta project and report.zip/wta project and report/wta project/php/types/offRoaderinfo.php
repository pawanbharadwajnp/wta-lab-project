<?php
session_start();
$_SESSION;
include("../login/connection.php");
include("../login/functions.php");
$type=$_GET['type'];
?>
<!DOCTYPE html>
<html lang="en">
<head>

<!-- Repeated code -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title> a4Automative </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<style>
#he1{
	color:red;
}
#hel:hover{
	color:blue;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

* {
	margin:0;
	padding:0;
	box-sizing:border-box;
}
body {
	font-family: 'Poppins',sans-serif;
}
h1 {
	font-size:2.5rem;
	font-weight:700;
}
h2 {
	font-size:1.8rem;
	font-weight:600;
	
}
h3 {
	font-size:1.4rem;
	font-weight:800;
	color:#ce93d8;
}
h4 {
	font-size:1.1rem;
font-weight:600;
}
h5 {
	font-size:1.0rem;
	font-weight:400;
	color:#1d1d1d;
}
h6 {
	color:#D8D8D8
}

button {
	font-size0.8rem;
	font-weight:700;
	outline:none;
	border:none;
	background-color:#1d1d1d;
	color:aliceblue;
	padding:13px 30px;
	cursor:pointer;
	text-transform:uppercase;
	transition: 0.3s ease;

}
button:hover {
		background-color:#3a3833;
}

.navbar{
	
	font-size:16px;
	top:0;
	left:0;
}
@media only screen and (max-width:991px) {
	body>nav>section>div>button:hover,
	body>nav>section>div>button:focus {
		background-color:#fb774b;
	}
}
	
	
.navbar-light .navbar-nav .nav-link  {
padding: 0 20px;
color:black;
transition: 0.3s ease;

}


.navbar-light .navbar-nav .nav-link:hover,
.navbar-light .navbar-nav .nav-link.active,
.navbar i:hover,.navbar.active   {
color:blue;
}

.navbar {
	font-size:1.2rem;
	padding: 0 7px;
	cursor:pointer;
	font-weight:500;
	transition:0.3s ease;
	
}


 body {
 background-image:url("https://cdn.hipwallpaper.com/m/56/10/d5qDRv.jpg");
 color:coral;
width:100%;
height:100px;
background-size:cover;
background-position:top  center;
flex-direction: column;
justify-content:center;
align-items: flex-center;
}

 

img .one #new {
	width:100%;
	height:100%;
	background-position:center center;
	background-repeat:no-repeat;
	background-size:cover;
	position:relative;
}



#new .one .details{
	
	position:absolute;
	width:100%;
	height:100%;
	top:0;
	height:0;
	transition:0.3s ease;
}

 .one:hover{
	cursor:pointer;
	background-color:#d1c4e9;
	transform:translateY(-70px);
		transition:0.3s ease;

}



</style>

</head>


<body>
<!-- NAVIGATION-->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 ">
  <div class="container">
<img width="400" height="120" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" alt="logo"/>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
      

	  <?php


	  if( isset($_SESSION["id"]) ){
 echo  '  <li class="nav-item">  Welcome, ' .$_SESSION["name"]. " </li>  ";
	  }
	  else{

		 echo'  <li class="nav-item"><a class="nav-link" href="../login/login.php">LogIn</a>   </li> ';
	  }
	   ?>
	   
	 	   	     <li class="nav-item">
  <a class="nav-link" href="../../index.php">Back</a>   
	   </li>
	 


    </div>
  </div>
</nav>
</nav>
<!----------------------------------------------------------------------------------------- -->

<!-- printing on screen -->
<?php 

function pprint($I1,$I2,$I3,$I4,$address ,$p ,$type ){

	//--------------------------------------------------------------------------------------------------------------------------------------
		echo '
<!--  cars data -->
<section class="sproduct my-5 pt-5 container">
<div class="row mt-5"> 

<!-- Images -->
<div class="col-lg-5 col-md-12 col-12">

<!-- main image-->
<img  class="img-fluid w-100 " id="mainimg"  src="'.$I1.' "/>
<div class="pb-1"  >
<div style="display:flex;justify-content:space-between;flex-basis:24%;cursor:pointer; ">

<!--img groups -->
<img width="20%"  class="small-img"  src=" '.$I1.'"/>
<img width="20%"  class="small-img"  src=" '.$I2.'"/>
<img width="20%"  class="small-img"   src=" '.$I3.'"/>
<img width="20%"  class="small-img"  src="'.$I4.'  "/>
</div>
</div>
</div>

<!--information-->
<div class="col-lg-6 col-md-12 col-12" >

<h1><b>'.$type.'</b></h1>
<br>
<p>
<br>                             
    <br><br>  '.$p.'
<br><br>  </p>
<br>

<a href="'.$address.'" target="_blank"> <button> go to official website</button></a>
</div>


</div>

</section>


<script>
var img = document.getElementById(\'mainimg\');
var s = document.getElementsByClassName(\'small-img\');

s[0].onclick = function(){
	img.src=s[0].src;
}
s[1].onclick = function(){
	img.src=s[1].src;
}
s[2].onclick = function(){
	img.src=s[2].src;
}
s[3].onclick = function(){
	img.src=s[3].src;
}

</script>

';
	//--------------------------------------------------------------------------------------------------------------------------------------


}
?>



<?php













//copy this for future reference

 if( $type=== "Mahindra Thar" ){
	
	$I1="
              data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADhAWQDASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAAAAECAwQFBgf/xABMEAACAQMCAgcEBwQHBQgCAwABAgMABBEFEiExBhNBUWFxkSKBobEUMkJScsHRI2KCkiQzQ1OisuEHFWNz8BYlNJOzwtLxRINUhOL/xAAaAQEBAAMBAQAAAAAAAAAAAAAAAQIDBAUG/8QAMBEBAAICAAUCAwcEAwAAAAAAAAECAxEEEiExQQUTFFFxIjJhgaGx0SNCkcFDUoL/2gAMAwEAAhEDEQA/AOXI76Te2MZ9eNN66E/aHrT8xnlx94ra1ATOpBHMdo/1q3Dqc8RBaOGQciJFIP8AMhFVQFPb60oXnioiW7l069IaXT4UkHKSJ5Qw94P5VQawWU4juAgPISjcB7+FWto7RRtXlk/lRdypvouqxgvGkM6DjiKZA+O8LJj4E1XlhljBEkckbcsSKRWqBjl78HFNJU8HXcO5s4+FBz+192MelSjrEHAkDtB/1rZa30eQHfbSq33oZdvH3/pVZrL7FvI8g7Fn2AjwzwoMklMkhAGPNkJGfceFKMkbTtYdzZU+o4VdfSNYQl/oFyy8DmJC4923jVdkIGGV0cfYmQo3owBoqEqOZDADkSNw9VrU07XdZ0wr9EmjePPtRTRrLG3nyb41l+0G4HHbTmDYywU+OBke8caI7626d6Ncwm017Q2eF+EjWUpZT49TMQ3pJUh0b/ZjrQB0zXm02cjhBfEqgOMY23WD6SGvOw3Zub+L2h8ePxpcAjioP4T/AO1uFVXUaj0M1SzBa2vdMv4wMqbO5USEd/VSY+DGubntLmBis0bxtnGHBHzpYZrm2ZTBMyHIIVgQpPirZU10dh0rWECLU9Fsb2DADtGohkI8Rhoz6CrtHK+2tAOeY/KvQFP+ybWAQXvdEuGwBvU9SCfw74v8tUb7oZAFM2k6/pOoRYyqmUQzEeGN0f8AiWoacf76mhuLi2dZIZGjZSCCuDxHnmpLnTb61YrNEyYzxBVlI7wyEr8aqYkHEcR31kOnt+mvSeMIk14ZolxjdHFuAHDgQtbdte9G9ewuoagYbhhj+kKsWT4OAU9a89zx4inhgOTetQejXf8As4uJY+v0u9gnRgSqynbu7Rtlj3Ia5LUej2t6W2LyyniXOBIV3RN5SJlfjVax1jWNNbfY31zAe6KRgp815H0roIen/SgqI7m4jnjI2vuhjDEHnnaAD7xRXK4ZfKlDj/6rtLdOjGut+1vbS1uZPrLLELck+DZCfGnXv+zvWY0Mtg8N5EeKhHEbkfu7jsPueoOOV1OBUme4mnXem6lp79Xd2txbvnAE8Tpn8JIwfcaq7nHPNBYyQRxqZLhlxzqmGbx99P3949Kg39P1ie0ZSu10+0j/AFT6ca7Sy6TaJMqrLFLDJjBDNuQnwYfpXlytjkasRyuD/rWMrt6Xf6LZ6oOut4WiZxuDq+5G8cVy1/0b1WzUyGFnjB+vGCw9/bVfT9d1Ox4QTuqnmmcofNTwrp7DpTbXHsagZYyx+vENyH8S8/nWK7cM8Mqk5FMwRXpU9h0Wv0aSOVSzD+sgwDn95T+lcze6BLEzNADLFzBVTkDxFVXO8eFOAap3hKEgrgjzpoHeKuwgBpwU08AU4LQNCmnY8aeopwUVAwKcUVOFGKKDAk029BLfRrjA4kiGTh48qYsW04BZWHMHn6VbtOlXSCyG2G/uQo5K5WUDy3inXHSa8vjm8+jytgAs0So594FZsWc0lwh4YPHtqVJpse0noa1LSfolOP6dbahG3NntZY5FHkuAaddQ9F9w/wB36ldjPJL2JFx5shommYt3GOBOPOp1njYZyD5VYj6N6rfe3ZLbXKniOpuYCx/hLZqreaJrFhlbvTrqEj7RTKnyZMj40Em9TyIoz5GszZcoT7bLx+18qcZLxRzRsdx40F5tp5qM99RkDBw3rx+dUfpM/J1I8hThPEebN6VE0uLcXMPCOeVR3JI6j0BxSPdtIR14Ew5YlJPxqoZISMe2fLnULY7DIv4hkGqq8y6DIPatrqJ+xoLgFc/hZag+hRynbb3CNnktwyRv8SBUStNjgqN50v7Y84gPGiEl0rVoAWks5inPfHtkXHf+zJPwqm4IOCCD2g5B9DV5WuUP7NmTh9gkZ9DUgnm5SxwTD/jxhj6gg1RnDfjnw+FGQOwg96nHw5VdcWjkn6MsZ/4DsB6MTUYt92erkXykKg+tBXyD2jj3j81pVZo2DIzIwOQ0bEH1GDUr28yfWQEfeQhvlVc5BweHgeHGqum/p/SvWdPwm20vIR/Z3sCsfdIm1/ia3F6Q/wCz7Uww1fo5NZTOMNcaVIDx7yF2N6hq4UnGKAw8ag6q80noZOC+j69LuPKDUbYhvISR4Pqh86w59LvYRuMZdOPtxKzrj3DPwqkCDzwfgfjWhZaxrOnEG0vZo1B+oxEkR80kBWiKIXBIzkrwI7fSncq6gdLbW8UJrnR3Sb/s6+FDZ3IPeHjyM+lVTF0Tv5MWclxprtnEeoTJJCD3CUrnHmaKwxt/XNaFlrGs6d/4HULu2B4lYZnCHzTO34VpydCekbR9fZQw30ByQ9jPFLw9QPjWFdWV/Yt1d5bXNu/LbcwyRZPhvGPjQdAOl2t3CiHUbp7iA8wyxsf5WG34VoWmldFdYAWDVoLa5bGI50WA7j+65Cn3NXE5I5j0pwNQdjf9Aektspktoo72HGQ1q43kd/VuQfQmuYmtrq3do54ZYnUkMkqMjAjwYA0+21PVbTH0e8uo1+6k0gT3rnFdBadJ9PmCxa1pxuU5GWGQlh4lJT8mFBzAOMcKkVh3110umdANSUPp2tyWMx5QX0DsmT2Dhn/Gaxbvo5qtuS0SC6iBOJLMO4I7DtIDfCgoKe0EVIsjDkar7XQkMMEcCpBBHmDxpwappYaltfTQOsiOUcciD/0K6qy6WyAKlxDC/AAyRrtbHivKuGVqkVyOIpo29Ma30TW1EgntusK8TGAko/Eh41g6h0angJa2kS4j4n2MhwO4g1zcVzLGQVYgjkVJBHvFdHYdK7+BUSURzoABl0AkA/EPzqTC7YbxSRsQykEHjkEEedAruhc9HtcUCeVEnIAAaMRyg9ysOBrMvujEyEvZM0yYyFZCr+PgaK5sU4U6W3uIGZZY3Qg8Q6kEe40wE5qCUcqKRTwooqraS9BpQF1Gy1GFifaeHBUHw6pwf8NaI0H/AGZXoH0bpJcWjnIC3i4A8+ujX/PUw0no3cttSKWEk84blsfyyZFJJ0PtHz1GpOpPJZ4VcesZFZbRm33QyxhQy2XSfR7pexQWWQ+AMLSD5VlL0c6REZitJZ155hdSp8V3kH4Vty9CNWVS0Munz9212ibB8HXHxqGPS+mumHNquqRqp52U/Wp/Ijn/AC05k0wpdO1yy9qbTb+Ln7Zt5gBj99AR8adb61qNq46u6mVgfq9YW9UfI+FdKnS7pxYHZNcswU426jZoDw7N21G+NQ3/AEr1HU023mmaNKDjLJaru/mcsfjTcGjYum94IzFc2mm3KkYY3Fom4jxKjHwrPfUdFvJAZbNIFYncbLbw8lY1NAehUoAv9O1OBjzeylUqM9oUFflVk6D/ALPLoFrTpTdWbEYEepWRYA+LBU/zU6GpRrYdEpY98Wt3EE2AQl1ZsVPgSrfnVRtDuLtili8F2R2xMiEj8LkGmTdGpVk2aZrOnaiT9X6OZon96vkfGoZOjnTG39s6TeOBx3wKs3p1R3fCrpDrjo/rliN1zpt7EvZIELJ6rms1jcI2MnI7HGKna+1yyJS4N9bkfZn+kRf4ZRitC26V3kS7JbbTrlDwP0qzhckeagU0jKMsqjLRqw/dwDSC5U81K+tao1Lo/dyFrvTUhB5nTGWL37H/AFqeW26GyKps9R1GGRuBS9gjaP8AmQ5oMPrVP2hSMwxzHuBraXorc3CmWzvdKnXntF7FG+PwvjjWbcaPq9vktaXGF5mJTKmO8NHkfGgq7vOmn30h61cg5yOYYEEHxB403rGxxX0qh4LDiMjyOKf10uMMEYdzIp+OKiEinwNLnNZRCFxbt9dGUf8ADx8jSNBAf6qVuPISqF+INFJmmlIbWccQgYd6EH4c6jCsp5EefCpgTwI7O0VIJpRz2sP31DfPjTQr5xjI/Kl4VLut2Ptpjv6tgMe400rZt9SdVPdIVA9RUVLbXd5ZuJbO5uLaTnvtpXib37CK24+mPSYJ1V3eG+tyMPDeqrhh+IDPzrnjEwA2tG+eXVOrH0HGmEsv1gw4dqsPmKx3BqfDrYb3oBfcNQ07UtNmbnNp8qzxZ7zGQCP5DRN0d0W4w2idJbG7LcRb3cUtrceQO0qT/CK5LrIhjLqPNsfOjrYSeEicDwwy5+dBrXeja1YgtcWNyiDnII2ePz3KCKoqc8iDjuIPyrS0/pL0k00Ktlql0sYGBFIwuIcd3VzBhVybpLHqBA1jR9NuSfrT2kCWt32cRInCgwww93bWtp/SHXNN2/Rbx+rBH7KXEsRx+6+fhVhbPoVejEGtXWmzEf1eq2plhye6WA5qCbo9qUYL2klrqUIPCXS5TNw8Y2AcehoNx+mNnqKLHrOhabOxGPpESyJMviCG3ejUkeiaDqw3aVqtrDMeVteSMhBPHAMuG+dchIskL9XMrRyA4KSqY2z5OAaM949ezyoN6/6N9INMy1xZuYsZ663ZZ4cfijJI94FZQJHPPOrOn6xqWnspglBXkY5gJEI7sHj6Gt7/ALQdG79QuraAolOAbnTZjE+e8qRn4mg5xXHfUyt3VtpoGn6jl9G1O2diSVtr2VIrj8OSB/lrOvNG1nTji8s5o147ZABJEcd0kZK/GimJI6kEGt2w6R6nabE655YV/s5WzgdynmK5pWIxkeRFSq9TSvRYtT6P6wBHdR7JSMAzOB6SVUvuirANJZyo6nJCMy7v4TyNcWkjKMg1q2OualZH9jMdvajgOh/hbhWIbJY3MTtHJG6spwQQaK3U6Y3W0b7eEt2kAfmKKCCNZ2OXggc+AIPwq1FEgYkwSoc84nJHoamiUjmkZ79hdPg1W0IBPsSDJ5jDD4U2qELgALNKvg65+NWIDPGcpLE3hkqakUp97H4lYVIADyKHyxUDjLcPwkjDrjiPZcHwINZ91YaHcE9fpdrkj2iIQjeqAGr+0Djg+40u5u/h48fnQc/J0Y6MTDKrcQNx/qpiwz+GXdWfN0LtH3fR9QI7hcQg498bD5V1p2H6yIfcM/CozHASfYK/hY1NDiJOg+sA7oGtJscRslaNvSQfnSJY9PdK/qG1eJVHDqZTPHj8KM4+Fd5Gdn1ZJB+Lj8qlDyc96k+OQadV288ueknTPqzb3d2WTGGW6tIlPvJRaoxXOjyZOpdH4Lrd9Z7eZoXPlgfnXqYkdhh41ZeRBIYH3Gq82l6Hc/12l2TEniwhVH/mjwfjV3aDo84ks/8AZtcKT1XSSwkI+rE8FzEP/NJNZ66Bp1zIy2GuwKMjaNST6O/v2nFekS9FujMxISK5gPPMNw+P5ZdwrPn6EWhJ+j6g+D2XNujj1jK/KnPaPBqJcg/QbpiF6y2itL5AMhrK8gdiO/DlT8aoFumWhOytHqtk6HiFMoUePsErXVydD9WhJNvLbPz4wzSQMfcRj41Ell0x01iYhejGCQDHcx+jbqRl13g9v8XKN0m1OeQG+MF6QeKXsKOT5ldrfGpW1LRrxoojoFvHK7Bc6bNcxyu37qSOyetdPLrGqspTUtF0S8z7JN7piq/8yEGsW4jsLgxx22m22m3N4ZY55bUylIrJQsk0qRucDh7K8eJYDNPdrPZsx4JmZ5u0dZQvpPR14y0V9fQzjh1TxQXSZ7i9u3ZVT/dkSq8rXcnUoxVnWyk2gjjtzIw41rS3Mk729lZoYbWGMQwrEwxDBHwAJ7XPNieZOa1tBshd/SNbu026XpJmSyheFyjvAodp8g4ODwHA5J8KyiLR5PfwxOq49/WZn9tOcudFjsUtXvV1BDdDNvGxsopJR3iMszgeYH6Max06MZeCZuHKS+II/wDJiHzq+899qFzeateKd8rlYFZSVghXgsaHHIf69tZVzMXLZOedY9Z7zLL4qI+7Ssflv95kFtLQ8NOhYhj/AFlxduMe9hTTd2a/V0rTeH3oZHPq71Sdx4fGo9/Pn605T4vJ4iI/KP4aX+9GTbstNOTHAbbKHl/Fml/33qCD2foyKDxCWluOJ7AAtZRfxPvNb3RU2sN/d6tdRiSDRLKW/VHwVe5+pEuDw4kipywvxmaO1v0j+F2RtYtIUn1nUF05poxJbWMVvbzapKpAw8kOFSNPFmz4d0llqN/JpcjGWRZZpVSGWP2Jo8SELImOAbHA8O2uSurqe6lubq4keW4uJHmmkY5Z5G4nj3dg/wBK6uGNbe10+E4Gwxu+OZCDec+hrmzzyxHL0l9F6FN+Kvk+InmpEdp+qZLrXgNqa40hVtu25S2lII4bcjBpJW6QsP2sdjcD9+0i4/zRMPjXPm1kYs5LAuS5Bx9r2sUqpNDxWWRCMcUdl+RrfFckf3PKtxfAXtqcEx9LNJzJuP0jRbCQ444tLU/+mUb4VWcaUx/aaT1PjbveweYG4vH8KYmpajH7Iv7or+8ySj0lBrV02WfUku2kKmWCQAMkaIXTkdwTArG98lI3MRLdw3D8BxmSMdJtWZ+epj/TKNlpUhPVXF7BniBKsFyvquxqWKxv7dxLY6hAHHJo5Z7OXz9obf8AHS3izWtxNCqodjsDvBxg4K4x50xLiYYzFGe/azD8q6IncbeLkp7d5pPidNf/AH90zSLq76IajajAK3tpb3qkf8yIM49aiju+hF2Sl5Yalplwc5bTZY54ge/6PcAMB5VVjugCD1cqnPNHVj8watG9V12y/tFxjbcwdYAP4gwq6a9g6FaXZ/7l1i0vSeAgu9thc57gsrbT8KqXmj65pvG90+8gTkJWhZoT5Sx5T41FeQW4VZoUVAZAjouWj9pSyugbiORB4nsp1nqusWP/AIW9uY1xgxlzJCw7mjkyuPdRYV1bdg8COwjB+IrVsNa1OwIEMwePABiuFEsZ8MNx+NSHXbO6GNS0LSp2IINxZpJY3JJ7d0DbCf4aaLbozdAm31WexkOMRarbvJHnuFxbZ+K1FaLaz0fvgBqGhxQSH611pssiNnvMRO004aJpl2N2la5YyOc4tr4tbTnwBZdpPurLk0PW1VpYLb6bbjj1+mut3HjvxH7Y961n7ipKsCrrzVgVdcd4biKDTutO1SxJFzbSog/tNu6I+IdMr8arhzw4+lWbLpBr1iuy3v5hFjHVS7ZoiO7ZKCKtHVdHvMnUtMKStnNxprpCxbvMZXbUFAPworRXT9ElAePWoo0P1UuYiJV8G2nFFQdbHcZA9qNs9xQ/oamWRc8UI8lP5E1zSypw5e41Ok+0+yzDyYjFRXSB4iPr+pI+BFPC55FT57DWCt3N/esfxYb51Mt6/asbe7B+BoNjY45Agfuhh+tJlxn2jjuYA/PFZ636jHsOp/ck/Iip01BcDEsw7w6hh8/yoLGSf7s+4ik3D7n8rA/A0i3cTkZa2f8AGuw+uKcJIJMZtwf+TMR6DJoDcOeWAPeD+VLnP219/wDrRi17Tcx/iCsB8BRshb6t3H4CWMg/CgT2xyz7qd1soHNvfSfRZjxQ27/gkKmmtBep/YzEfuOHHxoH/SWHMA/iFJ9KXuHuqu7SKfbSQfjiOfVaiMsR4exn8TJ/nFBb+lJ+8KPpKnk4/iFUsxngA/8AAVcf4TTSF++R+IEfOh9F9rlNjtKI3ijRpJPqn2FGTgNXm1zcm5lv78qqm8ldIVQAKlrC5G1QByLZP8Arb6Sal9DtnsYXDXV1FE2UYewkknVxqfFjx8h41zcoUbIEP7OFFiTtysQ259+M++saxuzoyW9vBy762n9I/mf2WIEZba8lH9ZtEUeQDxIJPEj18q7W9gj0voTFaQsxMtvZxkvzeS5YTyZA8c1x9rGz2N83AsbhII1JA9uRcE8T5Cuk6T6jpqaFptm2o2JvFmsVmggu4JpEMMBV9/VscYNbrfg8+k73KhekWun2lsgwFhTdxPFiMkmuKv5CXXI7Dy866HUNWsJ9ixXVmyhABmcA5A7TyrmbyVXO4bfZGCVYMCc5yCOFYxDP6qhbJH60MRk9nZUfEk4405lYAFtqktt2ll3HgCDjNGRu7zrStJ9mmarbhiHvZrVX4H+qhJkx64rMGM8WXHgScegqaJ41PF1I5cCTxz5YppZhLDb9Zc2cWch5kLfhU7jXZvbT3ClIkdmeF4k6uJ5G3y4iyiJxJG5jjwrnNNiLXQfB9gFBkcmb/Sn397OZtRRZZFjOUUJIygBZAQRg+FceSd5Yq+s9On4f0vJn7TbpC7Ho6SEpF0itlbiF+kQ3CLuHDDOuSPSq13o2o2u03VxGEYkLLv6yFyOHsSodp9aqLeHYg2NkKBzTu86U3MktvcQMxEauk4QngJFbq2YDlkg8fId3DvnT42KWjyWTT7iO3a7jltriFCFn+jygy25PANLE2G2nsYZHfitfopJie/TI9tJcbuX1C35VzhC55DIHCtXo9KY7u7x2cP5kdeFc+bpR7Xo8Tbiqx9f2bOpWOnXmrXAudUh01GtIJoJpgDHLIG6t4yCQM4GedInRvTXEfU9KtLc59v8AawjPigMgNZ2vP1n0SQ9odDnv4OPmawv2faq+grPFO6Q0eq4JxcXeu/x/y7Vuh2sdW0ttqmn3Majc/VqWKr95urLHHjimnotqiokranp6Qu6R9aeMaO3AIzg4z3ZxXIROI2DRkxsM4aMlG48DxUg1YjnkRJo0mmVJkMcyK7hJEP2ZFBwR51seZy2+a7cIY7aaJyrNBOImZfqs0UrwllIPI8xWeMd9WIzm0njAJAztAyeUqtwqqDjmMce40bo7dUgB86XLcuIpm7xpwJ7/AFqKljlkhcPE7xuPtxsyN6pg1pprl+yiO7jtNQj7tRt0mfHhMMSj+asjPfiig2RJ0ZnHtxajYSnttmjvLbP/AC5isoH8ZpBpckvGxvtPvO6NJxb3PkLe52nPkxrJyaXnzGceArEaLWWrRkpJp2oBhzH0S4PxVCPjRVeO91GJAkV7eRoM4WO4mVR5ANiig2lue8L7qetyM8u3vrmV1a8GN1vaN5F1P+apU1hwfas1P/Lm/UGsdwy06hZ04dlSidewmubTWYRwa0uB5SI3D0FSDWbL7SXS+aIfk1NwmnSCfxqRZx31zq6xppx+2lX8cL/+3NSrqmnn/wDLjH4hIv8AmWr0HQdcMc6cJhngaw11CzPAXVsf/wBqj5mpluoyRiWI/hkQ/I0G2tzMpG2SQY7mP61KL65HNwfxojfMZrF+kBFaSRtsSAs7n6qqvEnhVQas/wC03QhSpJIDqBBGQCnXySezvI4kAcM8aT0bMeK2WdVdML4/agiODxK70J9Dj4UPrFrajM0klsDyP0hePkjDca5t/pkwDiOd1dAQTegIVPHgqQ4qk9pcDLG2gThxeS4lOB44izWmcnyh7GL0ncc2S2odf/2q0tRw1RyBn2XtJZc9mAUBFRP0v0nJBge4xyK2rJn3u61yZt7xc+zZjOP7a4HAnAYqVBxR9GvwT7NpkbeUt2fadsKo7Mnn5VhN7/J109P4Gf8AkmXTnpLokuP+5bwk8ys9rHx/iJ+dRrqyysRbaHfnPIrqlmp+IxXPrFqycVaBRnmJLkD41L9N1y0Cn6XEgYkKC8pLHlhQyHjSMl+zov6Tw0V5q7/OUepaR0g1PUfpsWnyW0Ya2I/3le2wjzAmwBZI8ZHbyrKu7C4gJjk1DTrhywWSLSjd3MwH2sO8QhyPxGtyx1O9Ny0xMdxg4laaNnLbeBVZpF5jsw3u41Pf9Mbyzv4YbSSOKwWG1kmBgRWfrMl8SD2hw+RFbKTaekPK4jh8GOIyW+1HbpLml0zVZYxDBb69JAW6zYbRVjZu87QAfWpJdG6TSKgksJkjXDAC1tLcDhjj1UY4+ddo/SElQ73kgjbBU4mCnuIyKrv0ksVDZvpTw5IkrE9nHcAKwm8+ZdNeBxR/bH+XFno5qpO8xOGdssN68PLiBTj0Y1vcAtvmPA4G4jQ57eZNdE/SPTAfZW6f+BFz6vUZ6TWo5W1wfAtH+prH3J+bpj0/BPj9YYp6L6wyDZYS8uLG7hZi2TnAVlGPdSR9HdStuta40u4lDxvEd4BjXeMblMecEdhzW4OlKKPZspT5yKPypy9MGXAW0cE/8bHD3LWM235bI4PHWd8lZcwdNhTO+yzjgcXAJz/MKmNpZuELWI/ZoqZGScL2su7JPfwrom6ZryfT4mJ/vTDJnHesiEVRk6R2c8ZifSLUsAyJJH1STRqcldrqm7hnhWueb5u3FTDW0ROGuv8Az/CCwCAoUwI4jI6gcFCrlqwbhtrsGzmTceHPjwzW1Yy7kuZAh2fSZEUMM4UkEqccO+sfU12XKuV2RSJ1keRtTifaCk91OHj+p1T1m1fgI5Y6fgqop+9kDA7R2eNWYTIDK3MMpBwMjjj9K6Do/ptmsDXeoW8Mz3KBbeG4RZFhhzncyt9pvgPOtwaf0XYe1pGnnxERU/4WFdk5qxOnytfTM16RePLhTu4nafQ1a0U4vL3uCp8Sa7EaL0Rc8dKiGf7ue6QeiyYpl1pGgWVpLNp1u0M/WRdYXmml3RcRgdaxxg4Na8uSLUmId3pnCZMHF0tfs57VlLWsb4J2SRnyDArWIAD311VrbwX8tpZXLOIbqVYXaNgrrknDKxBGQfCrLdE9J9oJfX448NxtnH/pisOHyxFNS6fXOEvk4iL1jvEOPVakCkAdx4jt+VdavQ+2bG3VZxw+3bQt/lYUv/Yybjt1aHn9qzYf5Za6oy1l87bhslZ1MMDTIxNcw28kogjuDKGlYMRGNhIYhePZ8a3To0hXEWo6ZIvH+sYIx7P7RN3xqxbdDr+OZHF/ZShBI3VLDMjyeww2LuYrk9nGs9ZtMLIWeZVB9pHiI5c19k5qam3WGGuXpaCt0e1HHC1gnJ5dRcQ7vcFf8qrSaLeRH9tY3sf4Ymb8sfGrTGxdsw3aKOGFYyqc+ZFPR72Pjb6gVP8Aw7rb8MimrQnSWQ1iFOCZE485Y2XHmBk0z6I54JJG/YNpxn+YCt1rjXDxNw8gHHLGOX55NN+maocdbZ2snD+1s0P+UVdyahhmzuV4bD7sN/lzTTDKn1lYfiDL8xW8bgYzJo1gSTxMf0q3b/C+PhTfpOnZ9vTLpMf3Govw90ytTcsWEEfHDHrRW+LjRSPag1nPbiawI9TFmir1TRu23f63RAeJtdQz6DeahkttJOd/RrXYif7qUS/AofnWeCvcBSiRlJ2sw8mYfI1OVeZM9voIJ/oXSGHvDWyNj37RVV4tBBIF3fR8eU1owI88NVlbq6HK4nHlLIPzqT6df/8A8q498jH51OU5mUyaT9nU07frRSL686Z1dsfqXtu3vYfMVrPeXZAzKG/GkbfNahaRnB3RWz8O23g/+NTlNs0xDsliPk4p0cDtuwYsKpZmZ1CqAMksT2Vb222fbs7c+UKL/lqRI7PaWNtbrCk8Ek4lZ1SVFOepYqeCsQM9+MdtO3dnSk5LRWrRsrfo9BaTSSSve6kIi8CoXjtIpdpdCseAzYxnLHB7BitXQdOtrieLrWV1tkknKMNwe43YDOCMEgkt5+VYsupR3l3DLJJbvcT3DoscLZWKNbZ4lRATnHD41Zsb25t7rfbYKyBl3FwqGOTBOW7MevCrW0c3Xs9LJwtowaprfnU7aPSSRtPt5TCxDZJBPsnOAeOPMmuRku9RV5ka9m/o2l/TJ0I4tO0SlQCRwAZ14eHjWt0puTOkEO8M0zxR8Dz6xsHOOPaK528njYdIpQgO+4t7aM5bJjErylMg4xhF8fGtkRGtw8/LkyRfl326Jobi9ll0SJr+XN4GnuGwQDEJXTaAFyMKpOfGq5v776E90L6YGS86iEYJEarG0jqeHEnKD/74K0qx3Vydig2WjCFNrP8As5HtlhO0573POooTG3/Zu36oFJLiS5mXLgHfOIyx4/djow9y3zbentcnVZbdriSRIJhC5fOSY4CZST3FuOMcKepW+upDJMI+ukjgiJY/sYXkWPCgduCTVbRHeZ726OczG8mYjPEzSqmfnTZl6qTKKRnaykDkwx+fGtNpiL6l7fD0y34S0xO9y9Rk0+2jtWt7cRpDDbsgQxqy4UeyVbsOQMH9a8u1SGKe5l62SKMCRxEXOXkQOxwFzjbz44rqE169vLeQNFLG7sgZmfeCzZJEK8wOBPHuqK0ntrKCctp073kp3NcK1q3DiFVRKCQoGMD8zW201ny4sGPNjjrTcT4llWVxa7XmuzFLFbrmd5CZDgDgqJkDJ5DhUMmsXN5KTaW2nafCeEapaxyyleQLtJk5PbxHlVHXr03E8gMIjLujBAU9iONRGqERqEPac95Pfwz7eV1Psg5AzWimKs9e7t431HJ9msRFZ1106iKPVZAMao4buit4V+AqyLTU/tanfHP3UjUem2uTlv3TCyXEikY9iMtkA94XA+NQNqELDBe5Pjx/+Vbfbp8nm/HcR/3l2TWmpqD/AN4Xn8SIPliqEkmqRH27qcjOMgkf4Tn51g3Oq6fN1PU2C2nVqVcQPK/XMce25mc8fLvqKPUdpHVyyp4McqfAjJHwrXFK2jcxpux+o58dt823QrczmOcveSrIm1olKxkSZOCNxGQe3/rjFPNcCORpLiJto4bTBIxOM5BUZwP9Oyq6Srcxh1CiRTtlQDhnmHXwNGzIZSisGBByjcjwrltXlnUvreGyzxGP3sc9/Gu0/JVjlLRTyZ9oySMcAj2sA54YFXIrtWtUQ71kAEiBXZ488N26OUEDPPII5UyKCGFGQxlwckmQy5PDHMEcvKpVjtQFItnHAfVkcdnexqWmN9Fw4skUrGT5dTlv7xf7V+4cF/SpRqV6P7ZveqfpUW2y/uJh/wD2U+RU0BbD7k4//epH/pVr09HniPCZtXvEBZp+AxnMadpA7qe+pXksbo1zburAArHguwJ+yNgqrJFYSIyES+1gfWJA8cbR86SG306H2v6RJLxwzNsA7toD8+z/AO6zrya+08/PbiIy19mI5fKSG6niMbI5UowZT3EHIq8NXvu6Ln91uPxqpG1kq+1bq5yeMkzDt7kIqKe7jAMMVvbxseDyojdYoIwUVix59pxns4ZrClJtOqtvF8Xjw45yZI3pqJrWoE/s0RyMAiNZWAPmDj41YTXdSQ4aAZyBhhKDnuxzrnhedSMqMlQMcdqgeNWbfX3yqyIMDgJLaQrPHntXdwrsnBqOkvmo9Yra/wDUxxyujj16/OW+iEbNrFlZvZ9oAE5GOeKC+hXRaa5huIJ52aaVYHgZNzkklFkw3Hmawg+7ZhxIpIKSKG2uufrceXcQe71WDAa9z1RzduR1jbT9RRwyMYqYJtFpiW31WmGMNcmPXWf9Nk2Ogyf1dxcr+O2DD3mJz8qjbStMPFNQhz2CSK5Q/BCKokKePVIfFJE/Wm8R/Zzj8LE/I117l830Xjo6nHV3lm3dtnC/5wKYNGv1OYps/wDKuIzj0eoRMw+3OPxAnHqKGn/4o/iRf0qHRc+g65Gp/aXWAPvM3yzUDjWoue8j96NT65FQC6lH1ZY/cCPkaf8ATr3Hsy8vuyyD/wB1E6GfStSHApFnxhiz8qKUX+pn7c3/AJxoodGXupNxyaj3p95f5l/Wjcv3l/mH60YpNxpcmo8jvHqKdhj2UDtzdtGe4H1puHow3jRUgkP2hn51SmlXdK5zhQSM88AcqtpsDoZciMNl8HBIAzgE9p7Kgso9GvDM8iag1ukgCxiaKNnBG79owDHHgPWrAzrANNf2EWC2Z1LgZ+oOLZx2Yrpr6FLazL29uEl6xEUoGBUFXxgA47uynJBpiFUtLUwA4AC7WZj2ZY8fU1cudI1S4QJHPNEuckYifJHLiJM1Z15WtrV+7OnFS30sxt3kPtxyRljyOVYHjioHlcwyKs6gvdrIg3kFMK4LHu599dHJ0O1Hczdc5LHL/wBHJ3E+CuagfohfoeLc+X7G4BJ9wNILTNp5pYkkrltUbrlKybcASZ3PvRtyg8Ty509JZevs2Mynq7XEpMq4x+0O3OcdvKrZ6PuMj6VajBYHc0wOQcEY2VJHoFuMGW8RzzxG20erAmiI9HgW4jlaTrCkYjiVUdkyxBY5K8eHZV26itLSCSZEn3KyIMXEmAWJGTkYrTs/6HAII7m0igTcRuMQAzzZnIznzNZ2q6kt1ELZH66JXEgaQCOMuAVDBfrcATjNOWvmGyM2SsaradM1LqWW3jRycb5HPEjceCA/A1E8hAPtOPJmGfjTdh5dbCMYwCcYqKQEYG+E/hcGmojwk5LzO5n9SE7jlsE954nv7amAiigeRlBJ4gHPEngo4VAo3MqgjieOO6i8k9pIgfZUbmA7zyHpUYd+qsQST2k8TjtpBHI31VY+QzVy3gB9qQcOBx2e+rRuYogVVRw4YxUGQyupwykHxGKbWx9Jt5htlQbao3VsISGQ5jb6uOOKCxp1y0bqSx9nKt4xtw+HOt1ww5MfU8a5OFtsiE8icHxB4V09tJvtoiTll/ZN5qcZrmzx02+i9D4ia2nDPk193HieR5mmYbPDNPmyscrLzCMR501GLomQuSqE4Aznn2Vyvp/cjm5SgeefxUu0f9Gl4ilGe+sW3obtHd8acFXtA/691Ljx+NKMd49RRNwYWSNHkP2QSOPMk4A5VRUsSSTzyzMfUk1JeSqI4o1IJJLtjsA5VUkYrEqj60p4/hHHHyrtwV1G3yHrPETfLGKO1VeeZpWOA3VKTtBB9rH2mqNW7ueff8K04UhhXfIAScc+zypJfol0NoUJJ9hxjie4mt7wtLOl3ZLdS55nOD2HGN35Gprr6ULiYosoUuT7JIBz21iRM8MoP2lO0g99dVcixdIJYNQgmkaKLrYTlJVO0cFG3Bx28axiurbdU55tgjFPidsrN4eyb+bNLm97Ouq1Tq3acir12ojADTjwyaXr9R5lpSfEA/OrBxUbFuQz7qmhH118eZY/wIPyo626HMcPFRUbi5B4b8eCmhRcNjLEeYP6VBL19x2kelFKLeYj+sA9KKu10oAx/u/ClzH+56LTAV/u09D+tLlfuR/ymsWJ37LuT0X9KP2PcnvApvs/cj/lP60ez9yP+WgdiDuT3UoMH/Dpox2In8lO/hX+T/SgkijjkfbGELKpk9nnhBuPwqxoC74rkY5Sry/AKrxvJG6uiruGfsHBBGCDgciOFUylxaM8sLMsW76oZlOCeAPZwoOxRQkiHGNrqT7jU1/ELm8jmTLxdU4mKXUcbNIFHVLGuRhRj2u/ca5aK+d1G28IYjgjTbDnHI7jVU61fK2GY5BwfbJ4jhxqz1V0iW+tpHtEYkZWtpM9YGDCMIrQgK2Qr+0WPM5FaOjHVYb51uorgwz7RESWZYNsruOsLDicbRwI5cu/jRrtyMg8/Hac+q0q65OMnhx8APfwIqaGy0gYO33p7k+szmomNZf+98gZRQPAHHwNOGo5GRGpHaQx+RFZi1dn+i3f/Jb8q59UL8io7CW4YzWnPerLDNH1RBdCuSwPHgc8qylYDtIrGR0ekdHo9QhumlnQFHMK9U3sqeq6wSMxGDxwOOOGe2ufYbSVyDtJGRyOOGR4U+O5uYlkSOZ1WVNkgB4MvLiDUOfGoLEAA3ueQBB8uZqBP2kjO3axOPkKcz7ItoIy/D150kXAAd9BcGcYUqDglmc4WNRjMjY44Hx5DJqW1OkZcyxmUAE7pdxZscztUhR8fOq7RMbdDnBnbrCueaLwUZ9T/wDVJCsTSyIMR5hlXcQ4AJHDgONBYlisJpGSCP6O/AxsGbqmJHBXVicZ7wfMdtVY2OJLeUEAkrhuasKklwL9tpLQnqxuUf2e0LnjSXwUXG5WBDIuSORZRjPvoM9gVJHaDj0rVgmYRZVmGdrHHfjFZs3193fg1YhkUQjLAHljPHnWF43XTr4PJ7eaLL3XyEEdY2POkEjnPtNz44NVeuj+9ThPbccluzGOVcvJL6T4ym/vLIdu0t72NLn/AK3Gq30q1HZJ8KBe2w5RuT+LFTkn5E8fjjvK4qg9hPqalEYOAqnJ5cvXjWd9Pj7LfPmzHjUf0u6XcEDLuBBAXsPDHKr7UtVvU8ceT5XDzsq8gRGvLs8qCd0x7RGAo91V4RJuLHhsBb2hnj4Zp8LEkntZhn3111jljT5rLecl5vPlpKkZiklcguuFgUgEBsfXZTw8uylFutzYtdKR9IjLFkCopZFPE+xgHHZwzSQzGYCL6OCLaRwzo37R9xGxCOWMjn41YWeBZEto42VlMgZG+sF3YZmx38ceFZMGNMclH7WUbj3leGa0bTc0wC5PsscDj2VTFtNOAkSb2jd9w3Kp27gAfaNbun24tVkaTq2mkwOGGCIOSgkdvM1Ekm2YfYf+UU0mUc1cfwrWiGB+wp/hH6UH8A9FFZcyMzc//E5/uD8qOskB+tL/ADD9K0vZ7UX3t/8A6pMxj+zj98h/+VOYZ28nOTKf4/8ASgOB2N/MTV89TnPVxe+V/wD5Yph6nj7MI97n86bFUTsOxvX/AEoqwFgP93/5bn86KbGJsk/u4fTNLtftEA8wtVusf72PIAfIUdbJ/eN/NioLWH7Gg9yqPmKUC67MY/d6vFVesk7ZH/mJ/Ojcx7XP81EXQZxzkK+5APnTv6R2TD+ZP1qkBJ91z7mpdkv3G94/WguZmHOf/E1QXJkML5lDgFcjfnt7qjCSD7IHmVH50FGZWXKDII+ug8aKy2xmjIOByPLzHjTmAyeFMNAuTnHaOXfRn/XxqSNetKDjvyq8AOWeJ44+dTzWjw7/AGwzbiFUKSSveTyB76Cp391OVihyD4UhyOdORGkO1FJOCcDuFApmbw9Kj3Z7edSGCYc43H8JoW2uHGVRiM47MjzBoIifGkJqV4JUOGRgfIn4imsjgZKMB3kHFA0cedTKezwNQjgakBoLUs67kiIbbEqxrjuAq5bIlxlX37AF2ZAycEA9nfisuRHYs44glePiRVuCeKJPaydvsY57gxBbjQOmdEUoSoYynhGMMVH3u71qrIciPwyPSp7swySwpBkiNVTLZy3bnJ41XkypC8MqOPmeNBDJxK+VKjYUjOPKmsflSDPKkiYMCMN7Q7iT6ijMQ+wCfEmrlraoFLzpktjapJG0d5A7at/R7U/2Mf8A176gyOsQckT0/wBaOvI5KB5KK2DbWxBHURYII4c+Pjmq402EEESnAPEEDiO7NAxY1CxPNcGPrMABdmRniMk/pTj/ALvAz9KkY4OUyCTw4DgoFWxBZr/ZQeewH51KrRpjBUY+6gFNjAMkhGN3Dt4U6JsFfxCkmXZLMvYrtgkYyCcg0wE/HNFaaTxrLs3MNzD6uAOYPE+lWDdbLgKMM8UsryksHXayKMRsOOBWbHHvcyqyDC52scFjy9mrH7OCCXkbi4wO/q4wMZPieQ86qJ9Ndw9yy7gSFyQM/WJNaXWS98n+KsqyZo4mIOOsfd7lG0fnVrr3+/8AKoLeZT9mQ+v50Hf2pjzx+ZqmZ3P2jSGU8yT60FvdjsHwo3+HpVPrRR1o8aot9YaN57zVQy93xNJ1p8fdxoLgaiqoaT7rehoqDL3n7qe5Fpd8nf6Bf0qPNGaok6yX77euPlRvk++38xqPNGaCTJ7z6mkpmaXNA8Yp2RUeaM0DZY8kuv8AEPzqsRVouBzPKq8jBuSgeNBHypxkkxjcSO4nI9KbSggcx8aBQCxxxJ7AOdaFtH1Kkn67Yz+6O6q8MkQ5KFJ4Z7fWrAYVBY6w+NLvNVw3jS58aCfrDTJsyRSJnmvDzHEVFmlz40GdRmpZ4yrFh9Vjnh2GoaCzGwKlTnw44OO6opGBO1QQq5Ayck+JpgbFSBx2n4A1QqsyFWxx5DNNZiSxJyzEsx7yedIW58SfE86jJzmgDxzUkUpjYEAZHaQCfWoqONQa8U/WLx50/dWXCzg4yat7zQWd/lS7zVTeaNxPdQWjJSdZ41V3UuXI4BvQ0CXSdZiRfrAAMO0jsOPCqeamkd8lRwxzPbUOzxoHpIVPeO6pVLSkKBtXOWx3VDtXxqWNwnNQw7j/AKUFzfgAAgADAxSh2PLJ8hUXWnsVB3cM/OkMsh5sceHD5VRY/aHsI88Ck5c3Qe/PyqvuzzJPmc0pIxzoJ9yfeY/hA/Ok6xB9hj+Jv0qvuo3VBZ63uVB7sn40dc/3iPAcPlVbdRuoLHWN3n1oqAMKKCCjjRzoqg40o7aSigWik40UDqCeVNpCeFAxjmm0UUCYNGKWigQHjTxI47aZSigsq+QDmnbqrhgBS7x40E++k6wd4FQFifKmUFkypxBIwarOY85TPiOyjGeyjYe6gZS5NPCd9O2L2n0xQQ8TSipMJScOwUDcA0u091Lmjie2gVcg9lTK8f2mP8I/WoMUEUFnrLbvc/D5UvXwjlGp8WJPzqpS1Ba+kH7IjXyApDO5By59xqtRQOJJJNApvdSigceyikozQSBqXNRbqdQPzRmmUUDs0ZplLQOzRk03PgKXd4Cgd7VFN3t4UUCiimk0Zqh1BNMzQTQLmjNNzRnPLj5VApNITShZDyU/9edBjfhnA9/6UEdFP2d5owg7T7yKoZRT8xjkM0b+4D4UDcMeQNKFbtoLmkye/wBKB2zPMijYn3qZ76KB/wCzHjRuXsWmUUDt5pNzZ50UUBSkk9tJRQLmkopagTFFOIGMj0ppoCiikoFoopKBaKSloCgUUUC5ozSUUBTgfOm0ZoH586M+dMozQPz50Z86bmjNA7PnRnzpuaTNA/30U0UUDwrn7J9/CjY3aVHvz8qaZGPZ6mk3t348sUEnVjtf0H60u2IcznzOPlUOSeZPrSUE++EcgvuBPzo6/HIfIfKoKKCQysf+s03e3fTaKAyaKBTjQNopaMUCUUUUBRRR20BRTgM59abVBRRRUBRRRQFFFFA4GkNJRQFFFFAUd1FFA7bjmQPDmabQSaKAooooCiiigWkopaAooooCiiigKKKKAzRShHYZVWI5cAaKBKKKKBKWiigSloooEooooFooooCiiigKKKKBKO2iigeOR8qaaKKBO+gcqKKAoHIUUUC0UUUCUtFFAUlFFAtJRRQFLRRQFFFFAlLRRQFFFFAUUUUBRRRQFFFFBqab/Uy/84/5FooooP/Z
	";$I2="
                  https://th.bing.com/th/id/OIP.KNFMgfmUGV8Dg-vtszTARQHaEK?w=313&h=180&c=7&o=5&dpr=1.25&pid=1.7
	";$I3="
               https://th.bing.com/th/id/OIP.UasfsrxpA8IGIdYw6x_qagHaEL?w=293&h=180&c=7&o=5&dpr=1.25&pid=1.7
";$I4="
                 https://th.bing.com/th/id/OIP.25vw2TQM6sAYbFIwZq9poQHaHa?w=179&h=180&c=7&o=5&dpr=1.25&pid=1.7

	";$address="

 https://mahindrathar.com/#!thar-crde
	
	
	";$p='
	       <br>       About thar  <br>
	Mahindra THAR is one of the most powerful off roader SUVs in India equipped with a Soft Removable Top and this SUV also offers a true wind in the hair, off-road adventure experience and more. Thar Ride-On Day Break.<br> Its the trending vehicle in current indian roads.
 <br>
 <br>
      <br>            Features :- <br>
 <br> price :- 12 - 16 lakhs
<br>Fuel Type :- Petrol & Diesel
<br>Transmission :- Manual & Automatic
<br>Engine :- Diesel - 2184 cc / Petrol - 1997 cc
<br>Mileage :- 15.2 - 15.2 Kmpl
<br>Ground Clearance (Unladen) :- 226 mm
 <br>

     <br>
         Know More.............. <br>
<br>Engine:- 1997 - 2184 CC
<br>Fuel Tank Capacity :- 57 Liters
<br>Ground Clearance :- 226 mm
<br>Mileage	:- 15.2 Kmpl
<br>Dimensions(L*W*H) :- 3985*1855*1844 mm^3
<br>Full Specifications Of Mahindra Thar :- Engine and Transmission
<br>Engine Type :- mStallion 150 TGDi Engine
<br>Engine Displacement :- 1997 cc
<br>Fuel Type :- Petrol
<br>Max Power :- 150bhp@5000rpm
<br>Max Torque :- 300nm@1250-3000rpm
<br>Emission Norm Compliance :- BS VI
<br>No Of Cylinders :- 4
<br>Transmission :- Manual
<br>Gear Box :- 6 Speed
<br>Drive Type :- 4X4
<br>Suspension Front :- Independent Double Wishbone Front Suspension with Coil Over Damper & Stabiliser Bar
<br>Suspension Rear :- Multilink Solid Rear Axle with Coil Over Damper & Stabiliser Bar
<br>Brakes Front :- Disc
<br>Brakes Rear :- Drum


	
	';
pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}




else if( $type=== "Jeep Wrangler" ){
	
	$I1="
https://th.bing.com/th/id/OIP.ht-2pGCPFosIZ4pvIdJz4gHaE8?w=281&h=183&c=7&o=5&dpr=1.25&pid=1.7	
	";$I2="
https://th.bing.com/th/id/OIP.gXJ8kOo2xHu2ziyg33kXHwHaE8?w=281&h=183&c=7&o=5&dpr=1.25&pid=1.7
";$I3="
https://th.bing.com/th/id/OIP.1k-jd1rjqreLOcF46cW_rwHaE8?w=300&h=200&c=7&o=5&dpr=1.25&pid=1.7
";$I4="
https://th.bing.com/th/id/OIP.ThkfGVpF63WGdu6qeDZxRwHaFj?w=238&h=180&c=7&o=5&dpr=1.25&pid=1.7";$address="

  https://www.jeep-india.com/wrangler-jl.html	
	
	";$p='
	                                                                       
<br>
<br>                                                               About wrangler:-

<br>The Jeep Wrangler is a series of compact and mid-size four-wheel drive off-road SUVs, manufactured by Jeep since 1986, and currently in its fourth generation.
<br>   <br>                                                            Features :-

<br>price :- 53 lakh
<br>Fuel Type :- Petrol Only
<br>Transmission :- Automatic Only
<br>Engine :- 1998 cc
<br>Mileage :- 12.1 Kmpl
<br>Ground Clearance (Unladen) :- 217 mm


<br>  
<br>
<br>
<br>
<br>                                        

<br>                                             Know more.......

<br>Engine Type ;- Petrol Engine
<br>Battery Capacity :- 660CCA
<br>Engine Displacement :- 1998 cc
<br>Fuel Type :- Petrol
<br>Max Power :- 268bhp@5250rpm
<br>Max Torque ;- 400nm@3000rpm
<br>Emission Norm Compliance ;- BS VI
<br>No Of Cylinders :- 4
<br>Transmission :- Automatic
<br>Gear Box :- 8 Speed
<br>Drive Type :- 4WD
<br>Paddle Shift ;- Not Available in Wrangler
<br>Suspension Front :- Independent double wishbone
<br>Suspension Rear :- heavy duty with gas shocks
<br>Brakes Front :- Ventilated Disc
<br>Brakes Rear :- Ventilated Disc
<br>Steering Type :- Power
<br>Tyre Size :- 255/70 R18 113T
<br>Alloy Wheel Size :- 18
<br>Wheel Size :- 18
<br>Tyre Type :- Tubeless Tyres All Terrai
<br>Length*Width*Height :- 4882*1894*1848 mm^3
<br>Wheelbase :- 3008 mm
<br>Ground Clearance (Unladen) :- 214 mm
	
	';
	
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

}


else if( $type=== "Suzuki Gypsy" ){
	
	$I1="https://th.bing.com/th/id/OIP.iMyhfahi_6ium_Om13LIRgHaEU?w=300&h=180&c=7&o=5&dpr=1.25&pid=1.7
";$I2="
https://th.bing.com/th/id/OIP.WDn3LF_jzvP-095danTXsAHaE9?w=269&h=180&c=7&o=5&dpr=1.25&pid=1.7";$I3="https://th.bing.com/th/id/OIP.00hsyunZz82JSrE0iCCT0AHaEo?w=276&h=180&c=7&o=5&dpr=1.25&pid=1.7
";$I4="
data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADhASoDASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAABAECAwUGAAf/xABGEAACAgAEBAMFBQUFBgYDAQABAgMRAAQSIQUTMUEiUWEGMnGBkRQjQqGxUmJywdEVM4Lh8ENzkrKz8RYkNFN0omOT0oT/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EACQRAQEAAgICAgICAwAAAAAAAAABAhEhMQMSQVEEEyKhUmHw/9oADAMBAAIRAxEAPwAFhalCFAJ8vLy6YHKEB1sEVVAtt8L2wssjxi0iJ6hgGVq+H/bEf2uMjXIr30ojYfKsAx0oKAtEKBqVSBsPjgRg2qQ628YAcabLVuDZwY+byTAgvps7Adr61/3wO+g1o6H3mboF3sEVvgBHLUyyAyIihUIC3RNkb1jspKisTAvLWGuYCoAMhvYEEnp1xMyeZXpsOhrDFMItWXSCwZiBvVYAeeQmdWfcN4ba9mA2rHDc6l7dSLw/MRrIrBDuCsiHUNip1C8JTrErlQW76D9CSe2AbnosuZYA4Bbl6igO4/Epb86w2KV9dCwANypob4BLMksjTNZdtRbtq6Af0wVHNAo1B1uiGF3v8LwB7ZXhmYjmeOMQ50JrEiu7GUgWQwbbev8AXcGMgaS7aRp3UVqrzGHfbIwyG63BtQTgXQW1Nrc6ZGaPXta2av5YAmLNykyITq02LbrqvYj+eOcsxDMTqJ2J3oYHQgMzEUWoefQbE3iXWRsACSOtflgHqb96wo8iLseeDgiyJFIGa6BUgC9ROk6vTFeCe9b7dBYPTBuUpXK2W1IQaJoMfFVfLAHjOZlDUjEldJBKkOhHkw3/AFwkuYm+2yMznlyZfLOdh45kLDU61YIFD1x0+nZ1D7roZQDIW8iFX/X0xWtmMzz7cSFEURWR7hL2AQd8Bay8Q4kqhYKfVSF25YEJ/bskE/D/ALYjllkaKRrJEcerxklWZRuWI3s1fx+OAMzBNIkLNmIoFaWl1OjkPRrVpugR0/OsKHny9ZefOx6HFtJFodHDgLpJutzXw+d4ArLSKVV8xl80pdCIZdcLoFOxUJ4Tg+AjUHjLNzFBZqK7igLGK3K5yOB0cOjAbSRzMhRh0JU3YOCznshNJI0c0MD04K6nCvt4S1EKPz+WAMlbMMAmiNlBveShXwr+eFjhlUWJj4qW6oUOhIG2Aos+kiqUC9lIN+FiPMgYkh4lENZYuhC3GoAYM3St66/DAWShxsACdrboCfMYQxBSWNUxBJU+In4DECZ5ZAxZNJtlqTSp8I3JrevLbEA4jljIFUiyxUjSQFodSTv/ANx54CxKyj3dO9+JjRUVewwhj8QloF6ChgLIHkD5YAXiOsPSOAFtwunWqjcnwHV8fLC/bYMzp+8kQR6hXYg1ZvY4mVsnDp48ccstZ3UFBGs3rstqBXoK69MdpdOYW8SWaFVXY3/PEKLl5OmYIBCr0ABC6TV+ex+uJPswreeo1UFt9moHc3t+WOcyz/xev9H4/c8v9U2SGIlTy21Oy6fEyrfp54a0XMpXZmBK+GSMmQD3Q5ZCfDtW4+eBp452gdEdGZlV47erEZPiBI6j/RwyFcz/AOZleRWV2VHrUzaRsBRC1V+f+fpxw34r5LdX6eG+s808ePOPHOv+6FIqQFHXwqoIWnjeNT0JLbD6jy74hkkzLcsw5iLSDp+9QOWY9dZG1Hp2w12JidNIKkK7MFGpSu9eEgk9vn3wxkjhiSZnLR/cs7PFSBl1oAQdq3386HnjPikzw3ndVr8qY+Ly3Hxfyx+08jiO2+8jjdX5jQ6OWL/C3Vh6Xjldwh+05kPGUDDmKooVVXQY18MCIiFZBFm4mTSpBIX7wI/MYEg9Qb/IV2wmXV5XKJJNUJJVnuFy+lQCWY1Q7D19cdLh45OMv6eeZZ3vEVE2WzDs/MjfkAtq0OiKq+K3IN/Df5YdzIzuDBR3FrODXrceBXfNqsqSKTqlLuIyERZT/tHKbX07d8QNErMzHNAliSSS1m997OOLqLTMpzCJF02NjRr61hXaJqBI322rf6Y4wEkjUa7gqNR+BwzlFRpFtR31bkfG8A37NC3iI3ParB7bnHJAyWugqoO3iFfDbEiqti0Zd+21ncYevOVmKszKQaUEWPWm/rgIGQEXqquzAf0vDWy4YXfYbf5jBQcNXg3A3LUtV6HfEhXw7gMvUaaB374CqfLjcgDzFgCz5UcJRjBtfCAQwKkddsWTIpIt2rY0QQQD598RmKMmla633FA9qs4CobJ5eQuoc03WM7EV0oj8sIcrAiltKIiLbNSqAB1J74sZYaIKqy0btarbcEDD4MguaaRMxEHhUKWXm8uOTRUmqWQDZAB4/p16BSxSwZiQZeAaz4i2wAVR+Ik9sFnI5jfTPl0YEaWIdxt5rpqsa+LKcCXLRwzZKLL5c+OPM5BtUAJvxGRRqr+IV64EzvAM/EhmyLLncvWocrSJgvnp6H5HAZj+zfPNINhsIZGo1vVsNsd/Z8Y65tu3TLrf/wBpMEuzIZlalaH+8VjTAg0RXW8DtmVBAAJY9ugA/aYtsBgO+wRuAi5vMB2pVJih0A9BsPFXzwfNwLKZKFp837RyJHGLIy2RAdj5IHkBvHJks4zIjxyIX6EaSSD+ydx+WJF4VmQz65ctHGtA/anCylLujYA27b4APJRcAzshQcU9o6UE8x0y0KX3UUzb/PBGb4X7NQxyMuZ4pmJ9NIJc1CFLdi4jW6+eHQ5XhuViVJ+MZVm1ySPyld/E7FjWg+uGNJ7PLRPEM03S1hyqBTXkZTgAlaNBpWHK12BghJ+rKThRKg3EOVB9Mtlwf+TBY4p7NQm+XnJjpK1KcsikeoVcQnjfs2pJj4a7N7tNmiV+ijAM50feLLD/APzwf/ziKWddD6MtlpXWPmhDFAnhvTquga9bxOfaDh0QOnguXQEA/e847efiXDf/ABLl3csnCMi0jRiO+Q7uY7sLfWsAenBoc9lzLw3OxBpYwGglNqhKiwNPiBHToRgGfhPGcpDzJ0ZES0tCsoStg+pRWk/HBCe0XEZNEsfB4nAopIuUmI6bFWv+eJx7Tcc6HgzG9toZh12rc1gA0jipDJA6TBUjJcuNlNguWseZJGEn8BQcwuy6wvJDHV08bki+wG/88EZni+bSMGfgDxLKyxp91IIpH3pQiNpJ+AGCpcvwzN5WbM8PGcyrZeHLLnuHzubjSRiBPFIxLlQ3h3Y/IjcK6CWCGPMOqzqczFKjNIoKaSCusVTACzYrcHrtiSDZWSSHTrRXQnd3FUG9QcIMmZk8BAkiiIDRAW2+1xswJrvufngomfL5WWGY0s8aSxcxyrxyp1ZXCkeXasBHAzsmaMcTukJ0mSE1GAp0EMG7dcSiTM+JkjQohVCCzLZvpWBI5po2y0s0IjbMM0KzxvHLCWJ3DR9B0voDhJGy4lkjfMKxBCnQfu9XcB1a/KvTr6BEBn2zIaRJGdX+7J0uyoGJJC99v1xKk/EpjBp1AKIhIvhDWH1EVYayNj+uJHzMMugzc1ZYSg1xyMQGulckURfz777YdHHFK6RRMssrxmVV5mmT7pgSVL7knt1usBBJNxc6FOoCIsCrmIEkMTqpCG90it8Gw5qEwNBnckk6AsEeR5FarJs0SL8/hivmZV5TTO5k8YakUuUolbA3vzwMZcwhjYqxMkeqIvRKr+yF8j1N4C3km4f7yZfTmZLCuZAEFJWq6rt3vywHJJMdQR4NTnQRIxqFybJ1VX54EikWRuWU0Mx1GWvHqH4RX5VgpstIscDDSYXW5C8qArubKrux+nfARETmKW5SDGSQIyWBIoN1AY+Q+uEDwAAEvY2NIDv8SMDmmLyatJDBRYpgBt54JGWWhdXQu5n/AJbYC6aOQBvuwQepTrt88II9tIEhBslXY2TVdRvhzyxoCry6BYGpiqtfphFeQElZEaOwSFCuNuvj2OA7kk76Cp2BGq/zxHJAW2YsFrfTJpI38xiTnKoUodSGyQTsBde9dj6YRszFSlnRRRYamG4HbY74BpMwABB8PTSQ1/xDCAtuQvyPn6DEkRSUB4pIihJrS41WdrZKv8scziNiGCBg2kAsALBqtR2wDG1bkrVLsaJ/TDNLULFVV6Nh0wTCea8qR6WkRjaXWogAkoTsR6g1hqyEkiWCaGQagUeN1oWR1PhOAgMbORumq13JoEX5L3wvEvBlcrw6MnXn5GM1Ek/ZMuQzgnrTvpX4KcFRIrMmi2YsAgI3LsdKjp54BVvtedz2bjNwxkZLKMDYMGXJTV/ibUx+OAXL5nOZEjkTAIAoaM0EY9NozsMW+S4nlzJ91IchmWJJQ2cnMe5KEiie9Ff8XTAFxC9epW2pvw/PfDjEHRQ0etSQARrb5ggYDRSfYs4VXPZQJnHVo4ZYVWRZTVkI+mvWiAaHTDc1xHJcAyeVhynDMo0+ZdosvEkaKzkKXeSSRgWoDr1613wnDI/s2Sy/MZ1oZifxsS0cYJIG++wBPzxmc7no+PZ+ObJDNyZbL5IRkpl2LLJmHZ3DgXWwUDffACTf+JeIvmXgkyuXy6m+TlJXEcajukQOoD54rn4Zm9RE+d3JALLGzCz2Jc3i9hyOagGtMtmjQIpYW10asVY64XMpNl0WXNDlR0CGzFDvVbntgKJOFwbcyXMuBYsHSrHsb0jCtwvJqoCo7MV8JkckX5sCar5YLbinDlvlO0xBoCCNmIo+W2F+0zOisnD+IFSbsZSUgfEjbADrkMuBGDDlgwXS/LhU627HfBMacto2ji0sh8LxoARYo1Qx0eYhzSzcoECAXIJpEgK1d+Bzqr5YH+35NSwfMD0osyn0tdsBaRkavE76j4TzCzHSdqpu3lgJHA4pxGQMCIcnkkJWwOpc/piJs1EQJI5EKAjxl00A+RF/rWII59a8bzxXQmYRlhNEK6wwOtqGN1Z88BbZSTl5LhyE1pyeWsUB1jU9ScECVCRpdiCLHSifngELEgVUIJVFTxDUPAAoGwwQqyGmKaRt/eGgT18O2AmlzKfZswqyUVVJlUmlJhYSir2vbEoly+UzEWczEerLsmYyedESajLlsympfBYF6lWunvemA2Y1oIRg3v8AYANYu8TIpzPDxHdvLlAo9ZYxt+ajAJEMrKI5MpmYI2ljjlgSV1BIYWoYyNdnDEzMsiB54ZCYJCyiZ3iVS5CNqrVQ9aPQfIDhBWTLMrLE32aaSJeZFG5VG+8QAsCeh/LFsvuhjoUb2xjX6YCKCTK5fVEYnYWxPK+85bEE2QRqKsbo0fhiA5dHh+70aYwoJkk0rGBYIe63Pb/PBrPYXWFcKbHhar/wkHFfnYzLu6RhS2pW1SKo7Uw1V8LHzwDRAFcJoiEbC9BclCwqgWLbj4YlhkXJLHlsyiQySu+h1LLbEBxpZrI/dN1t9IzzFXRKwUIAqNZZVAFagw6f6+OB3SRRlyWWSNdeklldCSQw0qwqz8/6guayuaKyyQg5qQtplIslCGvbyHY9v0wIRmWZudBKrLauVBOk9OqA38sSqwaN48tJmIyxCjwilF6j47FHsOuHyRsHjV5HVYk1ppk3mbbxiugG4+WAjBeCMSOqIdIKtR5leVdfLbCrmopVHLXSzUHLIeYD0+QGHhZZ5IlAbSmuQtNuCuw33BPbbHFokmKrlz4QTLmHb7tmA6mMdvL88ApykzGVGdER6ZnG7uxHvUPpZw/ksNtb7be6n9cBQ5/SXjkAIJYo1VpUn02w5pn1Nu53O5N3v54C+ljWRipVTsdXiJsUMRhBEjxxC20qEEYsUPJRgsqrbMoKk3deXSsRSAbaQlbACqrtQr+uACPMmUadUeoBDoRAVUjcm7Gry/ywvKWbVC7CSOtKGWGJZlWgLDJW97jfBJUj3mW2BFE0D6FrxGSSpAiTmKZAVZi6gL0oqKN4AeOLKxGJRJokDDd23IO1DT2xZQ5bNZiTkQSmSySVpDENAG5dhddMRQiSR8vAkSrNM0aAuSFXV0ZgQDQ+J6Y2WU4AMirZlM7PmNSBXiA+6jsgl4g5L7V0vofTEFAPZPMStzH+yoT4h45WAJNmtI+fXBcXsxygf/MKDQFRxuVNfxv1xoo5xEyJMuuIgFWXrXmpxYhOG8qTMcwmOKOWZhYJIjUyEV17YuNl5Zytjzji2jhq55cuztLBEsUTMQS2czFQR0FFbWT/AIMR5LMey+T4Tk1iz3CvtggiscQbNABiPEZEhUtt5YH41mp4eHR8RAPNzHFI83CXU7iCOWVDRo1dEfHGMTOzSTyyyFdc8jySUq0WY6iRqBwnLdmm0fivDCx1+1GSiTf7rhfBcwQt9Kkkp/zwKsnso8yE8Y9qM5mJZFjj5eWSJdch0jTzGoddsZz+0dLlAhHiq9QG/wAFUYuPZ/mZvjXDoyPBG0ubk8TnwwRs471109sLwkbHjUi5LgXFirH7vKfY4izEtcpXLDxHe6JxjuDcX4nweJo8rlMtNDmZOdIZjpcsg5QAbUDW3Su+NH7ZS6OE5GAEXmuIQ6x5pAjSN+ZGMbCWfN5SEHwgRavCL2TmsLq8SXc2tmmsPtXxcrR4fwbLtQNZvOThj6hVxXy8azs8vPmPsssoULzBkZ85KFHQBpVPT44os9LzMzKeynQP8O2BbxZzNs3ho5eP8eUAwcUiVBsfs3Dctl9PwsE/piuk9ofaGRijcV4gx33E3LF/CIAVgbLxJmhmcswt5cvMcsbqszEvOT6gMv8AixVh01Ib2I3PoRig3M5jOTsr5mWSZlrW87s7Ud+rknEoyczrMUcAxuVVdIUPSg9e3XEOfY/bM8gVyqZiRDQtdKNS79OlVh0eanDEhiLCFgOhKjSCcWWfKXfwZHJFGub5sR5yEKj3pZDdnmJ7reVEYJGelly8GhmQRhl0A2qsTR0E+Kj5dumI83y5VWaNTzJLGZR28FrQBjPWiOx6Eeu0CFViVK0sCTV31N9TiKL+254imzWYPxkf+uIzIzElmJY92JJ+pxDqUVZ38u+H6ZQAeXLTFQLRheo0uxF79sXRtfLnNUEDIiGbRGWd20hGvS1k+v64HHG3yuYykRjQRpOz5grZK8yUtS71S2D3wZwnKSpE8edy4jOp3RZxEG5ZA1dbN9a3HXFJxeKKTjWaiTaKoYtq2qFL93bGVGRuOH8R4vlSCysxKAGto3NHcdwwxbq8bXocFtYUItanPXw66GKESSDimSbMbSGNMpmTV2whMSt8GpWHxxcR5aHQ2ov96dRpVpNJ2I1A/LfvgDCYwKqUht1IUaR8QcRkopGoFlH7puj1B7/liXVHpK+JlJRktqdAKtVfpR9RhixKQpY6tyQHb7wDUfeZe/lgBpY4dgkgQiygXYkHbY7fMViFlOygqSzHmLWkKOzHVg6ZFZQJG5gDBhzHdmQj9i+nr/liJmRIzpXWSDZJDHV8xeABlWWJN2Surb0fkSd8MKLPIqsKjGW0mawvLkL2u7bG/wDXXDpOVLoMkaJTDSyM6sTW4LA98TZUcNWJsvIrMr+Gp1EiLvfcg/HAB5v7VFJEypJt4dcLddVAKKP64VOG5oKWfMQkUajOtmNm9Tv59umLiOCKMrCpRjo3jiS2ZegKDYV6Wfj5qwpSEQxSK4aN5omiTT0ClE7df8sBSxZOFwCJYyxPhSaotSqOpJ+ffEvKT9iQ+qRZUqf4TzunlhzZOwyq0MuqTWGjaUuCCKRgwB3/ANHCGDiC2oglAXwgKhAFbbYC31kM5IcAeGiDWrc2Gvp8sN54ZWBB10DuARZ6Fgaw8Pv4bBvbwkXfUi8RSuFDNMPAARqW9XoK64BFZCg8Tlt1dhRJYD3j0wsihwrxaLK7Fi9jvvpwxZ4WSNvC2pRpVywLBR5t3w6KQMVDLFG2llPLcsSOoN6QPK8ARlYJcxLHli6xNOrxrIni0O0bDX4zqO++Nhwf7dkcjw/L5qZJM1HCI5iGLCVlJ3UkAnau2KL2fgimzaz5mZUjy7LHGsrRxNPmGU+BLbehuQB3GNzIkMkJjZA0Zux0NjuCNwfI44Zc5cOm9Y6qqzkMWZy+YENAuj6ktxoZh7ymMhq7mjY6j1qocxmoY3heVgXhWKR2IYsSKNsoA38wB1+WLMxzgZimuXKaW1qdLSQuSElod7BVvUX+LFRzoc20lDk5pdJngYhSSTVqfdv8j6HrZeU+Aec4fDmUWHMo1oS0E0ZqSF+7RN+oIo9xjKcR9mijcyIxxS2BHIBoyeaJ7MW2ikPkTpPYr32waSNnWUEmyGVtumw+eJNCMr0A8bDS6OARR/C6nYjHSXTNm3kE0TQTyR5iOSLMRHTJG8ZV0b95WONZ7DxCXOcVzOpjyMpDl11BR4sxKCar0XFzxTgOVzsVaHdI10xGPSc5lVu6hZz44/3GO3Yi7wvsrwxuG5fPhpIpefnlaOWEnTJDDFsSrU6myQVIBFdxuWV44MewHtzJqzPA8upO0GczB9DI6xA//XGSGaSDiBn0+DmyqptrC20Y29Nu2NJ7UHne02Rh/DFleGxkdf7yfmn9cZ/Itl0lJzGpMw9PE4YaohJbkgVsxsfD57JxiuXZjJmCVaSKRTO7CPmKU1t1oa6xOOH58gnREKBOlp4tR2ugqkn4YkzQ4llNciStLlyb5pVGK+j9frdYF/tTiHaYg/upGP0XGptirDh3CuOzyxy5PJvLLC6yJDrEOYZkphpjlG+M9Ks8ckqSo0ciO6yRuhRo3BIZSrbgjpWLAcT4nqVxm8yrKbUrK60f8JGI+LZzMcRnhz2YbXmZoVjzMpHimkh+7EjV3K6bPpi8kdPm3khgYID4RFIxY7OuwFDzHT/LAqOSw7dhQvphkbul0Ayt4XVgSrDyOHhUDK6Npog6ZL2/xDbDYc8s2tUQtfhAFCyT6YNi+yxVz4zNL1JZgI1Pkqir+ZxFUYbniiQulK8/PEJJN2cBZw5vJZbxQifVZNs6gj0UgE1hsnEkeVZ+QrTKoVJJXZnVR0AIo/DFZ88deKjTcH4jmc9m54MxmdK/ZjJAssXNiDRlRpYgiUWDsQT03DdBVZgznik0kqKryZuVnCOHCNyx4Cw8tsB5XNS5SeOaLTrW1phYKnqCMTQs80sMu2rMZ7OSabA6qhoX86xFX2eSF5shLpBliy6U2x3WRmWwdtvXB8GeyOYAjzsS5aWqXM5WMco/72FenxX6Yq5yecP3Y4x8jZw9a2vrWxxlVrmMrnYYmmjEcmWsaMxHIjwuK7VvfoRhsYYr493oBwGQiz0I04Fy2ZzeTcyZWVkJoOuzRyDykjPhP0xZRZrheZIEyrkZm/EgLZN27mq1r+Y9cNgWVHAW90BoknTX12/PEbQyJY5qPVikIYr6E+eLGSDMQm5UXQx1RvHvFIvQMrqSpvDG0nSSoB3Pl1+GKKkwtfunqSdNFfLz/lhRGtC0IJbYkDf64seWCoU0xBtS+nUBv1cDUfmccYx+zew/EdvheAEuRdOqmXpRABUehxOs+0VSlgATyjrqPteph3+OO0BQVJZgO0m4Au6GGgMhYCJmV7BZWA0keasDf1wDWKyMpFhx7pKKavsrVeH8zMf+6f8A9g//AJxG0LEG6Kkbr0PzGGb9rA7DxbYCH+0cqAQrzGiPfiYA+bKLJ+uJhxHhtqv2leYSFWPQ/ivo2o9PnihEmhwCQVY7EUevaxhX5TMrEDXuBsPEOtfHywGhMeWk3pGRhQIa9W2x2xE0TI6GKRAxuwWJ2FfhB1ViLhrkxMsemlJIJU1R3FG68+2CHaTwvACxRrYx6QevrZvBYos/mhNk0MhQHJ5qeBkXQGaVzeqjvR09e1Vjeew3tNmM7DNwniJYzLGpyU0x+8miUWAxO5ZfPuD+7ZwcMXDMvPJnuKNNoM0hiy8IAzEjajr3bwgb9a+GLiH2g9kEfKy5bhOeyGay0iywz/azOhZVEdOjAbEWvzOOGX+o6dvQs1O2WzWRzFkKszZLNDs0GbqLxfBgn1xREI2d4mCqk5bM8uJ63CsWBAPrWLDNPHn8o/JcFM5li8Dg3ZkQPGwPoaPywKiJIgz6sK4kuWzGjYaG0AuPqTjeXxkzj8xKJEcBJr2oRyDdk9GHdcdplhYXtYtWXdWXzB8sQHE0UukaHGqImypNEHzU9jib2Co4zIpdFrSQCB0vr4e+OFCQCgCRI7UKskqCT64q83HxvLZ3LZ/hsqT5U8iDMZdjp0x6/G5B2NA2dwdtrGwj4jxxchxHJpPHqy0uQV5XQfeIzTPTUOoob4zVjNcaZW9r8yHICxnIIxJqhHlRKd/ljPqUzUmblCiPm6KEY0hVIvoNuwxdZqSHOe1fFJYXWWKVsyYnXdXCcNlArFBkT/eD92L/AJcdPhm9jsrnczk5I43t0Y6RsWVgdqIo/p/XBUvDMlxANLw0pBmKBfKyMFicnvE5NKT2B2PYjAL+657hSR8cRZd5YQroRpKM1b2jaTRSgdr6jocWVLA8qTQySQzRvHLGdMkcilXU+RBwjsOSjG/BKy/KRb/ljQw5vIcTgjg4mhYRjRDm46WfLmuhPl6Gx5Yq+KcJzvD49ZAmyUjqYs3FZjPUAOPwtv0P1ON72z0qbu6BFm8Sw05VW90e8b3ryGIcSx7A+pxFESuGNDYAUAMQ468Jio7CHC4TAJdG8F5EFp+HjynlbpfuoW/lgMnBmTZVlyBBXUZJyNbUlGMiyR88ILucg5iSuwjBr0QdMPQ9jiun4jAZi0UMls6hmZtnAGksEI27VvgzLzRzKHQmroggggj0OJVgoX2w8AN5dcRr2374kB6X64wqbL5vN5QMInuJj95BINcEn8UZ2+YrFlHPw7Ok6WXJZlv9nKSco5/cc7r8/rin6DCbHptscXYu5Mu8LKs0eluqlgQGvurDY/XEXLFk7qL23u/LrgHL57N5UBFYvFR+5ktoz8j0+IwXBnYM2rvEpQo6rJGWsqWGpSCex3HpX1stODyrbXRobEda9QdsQGMBrVCpJA60tdCausE6h1DWve+wxwZOg267YqINC7lx6igQw2o4UOlDZ+n7OJ3Ar4Dv1+o3xHy4jvzPzwGReNW1LfiG/QX9RhjqShtiNOkhjVX5msSyCirDqD8vLCSAHWNPVSDgCuF5jkzKr7CVuU4rYSXsfh/XGhHMVqRIipOosLvr0AAr88ZKE6o7PvpSt52vQ4v8pK2YihdZJUkCtGxjkKix+IiiMBkc7NJnM7OxYkF2Ck9Qik4bqijFGGNx03B1ntswN/DC5dS0k53sCzfXck4ICunOZR4l02R7wAF2uM1qPQOAfa4OEZOLMKUbLu6whmVm5DHmoG09xbD5YOyCpLFmIQNTcNzeejKrWpYJ3TMxkA71TVse2Mn7NcRmkafIvK8ivA02WD+JtcJLOUI7EX9MaThk7JxLi8JJHPyWSz8YsqRJEWyzspG4NBcYvVaghyNRq6s1fWvXHA4Wfdi9lgzE6j1JO5DeuIgd8SU0NhdlNiq7g9CPIjAXE+Bw8WV8zl2EWZiAijBZmQxR2NLiul3RA2732njasFZV2VIWUkMAGBGxBO+M26XTG5Tg+ay03DZPsEkcsJ4i/EJaBUrJlpgjcwEqQPQ4yuVjIGqMhvCDLHX3qUAdVdx8OmPaTBDMix8tEYBiqJQicNYPLHu79xWMBxr2Wkyk0mb4YrsiS65crG3jjrcnL0bsXuvUdr7dpZlOHO7l5Z2Qjluw3AUm/lgfLm4Y/gf1wdnFyr5WTMxuFDnlAgVqka/DMu1HY7/UdyFl45I1khlVkkjY6lYURe9/DDoczCLXIvhkK6AQoINke8DtXn1xYcP4tmMqTFpBSTwS5WbxwzKeyarHyP8AliuzPhQn1AxzKrqAwsdvMX5YC6l4PwnPqcxwnSJt2lyMjkOK68i/0v8AoaDMRrE4UDSCvTuCCQbxOs8sUsZDHwlQjC9VAVuSbv5/5GcfZJv7LzaoQc1lgZ3ApHzEZ5UhHayV1H+LG2dKbHYTCXgJI+XzE5gYx6vGE2Yj0xeQZXhkygwxROo/atiP4g2+M/eJYpnjYSROUcdx+hvCUsaVchlB0y0H/wCtP54mWKFdgigDsFUAfQYDyXF4ZNMWbAR9gJR7p/iHbFoUsWKKndWBBBHyxrtnekL5HI5sIsqkMpDJImzqQdviPTA8mSzWSVRIBJBdLNGDp9A3dT/q8GDUpsfzwVFmWGxqiKN2QR5EdMZ0qqU0L6qAST+NfUjD0dWVWUhlI2KkEH4YIzMOSBDQsYmJp4kFx0e62dj6YFTM5TI61ysSmZq1uetj9o/yFYnrvo9hKZTPS1ysvM1gV4dIN9KL0MT/ANk8aIJ+wT1XYxn9GxWPxPiEhGrMSaaOyMVFHtY3/PEPPkbdgGNjdyW6fHGv1nusJYczBQngmi2r72N0F9OpFfnityGY5fEJIQQEnkkjJIvZNUi/p+eDMvnJIWUqlqK1Kkkkere9wpr8sO+y8HzE2XzEbvk8yspeWN1DZaXUGUlXSiDuCfDieul3tYXQ2IPofI/C8KC3UKenb0wzkmMC3AJUMpj91r72eoxG5KEkqTubK3/2xmXbVmkxc3e/kNqw/nD93/gX+mIhIGAAIO1b7Hr3GE0/H/ixUZ5we/8AUVhAQW3r3Oo87w7Y9Af5YjJCg777k1+mASMANKQANwp8sHcNkMcjAkCNmU217Eb7AEYBWu1EHy9fhhdWiRD1AING6I64CCOMQ8UzeXZgQzzKDVXvrUj5HFhBBH9oUPQjnhKWd6kjNnb4YA4haTZPNxrTFVVjp0guhsGwSNxsfhi1TTmIo5o2KqzKySD/AGGYHQN5X/rru0u9KnPTZubNtLGrQM1pHyrjbSNQARUqlI2AG1bDFjwfiue4TmoMxnAczFJl9Ds0glZstKQ2lJgWA0kXXY2D1INl/aDyouRm4DlU4izgRZ9uY4vYBoYSNOvfYg1v0Bxn+IZpE4nxKNlVoJJyZVj2AlGzPHfQ3eOXd9Wtcbekc3LzQx5vJyCbKTAAE7EGr5coB2Yf9ie8Rr3lsrtd9VPk38jjDcM4rmuDy64yJ8lmBUkbXy5UHp2Yfl8/Fs4p8vPEmcyT68u/hYNWqNj/ALOYfoe/x6T10S7EBqVvRW/TB0JoKPIAfQYrjRR2S6qmXqVJNfTBcT774xW1rGwqmFrd0DRB81PniZ1jkWpNPjqptPvEbASgb36/ywJGbwSuoDYXexB3DehGOcuqutsh7R+y8Gc58mWYQZ4hZnAbwTqLUNKq/MBwPj+7nJEybI8OYhnys+TVVeFKM8CAVzYA5plHUre4siju3qBrSQylo1u63lhHmpP4fP8A0cUfF/Z/IZyGMNSM7N9kzEJGrmNZ0xFu/mh8tvT1Y5TLtxuNnTzPiWVzOViiElSRM1Q5iPUYpgo/e8QYfiUgEfmUTdVPoMWWey/E8txDh2X4qIJMrvAs0gkGVnhBYai0dOGXtvY+ArEeb4dLkgzxa5Mqo1NqppYFJoFyoCsnk4FeYU+HGujatl6X5G/5Y2XA8vBn+CmDMxLLF9ozKlWqhuGBU9QRexGMZPRVKNhm7em+Nx7Kkf2Y48O2cm6jfdEbBnJmuMezmZyBknyxefJiya3mgH74Ubj1A+IxQeHzvHsJv18xQrGW4x7LwZovmMiEy+YJLOh2hlJ70BsfhtipKw9r2xIhBV9htR9e9ViwfgebiJE0iIQaICO1eu9YjHD0DyxmR2VAhZ0UDxN+HexjXrT2gQEhbfwjzOLHJZ7OZWlXVJCaJjIYj4qRhsMKKrFCwj1FbFFjp2tjV/ADCTrIzqkbu1Rl21O5vfSAbOGhpIc1lZ4+YXWGveXMMIyD6ayLxHJmMvX3Mkcm5BMTagK9RtjNCBwyHStkjfZtJvvizLCKLSgArZQAANTbkgfnhskLPmGsop3OzEHcD9n+uBwaGGWf644nF2uji9dMN5j9tsEfZ0ItACAAG1l7Lbk0EFV88cIVoeKGyjPSxs4ABAFlj6g9MOTUQiaVejHBEecvwyAV+0Ovzw0pGLXVTBtBISIrdgWK37g/A4jzPL1xGNdIaCJztVlgTdfCsN01FpFnDGvKPjhLawuxKE9WjPr3HfFgrgqpVSUZQyFQSDfyxmo3IGm/h6YtuGylkmiLMBHTrV9Huxt6j88Sz5UYQzbpGOu5Hb0wn/H9Vw9dKnubA3W6u/OsSVH5YyMs8jtQWgvdmIAxGJIwdIJb1Hu/LAWt3NufgB0w9SLoHv0wBpdB5fLphhcHVqJvSCRvsD0wPNKIxpXdz3r3fhiOInxszElq6kn9cAYqRyRzozEB2s2TSsAKat8O4VxGThmYKS6Wgk8Mgddcbp03U4GXmF6VtNr4tgemDPs8ciIZD1BUeGyOu14lmxps57TcJyGUmHBmVMxm49Eph566WqrCyUobtqAutsefOzOzMxssSSfjiym4Xml/utL+G6ChG+F9MAvl8whp0ZT6j9MZxw9Wrls7LTOjckqZIpWAaMHe+zIexHn/ACxbZHP5vg84mgbmZeW0kRh4JV/Eki+Y7j5jzxWwjlWVHiIokgE4nWVyWBUOjgCRDsGA6G+zDsf5GsbZb/L5nLZyAZvJEtGSiyRXqkhZzWlwPw+R/ntiyj0sNa7Absv7HqPT9Meb5POZnhUyZrLOXhclWVh4ZB+KOROl+Y+Y7EbvIZ3L52IZvJt4RXNiJt4WO1G+q+R+R9eWWPzG8cvte5YF2VR1J+g8zi3WDLMKZA4A3u9z8QcYvjHHpOEZaD7Ikf2rNsaMq60ijTqVS+rHz6V67JwL25BzMOX4mkEUstKsqWuWk1GgkyknST2INfDrjjjOdulnDVSwGBw8TymJbJTeSVP3oSfEfVST6eRisWVRYn5qpJydjls2hGpZIT2buK+W/hwTmJYXZmg1iO9hJWpTW4NeWKRi0WafKsTyc0Jczk7O0cwOqeEehsOo9W8sd7hue0c8crLquz2RyedgkLIJsudpUmvXGf2Z632/C4+fmMnmcrneC2332a4Qp1WGBzWRD7XdFShvrRUjYjfxbIZhncM8gizSjSmYatEgquXmh0rtqr42N1QRRsTGkHLkiWpMntspG7ZY9CpH4dx5eeNY574rOWFnMeX8XymXjGUzGUX7nNM4URbxM4raNQSwJvdd67bGl1HsxDmYMjmOfFJGs2ZMkSSJTMnLRdRU70a7jth/FfZWVlj4lwEK6wZlMy/D9RCGSMhiYQaptvEt/A9ivDuJ8bkeSLPcK4jJ4Vk5+U4fmUSN2FmGVXFWOgIO/wAcb0xvcXPlSmq2s0Pphtdfc/XAK5/OzUMlwHjeYJ6N9imRD/ilCj88c0XtxIfu+CQ5Vf2s7ncnCR8VLlvyxdVlNmMrBmU0OGujodVGpD5i+3mMYrMR5jh3EZsrmlSNpGV43BPKZWAI97t+mNPJwj2wlIOY4vwTK6m0hRNNO5O5pRHGQTsT17Yens3G8c44lxV85JK6trhyr+EBdOkGZ/psMbx2lY/KxloyVanEkg36HxfTEaqxzeZU+B1RABuOwvGyh9nOE5OFw78XzSrbBR9nh3v8GlS2/wAcLJwzgcLvKOFo8rKEZs3nMxLstUCqso7DthrhZvbIMGQnUCG2vt0xGzEkb9B+uLPjcsTy5ZIsrksusURXTkoyisWcm3LMST88VPa/XHO9tycHWTjscLrCdDiqsSYkhDMrNIxeXwafBHG4gBkBPcXW39cQssxQvAS0TWjEII3QkA8sk9egJonE8hVsuiZoOSH1ZRYFUTyIHZGQ7XR6gkbV3vDZYJCqc2XLQRRqVWKKTUYgeoKqSdR6tZs/kKOXkaBzJRzuVoKKDzQ3ShpIi8q3vA+dQRzKg/BBl1IOzLpjA0sPPz+OCIY4SMqsanWcyHjUkGSaNiPvHF2Kq6rp8fELm9X2vNMTYeaUhxuGAYrYOAhU74tuELG8nEHcuOTkxJ4TSk/aIo/F/wAW2KgimGLvg0bNH7RvpB5PC8uN+hMuehrp/CcSgjm5ck2+9/D6nEoeGh96PqMAsmqgUDMCe+G8iX9g/QYyM0WiXZRqP0GG6nPTb0XbHUB1I+ZwoKj1+GAQhrHfzOHJeofX6YYS/XoB5HDlLkj+fbATQN9+o/frc119caCM6UCqGIrxHYiz2u7xmVcrIWH7a18bxeCbMUA1BSCfdBIBHfbATaxdKEJBOrw0xU7bemHlY3WqDAgi78PyvAhls6qK7BRv2Buq8sOM6g7EeIlvCCaHpeAc+RyzWVDbnaiKHyrAcmSkSyqltr264M+0NQK23nQBrv1vHPnCg3F7keDc3f6YCsHMiLgoWR9pUbZXA6b9iOx7fDYkZPN5vhWYjzmTkLQsxU6gN/2oplO2qvkRv092Vp1k1EhWs7biq9e1YjRHDu0Yi5bgI8UjMFmHXSdrv9lh0/ULHjmfg4iMhm4EKRmAgxk3okVn1Bb3q+l/n1NBOCZXG3uoAO26jbE0kwV48tGytlvvZI7FTKWNGOXtYo/r3wZlIOHNmVbO5hYUkKKLXUQNJUmrGMWSTbcu7pqfZLjc80R4ZnWJngj1ZeQmzLl1oaWPdk/T4b3nEdbZZ5Yhc+Udc7BXUmG2ZP8AEupfnjHcW4TmuB5jJcSyjRyixm8vNAyiDMQrqeRnrub0AbbA7bba/L5qLMRZfMRENFNHHNHfdWAIB/Q4eLOUyxLMySCOaM3HKiyIfNWAYHCJMpCRzF9CWYpY652XPXwXVqT1F+oo9R8kAmXzGUuzw/My5dL68k1LEf8AhYD5YVu+OfV06zmCBmC8onYsmYKBHlhYrzACSC63pv1wTmMznXyeajTP5hKiklFKrW0aMwHi3G9bjcdsVq9Rgo/3GZ/+NmP+k2O2FrnnjOxvPM3LlefNSB4k8Dy+AWNWqvPteGl4u0S/FiTjG8Z9oOI8OzHD8tlmjWH7FkpXuJHd2b3hqe6FCtsaywaJAI8j0+eOsrz+qh4lx3iUOdzWVyuSyrDLPEI35DSuS8SvqAJrayNh29cCScS9t8wHEKzpa0vLgjiF11BZVP541JcjoFH8IGImd/2j9cTn7akn0GX7W0MHNSQyiKPmkkbyaRq3uut4BzAk38IHxIxYOWN2b+eAphYOJWoyPE1YTAmtwenmDgAG1PocXfFYCyFgDaHV8u+KFTTEHuMc5W8onTcYnysUcs6hwSEBl06SQ4QgkNWBYz1vD2JFMpIIogg0QfQjG2FgZisQkuLLtMmoaeY03iHUsSW9PF8RhYZmIYK8Bo2DQDAEnpQ1fxf54DSc1qkGtiKLsbY7gjVfXpiaCc2zGeOMWS4RPvGB6BFaxfbyHX0OkSLLM3PXmRo5XVK51KyIACDI6Dub2vfoN+gmbZXltNXLVQkeo2dIJN/PrhMzPJNewVA2rQu9kCgzt1Lev6YjsNGD3G2JtSe8Cp95enqMaz2fyxPAOPZhxvnGghjsdYstKov5ktXwxlEilndIor5hV3JH4I0Fu5+GPSTDDkuDS5eIaYoYstCgN3XMXqfM7k4gza5dks+pqr2HwOJafy/IYnDILvWQRQtDW3cd8N5g7Ia7eF8QYHlgXesbat0awvSyCMdphIsPfwo4vH1OrCpA10FRtW53BYMQcDyZONy7PCBID4zDGsa3dEBQdIwFXoXzPpth4pRfW6A+ODjkohsvMJsggGyPrjmyKaTbsmlbqQoGPa9PWsAC0GnxiRCLZqNq1+l7fnizjkBjiYXuATZ36bUMDnIQ2F1S64/eDaNN9xpAsem+CIoZYwFCMUWihJ8dkXZ2Hn5YBW0nr1uxp6/I4bZNk1R67g7dbw/YnxEkg3YvrXQ3jmKKQD4Tsqhuv+EYCPoCD5+7XcnptjiGO+/U+9XfHAKxYWwa9yRV/A4kugBvpojrZHwOAg8Y06Vut/CBWx3vD2eYhGCrsGX7wgB63LH/AF2wjAX3pqBF0K+uH7FQVNXdnbUSBuL64Bhiy8kiyzAqVJBZBR0ncNWrfyxXktNM1AdSfFYVVvYbWcHSldEvW1Vz21WQepwHAlxuw6liL9BQxMumse13lM9OuSm4NmjzMtNWZydEPUgsFVaxYPQgkeu1gn8B4vlMtA+Szk8UBimd8vqJ5fJlJfQH6eE2Pniny/DWl4Zn+Ifa4I5crIJMrlJGVZMxDF4cxLHfUglQB3o/s4EgfhpzBOfilbLzRujSxMxlhkPuzKpYBtPdT26UcccdTpt6BFmct/aL8ueGSPPZFWBjkRwZsq5Q+6epVl+mCG6H4YweRjfhHFcjLKsc2WeyssB1RZjLttzIWIBsdxsQRRo49AkEMkKT5dw8TLasPxCu/r54Z97ax+kAPiGCybgzP/x5/wDptgK/EN8Fg/cZj/cT/wDTbHTBPJ0wvtAFbinB1YAq2U4UrA9CC+4ON/2+eM1xHg8E0mT4vmJ5eTlMrkiYIItUkhjIYeOzQ3F+Ht9NFC7TwxShChkRZNElKy6hdG++OmLjfsLn+KZPh5iWdcw7SIZFEEYYBQwS2JYV/litPtDC5KxZOSxIYzzZkG9gdEU+Yrfvg7iPCl4jJE8mYaJY4Hg0xaGsOxbVZB3FkfPAy+zvCUZWd8xIVl5wBdgvMoKGpaG1CsZsz3w1PTXJnDeKycSeUGCOJRl4Z0Cs7NUjuhD6ttipwXIu2HZfh/Dsnq+zQ6NShWKk2wBLAEkk9z374cyR/sj5knGtXXKWzfCpzMSsCDXfGUz+WfLvqA8BOx8j5Y28iKb2H0wBmcmsiusieFhvYr88crLK6SyxkFbZiMTXY+WH5vIjKszRzwlO6PJGJPgN6OBUcNWk3tjcu2LNJlPhr1whtWB8sNDEdu5O+EZ7BsY1tlM1aq7NiNbBVVBYyWoVRbMR5DDNYIWyLFXuNqw+HNz5YyNl8xy2kUoxSNC+g9VDMCaPfBdVrsjw1OHZCUyojZzOoqTuSwKRtKg5Me112J8zfTGjzhysuVOWlnhhfNSFYls6nMFyNSk6tq8W2PMGz2fmKq+bzkhsEBpWC2u/QmvyxIc/PEJDLBBOzqq683qllSm1Bonu1IPcHGbljvS/qzs9tcRqZ8vJCwjlVwOqtrbQw8wVxFpT0/4zikyHGeLz5nKwTZmSWOUmORZTrtQCb377deuL0RpQ/u/r/lisqscwFtUdiyQxej076hZ+uHuE2aM+KvcDgg1vRPQ/TAz61N6jIKA0lQFAvcgjCmOPqI2Udyjnb4jpgJNgQoBDWPB4CRt3O+EKwkhioRiymi1Fj0Fb3v5YitGYIskdj3Q48Kgjc7738sMD2CajYLZAIDdfI4CXlCNjILQ6mLMpJayTuQSd/LfDfAoolVJ6DUSbPmP9flhyyEgqIyatVF77gXQvCgo3vREUwJDEgkAb9O57HAQsquW8SnSfFp7MdxhulbUnYDclhsfmcTHWVW1jUkkkIdgT3s0cM5dAdSReq99vgDW2AiKqoXqW9ARR6j3sMLKDfiH4QfifLEmmiBRCgi9TBTp6dhiMsltbDrsA2o/pgOGq2sWAQBVfrhaUE0LN7i6JryxHpK1pPhNXe9A9PXHXYHhDNYsnALLp5Uu5vlt64bk47yiN13f/AKjDHPskgB95W269vPBHC6fJSjb7uZlP+Jg388Zy5ax7RTRqoj5pIRYXCGiQG0s4BrtZ3/zxWAmq8jWNNmcvry0RVwGlDZYIb0yPINKqdPrVfHGYmjkglmhkVlkiYpIrKVZHU0QQd7GMyabo3JZ45dWy86GbJSPrkhDBXjkG3Oy7kHS477UehB6jR5DiUnDxzI3Gb4XO1Mw8NORRV0JJR/MHY9QT1GTjkhmQQyaY5QKimqlP7k1dvJq277brJBmM3kJn0gAsuieKUaopozvpkUdR3Bv1B74WI9E+0ZOdhJlJeZCQCL2dCRurL1FYNU3BmP8AcT/9NseaS5iASRTZOWaNmGoqWIkgbuhkFAjyPl13wUOPcZ0GJM2bKkWqAvRFdd8axmptMrcuHo+XVxl8saIqCLc7AeAdziKbPcMy9/aM9k4vPmZiO/oCT+WPLpXzcgBzE2alAoASysfoCcQ6EHSNR6nfGvfFf0534ejS+03s1HY+3iQjtl4Z5L+ekD88Aye1/ChfJyuflroSkcQP/ExP5YxcepniXYB5EU6RvTMBgviGVGWjidNdOV0GydSnvsKwmW2cvHcO15L7YTmxDwyNR2M+YZj9I1H64r5fafjr2FOThH/44NR+spOKMJO3RJDXo1fnhrJIpUMpBPQdT9BhtlYy8X43MPHn8xXlGVjH0jGAJJZpSTLNLJ/G8j/8xxGSo6sL9T/XCoskpqJHkbyjRnP/ANQcAlL/AKAwoA3ot9f6YOh4Nx3MEcrhmdN9C0JQV8ZKwdF7Ke0UhGuHLwjrWYnU7eoi1YiqTmMNtX545WLFQSTbKKvrZ6Ym4pkJuG5yTKTNC0iJFI3I1GMcxQ4AL74GSxRBNghh6EbjAX3EI4o8tQAUh4wFUDSATvuBioDAd/pgqJspmUUZvPTwOrFiWibMRupN+FQwIb8vUYFnaLmTNCGWHW5iVyCwTerra8TLHbt4/N+ucJIpE5oO+2oEKCT08gMETRZvMqOXlcy1VvyHUUN+pxp8nGIsnk1WtoIVbTsdWkbnEzCiBasDem77b7Hpjl+me0yrpl+Vnljcftl+EZPODOZeV4JEjjEjM0ylBupWhq3vfGm1D/3B/r5YUi7DCypJFgGq+GOqH/3HH0x3eRTX7o1RDck6RpZm+f54ZqVWo3qZgQfFfyPSsOC34qW72Yaien71fphT0O++wNDr5bE3gOYE0SB3qg3T4rhp5YUECqNEDv5kV8sSdE1qT7tlQCfX/vtiGRwUOq1bbxILUN6f9sBwbUSSVVxtr2HzBYV8cMCmyTLzPwE2PPqATiSNIGA8T6ia3cgsxG/X+mOWJEaiJFYmwSNgf2vD+eAhMY3sua8zXzxK6SxCJSugFaQMF1sCb1ftfPEwDRm4nUMvQkBjf8LYF+zl5XkksyNZMgJPz3OARwaAkIAo6dZALHYWARhugjorM2mh4lUX5bDph7QxMzF4gRQpmJu/MnCrGLu7X8JHbfehgIGYk2Qgor3uwTW+GMB11kWWIBqyL7DBFLZBAJuhY3Nmu+GSAa2VFLAEAMVoHbegdwMAMSxvV69BgrgdtJnsqKuWJniG+7x2f6fTETK1+IAEE2B0AXzGH8OLxcUyrRuoYyI0O9BnJFJfr0xLdctSbjT8GlyatImeZY4cxG0mWmkVmiTMRLokjlC70VKsPVfI4w/EFgTP55cu8rwLNIsTzgCV0BoM4Xaz1OPVYshwqCDPTZs6OFzx/b43Wudks0gIeII3W/dr1ojvjyOeQSz5iQDSJJHcAdAGYmtsc8cvbLcas1DPL4YnSVWURTE6QKjfq0fp6r6fT1H8sdjpplLIpRgDW4BBU2rA9CD5YmyrKJbYgDSetfzwPGAzqpJrfp5dcFrEqqCFB/eJ/rjOWPtjpvDP0ymSSeeNlVVIJG3huzWBjIRsBV9j1wStBdhQFncfzGI41svIQeaXJoghVHYg4xh4ccJp6M/zPJldzgkYzCtE2gAIyyCzV6SD1wVmJ8zmSpkMezq1JqJBHaztiIOT8t6IGx6dscWBHb4VVfPHWSTp5c88s7vKrfgeQh4pmcxDmHkVIcuJbhKqxJcJRJB9cXucyXAeAZRs20GZlaRly0Ua5mZWndgxCsb0gDck18t8VHsxneH5PM8QlzmYjgRstCiGQP42EhJChFJ8sW3EuO+yOcy/2fMfasygkSVORE8TLIvRkkdlIOKwBzXEeF8OjgkyXB+FS6M4+SzoWKQcvML4hHFJIoJsXuV6jBDcU4//AGvmeF5UQs2UlySGPL5VOW1lOeZnIJVBZo2O2AH437NxxiOHgLzKMw+aJz2Z1F526yuQGJJ+OGye2GeEksmW4dwyCSU6pJOXJJK583a1v54CWTM8fz2W9oY0zOenzGV4ll1ycuTd1gli1yxtGgjpdPRv9b67IZedcllBLzXnMKSZhpAS7TyDmSFvmTt8u2MDN7V+1E3TO8lelZaGGOgfI6dX54rZuIcYzFibiGdcb7NmJSPpqrAGe1dn2g4iD1Vcqlfw5dMVAFA/DCqjXe5J6k2Sfni3y+QgmgLWdTBlDhgdwd6HpgKjHVqpR1chRXcsarF4nCculFxJIACxpqHTpS0fzwVl4IY5AY8nAqhQQ5W5FbV3Y4CxDUq8wKBQUk1SUOxXDttq8+29etnEepQDzOm+4o9TWw64cuphrBG+wV08SkdiBgFJQgdAbAokg3e1EYT7NA25g3O5pz1OHiwTQXUenX6b46v3F+bDAV7IGskxkAajr7jptQvA4eCQArJe1mj4rvpvviYU2x3HYX/nhGjjbYUNzemhZPnWATVJ+FtgCDo2FfHCHUKPhPUkGxfldYTewEBG3UElSR3r1w0MS1Ma2BsWV32ok4Bmks1vtd+4arf1vHMZVoBrWqHS/ocSMbFUB03O3zw21NnZgC1H1Hl3wDC52UhSa8OoXRvp544M66yCynTQVTtV6qrpV4Wj1BsEfi3677YjZCBbFupHwGAeHu9VliRelfCQRv8Aiw3UUJ0BhuNLMooC+4Ni8docAEGgBt13HphrsV6IX38TFjtt0ArAPC0AGdm2J3FXqOrcgVhFjbYhUFi6UnqfK968sJr1XW9XsDXp59PljrcliASBufF0r9npgIzAQSCF6X0Pn3OIMxGApbWodDrBqqoVXhGCNQBKkXersSdtwN8NMbmmG7amJAAWge22JZtZdIM1xniuZiMWYzDMDWu1UM9ChqYbnFQTd+uLXMZLWryLKgdRuu9PW2xHf6YrTHJdVW/friTHS3LZvljsP5bjasKImO9j5b40jof7xfSzt8MFkBtwSD5BjgeNQhLddiLrpeJhpfVq2qjsOuCHA1eokigDe1YUnptflV777WccNFbA79fI4U7+nlW9b4Bhojbb6fyxxs9zvXTv9MOMb7E7d9h19cPMahVNjaj0/LARFXG3cfXCUenpeJSp2U7Gj54TSDv5d8BFp6/DC6PriXSdrBIN9Kw4Rnbvf5HyOAg0dDW3b1xIsVm6G2/0wRHFYN/hNAVVdq3xKINRFdQaOkkH5EYCNYPD4kO4B2HUHoR6YPhjUAGMtdABRW/w74jjRECrUgVAB5gAfngoIfwnbuN8BOiN1qjRI3uj33wtMPfClt7aiB59v6YYu5SmYUeoNEgdm6jBClWse94bOqwaAPTAd4inhAJ2B8unnhgCBgxiXVYBK9SRhzAjRpkkUGha3QHewRjgLOrnXVaSVQGwetr/AK+uAfak0QN/XqD64YY5LNOR6X0wpVwVbwsoPvCiR647mJ3UX8DgBB/fT/4v0w1veb4H9BjsdgI8v/6Zf43/AFxx6t/ul/5jjsdgOk90/wC7OBoP71fiMdjsAQv92v8Arvhre7J/Af1x2OwCt0y/8I/QY5vdb+MfocdjsAND/fP/AAr+uJR0H8L47HYBG/vIvi2FP90/8S/8+Ox2AZH7ma/gzH6DFQfwfE/qcdjsA3ufh/PCp3/12x2OwDk9yf4D9cJ2+Zx2OwD191f4RiQdW/w47HYCT8DfD+mHQe8/8Bx2OwHSf7P+F/5YYvuH447HYB57fxPiUe4P9eWOx2AnHf8Aj/kMSR9X/jb9MdjsAo94fxL/AMuCl6x/wj9cdjsA/u38R/TD0/B/Ev6Y7HYCce7P/Gv6DEJ/9M/+8b9Fx2OwHZT+5zXwj/5cMPU47HYD/9k=

	";$address="

https://droom.in/marutisuzuki-cars/gypsy
	
	
	";$p='
	                    About gypsy :-<br>
<br>
One look is all it takes to fall in love with the gypsy.The Maruti Gypsy is a four-wheel-drive vehicle based on the long wheelbase Suzuki Jimny SJ40/410 series. It is primarily an off-road vehicle, or a vehicle for <br>rough unprepared roads. It was sold in New Zealand as the Suzuki Farm Worker.

<br>
                  <br> Features :-<br>
<br> price :- 5 lakh
<br>Mileage :- 13 KMPL
<br>Transmission :- MANUAL
<br>Fuel Type :- PETROL
<br>Max Power ;- 80 BHP
<br>Seating Capacity ;- 8 Seater
<br>
<br>
<br>
Know more  …...........<br>

<br>Engine Type :-G13BB
<br>No Of Cylinders :- 4
<br>Valves Per Cylinder :- 4
<br>Valve Configuration :- Valvetrain SOHC
<br>Fuel Supply System :- N/A
<br>Maximum Power :- 80 Bhp @ 6000 RPM
<br>Maximum Torque :- 103 Nm @ 4500 RPM
<br>Wheel Size ;- 5 Inch
<br>Rear Tyre :- 205 / 70 R15
<br>Front Tyre :- 205 / 70 R15
<br>Rear Brake Type :- Drum
<br>Front Brake Type :- Disc
<br>Wheel Base :- 2375 Mm
<br>Overall Width :- 1540 Mm
<br>Overall Length :- 4010 Mm
<br>Overall Height :- 1845 Mm
<br>Ground Clearance :- 210 Mm



	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}


else if( $type=== "Isuzu V Cross" ){
	
	$I1="https://th.bing.com/th/id/OIP.gRwMziPmVm_Lv2jAXoB5YAHaFj?w=222&h=180&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/OIP.u9wGscmJKrEtp_CXqXojOgHaFF?w=228&h=180&c=7&o=5&dpr=1.25&pid=1.7
    
	";$I3="
      https://th.bing.com/th/id/OIP.IfTlWZe3NZCKuPQh9n-0dwHaE8?w=268&h=180&c=7&o=5&dpr=1.25&pid=1.7
";$I4="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADhASADASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAABAECAwUGAAf/xABEEAACAQMDAQYDBQQIBgEFAQABAgMABBEFEiExBhMiQVFhFHGBIzJCkaEVUrHBByQzYnLR4fAWQ4KisvElU2NzksI0/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EACsRAAICAgICAgECBgMAAAAAAAABAhEDIRIxBEFRYRMFMiJxgZGx0SOh8P/aAAwDAQACEQMRAD8A1Be43NmONh/dkZf0YU3f1DxzD02hWH12mpCvJ8Q+hpCrY615f5ZHTQzfBkjvdvOPtAy/+Qp4QtwjK3+Bgf4GmlTxnrUZjjJ5Udc9Bn8xims9ehcSUxODyGrgj+9Mwo+47L/gdh+hJp2+UfdmYj0YK2PzFaLMmLixCrA45ppDDzNKZZwScwt0wNrKQPmCR+lOVhKu7ABBIKg5wa0jNPolqiLxUh3etSlaYRVk2QnPNMKgmpitN2UAQGIHzqJ7NG5x+pFHBBT9nSigsqDYyA+B3HoOCKYYLpD+FsDyypPzz/nV8IweozT+4RgOKKCzNNK0ZAdGXnnwnB+WOKnjliO3wsT0wrBWA9iasruxlIVoFUyJJGwDkhSuQGyR7ZxThYIwwUU+X3Rk1NDsP0p4o4FmVrGAb3DSXU7NKyjyEMe0ceXPnU02o6eAwlv7y5BBQxWqLbQEEc5IAbn/ABVUTaeIVZ3ZYUXGWlcRKM9MlyBVRJqGjRFlGpwTOMju7USXT5Hkfh1YAn3xWivonRpf20sClLGxhiDYXc5aRj7n/ZoaXUdYusK07Y5wsaqg+u0VmptYWJkVbC/Y7NwEqx2wbPGcTP3nrjKe9E2932imO63sbWBdrd00kV1eFn425/sUHz3EfOsp5I4/3yS/mx6DLiSG0ha4vZRDbBkBkfOwu/ChQOSfYc+1VU/aLSre4jttmomY7W8drJBtGfC2JgHwfLK/Tmq2TVO0Eus2sd7cxSX2TY2si24/+PMjkS3FpAh296OBuJJ549avH0S0tGVrONfiDEzSXF6slzdOSmS2G825Byv1rj8rz8PjSjCW2zqw+M8qtui9tLKe+hgnhjLxTRiWOVQFDK3POfDn1HBqc6TbKxja8tw4Vj3aMZGHPQxoS/8AGsLH2yvdKis7FLOxmih71Ea77zwEyNJtILbec5HFHw/0gaksjxT2yrHsWXfo6o+xSFLFgFJOMgHpg8Zr00vg5Hp0bZdPg+/3d7P3cf2YKfDqCeM97OVyPmppxawtCrhtNgYqokaS4kuZCQOcxQhVz9f8qy1rqttrTfYanHM5JVY55HWYnrgK5x+tHHSbg8OWBPyH8jS5V6DRZS6xaIXB1K+lQjasVlBBbRIMc4Z1Muf+qq5ta0+GRpYNOjMrbczXs8k0rkHKkkn8uacmjL+LJJHUlm/nU6aRAgAwBzyAAM/kM1PJj0Bv2i1uUERyCNSTkW8IA5PqQT+tBPJeznMhdmP77jPX1FXwsYF/COCevNcYVXGAo+QpbfYFEILk9Bz5HDf6VILaY4DEj8hzVqUA5qMilQ7AfhEP3jn55P8ApThbRjjLY9Bx/CiT503NFILaM2FuPEYb3U4yo/BdLKD74cuDT1utajAH7QlJz4e/sozx6MVAyfyq1fSLYn+yX6DFQnSUByrSKf7ruP0BrDizSwZdW1lDtdtNl65LCeFgf8O5h+tS/tq9UAS6erjGN1rcqTj2WVV/8qU6dLwBPLx03bW/8gajbTrkcb42HkDGvHy24pPH9DsIXW4Mfa2N9H/gSOXHue7cn9Kemt6O2cyyx7fvGW3uE2/MlMUAbO8XJ2QnPBH2i/X7xFQNDqC/djk3DkbZFP0G9c/rS/H9CsvF1HSZPuX1qQeB9qgJJ8sEg1IjrndGwZT5r0rNR6Y8rBpY3TDZxLsck9c5FaC3iWKOONAQqDAz155JNXCFOyWGCTyp3BqNQakArczOxSYp4460oxQA0LTwvSlGKcMcc0wJYlQsNxwvJYgZIA5JArI3mra9cW1tJb3c8FzqMU15a6dp0Fuvwun94yRSXV24eUs23IVcfTFa9AOR5lJAMdclSAK87hjNslg808cQudP094JnlVAiwB4JIzyCChByPf3rn8nJPHicsatnV4uOOTJU3osLHX+19xjTbRLGa4hjhdp54N07ITg7g8ipwfPBJz0owWPbaVjLqmrd3Bh8xWsj2Uajk5ZrdUPH/wCT6+dZH9qbr26utNvXsrCOO3tpLm4maJbhVk5WOOJTO+eTtD5wOSM8F6lYRywrdpcS3CBPiO8jjjtbVINrOTH8Vczykg4LEr7c5yMfx+ZlSakopr4t/wCjDMoqbUOi2ksOylsZGvtSsJZGGW7wpeT8/utMZ359eKdLq/ZWyWOHu9RuEwCiNG6W5RhkFVuGSPH/AE1mtKs5NQQXV1cN8CCyxrmREjYHBVeY1OM8noCccnO07f2RshIGns2ZiRkMJZWwcEEQKx59N1J/psp6zZZS/wCv8GNlie1kEB26Xo9tgr4pBMZFU84D/BREZ9s/WoZ+03aWZ2No8cUBxskjs4YJmZeSiC5mkIOeAdp+nkJ+2dDPdLa2F5Oybu7W3sm8Jbg4Mr4GfPip01LV2DiLs7qzBgfvGOIMDg8EQnHtzWkP0vw8btwTf27/AMi5FbILoXY1SQvHOl0ZEG8ytlnBVWeONW3HoMKQcc4zmjZe2cccMqRzTSySqU3eNQNoztWSbB9iffihr291eOOR5tFNniB1jkluRMYmfhpEjXadxHAJxj61Tx6VYdyJbu4uoNyhyU02K6QAjP8AaRXGfTjaK0z+D4+dqeSN0dmHyckY8IvQXpWs3ZFzEpdoWY3N1FcxW0tlJkEYeJ0K5B+6cE444xzbQafp9/c3Eqf/ABskVuJWFmcQQSheAd3ILnyBAGfY4GsorLTNP1PaiSq0yJ8QYpFkdofEEgLMQMsUDDB+6RT2zbxRWm7L4E94efHPIN2DnyUYH5+tdja9HO7XZHJZQzMd9xb3M2/O5gIrh26Ad/bHOf8AEG5FG2etdpdGAWO6lkgTINvqaCWHI52xSx5UZ99nzoIxwPy8MR9yi5/PGaW1Y2U4VGkjguD3kOZGyrxgb4wGJOOAy59DUXYkzbWPbfS5hEmpWs1g7nAmTFxZsSMjbIhJ/ItWlhuLS6ijntZo5oZN22SM5BwcEHPOR0IxXj19B8VK81zaI4J3PJp4MTthurwrjk9GK5+lehaDrXZme2gsNLRLRYTsS0ZmO13bJG9/ESSTnPNKii9YrlvnUDkVDb3tverI9szOqTSQOdhUb0wDjJ58iCBj3qOSWUl41WPeCPFJNsRQCmc7UZs+IcY/0gbVaY5yKhbzqZ4LoEEoioFBJmypBI8wSAB9agbuU2pJe2CS8MczRSMQfLYpfH5VVEjCRzyPzphIqVvgUVs3M0hfA+wtp3IbPQEqn8aaPhFO4R3bNg4b7KI/Is7sf0ooqyxZFJNMMQ9qlOMnnzpMisyyEwqaTuFPkKmpRxzmqSFQK1sD5U34dB5c0UWppNOhPQKbcelPEagdOcVIc+VISaCRm0DyrsAUtIaBCGkpcfL3JIAA9STxQ6yzTjdaxp3eTtmuS4WQdMxRphsehJGaC4wb36CVFSDPocUGf2hAksstxpphjJkke4EtrGkYHJaXcyj6qayF7q/aW81e2l06e5tdKCJGod1g3QyKRJIrbeSeQjYz93gE4FJWKS4/ZtbnUrWydoTumvFVWNtCyhogej3MjeCNfnz6KaxOs3em7pZRpWnTX10JZUWO2jS134xmRpcSSMOSBwTz4cHNELunPcW0M4tlcsFggmkaZyfvOwBLMfUsefOniOGDvvjBEhjJJjujHmLb1zv/ABcjOB5+9NGTnRk5NH1y/jW9mkVEhjwkk7yQrEi8bIYQoA+QUVa2+j6jNp62NxfSm2RRGILK3iQOoO9Q9w5XPPz981eq0MqbkjMseAwKRyOm3yIJBWp9twy+BCGMZaNpCqIpI4JLc/kpp7qnIynOUulRkxpenW7CNbOCTuzt3Xl5POpKk5xFCir/AN2KIVzE+6FbSALkg2thArc8H7Sbe38Ks00HVJgNr253gldnxD7gD0BWID580bF2U18oixxxMcZJaRUBb6nP6UuMH+7YNGeku7qQFZL2/ZDj7NblolJ9xAF/ShZHhPLLu4/5kk0hP1dia1rdhu0sqIDNpEBZfGxNxLOpJydoACVBL2C1NC2/VoCAQxEVsVcjoQu/IrWKxx6S/sNRZkSyDaUjiQg9UjQN/wDtjP61EURzLOIoz8PhwxCqDKclQePr0rQTdlZomzLql40Y6LDFDEy/M+L88UTY6XpUUM1tPFdXCupO9XVZg3XeDt2g/Ty6HODTmqpFqLTK+6ie1uLHT3jcR2DFjuZkMskZy0gZuAGYs3HPOPw0PLKoDTzt/a95IdoBJbljjeQP1ozX7G7t7G2KvJGbeQi17+SFbj4R+BI6ACQ4bZufZglj61W6pGbzs9bXPdokw1CNZipXad6SRll/usV3A4x4qz42XZML/SEIMazyAqMGaZISWH7gEZHOeODSNqWmymKOSzmVXlQq4uzuWRcHIYpt46YPHl51l0gKtudkJxjbkA8YGcCjLe3uL+7trS2VjNcOIgcHYFxlnfP4QMlvlTqJNmrhid+N3gJDKQDhh5kZ/wB8GpbnToJ0JX7K6RT3F0hKyxt5ZZeSvqK60tbjT1Fpc3EUtxl50VFKlYgVQkrk8E5I+Zo4HyrH+RVjuzF+Zo7uzuHlhvIrj+sxQyd0rSqFRmCr4ucZ646mthHGXNpJIigNvUPdT5R/utkBefLzPNecXx+A1Cz1KMlVm+wu9o4VkGUkPlnHH/R71t7d2mS0uUKKDMFOSMJIqngg+/t5imVbbtjoYLYD+xt2kDuHcoGZispXJZuafyo+6BlceHA/CeePlUILq04Lbm76YsfUs2/PFSq+cA48hn5lh/OkSKWBJyg68ZJ/eBxSYOQNqgggdfcrSEDHvt//AIB/lXE4JORwT/5A07Cg9jyfnTM+9IxJJpFHIycDPJHUD5VibDmZVUs7Kqg4yTxn0+ftXBlO0ePxf3Hx9eKgtx3iJdMcvModPMRRN4kjQdOmN3qf0lOT1zTTG0k6I/ibQyGITxCQKXKSMYmC5xn7ULT/ACznI6cevX/fzoW+v7e0VopEaeQrzANpGCOBIX8PPpVI97crJJMgSB3RY3SAkIETO0Ek+Q+lVZMjSc+hx61HJPBF/aTRoP77AH/OsTd6peysUFw548Z3lvkMLwKrHmbnvJDzx4s/ruNFkUb+TVdLjzuuFJ9Fx/8A0RQj6/pi8CQE+XP8lB/jWMjfSdpe41Syiz0Rmldx/iEaY/7qYb/s8GEQvQxJ4a1tJpZGJ8gZJAP+2qSYGtm1q1uIpI43Q718aKJS5jBywzgDnz5qBu08HJJkUAgBIostt9skL+tUUl3b2wSRbC8A2t4rv4O1Zh053ncP/wBaGGp2twjdxDHBcE/dvnkVQT0Kuh2Y6+X+Ymmnb6OmKWXGoR7V/wBS6m7R/FyJBHbXE6s6mOOSK3Zy+cKxEu6MfM/nVfqOvass6QfByQywuHPx0ccs4ZOm0JGoAHtn50Bs1nUJrPTo5NP75yVKQMFErDLGSYRLuOPUnAA962Nl2dsIoRFqt/cXyxI0iWjSzR2LbQCVRQQzepzjPH1tOJhKEov+JUZ1u0JltRaytdzXLyLJdKqoZHYZ2JF3RDKuOq4HqTzVjDB2hulf9m9mIrdZdy/EX3cwkE/iIKGTgerefFXcus6Hoq7dMtLdMxr3ZjtrdAueWDMgJ8vUda6LX2QXUtxBHBGQgmnglnygkbCoQhZiWx4Rt9ckYp0QDx6L2rVUW81nT7OM44trUSuBzgK9xz5dcZo230u3V447rXtYncyIcrO8BBPBCupVgo8sD589Vj/ZbyRXcd/eFbpQUlmeN4SwYjuyjlXBzkEdcn25c8uk2k9zINkgSL4pFy7oqlygLuADkkHAwOBmmk2DYzWbi708wfAX0ky7lAi1CMSt3Shj3hkf7TPTB3A9P3hQ8XbW/g8N7Y2sjgYzbyvBIen3lO9M/UVkr/V3uJp5ZZiodiQoIUhc8Zx/Dy6eVV0mqWyglVLP13cHLetVRnZ6za9tNAmCCf4q1PmZ4S8a/N4sn/tou613QBbR3JvrWSGUbo2STLsvPKomW/PFeMG7nuI1ZY2ZriRYLSFAS07k7eMDpngfX0rUaf2Th2qL29kmmODdQQ7QizMoZoQ5yAPIH6+fJ0Owy/7T6QTiOCa6ffjj7NWySFBC5Y/pQqN211FN+nafHYwBiGuGXuyyngtzmUnitJaaNpdmu6GGMOSod8ZZic7XDNzgjOfmK0cEiQRncyIxAUofvK/3TmgDxGS21Cx1aWDU376O9ie1ln2b9rSthXHIPDbfxdD7ULp2hajdzTrKHjjs7lopmGRK8w5Ij3LwOmc+v5brtdpyywtMqj7PcGOCAFIwT4eff5is5kXFtaXhwsxjW2uygkXMseVDk5xzj+HpVPoAhOzumg5mW8aTP3nuWPGc4wABijodM0u2cmCzt2boHlgG/wCmWNVCytGCFnkx1IWR/wCRqVZrhvuyzYHmZWH65rLbCy2ltZZrqyuO8jhEEdxE4KkmVJMMF3DOMEennS93IpVS0ZAXJ2SqR1xg7sH/AH+YMdwIEeW5ukEcajwyGZ9xJwCXGVHOMk0Rp1yL62inlWKOYMyyRpIHTG7aDH5+hxS2Mdc25uoGgIj2lo3Xx4UNGdw4Bzz0+p9atNILwRw20rhsRxjOTgyJ4cjPqP4UOAvr/Cmi6VLyK1RWacQfF5XDIm1gFRwp3ZPl65x1oGi8JIeQD94Z+oFLk+tVyajKzkyWLANg7oJkZQMej4NTLf2hIDLcRHP/ADYjj80zSGFZPr1rj5UyKe2mJEUqsVGWUEhgOmSrAGpSPMUAWBPJxXAkEEHBByD6EU0kZPzNJu9Kzo1I0SaDKwBJINzMkUrGN4txyVSQAjbnoCOPX0B1bWZ9Ltkk+AL3l3IbfT7dLhHaWbGd7YUAIvmc/wAMiyUszKoGSxCgDzJ4xWH1DtCt9N2kS1tu8i06RbSOVZCO9txvDsOMg5DHIPQj05cYjc/kCvdS7Sd9ssrW3uX8JnuIoJpIEd13krJI/IGeWI/jyDcSa+48esRhiMskFvGqIp6ZZsHny61CO1UEqtC9rcJH3YRBE6OeCPDtKqAMe9Cvq8mAIbG5MfCqJFwBtIIA2qfQf7NapNejG7OlgDMPiL2+fc2B9qFDN+6NqsM0yOx05nfvA0pyxWMzuNyqMkmTGAPIcc/whmu72Io72boVRdpc4IHLjJVQc8560C99cvnBjTJ3EjBY/ViaqmLRcHSNOkXJu4oRtBZFUEggcjcVx64qa0tks1me2YWyEmM6jdqRKyt4RHBuwo88kYPv5EbR47+QTXAS4n2RswWIuXRV8RkUL5jB5IwBzjpksxtO7PJY28ccshPe3hMsrkZIUS3LF2Y/3Ryf0Kb7YPQ1JNJWWZYpRdXIAcTPhlDY5kaSTCAA/M/PjMhn0wRlpbW3nCkxxPPJfHLH8MapLEpBJJxhvnjgKsS95OgW3LvGWmmKb4LbcCQE7pOo6bscE8dcgzRbHS7/AFKaWR2SDS7c3Ch5I45JLnwpFCnxDhAD4mI8seZp0Ky20X9laBaM7C4XVL+ONp3jhhzawHxLbxu56kYMhAHPsKMV4b12TvdSKROS6fYLneAzZ28kDPOTUNxHp6SPKtnA3ILz6jrtmsId+uUgkDHHl1+VTWl3awBgGsnGxwz6Rp7SLE5AJZ7vUGSPzUnrjj1oaKv5Lm6tOzsdvHKYlKutsZzFbKYAjeBY3ZTtDEfmfnkUws9Huo0sdPulSWPUWuGWSJ4wwKNCsW8M65UEFcgZOfM1FN2numgFvDHpyQlhJIr276hLKVxg7CqRBRk7QM1mtR1LUxEdlreNE8hA+KZLeFpCf+VZWxQZ8uc4oUb0KzX3TWFolnDc3unQyWkrNGss8TMs+8t4hCC56DkLzz9c9q2qwHTpI7KVWE1zPNMZMQyMThQQJMMeABwOBxkedFGurS99DLZzplGXZp9o3eTtghYjJCGHGQSD9eepadj+214sCx6PfGNUWNTMsVuCByc9+6nH0rXiorsiUikRJp2ctxjk7jnrRCWkfjkmOLaAB7h84LekSH95v0AJ8udha9gu062qwTS6HaZkDtLcXTSzxeHDKqwps5/xHp9aH17s/b6JaabO+oQ6iBdulzDao1qm8oWjkMhdicEc9OgHQVDkrqyVFvY7QrNYgdW1GOJJZY+7sIpsKkNow25RSfvsOBwePdquZ9YtLJB3rYVW7vdMVgXb1x4xuJHlhP8AXDXOvXrd4InEAcICtkhLuF48dzN4v0NVD3U7SbwNjMxPeSEyTemTI2W49sUqsdG4ue2GoyIIrVpfF3hLxAWysCQc99NulPQZIHlQydre0ltEU+Kg2KWXAtUnxg5I7yZ959qxsczxyFtxYnOW8zn1Jo3f3sTnGCS/XGM48qT0MubntZqU8RNzKZIy5jKi32KW2g4IWbHQ+lJpGsQ3lwLO6gt47R1aZ9shhZnXCgCVjgHp1z0xVDcIPgC/H/8AshGQf3rc/wCVDwISsijkyQgL82baRTS0M2i3+gYVVsWeSMbW23jhcj1EfJPvx/mOtzEM+AknpknitH2mvNFfS1tbG9guCdRiljSJWUwQpHLnJdFIB3KAMnpWQGAEIwep4PFQRJ0Wa3YICmNWU+TAMD7EN/lU+lW9vaLf91A6963xShs8YH3UJA4HzpumylbixIBYkqnGSR95T09s/lVvd3aLJaxmOR0lJ+2Q5jQ8ghsA1En6KTJCc4IAwwDD6ihpbK1nubS7dCtxbsxV48KZVIx3cuBkqOo/1p8EolggaQOhwyYkGGOximfrjI+dSgxHGH56D+FCKIDcxRSJFK0a7jhVXIYjJHGPDng8UaBE65hdskZw+Rn5GsVqsu7Ub14JVdC8aRupBUsAqHY3setXOl6pJLcXCF0aGSSRoApV8IFRjhl8s58h1xVUBcpO0EiSjnawDjHVDwRV0GV1Rl5VlDA+oIzmqOTu37wjKkg5B4wSOoq9ge3e3tXKDLQRNlpDzlBzUjQeycmqrUpL9brRbS0uZLf4lb+ed4YI5pDFAiqoIlBULuPX1FXhXk1mu1MASM6gk9xFPaafMitHLsjCGQyeIAZ5xzyM8elQ3XZsEjT9Rk4k1TW36htskUHv0iiH8agg7M6VCkgSznCycuDLKoYkEHds2g/WsZqGqRWlppcMbXV7rV7ZW1xKvxE7RwvMgcFkU9eeF+p64psUOqsm7VNRdXYZ7iJolCdDgswIz14A/OnxfyRaN7H2d0CLBNpANv8A9W6kAHyBkA9f9mjobDspasrNFoqspU4kltmbyOMSORnjivI57fV957rV4+7IVfG4DkAAcqq48h510UOtRusqaqxdNwXbD3gGQRwGGP0p8flibDBLoj3l62pCQSNfwd2gdktGtu9BcS90pyOACOBjJ8q9EN/2dgUrYRdmhK5XcLG23EKTktlQMDHOf8q8km069YES3dy+eu63lO7z55oUWtwhZF7+ZM+NTbzMpx+oqnC9pgpV6Pb59F0XUGF1HFbW15NGwFxAFMcoYHLB0IRvQ8g+XtWP1XR7/TWuDPYPLEYTGlyk8SRsxwft2ZO+C5/DvAPmcHFZPTNY1/QCr2Us62UrFprW8hke1b5q4HH94EH+fo2kdutGvwltdbbWV8R91cuJLVyTjEVxjK58gy49/OouWPvaDTMbDDb7ZIr+UbLmRHm2atDbgiMbVWRUSTOOdoPT2AFEPo+jxs0lhPYGMpt+21HTxuDcskyTCTPsQgPyxWv1TsVpGqhpdOLWN23IXGYHJ5+4pxgnzU/Q54ysHYLtfJcTpMLK2tYXCNeTXA7lh6oijefqFrWOSL6ZLTRV7vgZP6lHpsZRcPcQhplBbIKrLcLyT57VpEvZbydrZf2lqU5A+wso2mcEYAbauUAHT7v5VuLDsN2dgCzX895rUkeSRuFlpit885OPXeaLuu1XZTQIjbRXdlbKi7fguz8CSSZzwHnIC/XApPNG6WwUW+yltey/aSeNWuINP0C0IwZL+f4m+kB/EVhKgkeQLj5VfWnZ3s5Y4uZkvNWuFwputUdba0RQBwiYVQnTI2nPvWM1D+ka9cs2k6bFb5z/AFq/b4q5b3Ac4FZS61HtFr88MUtxdXs8zhY4VZmzn0iXCil/yS+kOor7PU73tpommyrbx6pbQwCNlaHRrcPFEytkYYAjJ5z9K6DWrrVQjWVhqc8bbJHn1S5+EgWJhuWVguTtP4BjJ6gY5qu7PdhbTTO7vdaVJ9RAE0VrlDBbKBkNJu8OR1ywI/u8bhDrvbe1tt9po3dTyq5V7tV3Wdu755iUnLv/AHicceeKxlG3xi22WnWy81TUdI0WAT6ncBWYEw21oii4uf8A8QfLgerHA/hXmGua9q+tsQ8oj09ZTJbWituEA8lLlQ5PufX8qW6u7q+uZ7i5mlmlkZi8krF3bnjJNJFvdtvJ4ZsgZJ+ZrfHgUN9sieRsQbujsRjj738q4tECfDuP949PnikkBDPuIBBIxnJ/IUm5FXGCSeSTx8h61qkZWO71ugAA9lpAzKGyCOOh9TUqmQxd5uAVTtIUcj51FIrqw3eeGB65B86PYE90AkMMef3HbA4PBGfpXWDFpoVPRCpGOp+0DV11sIjYjP8AVxg+jZXmu03iZyfJR/Gj0UWqybxzg8k8/wCtTK4yvPQfx4qCMYGB1461MhyTwOgFRZkXNkzRsGiBd1ibABU44HPJ96sUmu9pRk7pMgEYQZ3Hk+Gq2xZRI+Au5k2jOMHBzirNGG2LdwAVaVUycYPoOfSsm9loIXPdwc5JQZJ86g1C4az0/UbnOGitpNhJx43xEv6mp4kYw27E5+yjBx645oDtBG7aNekEjuntZ291SZcjnjzz9KpdmjMlYtMLVZBK8bWsl8YWRCzZkhV+CAepx9DUtteNpWkyXUDf1y9mNrayFf7NIQJJZF3eeSAP9KZBeSWsN6jBnjLtI6uuyRdxRXCYOFyMBvYDoeaC1VtkGg26nwR6akxGOe8uZXlYn58Vq1Yiy7Pazem+itbq4kniuWZR3zl2jlIyCGbnnpivS4I4xFCCiZEafhHpXitk5jvLF842XVu+fTbIDXtq48I44AFRNUNGiK+I1ntam05nKXkcMkBmjtFWeMyrI4OdqoAcnOfKtICN65H4h/GvMu089ylx2fZBy1zduMEkkuvds20eYBOK5pK6RsjQ2MGi6hHNc2On2zxQySW806QxW6o8YBZTJIUOBxnnFBnUuxNvNcRMTG9sSk4hjl2KVGThlO0/ME0NoGuXllFa6PHaWkGnQw3byXeqRsWmmdi/iQSbSzMwwAD8uKfbwNpmnNa3EGg3jK9vLO2oMvxJlvpG7ws8U2fsvCHAGMEehpqF+xcidO1P9G6YzdSk9Ri2vD+uRRP/ABd2BAwLm4HsYbwfwavJdYVBfXAjNuQkskQazXFs6xtsVoiWPBHv/mQoImnnghXO6aWOJcdSXYKMfnWv4V8snn9HtP8AxV2LYxpGb1jIPATbXKRtxuyJJnVaC1Ltb2ZSCeGG5lt7mSIGFmhdlw5xndA58s456ih9K0C50l72WyTT9dhPwemR/ErIUCy3TxSMhhZlBjIHeHJwBgEY5pu2cTpHIr6VpVi6ahe20j2hke5uAu1w+HUHuzgFTnPOOhOY/Ar7Dkbns/2g7M62p0pJhOkdupkiuYmjKqAELpny/e+YPnVPYf0f9kzNd3FzJqN2PiLgLZwYgihQSkBZZhgdMfiHXpWM7ByyQ665iilmZrC5RY4oy7nLR5wqg1Y9ql1aXVrmzinntbeO2tZJIDdRxxB5F3HcSyqW9cZpNSjLhFjVNWzevedk9IRrG1WJO4gYm1sbie5nSJcljI5kWMAf4jWB1XtffHUjqGnh4I7VO4toJmFxEyqBETLtwuPNVPAI46nNHZW2p6dJPNA9ozyJ3Ge/hkJ7wjgBCfFnGOtSdqDDHqSadAqrHplrb2TlQQZJlQSSs+ec7iQPYD5BwxrlvYnJ0B6j2i7RaszfHajcSRlTiJWMcOMfdCJgVGYbD4XTlLgXUkFxcOYiGCs0wSOObJwBtDNwCfEPXivjBaRQFJZ22qFBLMWO0KoA/lXo3Zz+jyWQw33aMTRpN4oNKh4vbnngzkHwL6jOfcY56GlBfBntmY0TsvqfaG4kWyVFtYMC6v58raQKBydzYy2PKvT7W27K9itO+IV9hkTEl/Mga+vXXqtlCeQPfgDPWodb7UaVokS6dZQ2001uNkFlaAfs2xx074rje49Omfyry/VtQ1DUrw3l7PJPO45eU7toHIVFHhUewGKyuWXXSHaiWvaHtZqetiS3t1e00xzkwRsTJOQfvXUvBYnrjp7eZzkuJpIdkUMPdwKrdzuIYxId0r7ieT5/wpJBJsBbPRTk5xgn8qn0jYdY0RMA7tQslYOAVO+ZAQV9Oa0fHFBtejNNt7GX8VrE9u9rFcKkiZZp42RHb/7e7yoPvGJ3dMHOBwOPYV7Dddi9FuHaVZb62fay+CX4iD0GY7kNx7bhWH7RdlX0eK3khdrmMrMZpIoyFjw+VDjcxHB69OPXr5Hg/rfieW1ihLf3/wCo2zVKTkkZSQeI45BG4euDzTckkk+dOfeAm5SONykggMp8xnypuDXuGQoY4xk7SQSPIke1OcEY5OM4wfLz4pFADDdwPfzp7EGND5l3P5jihgKzu6rxhVQL6+WDROkqDLPk8CIn8gcUOpAjXPmWXHlgEHmidLGWu/ZYwPfdIq1L6GWIyAemafGzPjw8+3NSiBjyRgZ4JOB8qIgiiJK98m4YJCNuI9sIDzWNkUFWNrdylQkDkOVVS2du/PODjirqS6FmLWK4ikSYKIVLFWE7MNuAkO5vLPOOlVUSTlFeE3Z2ZKgxpGDg4yO/I4+a/SnSagtpt/rdnHJkd5GiNeTe/wDZbFz5dKllJUXMTME7sAHa8igjnIDkcVne02spFE2lwMrzzFVvNvPcxhge6B/fJxn0x6ngS87RSIojt1nPDArJst92TkllhHe/94qmsrPUtWu47KyhjEt3IAcRBVRSyqXZzuk2jOTzWkVW2XTYx5yLS+Unh7pmG/HfuWA3bpMbiPCMj1Oaiv3FxeYQhkihtbZMdNsMKRcY+RpdUgbTr++05LgXCWVxJB3oTaryJ4XZVYk4znHNMsow8ibiAMk724VT05rQnomt7O3YxsZCrCRShBDKQpyQw6hvSvVraeK5iiuIiTHKu5cggjnBBB9OlebxqbjUbSKSSKSMEFnDAoEjG/hlwfKttodzFK93ChG3d3kS+LPGA3t+7xisshSPQQVDZJACnJJ8gOpzWCvbCKbWOxc10qrYLPqDTO/9kO5VnRJieBuIA56g1rdQuRDCVHLzN3aDyIHibJqrs7a+umSaGXu4IpJcd5nbOzAq21Rx4T5n1x5VzOVPRvWi3kg0w286Wp0eFpomhEji2KKJFKtxG6noePFXna3t12ftp7FU0xpLJ5La2nntra6a6/GCJIwxxznJA9M+u9aymfaJEtJMfvxxt/5LTTZ29ukk81tZRwxJl37m3xgnGMYyflVKf0Jxv2eHtJbPdq95I3cvIrTi07tmWNj4hGCdmR6E/lnIbcG4ub2e4trVY90zSRLZQNFGniyNiKWxjyG449a9jS9/o4l7sXEWhgyj7Lv9OCbxkrlCIuRwec+VOMX9FTFSknZ6FyMqUle0YjrwQy1p+b6M+BiNFuVgkm+K05b/AOKSNLf9q288aQSwqSzBQX++OfTIySKp9evLe6kaO3sbC2jhLZksNhjYvtz40GMDGAK9RMXYNx3YvtKcEkhTrDkAkbTgNNjJHFBXvZrsQ9rPLbWVlLIkalRa34YYB5YxxNz8gKlZVdj4t9GK/o8jlk7RuYpXQx6dcyM6KhO3fEvR1I5yB0qXtXd3Fp2ilCfDTyT2tsshvUiZRgFgPHhBx/vmvQtP0XRtIlmXRrIWzzW8TXM7O11IyKchUQt0HBbGOgz0qr1Psnvkv9SheTVviNrS8wrdQ7MMQsbKEK8dBtPHmKj8ilPkVxaVMxuh3U1zqNq15DbraWjNqMnwkEEARbP7XLbFyfQDJ8uPSq03R9b7Vajd/AQPLJNNLNcXEpKW8HeMW3TSnPr0GSfSvRdO7IWUoW4maez0q6te5kgMe28vmdt7CFfvKCOGO3JHQgGrXVtd7PdlLFLIW8UWxQbXRrHaJGJ5D3ki5Az588+/lpGajtLbIcb7BtE7M9neydu+oSz2813AD8Rq98oFvbMBgpZRnq3UZBJP1xWQ7Sf0gT3Zns9DEsNm+Vubycn4u9Hof3U9hj+VZvXe0Ws6/Ost6+LeM/1W1hBS2gHoidM+pPNAmFHsklRZjO1zJE2Wi7kIqKwwPv5yflWihbuZLl6iM+OnAH9nx6xL/PNIlzNI2CyKoyzsUQYUegx19KJutGvbXT9J1Byvc6kZRDlWVRsAJy7eE/6UCY9sbHPRlzxw1bLi+iWqH/EMzY+IuVU5BOQw45ACAgfrRNvcXKNDOk8/eRuskbxv3ZjcHIYyct15FVpBJ4H5UVbSbODjI4BYsFXPqF5zUTSo2wq5Ja/qa/8A4z7W2CKDc210gWOQGa3S4KxsAR3k8ZHPqCc1Dc9t+0epQGIJbRnvESMWkAHfSSgxmOZZSylSM8Y9PSqO4SVbfa0iBGVmG7dHvOd2VVDgn5ihooWghgv457cEXYjjUsTKrIN3eMgH3a83H+neGn+WONcl06o6PJi4ZEpKi319+0d/Dp91qkNpGltarBbpbC3jZIGkZEzFGd2CVIHHHtnnPCIDJdioGQCo3ZbHTrirPVNRfUbv4p4VAjiihjUADMcYwC5HJJ5JPvQAXvHIOByGIGRgHklc8V6eHlwXNbOTLxUmodCxxLJn7TopJ3ZycDPHH5VLDZ99tVFd5mIAWJkZvfCdTRdtDbM2DdQxklCG76NDGVIG7Dcnjy96NZZ7XCukWNqM04VIbqJn5IjZAGyR7efnVszAf2SXgLR3kQfcT8O5CyKB4WY5x0PUdfnRlvptnbQYe6D3c9xb4CK/dJCjhml3YBGOfMH25qSKTEsUkjhTJ3ryqwG7eR3Z3sQCc8EH60YWR4ZkQASZVEXfhvAChVgeOeD74rOV9BZLv0iFt6RB3AwGcE48xgvUcmsJECF7uMfePC+fGcHj2otuzFhqFhHNY9p4Yb1QUmstVa2gLXCDcdksTcKT9wkH6YrCzxSxzSxTEm4jlaOXxrJh1O0jcpIPzBIqFFP2VTNPaXbaxdxWaXNkssoYq2pzyJAzjACAqNu7rgEj51YapoevWB042N3p173rvuit1tYsSIN+wrJIdy4/veR486yOm6Rqur3HwunWzzygbpNuFSJc/eldsKB8zWnl7A9o7C2lvDc2zraRvcyw27XQbaq+PYxjC5xnPTgUaj7BEUl9DYaRd6Tf6VHFqq2ndR3iCCSZjLOJSJWGTjb0Ic9MYFM7GyqO0Oh88TvdW+fQshYUE3ZLtFHYyaiYN0SSmMwRiZrtwshjJEKoTjg9T0H5j2Nh2pUwXOnWOqI5Int7i2ilTgMIwyOAOhPr7+4XFPo3hkcYuILqjpLrGtSOxIkv791ZCDlmmcg5YdPpUtnlCpUqCRglkLL9QtBXSXSXV2t2JPi1nlW5705fvwxD7z65zmnwyMjAqSABgYxxz71teqOdhwmMN9LIsoJSGVhIitFtZsLlQeRjNXnZi6lXVUjcj+so4fOTlhuQ4A4yTzWZG6aa5w+S9vKxbAI6byOntVronfx6rpJxuZrkoAMFiW2scbuM/wCdZy2gR7NNDBcI0c6LIm4NtYfiHQgjmnqVRURFVUQBUVQAqgcYAFR7jk0ua5zoJd2cfzrJdrtSSR4tFWK6Ekc1vPM26WOOUOpwpVQAUA5JyevTnjUPcQ20ctzMT3VuhlfaMsQvOAM9a8o1C8eWe9mmkmlWd3KOXxK/SSOFNowpG7ORnOD0xitI7IloGM8E7wLKJREe7O3YAkm5DkyMpwIx91RketMutMtbtlZJyoVcKkbQtGg8gFBz7dT0oK5naONkSfcO6MTiHIjACrGqq5GSPr5e/NQVAyOPYfzzWlPsiy8TRIEBWXvJmJXb3TdyQMcjBVxTG0uePmCF3SMln7yN/ATxgypHjj6VUw97IywicRqxLEySFIlIGct5fpXr3ZgS/sLRZFTIWzhmFpaNvuABqO6S47tpe8O9Qw9OuOuBM20tlw07R5pC2oQzrcwSYeLiNre6KvHJ6hxgg1tNL7catAI49Ys5LgSQ8XlmYhdorggGVVIRwR5EKfet7qVhaTW5f4c7RHdM/wANbxmdmMJKAERk7s4A4/EfTjzTtnENI1S2tIUVphpFgGCoixtIFKvM4UBcZHFZRanpIqcpN8my61jt3tj7rSmu/iZIvt9QltCXj3RljHbIThcHAzjz4zjJ81knuZ5Lie5aR55GLF3WQM56ZZvU1vdP7MM9ql3r91+y4poWe2h8HxEpVC5YibgAYBCnnBzx5gzaTL3cFxYKbixl+HKSzXFskx+Jfu4R3CncAxBwSR+lUnDG+Le3rf8AszdsxJPh2luMkhckAD2Bpu1DgNkHy56itD2j0S+0+W0uLoFI5rUguEY7J0zmFxn7w46EjBB6GqW1eD+srPHAzSwiOKSczfYMHDb0EZA3EDbyCOenmOnG/wAkeUNkNUdvuTElubiQwJIZUiclo1cjG5VzjP0pkguCFG0MueCgJPyxR1tMbdLtRFDItzCsLGRctHht4aM9QfX2oywuNGtpIoryUMJIy0waBjHC4YhVyMk5GDkDzx5ZqU3Z0ePihlnxySr7BL7QNd0q20u81C1ktoNREjQ98jgpsIAEwI8JPVQecc0y2GktZasbxpDeBYf2WsCDDSmX7VpyedoUHHPU+1aaVOzk1vM8d4HjRTKEF27YZQcYilPX04rLE2wEIDI88pJcLuKxKeedoPTzA/lTezryeFHFTc1QVCmiy28Zvhd28m9yHgZJvAcYJhchsdfxUJcppqW9ktrcSyysbiS572ARJESwVI4zkljgAk8Yzj3pjpO8MUyqDGZHiEmNq7/CxTJ9M5pAqFh3p3kAL4MbcKMADFKETz5yTECxYwu8s/hG05OflRcNpcNIgfuSAq7y+cKrHqB5kdcYpgTaolg+zcMoAHIJJAwwqztLW7kYhJIUbhiZUaRyzZ8twFaWY0yT+sW0LNLY2NyhCqMsxl8fhDBXQDy9Kru8aQSh97EK3JZnIYdRlufTHPlR198Xa95FNNDJIxt3keJO6aNI1KpGEXwYycmqnxM8ccQyXZQvU85KkVNjLCwt7m/ltIkPh7yOKMvnapbGAM+/WraTTntwphneWZMCSKKFixdY5JXEZVm4UAEnH4vUVLBHHYRQWsSSTXTo21YlBOTySRkUI9zLHIAwkgnVlKtgI6kHPlxjIGflWDk29FpI0XZDUoLa7+Guu7MGpBY0BCkG8A8Ejc5G4ZUnkcDzPOtutK7N3WTc6VYzE/ieKMv0x97AP615l8fEt78YirAyd3MzBQw75GV3KrjgMRwPL+HoDXjOodDlHAdCOQVYZBBFY5Lu0XF+giPSuzsEYig0+CKPOSkaxgE+pzyfqTTf2TomCFtnQEYPcyMmfn3TigmuW/8AdRNdkE/+6ydl2W62drEFCSXqAfd+2uSQPYlif1prWitymo6ihHI23EwGflyKqPjGpRfMPNh8iaLY+zzXtXaiy7Ra1D3jShrgXCyO25nFwizZY4HPPPFUw6jHlWv7dQiWbTtTQD7WL4Of1LxeJCfocf8ATWPzXfF3FM55LYbaZNzCNw+13wkZx/aoYxuz5ZIq0szIt5pQZMNHdAEsMqQxWEMA2OuCR9KpoGO4cgAYIyBtyDnktWytI4bu50y5yGd57Z23ZcEq4JQZ+X+8VMnQI9Iznd7Glz/Cmu8cZ+0kiUk9DIm7n2BJ/SomubTIHelh/wDaQ4/N8VzWdA3U5biHTb6SCaKKYRbUeWURAgkBlViDyRkcCvKZd0Yi2uJlJMQ4JEkvdurSpnoq55HsPr6Jrk9lJp85lguGWIiSPu2ywdQW3Oiggr9a83kQhlVJdskdugdWPDB2VDKPcjbz7eta43dmcysu2eQqpI8BYbUGASAByaCcbQB7ZFF3WVlYAggclweWzweelCyEGtkQR8BfcmvWOy+vdmLeDSVm1ICaLTIrUwGNwIZlVN7ZPUnxDjPGPOvPNIhtrtdQsrrVU0+GS3NzEZYy0NzeQA9xDI4PhHibxc9enPFdCRHPEznCo6lj14HXpSnHmqLx1yV9Htmr6rpWoLps2nanBNDCLz4pYLtYJDG4QMm1mR9zAFVAHJOCRnNVk912ZtdSsNU1LfcX1lotmIYyFmhRwMAo4J3TDoQenXkjIxMOh3kYl1C2ltmktJoHk5LsrXGCgWJk2+HOSScflUdtBcyX10Iz30sdrPNK8sjbSQ2S5Y84P0rDFPE3+7S7fwayVOqCNY1PWu0c11LO8kVuzBoY3OFbBbb3mPMAny8/Oryw1GAaZpNteSbLnTrzTGCRW4ZHgs2bx96uGJIP3T0K8ff4odPsBfxpdXQ3tdK0UKltoG59m2FcqM54GM9fer+47K9ooIbdrXTLicA908bTwi4GOjbWPTyPPXHHNdE8vhZ8iwNNcfZnxlFciG+1OxnS30qSHUZ9OujdNdXNziW4spnYCCWBlOMJjLDHKuV8s1ldU0O80ue4RmV4YhEyTj7lwkvKPFtyMN1XnpWr03s92h1K7gja0ez0/Obm9mALptUM0cUbgEuPu/dIz58Vfdo+zKjTbKGGbdYWZzM90DLdQRnbuKtGmdg5OABjcfIYrW8XjVHC7Eoub2eWwnI8+CevUUPOv2shz5/yo+WzNlcSwysxxtdG2kd7G4yrjPkRyPnQlxhpmx1JVfbIUDk10YOMskr6oyeiFAFVpM8r4VyPxHpilguJbWRZ4gN6rIilhkYdDG3HyJp08TxJAD93LgE5wzjG7k+nHH+dWlro+rajpd3c22mymKyKztMsTBplfEZWPI8W37xxnArk5FUybTpFk7L9oLZu6Bh1DS7y33sokLsJIHWIHkkgAnHkKr4d42MVOzDbdnPIHNLFbPFGyPvWYPkRvFKp7tlyH8YHXkVNGHXu92B3BLSYGWwykDIHA9aE9iYqRhl75gSXZRHGjYDODwHbpnzJ6DHtzYpFdxR3Fwt1KhVe8buYYxuWMYA3OrdOfmTQyQwmZs4yFWRSGbaN+VZiB06df9klLezeHv3i71mi3o1w8shXjPO8n58AUNgA33f/ABTma476UOY2LhA+AAw3hQBnkDp5U7SlD3DTsqqlshYcD7zcL9etBzOJCGUkvhjKXydzlj1JJ8sVd6VGlvYSXcndlBeAyCXcytFBCZjwOCv3QRn8QHnzMnoEV1zrMi3b93HFLbqe7mVxnvyOCd4546L/AK1O8me7iWRpbeeE3WnSSEtIig/aQOx5O3n/AGeKnU4e4unQFmSSO3uUZlClo7iNZlOAT5EedT20pNlbFjxaagNo6Hu5wAwBp8VQwyGTLxk4Pi5yM5GfQ1v9LDHTLFSSTHG0JJAH9m7JwBxjgYrzolkllXzDAjnOc89a9D7P4bS1jTJEEsiOzgcGXFwBx6bsCsJqkVEmdH8qHeOX0qz2DAPUeox/Ko2QkmsSyrKyehppjm8gatxAPSniEen6UAZ3ULJryxmtZFOJQm1sZKOHBDrnzH86wFxpeoQyyokUsyIxVZY43AcDjIBGa9kaJe7Y4HTA49TQgtov3a0jNx0Jxs8ijgvVdf6rc5BxgROT/Ctp2asLoXPxc63ESKhW2imGz7R+Hcr1HAwvzrVC2izkKPniniMDGM8c05ZL0CjQkVrPk8BcnnnJ/Si0tOAWc/8ASAKPW3PO5h16AVIsMYxwT8zXIjcrbuzD2lwiSd02zeZGLlQqeJgwTkgivMbyKQMVZGnCz3LyvGQr71XCkjAOPMf4fPHHswCAY2jaQQRgcgjBFeddp9M+Dvl2QQwwztcSWL2xKAOy+FdhJ5HORuPTP4uN8TpmU0YS5UxsMoRuyRu6c4OPWhXGQDVhd8pbuXRy0aFigOQxHIP8OlAEjp5eXtXUjEYCBkYyDwQa7ZxkMMZ6HyrmFMzVoC1j17U4oI7QOht0CrhY0SRlTlQZlG/jy5qF9VumM/dfZd/D3M5BDNIm7fgswz86r8VYaXpd7qt0lraRF3OxpG4CQxFwjSyMeABn/wB5qFigrpD5Nmy/o/0KPUbybVdQhmkt7DuJLB3JWFrxZN3HHi2AcjOBnn39XLgDrxWd0yG10ewh02ykne3geZleZg8rGVy5YkAAD2AH5nJJN2P3vnXPOXNmqVIt2mHqSaj77BHP+/eqtrwetRG6Yk4J5qaGYvtfZIbqeC0treK3sxDOjqT3kayw95JGq7vuZ8QGOpwOKqdF0B9UDTbl/q9ygaIq32yqyNIhydoyOB862Wo6Pp+qTPcSvcRzvEkReFlIIQYXKupHHTqOnrROkWFtpVusCu0jd5LI8uNjOXbIJGSOBgfSubzc3kwwt+NuQ4xg5fxdFgbrS4UgiGnG2S2DtbxtZxmOAMfEI2QEAn2xn6VI2p2fDG8hIGP+Z4hnn7v3v0rmnBbhjtx0ZMZ+eCaiYQMPFGj+vhUn8iK+bj+r+dDWXC/7M6Hig+mZHtneWt5NphgmR5IobhXdkyuzepGASHz1+8AMdPOsjvERkC5aaVwPGVALYwA46bR1xWl7WQ28dxarCHBnt3eVXVQiqH2oq7vXnPB6e9ZttmZXlwU2rbzbB4QwOclvbOM19b4eaWbBHJJU2ceRJSaQuwRd3Ci5lljfvJScSKq+anPnkj6e1LJEFjXLMTJleZpGAwDgAZx7U0pMHunDqzQHuyzkZEO3eG6Y6UjwXbJueY8EsgJO3kYzhVxXWZgGNzHap9ODzx1FaSa33aHpVsglcym6llhhbxKuYgjhPMn05zt6cZGdUASKDgYY4HmMcceVaS5jefTdKtkCmRy0cffM6IZ3eLasLRZO/JA54pPtAjO6tJFJLZd1N3qw6dYW7OEZV3xRbSo388dM4/TkwRMfh7weW63I6DkNT9Rm7+7lkxgsEDL4vBIFAZPESSQc5Pmcnzqe2iD2jdcy3ltDgDz3Dj8gTWj6ESLuaTAyWJ8IAJJOeAAOa2Wk73tXGwhBMNvow7mIb/8AfpWasUddYsVhdIJI5UdJZmZEidEMgdiASOmRx6eVbLR8zQ3UrBgXvLgENjO4bVYcccEEfSufJ0aRQXAjxEMhK+oHQj3HSrFJIyMshB88fyqFUPAAJ9h1/KpQoHDBs/l+hrA0JAY88Z2+uP5daXcmSPL1HNNXbxliB5ZBP8K7gE4II8iAf50DJJAO7GCCCw6fLNQhSeg+tSAttIyduQcZ4z0zScdBkUDGEY4xSY4+dSH55pD9KALcjk12femsTz/Ok3YxmsUMkDAYqK7tLPULd7a5jDIwyrYUvE/GHjLdGrjIgz6+1MM7+Q4HnWkRMwOtdkdatmeW1X4y1+0aRoADIsR8mhY7sg8+HIwfKsFcW88DsJI3XBIIdGRwM/iRwCPyr3G5ncLgNl/3Wzge/hrL6lo8WoyyTXBZpXBXfvJIXyAz5elbRyV2ZuNnlxbOM0yt3/wZZFgWmuNo/CCg/XbR1v2b0u3xtt0LD8T5ds/Ns1r+aJPBnnkNrcTMqrG+0kZbYTgHzGf869G0CLQ7GPFsjw3MirHLLdA97Ng56higHsCOnnjNE/ARLwE6e1Na0jH4QPlx/pWMs3LRUY0Xm5uRmoyW55/Og7N3XELPx0i35zk/hB/hRjJKp6E/lSTTKEyT/vFdznrTSx8wacMUAOBIp4Y0wc4qQL+vpToVDgTzTlJzTVXmpFGDmgVGQ7ZtI0umx7EWNLaaR5suJHYufswRxgYyOfxGsqZHj3xRr95N+9cMyjOGcKepFbztdbS3GlQyJ3u2zuxPKIzxskjMZZgQRgHHPvWCQFZDs8Jji8Bk5VmYnw549q2i9ES7O2IojitSoEsLZJYsGXgA5xn1zxXTWzgo0s5ySFZScYB8/Gc4pqrDJPOrFod4TdtwFSRTtcDqCDwacILTYjM8xd03FWYjBPl4MVZJBGoDA4LndzjHTOARmtQJpV0m0lijPf2Ml8bYo2TFPLCjrKhVeHADYyx+7kAFecxtQv4TtA5wepGeOvNajTR3llcRRxl5FEd2H3SYjSAsXyoOznOCSD6DrUN1saMO+4yNgl3cgg9S7MeD86uoYx/U41KslssssroV/tWzGFO08HO5v/VTS6IoYz2EZlVzKWV5UQWxz/Znndj3/h1qAqmnWzIrK0z8u0XAZ2BXap64Hl9fWteSfRPQbou2bVZpyWUW8N3cIdy7gwTulP2oKnbuJ2nrjHy2+ipjTbTMYj3d82wD1kYZb3OMn51itMgez0+/vWk3C5D2CIgDMoUrcd4V9SVAXHIPPnXoFnCtta2luSd0EEcbZ5JdVG4knzJzXNkZtBBC5UgqSGHII6g+opzMzkFjk4xnABx9KQY9acAKyNKGhRkfzpQoHyp2QK71oATjHHr0x1ptScV3FAiPmmHz5ojHWoypw35igYe7Ek/OojuNPPJb51wGKyKIwDSPlVJBG7HhB8/KpwoPWg5HV3yAQAMYJ9DVJkg7Fyctkn1+XHlTfB5jmiMCkKIc5FIAYoh6HFNMRFTtD+6aYVlHkSKAB2jPoahZM0ZvPQrSFYm9qaAryjBgwAJUhhnpkc81bjLKj+bKCcEHBxyOKEaIc4IIou3XEI4ONzdeefariIYV+RpBGp/DU+K7FWIgMPoxru7kHv8AWpwKeF6miwBxuHUGnA+dEgcE5AUclmOFH1NCTzR8iFdzf/UYYA/wKP50mwBtXtZb/S761SUwmVEIYv3auY3WTu2Po2MHj0ry0yhVYQuGZDyGGWwODkdcj+VenSK0rb5ZGZh0zjA+Q6fpWH7Q2clveXBSF1huFWaOQAFS5/tANvQg561eOfoiaKlmxEIsDcGTryGJYMWUmnmOLBMjscDI3yBVHzUU2RFcKiOhZzlUkwVjdRksfMehGMGukFikp7yAsyLh4ywKd4eQww2NuPnWxmNWWHD7FBXABC+WPOrzRbpYpLeVlYqrByrMQzocqeoz0z5VSKxlCrDB3MY3PkADoACfLy5+lExSrHLjerk4Z2Xg+AZ/2KmQ1oudQtkhk+xdtjxh4JG8LPC5O0sFxz19qp2gUyFz4iMbBjhfce9WO8zDcgyD0+ZGcc1CEUEMxwvuRzgk+GknQ2WMEUU8ug26RssbdwJ1GcP3ANxIWJZjtzjB49K2YPOc+9ZnQoy/f375+1LW9uCPuQxyMDx05OPy960kSnHNZTNYomWn80gWlx+lQUdzS5pOaX6UBQv0rvzpRiuzQB3T1ppJDHiubmmk1LYywYcnHrScDrXMGyeePakBPmKzQxJHZI2KjxcYJ8qC55z1P8aKud21ACAGzuHmcc0MFI6VRIop3WkAI8qX6igDq7rx5DP613P/ALpcGgBuxT+EfOo3tlPQ1OCelcxIosAJrZ16EmlSaWFSpUMM58WePlRBY0QLQuoLEgkcgr0pgCx3MLnDrsJ4DZ8JNTBUbO1lJHUZGRUM9oEI5Hi54GKiSJ42Vl6jOeoyD8qpMdBezyA5zimSSRxcHxv+6uMD5mmPNcEbcbEI6Dkke5qIbehGKLEMd5pP7RuByFXhR9KYR7UTsB6UhiPpSex0ClaFu7SG8t5raYMY5VwSpw6kYIZT6jirExn5VG0ZNLoR53f6PqFhKXZGmt/EDPECdoGCrPt8YPr1+fNV6zMJpX8DB44w3hGFK5xllHX1OK9NlhZsjqMHp1FUF72fguGaRC0cp53JhT9c8VtHL8mTh8GPaWWTDSTQxREhWKse8Ixjkny+lSr3ZLON6x4ZIvsx3k20g8Z/yo6bs3qUIIjMUijJG9MHn0IyKHXTtUWbfJaySyYYIAQUViNucLWtr0TxYwXDx8N3ihZh3u3ghCCAmegLH2z1ouwt59UljjDskcSDviCfs13g7VxwC3GMnPGfOirHs9qczxfHP3Nsi5KI5aeZjnlvIH3rXWen29sixwwpEgbdtQYBY/iY+Z96mUkikn7HWVpFBHHFGoWKJVRF54A+fNWKrx8qaqfQf76VMqn3rBs1QoHApQtOwcf5U4DoMVNgM20uKkwOK7bSsZFg5+lJ86nC801l60AQkedRk0Q69euCBzUJUnp/7pMC0HU/Kmnzrq6kgBbn70Xypg6V1dVCHeQ+VI3QV1dQA49B9P4Ug6GurqAFX+RprdBXV1CAaOv1FXB8/nXV1NgAXnSP5mh1/wAq6uoQHP5VCa6uoGh6+VSL5/KurqChjedQ/wCVdXU0QM86gl6n611dQwIj90/Khofvt866uq0IN8xRadB9K6uoYEvkv1qUdBXV1ZMaJFp1dXUFHCnCurqAFX730prefzNdXUANk6D/AH51GfvLXV1ID//Z";$address="
http://www.isuzudmaxvcross.in/specification.html
	
	
	";$p='
	                  <br>   <br>           About V cross :-<br> 

<br> ISUZU. V-Cross. The Adventure offroad vehicle Pursue adventure and traverse all kinds of terrain with the brand new ISUZU V-Cross. With 20 stunning features, this vehicle sports premium interiors to enhance the v cross.its basically a offroad pickup or offroad utility
<br>                                       <br>   Features:-<br> 
<br>Price :- ₹ 16.50 Lakh onwards
<br>Engine :- 1898 to 2499 cc
<br>Transmission :- Manual & Automatic
<br>Fuel Type :- Diesel
<br>Seating Capacity :- 5 Seater 
<br> <br> 

<br>
<br>                                          know More ;- 
<br>ARAI Mileage :- 12.4 kmpl
<br>Fuel Type :- Diesel
<br>Engine Displacement (cc) :- 2499
<br>Max Power (bhp@rpm) :- 134hp@3600rpm
<br>Max Torque (nm@rpm) ;- 320Nm@1800-2800rpm
<br>Seating Capacity :-5 
<br>TransmissionType ;- Manual
<br>Fuel Tank Capacity :- 76.0
<br>Length (mm) :- 5295
<br>Width (mm) :- 1860
<br>Height (mm) :- 1855
<br>Seating Capacity :- 5
<br>Ground Clearance (Laden) :- 225mm
<br>Wheel Base (mm) :- 3095
<br>Front Tread (mm) :- 1570
<br>Rear Tread (mm) :- 1570
<br>Kerb Weight (Kg) ;- 1935
<br>No of Door :- s4
<br>Front Suspension :- Double Wishbone
<br>Rear Suspension :- Leaf Spring
<br>Shock Absorbers :- TypeCoil Spring
<br>Steering Type :- Hydraulic
<br>Steering Column :- Tilt
<br>Front Brake Type :- Ventilated Disc
<br>Rear Brake Type :- Drum

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}


else if( $type=== "Jeep Compass" ){
	
	$I1="https://th.bing.com/th/id/OIP.auddvL3cPgUI7MSwXfGQJQHaEK?w=322&h=180&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/OIP.yHz68tHL1ig4fACz_1-dRgHaE8?w=270&h=180&c=7&o=5&dpr=1.25&pid=1.7
    
	";$I3="
      https://th.bing.com/th/id/OIP.4GBePc94Tx4-0oZKZBRi1AHaE6?w=266&h=180&c=7&o=5&dpr=1.25&pid=1.7
";$I4="https://th.bing.com/th/id/OIP.hcTxL51R1FRVFC8OXK0tzAHaE6?w=261&h=180&c=7&o=5&dpr=1.25&pid=1.7";$address="
https://www.jeep-india.com/new-compass.html 
	
	
	";$p='
	                            About compass:-<br> 

<br> compass. The Adventure offroad vehicle Pursue adventure and traverse all kinds of terrain with the brand compass. With 20 stunning features, this vehicle sports premium interiors to enhance its basically a offroad pickup or offroad utility
         <br>                              <br>   Features:-<br> 
<br>Price :- ₹ 17.19 Lakh onwards
<br>Engine :- 1368 to 1956 cc 
<br>Transmission :- Manual/ Automatic (Dual Clutch) & Automatic (Torque Converter)
<br>Fuel Type :-Petrol & Diesel
<br>Seating Capacity :-5 Seater 
<br> <br> 

<br>
<br>                                          know More ;- 
<br>Engine Type :- 1.4L MultiAir Petrol
<br>Engine Displacement :- 1368 cc
<br>Fuel Type :- Petrol
<br>Max Power :- 160.77bhp@5500rpm
<br>Max Torque :- 250nm@2500-4000rpm
<br>Emission Norm Compliance ;- BS VI
<br>No Of Cylinders :- 4
<br>Transmission :- Manual
<br>Gear Box ;- 6 Speed
<br>Drive Type :- 4x4
<br>Paddle Shift :- Not Available in Compass
<br>Suspension Front ;- McPherson Strut with Lower Control Arm
<br>Suspension Rear ;- Multi Link Suspension with Strut Assembly
<br>Brakes Front :- Disc
<br>Brakes Rear ;- Disc
<br>Steering Type ;- Power
<br>Tyre Size ;- 255/55 R17
<br>Alloy Wheel Size ;-R17 
<br>Tyre Type :- Tubeless, Radial
<br>Length*Width*Height ;- 4405*1818*1640 mm^3
<br>Wheelbase :- 2636 mm 

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}


else if( $type=== "Mahindra Bolero" ){
	
	$I1="https://th.bing.com/th/id/OIP.fF0Uupr-v2YsuEARui9xogHaFk?w=249&h=187&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/OIP.kiAhqZRBWwJy6O5HuvapRgHaEc?w=254&h=180&c=7&o=5&dpr=1.25&pid=1.7
    
	";$I3="
     https://th.bing.com/th/id/OIP.Jtzcd5KuQGhkbL0q1g5b9wHaFj?w=223&h=180&c=7&o=5&dpr=1.25&pid=1.7
";$I4="https://th.bing.com/th/id/OIP.iW4BC7Z-YHw7ZgmM1U_a7QHaES?w=318&h=183&c=7&o=5&dpr=1.25&pid=1.7";$address="
https://auto.mahindra.com/bolero
	
	
	
	";$p='
	                            About Bolero:-<br> 

<br> You will find a lot of Mahindra Bolero plying on hill stations. It is the tremendous power it generates at low speed that makes it popular among people living in hill stations. While it might not score much high on aesthetics, there is no debate around its power to carry a heavy load on steep climbs and rough terrain.
<br>
  <br>   Features:-<br> 
<br>Price :- ₹ 8.42 Lakh onwards
<br>Mileage :- 16.7 kmpl
<br>Engine :- 1493 cc
<br>Transmission :- Manual
<br>Fuel Type :- Diesel
<br>Seating Capacity :- 7 Seater
<br> <br> 

<br>
<br>                    know More ;- 
<br>Engine Type :- 1.5 Litre mHAWK 75 BSVI Diesel Engine
<br>Engine Displacement :- 1498 cc
<br>Fuel Type :- Diesel
<br>Max Power :- 74.96bhp@3600rpm
<br>Max Torque :- 210nm@1600-2200rpm
<br>Emission Norm Compliance :- BS VI
<br>No Of Cylinders :- 3
<br>Transmission :- Manual
<br>Drive Type :- RWD
<br>Paddle Shift :- Not Available in Bolero
<br>Suspension Front :- IFS Coil Spring
<br>Suspension Rear :- Rigid leaf Spring
<br>Brakes Front :- disc
<br>Brakes Rear :- drum
<br>Tyre Size :- 185/75 R16
<br>Wheel Size :- R16
<br>Tyre Type :- Tubeless,Radial
<br>Length*Width*Height :- 3995*1745*1880 mm^3
<br>Wheelbase :- 2680 mm 

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}

else if( $type=== "Land Rover" ){
	
	$I1="https://th.bing.com/th/id/OIP.ySOxuNSHi8lfvN89pDTUqQHaEd?w=304&h=182&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/OIP.DSJELZMIaxzUxxijSxBeJQHaE8?w=273&h=182&c=7&o=5&dpr=1.25&pid=1.7
    
	";$I3="
    data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCAD6AXcDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABQACAwQGAQcI/8QAVhAAAgEDAwEFAwgECAoIBAcAAQIDAAQRBRIhMQYTIkFRYXGBFCMyQpGhscEVUpLRBxYkM1NicvA0Q0RUgpOUstLhF1Vjc6KjwvFkdIPEJTVFhIWk4v/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/8QAIhEBAQEAAgMAAwADAQAAAAAAAAERAiESMUEDUWETIjJx/9oADAMBAAIRAxEAPwDG20CvbXNzNkxQOkMKA8vcSjOfXAAzV+S3gtbG2uYye8eYRluobcNwIB9OaEiWcqsEQ8LSq6r6yMNgNG2tba0nksZpUkEcTCTvPFGkzJhwoPQjoKxzcKvafbtFAWlkRrRWt5QR5lXC+IjzquEtf0nqILSBkkuHgTrEzPlQcDnw5z1qKK8U28GnoixQzvArkDpl+SB9hp9+09rqDtZpiK2k7kFl3GWXHibPoKzIm1LepYD5FFCC/ciRZdoYNEXwOc8dckUGilnMjJGDNI7N5eeduT76mllnNi21nBkuT3rscMTnJwRQ5ZJ7aQSpncpKE/Vbzwa1hIsySmGK4R0DSOi5Dj6DBsYABqpAO8bxkhM8bRnLngDHWn3d3DdzNOcK8gAKocgMBjPNMtp0glDsrnaGwAPrY4Na+NSdLU2fCs6/NKCGKghwwGBnmodpEdvtORjD545J6Zq5MzSQkxguMA+HDFmY9Wx50x4HCwqwCqQN3ORuOMqwx1rn5JqHu2kyqsgEfibPTPvqEZnnCOyIpYFtzAL4eOpq4Y1cyQnHequ1cLw6jnHPnQpsbmGWIUnHQVudruirxxFwokRjGpYiNgwGeMnFVJjC6ookYMrMQSo8+ORVvTrdEjmaXIea2Lnaylo4QT48dMmiGjpDJeWqdzut+8luLl3A3NFDHuUMPLnFcuWSsgcVj8onVS+ETG5yMDA5yd32daLNGIhDbQPH8/J4nZtzA4GCQOPcKtLcIdSAnjiVLq6kYowySjkDxAcYHAFOmltbK6vEMY7lnliGMF4mQ8sOpx6iuV5eVy/Gby1A1sZbTULJiC8Km4iJweUBby9ec++s2badUTcnhZifpDrjOKJajfXAuj3JR45EURyRg4l4wRxz7xUsRMsTCZTEDJG7EDJUrnKjAPWuvHl4zFnKiFvqCxaMbZEkj79u5ldh9BejFd33VXtbwRW11YLLujkxFEy4Gw7u8c8jpjg/dVO6uN+nv3KFFS58Ic7mdD5/vqK4SZ7SG9hQrBEJUndxsL8gLgfHmtdfTNXbZVv7q3ZpVdVkXvAOMiNcgce6iZa2MWpw8M+2PCElT432hgPPqKC6cl3HNaOm0bY1uJSOm05XH4Ur2a8tdQt3dlVpHCt3iniLIySB5HPHurFy3IWIb8TQs9scmMuhQnKneB1/GuJZSPEiogMoZs8+RHAOeKITiXU7p/k3ctG7RhDICdvdrwFPw5q1qQtrKzSNWVZZ1hkiwpJZ1bxeL2e+peVzOKzlMZmSOWGR45FZXTG5TjPPI6V1Ud9rDoBk59lEppEv40MiRrNAhiDIfHIv0hu9g8qqRhkibwkMWbd1OfjXacrnftfI4P1RRuVsMcnA3DoaiBUlgvljpyOKsuIhHsUF/ACr5wVbrjkV2CFFViSdz8eLBB91T/1NiFppkX6KEE9SeRgYwQKUtw8oTOPCvOARz0rssUkMgVgecghT5Ebgc1E0Uh4C/TGBg9M0z7WoaAQF8+pqYNswWzyD7sHyFNEUqsgwcjgBuhwPOomc52tnGSSD6mrOz2K293bxw2xZyHiLRlACSyueWBqzd3UCQiJBvLbZA4bwkFSwXjnNAywGBjOfL8KlUEKTzhcH3HrWbJusWLqEGFpMgKCDtJHLEdB506z3Ro8zuAEkGzdjlxzkDz9lU5Vj8Lq/Dngg+eOc1LaWzXFxBHjKM4LA55Uckg+2mdGdNKtwdSntEkAjVk7pQx8Rckb2GPMjoKvSWFkLy3tFL7haM0OXyRGG7tkb2HqKETXENpqulFXUrBIwuNvIR5Bsxn7AfdV6Q/J7pby+lMUkrqkcwA7lNhJCsPJGFcbx32nqBPyd7u9jt5PBNslimYnIZInAIAA4PlXbm0kG2wfxIhX5M4IDIH4A54NOlaUX15JBgO0vyxCzLlBIu7YpHGD1+NcSWWONGm3GRWVogwznByCT7K3xnXVP6uyaNDDLY20ZcnwiaQnqv1mI6VsUVt0dqjAd+kVunmQxHDevA/Cg1nDNsluLkAT3Mhk2fVji4Kxj8/8AlWmsUjYy3kn0rUMqHGAHkT2eYB++uk4/trjNoT2luAPk9nFwoCRgdTsQBVoVI8drbM0jBY4o2kkJ8lUZNOnk+WahNMfoRkqvpxWY7Y6j3NvHYxt85deOTHVYEPT/AEj+FZvdx6p1GLvrp727u7t+GnlZ8ei9APgMVAvGWPQdPfXKcg3Mi+pH312ZWIgVXOOTyaVWAoFKog7FaLNcRJCJ97OqqjYzkehH30SvbJILf5VM8c8st8IrjuGaTuxymMngknrVjutlxLKC6SxLtQMR82XXDMQOc+nNWNPeBp9NtUUPmRriaNVUIRksdxk4GDzXDj3NcLf0FXFrDCIYEingO1WJkU71U8jnNW57xjC0FskaiOBVSQsXk3g5MjgDGTzUs9/NPf3TTmFIrkFIwWTb3KHuwUc+XtqK0uoe6maGEvezMkcYtstGtsmQ0jA/WrXaXVXTtPfUINRWSSTuotjhYsDMqqW8Rby9amlt7OHTGuIozJLCqpcwuMeDO3vUOCeD1opph7q2nMcbRZkkBV1bdIVAJLcZ9AKotY3ItZ8GSO570vB3CythJAS8bLjGD5/86z3und6jKrG8m7YuSMk4X7zgYpjFyVJOeBgn2VoRBqcFpNa2tje7n2BHSMggN9NmJxzjihv6G19goXTrgAdNxiX/AHnr0cbrUlKyvUtYWLYMhuIspj6oIYmnX1xD3lwLeUMO8II6rLEw3q3vGcGkvZ7X2OTYkdOs0A/9dSfxc10EFbVMHrunhH4E1fGbq+FDpZ3kcuPASEHh4I2+earlNxLMzknOefOjY7Na+cfM26+u65T8hVm37LaiZY/lRgW3BzL3UpLkfqr4R9ta6i+Nipo9urxXUfiKyyxmVix+gikKmfQmjFothYXABeQr8nctuRlEswYkIgP1fIHzotaabCirG8caxBukfChR0Cg+frTJ9JMrE+BlSTMKvI2FQHOOBXl5Tlb6Y8aBahbPqdzNPAiiOzCDw5zGxAl2DHmPOutaTmK3nGwtKrzI5yS7nhw49tHItNuodNvrOOSLvbqaV2kcuQEkwMZAznjHSmrpd4tnBb99b97CWdXw+3eWDeQz61Lw5buHhWf06HT+9muLhIw0IkYjoImY4yAT59BUjK08RaCPAeUuzx5CRjoFy3n6ir0vZq5lmllN1AollZ2QLJjBOQMVdh0a5iieD5ZH3PJiRYeUbOckk9Kt4W+onhWYudsJA3MwAjjLbAFQg+Jjtq6dQspmhsZFyqSQYePBhcp4sY6486OT6HFKMxyrDISGZ1V2y2PFkE+dUJeyrysGbUwCDwY7RF+0hhXScL9izhQu/ujBMBAihmjJfw7gI5OqlfbRO6jivLOzuWiVpoYDDnAMm2MjwE+mCCKsp2bQJch755JJ2BMrQjKgAAAKGxVuHTGjhSLv2KgtndEm5lxjnnjyrF/Fd2RfDkC28otTCTEHgRh3m3wyFcEAqD7+aH9oLq3uri2jhdJIbeI7GTo3eMWHHkQODWok0dJlfE7puK4KxqThSD5nzoZP2UtmkeT5fIm45CCBCB7vFmt8eNnsn47rNRiNWhcLw22Nj0A3cdaIIq25UOv847L04OfKir9m1kWGMX0ojixgLboD7T9I8miI0jTe7jjumMgjGCbiXYxBPU7CKl4W9wv46xk6mG4aGLLQO8TrxuJQ4zgjyHP2VagimaZikbyq7BERI2d8A8Ehc49tHrx+y+lD/BbfvAPAoTdI39lWPA9prPXPaG+ZXjsUSygbPEKgSNnzdsVq8Lfa/wCNcm0a8Mne3t3YWMOc/PSF5cHAIEcfPuyac0vZKByzXeoXTDgi2jigjHuZ9zVmHe4lcsxkkY9WJJJ+Jq1Do2uXA3R2u1D0aaSGEH/WuD91b69Y34QZOrdlVGF0q7kwes99Lk+07KiOpdk5GzJokvPUpqFyD+OKrL2U1xshpLBfLm9gb/dJNSHsfrWPDNZMcdFuU5PHApOvUXxWEfsRKwbu9WtjkE7biOePjyKSrn76svpemXMEkWmaraO8kgfZfLJbtjqQrDclA5ezHaeIMy2UkoUE/MPDJwPQI+77qGyDU7N9s8M8TDqJI3T7mAqWS+4XjBa60rU9Pb+VWsiIxxHKMPA+P1ZYyY8/GnW95LbyRSmPKISJUI2hvCQF3Co9O7R6jaZVJjsYYeN8NE48wyNkfdRXOh6wvzTJpt4xyAgY2Mr+e6PkqT6rn3U8ZWbxUJL6SS6EkyoFLx7kj+j3YGMKfvq7f6tFe2jWf03SVIg23iWJF3K59Dnih13Z3NlJIl3E6ybAySABonHRXjkXwlf78dA6wWJ0gZh4hIImdOdxY8E486xeEcr0v24uRaku0URc93AD/OzMpAYhscACtDpmli7k33ExkjtWBjJwBIw+iOPIcE1n4LWa51CGzRmLiRo8bspBERud2FeiadbMfk1vawu0UQVXcKAiqvmznw5PnzXOcLupxl1Kls3hgwGmYkIPIk85H4mrOryx6dpjQx43FdpK8b5G+k/xopBbR27SSEh5n4LAYVEAxtTP3msN2t1DvLswocraJ0B4M8mAoPu4zXW9R6OPHvVaIrDCXcjkM7EnGAOSTXl2rXzahf3Vyc7GfbCOfDEvCjmtDq2qXI06QSSlmvXaK3XCqFt1wGfCgfS8vfWQqcZ9bpVLbjMq+zJ+6oqsWw8RPoD99bRcFKuClRHsS6RpcLO0drGCepO5ieQfrE05LCyjJaO3hRiCCVjUMQeoJogxTJ8S/bTCY/1hW/GHSmbS2GD3MOQNv82mcenTpTu5UfRUD+yAPwqxlPI5+2l4fb9hpgrd3XNlWSFI8/sNNwB5N+yaq6rmOud2vpVg7fRvsppZB6/GmGoNg9K4VHpUxeIDllHvZR+dRmWDODIgAGfppzz76Yabs9+P79a7s9lI3FqOs0Y98kf76abqzA/n4f8AWx/vphru32fdS2+ymG7sf84g/wBdF++m/LrAf5RB8Zov30w1Lt9lLb7Kh/SOm/5zbf6+L99M/Semj/KrX/Xx/voatY9lLFVP0rpY/wArtf8AaI/31w6vpQx/K7X/AGiP99DVzFdwao/pjSOc3toPfOlc/TejD/LrT/XCmJq/iuMCFbHU8D3niqH6c0Xn+XWv+t/5Ux9d0UBc31pw4J+cPkD5YoaIyN3aAKpLMdkaqCzE4ySB7KCXms6VZFhcXcQlGd0cf8onHnyIjsB970E7U61HcRWkVhdK6EzC4Fu53HO3aD04rIiGe4imeON8JNb26nHBmmLbY89MnBPwqbg1z9rWupktdMsJp5ZGwpuZQicfWMcGBgeeWqK+126hQW8csMt5yZZYIxHbwt02QqBk49ST+4W6ppMJsbZle+mUfL7hMEID/iImHkPM+f4VdscKF5G2qPpN5k+gHqam1ccbvJGeWRyzklpHc/eSaqy3UKZWMCRv1myEB9g6mo5ZLq64jik7rJ2pGrMDjzYgcmqzI6HDIyn0YEH76mUOe4nc5aRvYAdoHuA4pm9+u5s+81zFL4VB3e/6zfaa6JJR0d/2m/fTcUsVRKt1eLytxMPdI/76lbUdRddr3Uzr5LK5dR7g2arrFI5IRHbHXYpbH2U9bednEaxvvPO3BBxnGTnyq5Q4TI+e9Xn9dOD8R0qaOWSEh1bdH5MvkfQ1WmSOMoquHYL86V5Tdk8KfdimpI8ZyOh4YHkMPQisjb6H2jmh2QTMHiJ+i/IB9gNai9hi1SBW08mG/RTJb93tSO5wNxhcrgbuPAccHzryhGA+chJGPpITyvu9lavs/rTRyQRuc4dWRiR4CPPn7PjWvcxPVWbe81KFjcQXTo0nhdmMYkLKcFHEgySDxXpWj678ttLZbll+U9yuzZtAmk+htVU8O7NAbBNHk1/vJ7aOaLUNPlu2iZQ3c3sEkcbsgPGHDBveD61Drd/oMNxbfonbEtsS83ydCqLPHJvBVs4P2eXtrnON4+3WycvUbjULpLK0ubmQ8QxluvVvJR7z0rx3U7l7ifui/wA7cOzzNnoZMlj8Fz9o9KNa120sdQtYbWUNHIHjaZ8HunIHDAryDnnGOv3Y3UtSsjFL8ldWmkUoGUeLDcMSSAal79M+vYXqt2Lq6bZxDCBBAB0CJxn49aoUqmhtby5LC3t55iuNwgjeQjPrsBrbKIZqzAMBj7QKjMM0TvHNG8ckeN6SKUdSfVWwamjGFHtyftoJhSpudoz8KVAVPantW3+XSc+gH7qjPaPtSf8A9Qn+Bx+FEhpchPhtLk+62nP4JUg0q4/zG8/2S4/4K3lQGOu9pj11C5/aao21ntGc5v7v4O9HhpN2emn3x91nc/8ABTv0LqB6aZqH+xXP/BTBm21TXm6313/rH/fTDe6w3W7uj/8AUk/fWo/QOrHppOpH/wDZXH/DXR2f1j/qjUv9jn/4aisp8o1Q9bi4/bf99c73Uj1muD73b99a4dndcPTRtS/2SQfiKeOzXaD/AKl1P/ZmojJW9vq95IYoO+kdYZp5CXwscMK75JJHY4CgdST5gdTUo07V3t5bqItNFDCtxN3ZO9IGcR96VYAlckAkDjPOM87nTNA1eM6nbXej6rHbanY/IXnjtO8a3ImjuFcx7gSuUAYA+fs5sjQbvT4tQt9PsdUvb6+szayP8ikt7a2t5WBlO6bBZ22hRxwM9SeLgzXZbs3Lq8L3V0b1rd9SttJiS0MIdZpV7x55GlBHdxjBYAZOcCua/wBlRohikm1qzVbu8vorYTxXOO5ttnLdzHIcncPLHHXnA9H7MaPqllZaD30BtoYNT1e+1NJ37uRB3XdwnYMg/RHn0rKav2gF9baBeQX2pacJYdTDLptnFqSu5vGXEsjzRANhVbGDgEc88sLrDi2sfPX9LHuttTP/ANrTGtrPJI1WNlGSWSyutuPXxIK0o1e7OMdoe1ZwQfBodsOnP+d1HNeT3AcS6z2ykD/Szo0I3fZeUQCS30faN2vwqSOR+jrliPiVxR1+yMS6KmvtrBNs1vDIgSwcEmW9NquI9wOMAt0z8KkXUb5iAdX7fOSRjZZKp9P86NFbvUXeLU7WO91mZrSx7L2/8hlV9SV4kuJZ5Dh2XcrsqyFWPpnHNFYs2WneWqzn/wDiph/6qjk01zsaFtRnjYZEiaZIq9cYGWrQfKr0/wCU/wAIh/0m/wCKq8vjJMn8e2zyTIMkn1yaGAyWCruWSa+idTgq+myFh58+Ki+ldmDrC6iI9RmiFnDDMTPp5iVmkk7sLuZx7f7ipEnjiBCv28XJye7lCAnpk4FX47lX08xd9rha91vQ4Yl16ZJWZY5JHdrePGQBldxx5j4S4vGbV7UexEVr/GCG2E//AOEWVncR3E0yub15VQupjUDbjJxgnP4efW9nd3PyhkDbLaH5RcyMcJDFvWMMx68khQOpJr3660vVe87a3LCOZdUW0isIbd2aXZFF3ZEgcBQSfbXndh2Z7T2vymwvNCvzb6xbrBIbZ7VpYWtpVuY51ZpO7G09QzDcGIz5q6RhDZzsJTEJmMUTTyK0bI4iX6UgB6gedH9KuZdM0G6kdI+8v72OWxDLmQNBFLB3oz9XxsB61p7ns1q+nw3M7WVwzz2zaa13LFZ2lrYWl1iKeQRLczSvKynYvIA3E8nlcneyLeX3dwrttbRVtbVB0VI/Dmp6FeGNgk07sN2DJISPCyjqeOjDy8j099CW4WVu8cYXxfJo25Qc47yQefn/AOwqzqs20LaoeBtkl/8ASv5/+1RQaXqF+WFhb3N3KgtlKW1tNIFV4yzF3A2jbx1/Wz5VeP7L+kMLRSF2ubm5Vl2iJYYRKXBzu6yIAAOnWuStbRzMltcSXFrtVs3MPdFvDkqYw74I6AhvbU1xp99phVpp7aO4DbRDBdRTXC5BB3C3LAfEg0ya3sI7Kxmju+8upWcTwbR80ozg5Bz6deufZV8uS5MMRbBZS08dzJburbFgljjlVsjhmZGU493nTJId8sptoJxAXYwrIRI4TPAZlABPrxXWRRbo2/LblwpUjyYZz08sfCiQ0/RNiMdQYEpDlFkgZt7KxbBOOhxwfTGeciyS9pf9blC0gZXj76GfutymQJhXKZ5ClgQD8DUxjte8kkjjkWLIFvDctuLsu3cJJFCjA58hVy7sNIitWmtr4yzg2zCNnh5SUMWwE5yvhz76puqlIEPegCJWQEfN7m5Yr+Z9nsq+Pj7Q+KaIyRJc3M0UIm3/AMkUv3HlmNSyg/aPfXTcyH5iPabUNJiJ9yxy54DyDcTu6H6XxqukE8vfvHGWjt0DzPjwRqTtBY9OTwB505E6HjknPuqTlTHLiCONVdOVLKrZz4Hxkpn2eVVW68dKJ3CqLOTmXassLKCB3YY5B59SPwoXWeSwe0SFJNM7ZylQZLfS7N4iQDtLajbISPhkfGh6kwusiZVSRx+qaPdk7a4udO7bxQQyzSvpdkiRwxtJIzfpCBsKq8+Rpj9nu0JDr+hdW5BJ/kU2OBn9WorR9ndRW4EBcbrm1juVgI+mVmiMbKPuPwrNXVyw7yJfpKGV/YRwRzVfSLuS0uUOcbWGfLjiiPaW2WK7hvoR8xqUZkOPorcLjvB8eD8azz7jt+K5WdmJMYOc5UfaDVIg9fI/+1XHB2fBh+NQbcpx12sf2TWON6X8k2reiadHqmpWtpNI0VttnubyVMb47W2ie4mZN3G7ap2588Vcubi51Dd3C/JbG3VjbWVu5WK3hUZ8WSCzdN7HJJOfYKOj3402+S4dC8DxXFrdIDhntrmNoZQp8jgnHtoxJoMyMr22raJLYuO8iuXvUQhD0EsABlDeoCmuuPPqk91LcaRcQXR72WxvLNLOeTJmjhnjn32+8nJTwhlHkQcY3nNFfIegAq9qMtgiW+nafIZoIJZJ7m6cFWvLllClguThFHCDPmT1bApLUDZThR7SPwNKuyKXKIPRm/AUqbDX1MZOTwftpd77PvNQseTTd1RU/en0rnen+5NQZpbqCfvW9PvNLvj6feag3VzdQWO+b0/Gud8ar7vbTd1B29vGtrS6mUDekfg8/GzBF+81KZ0hjbcQscSncSc4C9SaEao+YbWP+n1LTIceoNwsh/3al1CdY7W6c4wFzz780hWZu/4UtAgnuLcW07d07xMWDclSVYYC1RX+FXQIAy2+mFFJ3ERrsBPTJCqBXmUj2VzrLyX7uto93m5eIZkEOedoHOegqPVU0cXk/wCiWnew2Rdy9wG71jsG8sGA881pMeo/9Llhnw6XK3uNRn+F63HTSZP2sfnXnejactyJp5Le1uIotyNHPcXMDhggkyDbqT7B6k+zl0celgNC9nGbhJdr5lvIJI1IZ+Yn67QpB9/trcmjfn+F+P8A6pOPbIf30wfwuxLjboiqRnBEmOvXoKxz6TFMUktbnTLaAoMhriK4TI5y8sxwMgjgkdPhVQWCFSTqunIMsoEkVshbDmPcvPI64Px6VrwZ88b/AP6XmAz+huB5983n8K4P4XyemjeeP54/urB3Vx2dC3UEdvaLNzGlxF8okCOrcvHg7CD5cY5qpbPokIHymGG8IlWQl2vbctGBzERDxg9c9azy44suvR/+l8dDo65HX59h/wCmur/C5AWBfR0HlkTEsB7MpXlt7H3c8se0JsLKEUswTxHwAtzgdOanux2fNppzWB1AX4RRqCXRheAyc5eBowCB0wDnr7PFhX0VpurpqdlbX0IxHcRrIoyGwGGcZH7hVkXD964wMCKM/azCsh2IJTsxoYz1jmOf7UztitEJB3s3sSEH47jWKrOfwg6s9tp1vbK2Hl7ydscHj5pM/ax+FeZaZayStEkeO8nkjhiL8KJJWCBmPoM5Puo//CDdmfVzbA+GAwwY/wC6jBP3sao6azQJFNGgeSBxIEPngEVuBuvdkpjcSzaVIs5DFLi0lmj7+OROGMUjEK6nqOc+/rQuPS+15ihs59P19bBHDTQQ21y0eCwzJHFjuy1a267SRB4Jr6OJxPNbxNNjZ3JACHPsIGenUH1obP8AxYlFtcMoh+XMWgjU3UcjeIruREboT0PANbnSf1nbXRe0q3GY9I1KFvnSkj2tzbhQqk43bCOcYHtPtpp0PVREs82manEHmMWxopjMDgMZDGYs7OcZz1osNOuJr2BrDUAmlG4toruWOSaSbT4pXCGWeKXxbc8BuVzgEivWdPttI0WKNbBGBeNTJcTSvPcTjg7nmcnrnOBgeysZPbXlfV9PFE0TW7xwlroesyovhXbbS7Rt8IBfuwPv8zRWHsL2tmxjs5dKCOs+oW0H3O2fur2STUSG2kk5UMMk9DXBfE+dTyS/7Xa8pX+DftRIObG1iP8A2mrRsf8AwRsKsw/wbdqVZVdNGKuphMlxeSzdxG5z3kaRoniXkj8K9PF2x86eLl/Wr5Uea6h2H7VmFLDTrDTxptu2+BWv0+UXFxja15dnCgyH6oyQg4GclnCSdi+2dojyXGhzyqg3FrWa3nx7dkTlz8BXtAuGPnXTdMm0543AVPIfPF/3SW7RbiH7xWlUhl2sAQE2EZBGTnNVdL0fV9ZuEttOtJp5GIBZVIiiHm0sh8KgepNe9dpDN8iF7a3d3byWsid8trci3SWKdwm6XIxkEjn21jr/AFvVrW4TTJpZb64JxJEs00lpCjpgiRVKtI+Mk5IA+9df9J6W+y9x2f7MO2lWS3mq38kwGr3ljD/Io5lyio1xLhRFHlsn1OegwCmqdubezF0Y7mxRY5lghFqVvZHJcpvaQMI16E42+nPNZG6uH1lfkiEWdyd/yZIC9vb3Yl8W2e3DMhDkAK6nggAghspm4bSWOWWae+gjjlt+4drcsZgnh27AVC+WPjVyQyn9obeG11u9a32G2uJBdwFAFUw3AE64C8Dr0HTp5UahCajocsb2hvZbNlnt7dZJY3kYkRlVaLxdCTj2VmLgxkRRxl2SIBQZDuY48ya0HZpld7i2kPzdxFJC4/qupU1Iv9UHsLno3Y3WB5eC4vjz8YjU132ZjGhnWLeK6gKwyvNbXLbzEUna3kQkqrZBGRVf9ER79q9le074OMR3JIYA48JFj516H2Zj0+47IXGhXcNzZy3U2vWltb3IL3ESxsJmDMUUZXIz4R99MJyuvJLPR7y9/mlJycDAzUt5out6cpaW2JhP+ORdwA/rcZHxFb3sVEsU+p20wDPaTvBnH1lYoSPsr0EW9qyMTD3mFY7FC7nwPoruIXJ9prGj53ijUKWZgM8ZJFPDQg4V1J8sEHP2VvtW1ywsbuaK37FaRaXWXMkutKjtx1cpEoT7GNUV7S6pcSRRw30tsjjPd6FpNoir4SQokZEbk+fT3+VktOmStmia5cuwCLCVzyfEWBxxSrZwzi9QSdotCtL5k4gupZl07UW8gLlrbwuOuMjPtpVnl+O26xY9iY8mm5prNyaYWo2k3Vwt1qIvxXN9BJmubqiL00vRUxcCm7qh300vRFfUGzcaDH+vqiP8IreeSq/aGUpo+oEf0L/cjGuXcmdR7PL6T6hJ+zZuPzqHXVkn027ijUuzpIgVepZ0dV68daT2V4tYi9fVIVs4bea7eVo4I7tbZ4WdkKYZbs915nGfPGOai1F7tru+F5FHDdxyNFPDDDFAkckeIyojhAQYxzj864sMAvu5vnlgg7/FxJFGJpEj6kohIB+2qrdHxyDjBI6jNbqNDpF9bWlncqxmWZ5y8bRw3Dq5SJNqs8EqDGeDwcZyOarT3Ul7PJ37oC8styzRI/ewRJDIzrvmAdsjgFmPT21YsbbR5LEvNcCG8aedd01xdJFwQEYrDGQVHn4gapd3bl27zbiNLl5JLO4LmS3RNoA75nxkkYyOhrp8BODTIVt7pItchW1kR4ZJHaQRd0ZULOo28KzBVJwfTHnStIb2G1xba41tayRu0cMiuplGDlkCoyZOcfSHUDzpi2mmxaTPeLLf/J7iKESwvHB3u35QQvdSNEfDuXlxtBI258mgW1uDEktrHrrWzQqqNbyRlAjqjlDsA88Z4GcZpmJqzdXOoWqxu2vzz70mgZbNe9aNdqlxMHCAeQPJ6eygSJpRdF+VXgJZQP5PFgZIHPztag315DbsJ9FvzDEjC5Z+9VXG1e8M2xwuWwN5xQuTVdLnaFIdOW1fvY8PbLHlj9HayyFxjz6Z49tLJ8SWhuoq63c6u25uN7DzJBJNE9X1DW5tL7P2l7Yw21okInsJUV1e6jEYhDsWkYdPRR1ofrClb+deMhLbPGBkwoelMvLfSo47drHUJbuWTImjeya27o4GNrGRt2Tx0HSsNR7J2RYR9m9CX/4ct9rE0bjcGeYeptlP7OfzoHo6va6Ro0DKVZLKAlSMEEjJyD51eimxNMc9Jrcc+yJT+dc6ry7tJMZ9evWJ4N1dN/5zD8hXbeV4tpX2Gq2rnOt3mevym5X/AM1qsRgYWugt3l+qWVzMbeCSREyneRRsA/QMQR5daAX81lPem5lkdAUhaJI4V2JAEi7vuwTjAG7jAxtxRS6TfZ3o8u5kP7IzWemD99aRxI0jG3s5IVRSXEjxq7Kq4Oec8YqaNLoVzpi61ZG0e57ie2miukaNe62PBOLgnBJ5UK2AcZJ9K1Wm381zY6Qzk5axgz8I0+PlWC0p7yLV7NZu+hlkuoxOGDRzbZWLlCMDAYnJGB+VavQHLadpPst9v2KR+VSjWtKWeIck92owOvHurg1CzTgygEcEHg59OarwzrDd2Uj52LtLEdcA44oWvZ8sxJ16QpucovyKJiFYnwsXY58uawrQDV9PX/Gj9pf31Kus6bn+dHr1B+zFBYuz0IC51y+JB+paWSnGc4zsNW4NAtIlCrrGsY4P+SDoc8fNH8a10gxHqVpJjuy75/VUn8qtCSOeDvEzjd0YYIKnByKEppKDG3WddB46XMSfR4H0YqJovdRuod3yxYtJy5JOSWI8/Wlz4BvacM3Z7tKEJDJpnyhSPWCdZCfurzfVZrmO91DvIxIl3FEl6YgS8DG32E7BztYHOcfHyPp+trv0XtIufp6Bqw/ZhMn5V5XraxPrMbySFRLY6ZL3iqWaPfaocAKQfvq8Srun3F3eajprz3ETbJIrcSlCI32yrMsYZVBLEhR4QcDJOPPHB5WILMSX8R9hJya2WlpaJeaf3Lu5NzaK0kq7ZOZ0yvidjjp51jSMMR6Fx9jEVrkT0mUGj3Z5yl7Cf6y/jQJORRzQx/K4ceTL14xzUgnvNNtmuLphDf3JFxKWttIS8F0dzHnvXt2hCjz6+ytF2TZrW30pU07U4oIdf7Qm5W6Bea2gOkRtumYRoBknzUZxWYvFtpL2+Zk7XPuuJiws1UQFt5/ms58H6vHStb2OnS10DtRCiX0YkvbsFdR4ucHT1+ngAfd6Vq1n0Edj7t57/W5yMG5mNyVHkZHLY+Ga9BiuSMc15f2GY/Kb8f8AYx4+0Vt5tRt4JRBuBlEfesoDsVTOAW2KcZ8s+lYxoav7DSdbtzb6hCG4IjmTAmiPqjflWN1PR9e0RC0fc3mnhgFvVhd5IU9LiFCOfbg9K0sNyHRZFPDBSPceaIwXpXjPUbTnBBHoQaTleKe3nVvEHXvJtT7xZDvCxlNgJ9FOT91KtvP2Y7OX85uAstq7AmVLRlWKRv1trAgH3Uq6ecTxGGuEyfEOtN79P1h91ea/xgmyctJ7yrUv4wS/0j/sv+6uGt49IM6frCm98v6wrzj+MEv9I3xDfurv8YJf6Q/fTTHovfL6j7qaZl9RXnn8YJP6QfbS/jBJ/Sj7aaY9BMy+o+2m9+nqPtrz86/J/Sj9ql+n5f6QftCmmNdPKDqmincPCuqt9lsoq8ZYyCGG9GBV1z1Xr19nUe6vOZ9bn761nVwwtzNuAIJKTJ3b493X4VN+n7gvFDGXmmmlSCCKDxySyyEBUjA8zRRLWew8GpyyXWnTxxSt4gpAwW64I8vd09OOKAS/wd9qCHYdy7lg+N0a7jnJ53/lRHVNQ7R6NBBc6rpl3awzyGGHvJIC7OBvxtRyQKFfx2ODhbv2eJf+Kt+TOLMXYbtSsTK6RruaQsm2GXhj+t3o/CoU7A9oI2O6F5FKlWUCNMg4PVZc01e2shyF+W/tqAB+1Xf47Tc+K8/bX/jrXn/DFg9jte7vuTZ3hiEZhCCfwd20gmKY7zGNwDY9RVV+xOsFi36PuSeAPnY+gAAGS2ad/HaXzkvP2l/465/HaX+lvPt//wB1f8n8Z8UDdidd8tOl/wBKZMf71di7Kdp7RpHg0tS8kMkOXlifG7zG48H2g1L/AB1l/prwfb/x1w9tJv8AObsZ9rj/ANVTz1cM1Lsn2ku7yW4hsyUkSD6UkSlGSNUII3H08jRvQux8OnSpqOtNHJcIQ9taoq92r+TnyJHlxgdefIKe2dyf8sucehMn5Guxdob6771oe9m7sIZWWNiV3HA3VnyVv3uN7sxwM4AA8gBgVFHNhrsk/wCPjH/kRmsGdevFcozYcdQeGHvBpq6/eus/OD36lvb80iA/dWFQdoVEeuXhH0WuXkB9kgEg/GpoiCqk9MdfIe+hmp3Ml1ILhz4wEUn128DNELTE1pOAfF3RIxycY5rpPSIrrUbJIbmLdl2ikQY6ZZSvvoTLDcz/AKPeIFmNimzDIGPcbkZY+QSQOgGT+RO0vLK17z+RxZlx3j/zhIByARIT92KsXk9jdW0yxqobvFniaErHLBKOGZAMDDcZHHIyDyQZqhmmLci5srvEhhhv7FXmYeEO0iHblvPFa3QOLOyXnwTzxn3B51/IViraNA6k3qRmKSNnjeOfw7GB6xqV8q2WhTJPatKgYJ8unkTdjOyS5bGf2uacvSRppv8AJj6oaljPAqKX+Ztm9C6/nToj0rCiEZqdG6VTRqsK3Sqi4hzipnbEb+786qxt0qZzmN/bgD7aCLUiG0zXAfPQ9YH/APVevJ9VWFtS0wzyd1FPpmjNJLsL92ptUUnb8K9Zu1EtlqkRYIJNJ1GJnbJVBJAybiB5DrXml1aWs5tzcXNk5igt7cPb2mXKQxiNfFNIR/4asuL8d0mBJtSiisQLhYbhXjcjuxIY/GiliCQGI544UE4qi3YHtm948TRWnds5c3guoha+LxFgP53AyeO7o5p17ZaSpFty5Ur3krx7grHJWNYwqgHAzgc45zji8e0snk68Yx4x5Vby1Mee3mn6po9/Np2oR7J4gjDawdHjflZI2HVWHT8jwDmhKBNvboqkk+gHNQ9ob86pqiSHn5Law2g88nc0zcj2tiuGb5Fpd7MDh3iMUfTO5/AP3/Ck9Kil7QzncRBFkliubnVgCMnGQt4F+wAVF/GnVUtbizt0tLeKcTNM0McjTO0qhHYy3EjvkgAZzwOmKz24gYyftrmeKbUyNt2GZRc6m5+gkEZOPQZNa23JVWkPEs7G4mPmXccD3KMKPd7ax/YtG7jW5MHmMRj4qSa15POKgv2si7DF5xMSv/dv4gPgc/b7Km34JoXbSH9Id0D00/vXHpun2A/cavs1Ki9Fcsvn5UqoBufhSrKsMQmTSwlVe+HrS72strW1a5tX1qDva73tBOUFN2Cmd77aXe+2qHGMez7KaUX0H2Cud57aaXHrQcKp+qv2CiXZmzjftN2ek2j5u8EgwOMqjGhhYVoexY7ztHpY/V7+T9mNqIO/wpxrcx9lLHvFRrnUZ/EwJCr3YQuQOTjPTz6edeW3en6Z/IRp0txm4cRiO+MYm3CUQbjHEOFJIK8ngEfUy/on8LkhWXsvtYqyLfyqVJBDDusEEedebWNnf63ed3GyK6o9xcTuEiSKNPE00rKAMj1J+IHNdWYe2l2sKyO1/wCFZGhJEMRYsGKn5szb8cfqio0021kUul9HtGQe8S3jIIGfovMD7sUWaOKTvUs9eurueNWZxFcTiQhAWd445okVgOSQsuff1qBbS/mhnuYtXuJIYBG0jkSDaJDhMAy555HTyq4BItbN2VUu8sxwuYVXJ9vzlRmCzyB8pBycYEPOemPp0cjtSsEd1e608MU+75KsjyxtOikqZUULK+3OQDsA4PPFQXEE8DLnVHCSL3kJO+ZJUzjekkR2kdRyAQeCBUxevX0Mms4oCBJPgnO35sHJBwRlXIyPOlHYmRUdZk7t5FiVzgZZm2Dw7t3X+rRBrLUTcRWvywm4mKLFEI5XZ92cAbVI8vM/Z1qX5BJuKw6jDLcRAuwt3t5ZlK8kqiHJx/VdjxnHHDECBZuE3HLELPIyxYJWGFtjSEscYz091aLs3bNGuvRsQdjaaAw6EP3sinHXkVn5Hnty1vKsMoR+8j3ASJ4gG3xsDyrcH0PpWo7IB7iLtBI7Fne404uTjJO25YnjioAWtxlb6Y/1UwfP6IobE7AtuLHoeprQ9pbcw306ekUL/txhqzfRveBSpFtXVsqfrDHJ86I6RcmKQI3kdp9xoOPLmpw7I8c49cP7xSKu39v8muZUGdjfORnn6Lc4qoQD5fjRoqupWigEd/EMxH9YfqmgrBlLK4KsvDBuopelVYztklx5hgPgc1sOzcqRxS2cjgSKW3qvLxiTxDOfrDr7xih2kaBfXiXeoJGwhtiN0xGEiZhuGCeC+OfYPEfIMMllns7v5RbgoqeEHn5xQere+l7R6rbzRyxtDN4WyCSv1W8mH9U9R+8VIUkhI3DKnlWXlSPUGsxpGsW2oRoGfu50G36u4E9Rg8EH0/A81oYbm5iUqQShIzsBkQ+4HxD3Efb1OFW0k8s49tTK58ycj2D8qqreDziX/VkflUyXh8ogPdGf3UF2N+nWrAcAc+XPH3VQFxI+MqQPcFH31Df6pp+k2xvL+Xw8iCCPHfXDgfQhU+fqeg/GjvaK/W20qW32lrvWW/R9rCgBcxnDTPgn6Kjg+1hXmtwLK1XfOiINxUAqSxYcEBeuR5+n4xXfaLVdS1T9JtL3ToO6tYoyWit7fn5lQ3Ufrcck592ntT2d7TW7WmrhbO92Zt7tAzL3ijyA5IPmM5HqRmrmjIHUNJH+Lc//AEl/4qQ1DTSQqQSMx6AxoAT7fFUep6FqWlXZhzDPE+421zA6NDOgzyrNjkeYxn2VHbWhhO6TBc8eHkCnii1bxsWGcckseMDJOTUt7dw95Da4LYUNgAFVPkTTgywRlsFmIO0L1PuoRucPJNJ/Ouc4/VHkKt66VPIyDPA+wUOZu8kJA4zgU+aUt4R8fdTI18QI5x1A5OPZUkxHoXY6ERWR3AnvpTu9oxjFE43vTfS27Qh7aQGWzuIui7dqNBMP1s8qfTPpxX0EKllBtIIKgg5655zxVm501ppJpIdWvLK3uS7XttBHE/eO4w7W8rnKFurYBGST54oH6WyT3GsagrZhklh0+0cfRkhsgQ8in0Z2bH9mrr3MQONw+2s7qesWunRxWdmiJHDGIoUjJ2oijA5PPtJ8ySfOs4+o38xLd4wz5ZP5VNMejLOjdCPtpVgbfU76MEd4WGOM/wDOlU1Q0XC+o+2ni4HrQLe/6xrveyfrGtYD3f8Atpwn9tABNKPrU75RN61MNH+/9tdE3toALqYeY++nfLJvQfbTAe73213vaBC9lHl99OF+/oftqYDfeVq+wPi7R2x/Vtrlv/DivOxqHqrfdW7/AIMbgXHaCY4I7qwnbnHngVZDRD+FfM+odm4FPPya8b2DLqCT9lYzTozBZ9pLFpUhlvrSFYpmbCtHHLuKs3kpOFYngZGeMldh/CJND+m9OLuqhNOYKWIH85Mc9a83nnk+VTTI5VkdwjIcEKPAACPUf3552kF1nS3ks7h9Nt7BLORJu8Vx8ouGiUhIo8dd31zg+8dDRtSjWF8zLbEooCvJdtFJGWy3zcIOGqgbiU4IEaMTy8cSI5+Kj8MU9L7UVUKt5dKBwAJpAAB6DNNXBe/Md9crfJaTXtrLYW1rbx2spQ2c0FssAR1RW4UjcBgAg9eTijO4ht9NschriGS4ll2uCqNO0YWINnHG3J9rVTkuLmUhpZGkYDaGkJLBeeN3XHWuRTTxMDG5XGRwBjB4PBGKbDBmOVY7i4gZRFe3GnXlvFLJdC5y8+0KgfoCVDJ1+tXYv0dGbQx6bdWktrNDJd3txLKBGsTIxKp9HecMAPaMewR8tvBuUScMCGGyPkHqPo1C00rhEd3ZV+iGdmVfLwhjioie6lSWQOoIDCRgvB2K8rMqfAYrYdicJZ6ux+td2i/sxSn86wuTya23ZEH9HXpz9K+UfFYR++k9l9I+1J73VLtgOO6tlHwhQVkG4KH3itt2hjC3l16iODP+pU1iWHhz6OfsoHVIjAZVuVbhh+dQbh613cPWoCNnctayhGPhJBU58qNTfJJ4Jbloldo1BYDg4z186y29SNpPQ+E+lX7HUZLd1ViCvTnBVgeMEHyrUHq+ihe0fY6bS9MuoYbuIrI8CBYo5NrbmilK+LD+bc848uKx9x2d1iczxDTbxXhJWffCw7tsdAQMH4EjzzVHT7m80u7i1TQ5SjqwaW1Bz4SfEEDHBX2ZrSdq+2+sajp721nbyWFnKvd3blv5TOh4K8fRQ+YBJ9uODajzySFbW4cQyndGSu+NgQCOuCOKMWvaPV7dVQmKYKMAzKd32qRQLvEHp91d75B/7isVpqR2s1P/ADa2+2X99O/jVqnlFaj27XP4tWV79PX7xTvlKev3ipg0rdptcb6M0UftjhTP2tmhz6hdvcC5uWa8YE4M7AzxbuvcufL+r09MZzQv5Sn9yK58pX1++rEau107QtcWWWKdre5iUtMYo1MqY+tLbEjcPUqcj1NVljjsO8/lUNzOSVha3EghjU8b/nAGLnyGOM+Z5GeV3kdWg3LMpGySMkMh9crzReCW9juLW5aaAzQsXPeQl+8byeRc7SR+Vag0QuLfS9A1eyvohNe60lu9rA/LWndbtt0/PBGfD5k8dBWZ3Iq5bHBz6Zp1zcFnkmnkaSSRi8jyHLu3TLGhE93vJAPFXSJ57gyE88DoKpyP7fdTDJmmDLHmshAE8nzq9p8e64jPowNVlWi+lxfOKcedQbGyU2saug/k7HMiDnuXb64/qnz9KWsamlpAwDeNgQoHXNPilEEPeEgKiHdu5UjHII9Kxur3UNw5ltmkAXiSGRldYR5CNh4sew9KixWZpZnaSQ5YnPPtqeNDxQpbm4U/SBHoQPyojaX9uzBJsRnpuJynxNTBeSE88UqKRQBlUjBBUEEeYpVBg6VKlXRCpUqVAqVKlQKlSpUCr0L+CshdX1WT9XTyP2nFee1vf4N27u61t/8A4WFftc0gX8Jkok1uz9lgn3yPWG5wfeBWx7fEyX1nJjxGN0zgZIAj4+HP21jWV1JUqwZeGB8j6UqcSGcD30vT31zDjyPNc8XmDUb0799d5++mjI5wD7xXSWB+gAfdgimGuHrXPOlzXc+wURytt2UONOn9t/J90MX76xPNbLsucae/tvp/uigrUSpe0Uu+9vyf1Yx9kKLWSkX5sn+/QVo9dbN5f/2yPsUCgUsZET5x0JBHQ+EVAOpUqVAq6GPTy/CuUqC1BdywkYYlcjz86N2+pxTARyFSDhWV+Rg+tZqugkcg1dB2TSrG4zJbymIuzMqMNyqpPA9apyaNqCZKCOUZ47txnHubFVY7q4jxhzgVaTVZ1xu+6grtYagv0rWb4KT+FNFjfn/Jp/jGw/GiQ1f1LCkdWHq330wU00rUG6xqg9ZHUfhk1Zj0mFMGebd6rGMD4sf3VxtUznAPxqu+oSt9Hj30BIfJbf8Am1VAoGcclkzzyecjqPjVae9RSQmCckZ8qGPNK5yzE1HTRLLPJITkmoqVKoEOSKmVT1NMjGW+Bqyq0HVXNHdLjwVoREviHtNHbPbEhdiFVBuYscAAeZNZFrVbto4FgjAZyjSspYKNiYJ3E+Xl7SQPOsrHEe9nBx4kaRW6BkPiBwOMHz9Ks6rNObhZGdHS4t7eZBGQVWOQFkUkefPPoeOo4r2s6mRYkfZJGxeyd8BQ55aF88bW5xnz9jGrhKjVYoZHjmUhG4D7QzxMD1wTz6MKlmPczSv3ECqQFSMMXjUsuVli3NuI81JyOa0cXZnVtbit5rWwgsojF85LeSSRNLLvJLCLBbjoCFAI9vNXE7D6rHEkcuo2BKb1QiG4cojghkUnaCpznkcHpjzi0A0/Urm2HdqYJQUD90ZVCqWx4lby9GXyNKja9jNg7qTU4e7Lbyq20nLgbQctL+VKmwxgqVOKOOqsPeCKbWkKlSpUCpUqVAqVKlQKt12BIQa3ISFCxwbmYhVVQWYkk8YHnWGo7pDzJZahCxKWUjQy37Idsk0ak91ao3rI33KT0TkZrUa9DBdW41Oyc3RaGJhLtPdQ+IgNGhG4EYO3PXBY+VYnuhzx7T+6tn2d1dJpJ9KvxGIr52NntGI4pGAUW6DyUgYT0I/rcRy9n7KO9urKYTblAuYHjcoJLdjtJxyMqeDx51N8q6yePVY8R7iWPn09g9aaUydo+Pu9K0up6L8mSD5HbXk8squQQyGONVYDDeEcny5oQlvLCxju7eeOVuU3YQscHwjcMHPlzTLF2VUCKu5jjbFg+oZ/JfzP/OimhabDdzGe7kWO0SRYXmmQvAk8wIj784OEJwCeevsqOWzbu4oI0ke4aUJGq4JmllbAAXHsxnPQfbt7Ds+scL6XcyNA3dxPYyzhhZSXGD363OzkFjyjYOBx5c648f258rIGHSNTSQW0Zs2YEbVtr/TxF71PeqMfCqcmmWcl49rNHb3l5BFLc366c0U/cW6bRtaZSFaUE5bbkBep8PFW+7K9pY9Q7pbeybfuaN4tSsjDtXqWkeRcfECjFj2fTSsXE97Zz6hlGtYdNndorBh4hdT3aAIWTnwjIwTnrx0nbDI6laQxS2kEMKpLIu8gM5yHO1M7yfQmjGjyRQpPax52w3T5Y9XLJECcH3VQn72aW+1SQFBcXJs7BXUq5HALhW6BU49703TJSWvH/XuWY/HmsfVWtYbddX5/7RvwocYiLRCfrLIwz6dB+FXNTYtJdsOSS+APM46VNeW/dRJDyTDbpEfayoA335rF9jK0q7xXKoVKlSoFSrp8q5QKu1yu8ev3UCNcpZpUCpxAxkVwdRXT0I4+FA2lSpUCpUqVBPAMlj7hVoLVS3YB9p6N099XlFSiaFMnHr19ntrmqXJWOOzXrxJPjz81X3eZ+HpU0O1N0jAlUVnIHUhRuoHLI80kkrnLOxY/HyFIJjcZiiXxiWIbEIxgxli32j+/SjHZzTIriX5ddqGtoZNscbDImlHPiB8l6mgCKzsiL9JiFX3k4FbmweNbS1ijVkWGPuyrgBg4J3E48ycmraNfZXskbBJGyOqn9ZfUe7zopJiWMlTzislbzAgIzYwcow6q1HLC7bmKU+JTj/n7qwrKdobq9tLiOFWZC6tIT6jO3g0q1+o6RpmrJEl3Csqxv3iHJVlO3acMvOPZSrOLsZVrSI9QPjVeTT7V8bo0YN0BUHPqaInxsUUZxjd7fZUuxIwWOC3mfyFehAM6LpgyWgiGf6tcGiaa4O2GIgcEqBx78UTllzQ24ultrix2ECWWZEZc8GJjht35VMFefQNMVGdkZAOPAzZyTgBRnqfKhVxoMyDdFlevgkIYj3kD8q0cTNe3TSKfmbF9sasMiScryx/sg4HtPsokVjkTO3HkQecHoRTB5rNa3MBPeRsB64yv2ioK9Dms0lIQBQXO3JA49SfYOvwrMapY2q/PQKYtxBVSfCIeQHcnnc3LHy9lZvSBlnay3U8UUa72d1RVyAGY84LHgAclj5AE+VE7meJQltbnfbW5J7zBX5RM2A820884AUeSgDqTmZIfkFqItpW+vIh32fpW1o4DrGR+vJwzei4H1yBVEJY9PCvJPrWLXfhxQl5R4gcOfoEcFefpA+vpWsm7Rw3Wn2VxL4dW0/nJB2XCsNkkZxz4xhvYRWa7mV3zsOOdoxzx0rrWVy3CROzYY+Ec46knywKka5ehM6rqdvfXFzdoXhucKkUUoMG5QNjRkZGFBPvzU0msW1zbh5bZNkE6GJpGbmYDJVR6AYJ9pWh8Og6qVysAyy+DdLGBk+Zw3QVVuEMktvZ2gMiIywQEDHfTO3MmD+sefYMfq1vyrnkxsuztzYPcyX/yRkjhRrYPHJLIrM+GZcEZIUBT1HlWo/TOkFdrtIq5wRvlHOMZG5T0zn/3rHWFpMDBYWcjYjRxvDuE+bUySztt5xwW6Z6Dyqx30iQ9+Lm7Nupw0/eJGzA9diO549fF9ld5048u6tzixkleVLm02MclJIh3w56MVAU+tRaje6fZQvM0kfcyMtspibvJGY5LBo8BcEA55PB9tR3L31vIUa4dg0EM8fze4tHIgdC6y5KnB5GTWY1+7mnmt7d2Qraxd44VEQGWXD+LYB0G0VbyyMzj25qlxLqF7aw26OxghjRUUFz8qucMwyOOOB/o0T1HT7fTpo0jTZC8cPdSbTsldEVJPEON24EnzwwqHsnG4aWXycSTueclYvAoPvJrYpdyRxBBz58gdfjXn8u3TGVtdMe5k+W3StHYxv3kSsCsl26nI2q3IQEckior0F+9Y8k72PxBJrRXMkkpLOcnGB7PdQC/IS3un6bYZT8dpFTdGKpV3FKtIbXa5Xf+dAj9X3VynMR4cegBptAqVKlQKlSrtBylSpUCpUqVAqVKlQdBIII6g5FE4W3hWHn199C6t2UhEgi/XICf2+gFSjU6LbxyNK02NkkctsM/9qhVm+APFZG5gltZ57eUYkhdkb24PUe/rW4tVEMcaL9UDn1PUmhnaax71I9SiXlQIroAenCsfwqDO2MqwXMUjMV27wrgA927KVVyCDwDgn99aUQT6bLCzyLLDPFErGFi0UcqZUrk888FSPKsjWn0K9guYpNMvXwjIFjc/UC/QcZ80/A+zjpMvVSjccm7BXpwRRa2lLqvOJF+ix8/Yaz6Rz2cr204wyPtB8j5gg+hHI99E4WI2kHFcrM6anbUWd1uUh8hl4IPUGlQ2Bu8Gd21wMEnnI9uaVDFVUWFT13HrVS4m6jPlT7iYDODQyWUknJ499dkcmuFjR5GIAUZoJFK0lw13IRuXJhLjiM4OHx7Bk/CuX9z30jRg/NxfSIP0mzwKk0tJL262uoENtteTA4cnBVfjjJ93tqarR6dCYbaBSu1iC5DfS8ZL+LP1uefbVqPnvvTcD8SozSBwCfQdfbUazQxoS7jcxLFVySM8gf3NUcm+g4BIMp7hT0wCN0jfBeP9KglvHHfXk1yVSS3t5SltE4LLPOm0guv9HGCpYeZKr9clbt7J8pURq8iJsZG27QxDnL4PlngU2KV4FSOEIiKAqqEUgD/AEgeazeyYnTSnkE9xJtA3F7q9vpBFCrMdxLyN1Y5JwATz0pncaKo2jV9H465ku+v+z1G80sm3fJIQpZlG9gFLdSApAzTSQeuT7ySftJqZG/OrHyO3naFLK/0u5uQ6vFDDcmN5T0KL8oSMZI4AzT59NuprW9tVjlikk7viWNo3DwksYpdwBHtz5gDzqk5iZSjl9p+koeQA+8A02SWN3Eku6Zwsabrh5JDsjAVVO5ugAAHupkTyt9rGlPeT28ltdQlYoAIATuV5sZVl9w+jke30p0Nra2k880kLAOvcWPyaINcrM3ErqGbHCkDp1PGNtCrlJrqRpnvLrvSAMs4ICr9FQoAwB5AYotZzoiWypdCB7aFYUkuDIWbOS7B0RsFiSfiPStT+pyv6XLS6s7a4tp7OSe3mtV2oVsrdQVHJLlZwSffz7ulX1v4kZdQaHSkLO/dyTaSAO8XHISPcAfPO340HWKFlYLc2DsSDlbtR68FZFX2edTTW7zNbiGKIxQxxgBbi1cuygZJCy45OfLpj1rd7c507cNFeTT3E9/DLMxluLqQTyIWhjUu6iKSNfIYGPWsvqptXso7qOMG51C4Mru27e2ck8E4wSfuFGNaWe3s5824glvz3EQbwjuFIedlPPGQifE+lAZYglxpVnnebeNbicod2ZG+dIBHHoBWOVb4z61miWwt9Okcf410t0OOqW48R+LE/ZRH6opxh+TQWdrxmCBA+P6VvG/3mufVFclRSDrWZ11+7spR5yypEPaMlz+ArTye7yrH9o5My20I+ojyt73bA+4ffSJWc881yn7TSxW0RmkBmkeppUCwcE44rld4rlB2uUqVAqVKlQKlSpUCpUqVAqVKlQKiOjwCa8DEZWBDN7NwIA/HPwodR/s9sBuM9S0Yf+wQwoNCgwOTQLVb55X7lGwsjCNVzhSCcZail7L3ELoThjlSfRR1NY+4lMkrNnz4x5Vn2O3ds9rM0TcjgqfJlPnUUUkkMiSRnDowZT6EUWwNSsvW6thxjqwx0+P4ig3StDbxXker6fGw/wAMtoyiqDl5YkBdox5lk5K+wn4T6fdCdFBILgLnH1gejVibW7ntGLRHkmNx6q8bbldT6j8yPOrUOr3Mdys5CcyyvIEULvEpBZQB4QBjKjHHxq8u4k6ehxtjoeopVVs7iK4hjljbcjqGUj0PkRSrm0oTzZzzQq+uu6TCkGR+FHFSXFwqK0jHAA9aHWtjfatK0x+at8le9cEjA8ox5mutFIFpGWOMM7FjgIpLOx6kAVq9Kt5rO1CSDE0jtK4JyEJAAXjrwPWp7Sws7JNsCYJGHkbDSP8A2m/LgfnOxA6UkDWaQ/SY49Og+zpUDU528qiJqjhrhrpNNJqIaaYSeacaY1MUxmNR85qSltpg4OfxpwFdAAroGenmcUQ3arEbhkDryRx55Iq5b6bb6irvaNsKZ3xSXA3hfJ17yIZU9c59lD5pEVW/o1bHXiWQfV9wqCz1G8s7r5VCoeTupYgH3FPnFKg4Uj6Jww58qbhYk1Bz8ptrZHzHp0SWaHeu7vMtLKSF4+kWHuWudmLcajrcbOMojLNIOuIYB3mD+yoqmxltrW4kd3eeVHjVdue67wgvJn1xkfGtL2EtO7tda1Jh9Mw6dAT5H+el/wDSK51v5IPXDF5Hc9WYmoSeKfKeT76gd1WMu7KiDgu7BUB/tHiohNk4A6nAHxrCatMs95eSK2UEndoc/VjGwfhR3U9YV1+Sac/eTShleVMhUQ8YjbGcnpn2+tD4rCEbVIDlOGY4wXHUqOgA8v8AnVkSgaRyP9BXbPHA4qZbG5bqoUe2tIsEKDkD1xUE0iYwi8efOM+6umAXHo+5EdnJ3KrDaMDkV06XCo6E+9j+VGbNt9laHzWPY3vQlaikI5piBPyGAfUH2t++k1nb96g7sbWK8Anzq6xzUZyWU+YI+6pgrGxiCKwQdMHOT4hwaYLaL9RfsomwzAx8xK3381WFMFf5JF+ov2Cu/IoTjMYxkZxkcVaBqZOSOKYBzWEClcJ1yp5PUGu/o6I/Vx8TRCUDA9Q/4jFTIvAq4BR0pD0B+BqJ9KYZ2lh7+a0AUelOKjGeKYMg1rcAsAhbacHH7qiKOv0lI94xWhEoiubhWUYYI54zwPCfyqwbW2uFJj2n1Ax+FTBlKJaLN3V4sZOFnUx+zd9Jf3fGrE+mBc4XHu4qlNbS2xSeIllR1bOPFE+cruHofI+dMBzW2k2IzIwLJhmHKsqYwfXPrWW6mvRRFBq2loVC5mgIUn6rsvn7jXnjo8bvG4IdGZGB6hlOCDWYqezuGtp43GSudrgeamrWqWqxul1EPmZ+TjosnXHx6/bVCH+cX21oIFSaB7Wb6DrhT5qfIj3URm6VSzwyQSyRSDxI2D7fQioqoLaVq8mn97G4MkL+JVzyr+o9/nSoTSoNbaaZLfOtxeqyWqHMUDZDTEfWk89vp/fJ8BEVVUKFUBVCgAADyAHGKczYz7KhZhzW1cdgBVd360nfrUBbNA4nNMJpEimE1A4tTC1MLVzNEOLUwtTCa5nNA8Gnio1pwqiUYNNdiu1VIDSA8/qIPpMfypA84/GqF3dokbsD4p+E9RAvT9rr8aUWLeBb6Zi+VtLcBcZ5bzC59vU1NcNEg2xoqKOAFAAH2VJajubGBfrSDvX9cuM8/hVKd+cUEsDrkZAI9oo1aX8unxKi86e0peWIADumkIBmQ9fTcM80Bh6ir9xk2MiD6UrRQp67pHCDH21L6Ucu3CHbnkny/Ksdq941zcyqWzFCe7gTPhG36TAdMk9TRrWrwQTuoP8ANqcc+ajisioeWREHJZgenVjxz9vNYgKWEeFeUjDsAwIHIJyqD4Hc3+jRSJQq+hAqvAgWNAOA5Lj+yo7tPwJ+Ptqd8eGMfW4OP1eM/b0+2twNZtw3fVB8P9YjzOfuqrISSTVmTnjyA4qBx4T7qqJNPx8ij/tS8f6bU1+c02wb+SY9JJf94080EBWuKniX31NtzTkTxLQNA+YuB6SKftFVwmQKuhfBcDHB2fjTAlBXCeypo0ORUgSpVQ8cUFedMd6PQoaniXKD3Up15l/sI331JDwo48qoQWnMPCfXFOI9KRAx8SKAHMSLtc/XR0/Aipoz4iCdp8mHUe+o70bJoX/VlX7D4alIwQaz9FxZQ4CXAGSMK69GPtqtcQmNt4XcuCGU9HjPVSfb/fpUsZBXa3Kn+/FTKcfMyEFSPm3Pp/f+/rRNoEggMtnuzC5762zwQG+knwOfv9OQ3aqw+T3i3aDEd2Dvx0EycN9owftq6Y5beQFPCwffCfIScZU+xvxx60WvYY9a0mQIB3hXfGD1S4jGdvx5HxrF6HnaNtZW9DmjsUgZUYHngg0CIIJBGCCQQeoIq5aTYGw/CpQR1G3F3bi5jHz0C+MDq8Y6/Edf/agNaG3n2OCcbW4Of3UN1Oy+SzbkHzE2XiI6KfNPh5eykFClSpVR6S56++oHepn6t76rSdK2IWbrTDTj50xulQNJphNOPWmGgaTTSa6aaaBpNIGuUhUDxTwaYKfVUydjsCAnMxKE+keMuePZx8aBO5vbyNF4R5ViQAcLHnHFF7zpJ/8AJTn/AMS0J0r/APMLP+23+4alRpp2CqAOgGB7hQqRtznmiNz0+FCz9M++rRbg5IoqoDXGjQt9E3QuH9iwIZc/bihlt1FFY/8AD7b2affke/YtPixnNZuDNdzEHw7vP0BqCxUs5cdfqY/WPgX7zUd7/hEvvf8AGrWk4Mlr7bm1H/nCsgyoAOFxtQLGuOm2MBM/HrXAcvI3PBCDPXgYP4mlF9FvcfxNcj+if7T/AO81bCqOboKn/v8AdUE3T+/pSiCxb5l18hLL/vGrAqtY/wA1L/30n+9Vj191IjvFSR43p7xUVSR/SX3igcWUCf14H/iriNSk/wAd/aFMTzoLIK8VIuDUC+X9/SrEfX+/sqiOZSWbjhoD9xzToR4R8OlPl+nH/wDLXH+5Tbf6Ef8AZ/KgkxTSBzUh6/b+dcPQ+8/nQA9TXwsR9Ug+/BzUieNFb1AP2jNc1P6En9k/nTrb/Bk/sx/hWfochxirQxImOAy+JDjoRVb1/v51Zt/pD4VQ8YuYiG+kBggfZ93l8KVjdNaXK96dsNwwjnOThJgcCTHxBPsY/qinWX0pv7+QqpfY2Xn9j/7a4P5D7KlA3tNp/wAjvjMi4iu90gAHCyg4dfz+PsoLCSHFbPtRzpFiT1761OT15gbNYyL+cWsQE1VsA0SiSPULWWzlIEigNE5+qw+i35H31Uh6H3Cp7H/C4v8ATqUZ2WOSGSSKRSskbFHU+RHBpUT7QgDUpMecFqT7T3S0qo//2Q==
";$I4="https://th.bing.com/th/id/OIP.uMS0xXqeQzBTlRUpyfvPiQHaE7?w=300&h=200&c=7&o=5&dpr=1.25&pid=1.7";$address="
https://www.landrover.in/index.html    
	
	
	
	";$p='
	                            About Rover:-<br> 

<br> A line up of the most premium Land Rover luxury SUVs - 4x4 sports, 7 seat off road SUVs at Land Rover India.Jaguar Land Rover Limited is constantly seeking ways to improve the specification, design and production of its vehicles, parts and accessories and alterations take place continually, and we reserve the right .
 <br>  <br>Features:-<br> 
<br>price :-  1.86 cr
<br>Fuel Type :- Petrol & Diesel
<br>Transmission :- Automatic Only
<br>Engine :- Petrol - 2995 cc / Diesel - 2993 cc
<br>Mileage :- 13.33 - 13.33 Kmpl
<br>Ground Clearance (Unladen) :- 295.5 mm
<br>Boot Space :- 909 Liters
<br> <br> 

<br>
<br>                                          know More ;- 
<br>Engine Type :- V-Type Diesel Engine
<br>Engine Displacement :- 2995 cc
<br>Fuel Type :- Petrol
<br>Max Power :- 336bhp@6500rpm
<br>Max Torque :- 450nm@3500-5000rpm
<br>Emission Norm Compliance ;- BS VI
<br>No Of Cylinders ;-6
<br>Transmission :- Automatic
<br>Gear Box :- 8 Speed
<br>Drive Type :- 4WD
<br>Paddle Shift :- Yes
<br>Kerb Weight :- 2330 Kg
<br>Suspension Front :- Air Suspension
<br>Suspension Rear :- Air Suspension
<br>Brakes Front :- Disc
<br>Brakes Rear :- Disc
<br>Steering Type :- Power
<br>Minimum Turning Radius :- 6.15 metres
<br>Tyre Size :- 255/55 R20
<br>Alloy Wheel Size :- 20
<br>Tyre Type :- Tubeless,Radial
<br>Length*Width*Height :- 4999*2220*1835 mm^3
<br>Wheelbase :- 2922 mm
<br>Ground Clearance (Unladen) :- 295.5 mm

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}


else if( $type=== "Mercedes Benz G-class" ){
	
	$I1="https://th.bing.com/th/id/OIP.udlS6VyskQEE5fTuMNqTOAHaE7?w=239&h=180&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/OIP.NXWcOXkMMEsRq47aKTLQzQHaEK?w=284&h=180&c=7&o=5&dpr=1.25&pid=1.7
    
	";$I3="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADhATEDASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAABAACAwUGAQf/xABREAACAQIEAwUFBAcECAMFCQABAgMEEQAFEiETMUEGIlFhcRQygZGhI0JysRUzUoKSwdEkorLwBxZDU1Ric5M0NeElNpSz8URVVmN0dYOj0v/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/EACERAQEBAAEEAwEBAQAAAAAAAAABEQIDEiExE0FhURRx/9oADAMBAAIRAxEAPwDb19ZYxppaRTdQEuNJtsxsOQwD+jnzKKVa32iChQEfZ2Ms4vey7XCjn54uJ4I9hKsIjCvpADC7WNgSu5wwpJUU8UUTPEyBAsiE90DYix6dMX/qB4oaQw6oqaTTHGtPG8xYMYFta4/9MD5hPBR0sarDJKX1IY420hNQuXkZtgvjfFiixxxkzTFwtgXYm/c8V5Ypc0rBURvT00LSiQMz7lQI13Kt64ltWM6ZxRQSwKzVs0hMUKQoQ5AUgWHOw33vjLZnLIJaWISKTSwDXoOpRLJZ2UHy2GNBVRT01PNU/aCZhHFTamJ0ySX2gQEnYGx+eMvUwTU9RV088brNDMBIpG6gDmQNsJME9NOkjHiWRtIAJ5bYMj7ptY94Kgufd3NiLYrQpZC+g7XsyglbeZxNTyvFbSyvHa8moXsBvti4unVwXXG4Jsws1iCA52Ox3xBmKtPSiVN5KVkkJHPS1gb/ACGLNVgmpzEGAY3IZhdkYm9xjlPBSjjQ1EbsAri6lwbNcEDoT4Yi6yFaurTKnW0i+Qbe3wNxgmNvaMtuP1lBJew5mnnN7/Brg+uOSwsntFM/vQu1r7HSx5/kfjiDL3WGZkkNklLU0q/8kvX4GxwZbfsbW6oqmjLboeKnnfmMFduaNp6HKsxjtrpJ/Y5Sb7Q1FmU/Bhb9/GSyepky3M4dZtw5uFL+Emxx6dUU0WZ5dmNBey1dM6Rt0D21xsPQgH4Y1Gb4uvIyyLqQgPY7b2AF74Ns3DsLDbu2PNfHASjvrxk7wd0lU80YHSw+Fji4mKvEzxGm4C6Ao7qSjoAAOfnjLQSGonjYjUDtbfkfUYs4aj3VkjBBBD6T7vW9sVEjFUAUAkMpuNzfkee+CkZmClTcdxjfu7jnzxDVyaWI6XMytGRcJHDI8m9tmBKr9cctlxFo5asFSdatHGgX8I1McVpqZFD2Lobi3Ww8iBhyV6sivJZpEGje2o/LDKurCOSNXLR6XnVT+sJEji3S230xEQwR6jgqQupiWJ1KRuCLkbjDZIYplimjdlYbqRzHlglVYpYshtf1PqDjUKrB+kaKNaqNxw+JEVdO/GTbWuoctsQzV81VK0sxAZ3EhCDYPfVcA/PF1C0yRzRCNGhkW8ie9dgNiEIt8jiqqKeGWXXDpTiALwmUoNSi5NzsL4ntD8xqmrqalbQqCPWpRfdEjNctvvvhtE8/tEUQRS/Bfls0oAA03O199sM9kqjGwWNmjIDKeit4m/jh81LLLwwjWlCq0UiGxBXYlSMc+XtY9HyxmamihlWRDFAEKOACpTYbjEtS8jgtH7iqoYdB4b4oclzOqmENLmaj2vhs0U0fdUqp0DX4N1NueLCQVcChh+ra47rkhh/zDHns2Ok8I65ompzxNlLKhA2INrg/zxf0VHQzZUiRSKXkhSOpdWNzKouQwPI4zAElckkcTqZTMO/Le9rche2/hi3y3KpIPaK+SpmhAihQRo3dmMb++4PU+7hx/XTnfHtNmWWNNFDFBYtS2VolN31aRpJGPLc6o679J1VRPdJnkD07R20iNNlsPKx+OPWUy5eG6tUSs0olJDSMXjDkmyNfUAL+J5YxmaUrsKIqnegy8uFa5lcGRluT4beHXE7s8xj2K7O9r1tT0GbpHDIumOKo3WGa/ISjox+WNUaWGOQvGzFCGNtXuBhzVuRGPMMtoXzCSoilSzEFUPXunqNhfGry+rzTKE9nqZpquhVlQrUAM0Nx7uoDV54vzSXKl6d+mhpv0jC7R8VpEdjHGxCDQNNwSPHBIarleQEHioGQKQDExsO8eu9vHA1NXQ1IQJIRGixvxVF0Ookabc7jBjwuWdhIFBKsph2bxvq+hx6J5nhzxnsxgqoP0hUVZip0RRJHVKGZYZAR3jHvdenPrjLVPaTtJNLEfaaejjjkdYabgBuP3CweYvc2PSxtvj0Iusq1dO0bNokZZOOGIlDKGspP3T1x5zXU9MamU1MPBqOPIVSmVlRoQRbvNt6YmYhn6c7Uf8ZR/wAC4WI+BQfs1X/d/wDTCxdo9iChlVWuyoA2ptrm1+mImqNEbBY194juXHPYXviHL3mFPTrKGWRoEYiQd7Vp6jxw2saiokFTWVUcEbOGRp3Ci9wNl5nn0GO/KYkuoRFJJJUQT1TiOQ8R00iyg9A2BqorBBIaeKMtKrRKzDU9rWJXr8sUFX2zZJ61KaiSaFGeGKRyw4gB0iU26He2M/PnWZ5gJo6ia0crKpSCMRAaNwqMN9+pBxy2fTfbVvR+2ZiIKWemVWE1PIW0sHiplJBLSkkXcgXXwGM5mcjvmebSh9f2rqWfcMFUJfb6Y0VBnIplgV4AGiZAzKb/AGK3AHmfDGYrJqeWuaRjwBpVjqsFLLc732x0vL0ziGKepiH2UjqWjKWFraW2IKnEgjFldTpVx3TsdTX393HKejrqiNXho6ycuxAMVPIy2J56wLfXBU1DWRrFFMKSmSPU16qtooru1rgq8obp4Yomp6cSlZNJDDX7oIuy23A8cHSPLHR1VROGBj/VooFmAHvM3TzxHlstHC8JlzXJlMTgxwRV9O3EJBHfkJ0338cGVlFPU0dRS0/9oqXAV46Wpp2WnVWBYtExDm/IbW+e6eTWJrHmd46qaxZrpLp6qRYX+H5Yq6lSkmq+xNmPptf+eNNUUFQqVVPLSTJIYyyCZDG6lBq2B5g8ja/PGdltJFuDcd3fnsNvp+WM2YCJXaQ09VvqkUCQn/ex90/yOPSuzleamihJN3iAic3323Bx5jl4lqleiiR5aiQhqWKJS8kkq7FVUb7jf4Y2mWJD2ZjkkzmvjSokVbZdRBJ54+v20lygPkAcImKrtPQrSZ3XaRaKtC18OkG/2ptKFHkwJ/ewVS5UzxSOtIzsI45I2CSMpBW52te/jiap7b0/FDUuUwsygqk1YTNKFJvYdB8BiBe3ExY+0ZbQMBuQBoYAi3NTfEoHnpNEbcdHhkW1mdGjcNqFyysL2t5YrnXvKqMbMQxsD3d+YBxsKHtFlmYgQRVLUkjXHs9cRW5fKT91km1EfA4bUZNQ100tPHGuXZwVDrTTSs+X1agjvUcrElSeQBJX054SKzNTGkSwmOSd1bUrmeIRkPcmygM1/mMQrDNIycFC4JsQNvngqakq0l9lqI3WenLh4JDpkVwfcIJte2//ANcFU8nDsrIUVBuV5A9L3xb4JHYYp40iV3ZSyldKKxXY/ePK+JG48Z1bGzqNZW1wRvYHHY5mvJqdyrNZe7a+nnicxXUaBrEmqwYKbjn944zLWshRzxr3iuolQYzHsLmxF/54jllpJdZeNdFiHB3DHoVOIuJwgrIAigjVqNwGOwIvfnhrTmbuDhF+44LgDmdwujni6VIKnMAJDSOkkZQiMugKwsp1HUh3N8C0lbVVc88RSNaiP7S0YC6hq3Cr+WJFZoLWcI5ALEKzI3O115g4DrDPS1MNbEQGZrl0QhbixAOrr8MLJUW7z1cVSGYKVRo2IIsFKkWIHji6pqn9J8dJY3XSQRKbh2LXA0ry25Yz0GcUcySCshKzkHhzKNaar37wG4GLOinHs6utg6ssiWNzJvey+WPPeFjpOUq0yyiqWzSHhOs9FC3Fnluyyu492MhgNh19MamqrYo5qSmltrkjmqtAvpAQ6VubWv4YFoKiNqSKWFAA4eQqV5kmxufXENfNJM9M7xNEeGYwGAJI1ndSOWOU2TyXzRD2cB9T6uGsjoG21HfTfnjO59IkdZQOlSsRWi4Tb87SMQH6W+GD6mSpoElqXicx8MB3YkaZLWUW8TjK1Cy1sTTzhRIbvsNgtyQMXjxb4T7PejqoJfaKdzJqPFK6hudj73gcXsrVOY0NPJp4TyurOztaROGDa4Xx6Yy9LmaRQT087OsiC9OQB6Wt4Ys8qzqNFlSraNgFsLX7wG5sOd8Z5dPWtWMWV1ERhNHUSxzmN5KoS30Ti+xtawPjgmLN6ujkp/aVZi2hGgiQy1QR2sG+yup8Ty2wRBmkUqIVvpALEG2l9IuBrP8An5YCftTBC80kFJA8jExS93SsTgEg2G5xOn3cbjHOaNnqmhFbxKsO3EacRqrLOouTw9Sm1um+MhmuaUtRKyqkhUqDFqsJEJ2szW5D1xyorVmBkjnhWUvq5srykG2nScVUrrLM4OkMSNQUBbFiCQbk8sevj49uLnF8z/EMLHfZ4vEfxphY1pj1DM8/oMtpKWedtVSyaqWCMajIAPfboFB5+OPN62vkrqiWprZDNr1CNyNobnXojG9gOgxDUVstVJBNK7yCKMwqoGlUXUSFA8N8CXjVxHJZI5ns7aSxjW9yR0v0GHLlrfHjOMSyPGDbWZEVg2o3Xu78r2JwyKbSNXCLMoJjKse4G2vvhiuryS6GHDDExmcLqdRtpA3OJYyyEaZI0VNmUjYc7klgOXrjGr7FUkntYnjk1+0MQFmsVhhhAZpXm2A7o72wvbFZNnTLNbKoY49IWMVtREk1fP01AygogPRVUW8Ta+Dq2oU0WYGGUMhhhpbgd7XUSDVqIHgp+eKqgiCrLOwHd1KhtcBnJhB+AElvXGuPK2bWbJoxFqqzTNmtZW1SBdRjeplYgk9STot6DE9P+j6Zy8eXUEtlbWlVGHO595T0PlgZVbTKwLcMHSDeylvDfbbDDqsQmk8rkN3jfmCMaTBjgTszrDEqke6hGhfBVGBs+lNHmcqUjPH7PT0UIMbFSGWFQbFTf/PliaKN1lpWDMiPIH0qdysX2jX8tiMVmbymSsrnY3ZphGSOpjUIT8xiy0sizy7tbmcPDpq8LX0jMq8KrGtk1HTqjkI1Ajn8MKnyiqr6rMaOkVXqFnT3yEjjTW+uWVuQRRuT5W5nGcp0d56ZER3d6iFERACzsXACqPE9MegZoUyyOtyqlZWra5hU5/UxnnueHRxsD7i9fE7+ltt9s5PpUyVlDkMctHkb8SpdTFW5sVtNUHk0dKD7sfh1PXwGecySMWdzqcklnJLMTuSb74tKXLqzMJZlpopGWBQZZFjeRI9WyIQttz68h87CPs2rCMVsmYgxggmKlWMFSb2JYnAWmU9nchWGCeRWrpJUUh59owWG+iFDa46XJPn4V9a1P2ZiancJXP7VJPQpIqXpoLaQXZgbm9wLg8saLK6Ps/Rw2Zqxool4jyVFS4WMeN0YD6YyWc/omavd6Y1MtPEgFNx2RAiRsFROGAWKi5sSwPji1IT5nmGZRhqjJqV0KjQzyxQSKOmhgocYucrnnzOAZXWpwKiMl8oqDPHNJDKo1CPWm9jy5YpqV1nDBld5GkWOJYy2p2I91QvMn/PlaJlU0bJMlRw5opV0iMTVCpIq8XTJJDGUFhzsTb4Ykir+OqfNssqXajp5c8yxWjlSWmglmqYovehHEF9QAum/QjrjMfp7LjtNksIBAPey5125jeKTF7JOaLP8ur4SFizemhnYqRp4wG5BG3P88UPabLDRZrVcDu01UqV1OoRiqJNcsgI6BgwGLmkI532dJUtQRRlfdMbZlCR/eIwQM97MuLGKwsy2WumU2YWP61cZx6WuBjXTdpI1lRQTqKMbA2wIy1AJW2phzSM63UeLKtyPjhi41ft3ZaQW/tPlatpWI3/5oxiVZuzhQqiVoJN9SeyyEEi22kjGINySCl7Gx2U2PgRhrKqkXRRcX3RR/LEw1veLkpuBPmCgqF+0pQ52Hiko2+GOyHJJ0WNq2MIANpaOpAJHIkKSL48/Grmu34Wcfk2JOPVp/tZ1/DNKPzJwRrJsryxu9S5tl67D7OU1kYv4h2iNvT64MoI2hh4L12VMAxMd6s2UNzG6A4xC1tcP/tE/xkDf4hiQZjWj/bE/iihb+Qwvkev5RXUkMEUclZR6kd9hUQkFNVwbhsNzjMKmWaM0MQmZQpEiNTsgK9CA3L4Y8kGZ1XVoW/FTgf4Dh36Sl6x0h9VmX8jjl8ca7q9Cnm7SVqiCqp6gQhi90iLqWtYGw325YBnpKpYhCUqbWaO8kEisL9bWxj0zSRSCscQPjHUun+LBCZ3XL7hrF/6NeSPocPjn9bnUsXkVNTxw1CNIzcNW4ayAamuCBe/I4DSMMUVHiJcIrHUQocWB3PTEK9os1TnUZyo82Mq/3jbEq9qatCNVbKLG/wDaKKBrHxuUOL2fp3/i1SnEUclnkW+pSYnuG0e8QN+vLFjFT5VmMjxOajWsSaPZNJkUFbESCNAd+t8VNJ2zro2vHV5axbZhJSRRFhe9iwQfni/oe1sUkkS1lJBTs7ArVUgDRsehdfD44x8PndL1PwZH2MyOdYzprVeMHS1RKg1sW1XOnmR0xNJkXs0WiJaJ121celidyFNx37Xvi1GYNcXOtiAylE7rKdwVPLBImim0llII6g28twMdLHPazfsU/wDuaH/4aP8AphY032Hg30wsTt/V7nk+VZZPXyyKxlSmC6XlCqw4pdRpCMQdtzy6fDDszyZEeKLKq0VpKkk1RSFQ+vhkL7oBv488XtRmJWdKPLFp6g90a2ZOFsC8jIY2LEC1hvufXFVmLNm9a9PDSVEau8Zlkm0qI2HdHAjBI6Ane5x5OPPleWvXeE4xaLktFQZMYqmBZayFHb22FS1Y01wCKfSb7ch6YEc5XRPC8mXKaUvC8ktRG/tHFeLhhyWLIAPAjcsfDAmYfpPJJoY0qkqJmog0DxNqiFzvBLHIbK/Iix64EyyWp40gzeSRFnRFUKXEiASE8R9dha/K4t6YvbZNtSXzkiz7RvTZhlkCUUcSSQutVNFCQCIUDR6iqqALX/zbGaggkOWgoTtUmCW1rrIvFkAPqGuMXcM2bVlZop4o0jptaPJIBHFKVlIKP0JIItv88TCkygGtgfMafLkrNHEjrS0acWBiY5aecAoSveFiQbMR0DY7dKWce21y6vm90UBnqJIFp2k+zVrhAbEkdbYYGQWGg3JuzG4Y26ehxcyZFJIyPRVuWSxoth7NVJMzbWv3HLX68sRDIs5cqixPLY21ez1wAvzAYwaf72OzloSnZpZ2kkCKgVVLWsVQEM1vLSGviiqH4uuQkBnZj6BjqNsayTs/2jWCpjjopy7xCPVIY4YxxDpazSlTZVuDddy/Lu3NanY7tPIyrwqRWkYIl6qJrFjp+5fFw1L2Yo0ooqntFUyLGlOXpss1RK7zVZHeeJX7vdBsCQbE35rhyNLUsI4ZlqK+vqlRVKlJHnlbSsXEB07352FrHB+YwLIkdJR2ajyuI0NGNu+sN+LORb3pG1MfK2DuxuUmIjtBOheSL2lcriK91TGVi47X/aZtK+QJ67Vlq4cnyXs9Q0tHLHT1VdpaWslkgV1eYgF5HaQgAbgKByFsGxJRScFfZKBYqgVEaVNDEYpIZ4lMhVrMeVtx/TGdzWlrs5q6yggrIqanjMqTS1I1mrd4xxRMkbCRVUkFGub+enD+zgzemy6uhrogZzW1gp3Rk4LxyR6DULoJvqLOel9uXWYij7RTtJPR5ZTlU4hM9QVFrnc6iB4WP0xT9pIIsugyOnRFWSYGeQ2HFZNNl4jWvfe/xxpamgpoKuSvmjknleyvqmeOyjpHp2HLwOIszyLLu05pKymzOen4ERh4U0CTMjrbZiGQ+H+dsXNNZrJp1pUmrHRm4auIrwyPEzNs0bvGRp1AgXv4+OGyV1ZUN7U8sjCMpCr6jZdC3SPnyA2t4YJzLJK/J6QRTustPK5WOspZ5RTllYOInp7A8U87MdrXG3vV9QqezQQUkzSBqkiCnEb8WdnH6wqt973XxPQAbY0001fUpVZT2Xqgw9ojcM66QhCPY6lUADSelthy2wZ2poq+vgyCahhklnjinhkWN1VhGxV1tqYX3viukZZez3Z+A8QyUdfLRXliaGRHjtrTTckWvY772+Vnm9TmdNRZeKJkeRZ4r61u3BtdgwBAtcDcH4YcfbNY2hWpqaiWIyVCxUytJWPGftrC44MOrkxsd+gBP3dzRWyl4I8tXgQQRktBFOtNE0nes2sOrsRsbliSR4G2K2cSwRNxiEknqppNCBvtCoCksxPIXNh54gViQe8PAi2LVWXFjrIVjqpBJXBJZIahlCuOF3hTyP8Af1AEqT7psN74qpmVit1+6APG3PBlA9WagLAb6mj43ui0atqO5sbeNvyxVzSNxH0jYWReXIDnjNRJaM2AUAkgX22wY70TK6+yRAlAquHk7rAKNVr2PI/PFSskmtb+vLE4kc9L4SCYwUrc7A+jfyww0cLe7LGPVyv+IYbrcblSB54uciyZs2qJuMZUpaXTxxF3ZZXYFhEjEEAAAs7WNgPFgDcTVR+j5Dsro233ZYmP+K/0xw5bWgX4UhA6hSfyx6hD2H7OZpTTLQSRwVfC1QSU0s09Oz8wX4xOpTcauRHwtjzapp5aa3EQxOZZo9GsHS0DmKS5ve2od3b8sZvi5WgTUtQvvIw/EjL+YxGYW8FP+fPBgmqU2E0q26CR7fni9yqChqKITVwaWWSq0o2qoDCIAlgNKFCbC4F+tza1j16fT77kZvLGV4bjcC34Tb8sd4kybCSUX6a23HzxqqmgyG0Zp9UzHVrEdZRQNGBbf+0Ob/58cDfoyILMsMedoJV0ycOnpKtGANwDwXvjt/j6n0z8nFn+LI2zFW8pERvqRf64NopQiSSi6RpLFDVRi5jKzB9Mq3OxBFj6jlbAdTGkNTURI0jLE+jVLEYnuALhoySQQbj4YNy5DJCIzyqsxpwQdwUpYpJWHzZceSyy46e28ynMc4rMrggyRKSvzGknZZqaeRVL0uknWrM6jY2PPqfDBJq/9IsIBk7JM1uZp6lXv12Cu2O5M2XZTE0lNCkUs3CWVkuCzCMFt/W18XS9oF6s3wOL2ymqT9If6Rv/AMLVH/cGFi9/1gj/AGm+mFh2RNqig7P5+ITDw8upo5dPGKTsZiLDXpeOM2LfTph69k6vW7fpSOnQm4SnFTIwT9guzr8dsPk7TUlzp4regt+eBm7TD7kLn8TW/LGZ0uPH1G71OV9joey1LF7+a1bAsHZUjiVSwbUG+01b3wb+hMoJ1zzVtQ2lkvNOl9LXJUaEG2M6/aOqPuQqPUk4ibPcyYbFFH4R/PG+2buM93L1rTx5P2Xh4JSghJiuYi7yuUJ2JXU554Kp4chgKqKCljQAqgigiAUne9rX+F8Yhs0zJv8AakegA/lhhrq5venf+I4ZE8t89RAq1CQ18EQLExyJ7NC0KWGyRsN7b7Nz8fCvWpRsualrs7kerJlSWrpJJRNJckrLDwFKLzHdIPL4nIGrmPvTE/iN7fPDWrdu9M1vIm2KjVjMo4Kamhatqah4kTVK9KwMhXa7F5U8t/64HbN4Wp65o4SZ6OjllWpvCjl3tBGDHCSCbtcG/TGTmr4VU7En4D88T0kxmyPPplHDMtbQUakN91FaZvzGJVHZH2cr80XjieoipqVgrPAY11yKRdI3lBU2+8eQ8ztjb+yx08VFS+x1LxtLNDK0lQsUVLTxBpVlcRtvqa2lQOtzbTbFUma5JNBRQUtasSU0KRQR00g0R262F7m/vHnhjy5swvBW0zqSOKojZiQLktsxF9+q/HGQTU5dkUcBzKogiW7JXM5EokWNO8JJNZ1FjYaQR1+YqQ5pmcT1tTV1VFTKnGioqRjFw43fTH7RKvfLtzO/Q2AtvDmkt8sjVleUcejqKxSzFnjaUSMhK3Nh3R+7h0n6TmSDRVcScS8YQU6slHMACOG6XJtbkx3B3/5SAtZI4imSQu7QyNHxDZmlSysH9d7H0xT5RO8VTVhSQj6HsdrHcXwdm9YLJEshdYUKKSF95mLsBp2sCdjisiV4qV5zcNKSyn/lGw54sVoxPBX1c2VCEVPtWWStWLqURwJFNGYZX1Cxe5ZV5HvHfbFHm3Y6vpItVNG8xghbhwoFgrjdi5l3JD25d1ybDliz7Dh4aavrzNTRzVtWpVp1llmkpaYEIIkQctd289I2tvjQZiGGUxRisjm4Fdk6xmMuZ1Mk4d2maQB9TjVe4Gxta2GjGUbNV0fZmIwvCxkrZpFleR5DwnEHEcyDVc2O2Ld67J6StiOZvNw3jeGBYYWmczEq3uLvYAHe3XCLCTNcwnJvHQQx0SnpxQNclj5E2xk86zOnSshWUqyJqldGDEOGsoBVdjyJFzzt4YS4LXtHl8UzwSZbAZjJfQKiN42gEgXXJwiCdrAkkGwYmxPLIRQTsq2H66Z6enAsGlljtqA1kDSPHx2tvjcZF2rzNajNK6myKrqo5KZ6amliV2EZbvAsoU7EgA2B5Yxk8naSnJEsTxupIJlp0SUNcMbmVA98O7+h0TU9PAlSWk9peOeNUdVUJqOjjIeo03Av1J6Des1A39b45I9Wxd5VlZ3uWdtTEnlctv8AniAMRsdvI7fniaC4xqawAJxYRZZUzck2/wA+GKunqWgfiAIxBBs4JB+WNRl/aung0rPlsTgWuYpmQ/JgcdOOfbNQxZHmIKsrSqL76bn6HG37JiqoaLMoXWKSaSb7Z0jkSaOmMa6GUAbi6lW8LjfENF2x7IyaRPS1sB2v3IplHxDKfpi+hzTslUqj0+YxxMb6ONEyt8rXt8cWyX0RD+l0oJoRR6lhSY1FWYY44yyrHfhIjixDGxYgE32B8POa8STyNPLlk4qpJamqqXc3ctNIXCgGyCw8FHPHq8NLkdSS4rMvmlb7wlQPY9AJGJHww6Xs5TyglU1A7gqdQPyuMc+zztrW14fMsChy0FWuxJJCN/PGlpaJ4afLxpzOJfZ2mWSmU6mDHhh1W/LZgTfc/XYZh2Yp0hqJGQARxu5DC3IX64pBABzSoBCqqmKW1vHZh1x6+lPuOV8+1YzzBW/9oVutUcxx1UCyBrn3SWY89vu4AKySrGskUACHVqjghjkIAJOp0UEjGgmiLqYzUVhjJDMsyh7t8GxXZlFFS0FdOsyuVp5FACSKwLjhi+sW6+OO/dk1nGEZmdpJOZkdnPMnvG/XGgyiGzUV12goqitY35S1UvDW/wC6oOM9ZjZEFySFUDqTsBjYUcPDWtZeU1VT5dAeeqOkUU4I8iQ2Pme7ruLlkdEgS++kyN6ubD6AfPEPHk8T54iqKhTLKykFQxVfwKNI+gxdZNF2Xhp0rc9mkmmn71NQ08Msojh6STKnMtzFzYDzOKKr2h/2jhY1f6W7Cf8A3VU//An+uFgjGtNSx+/PAv4pox/PDVqqNtklWQ8rQpNKf/61OPToskySC3By+jS3VKaFT89ODFpoE2WMADlp2/w4arytErZBeHL8zkB90pQzAH0MgUYnFBnxSSQ5XURwxIZJZKqelp0RBzLFnJ+mPTWRANgu3l/XGV7as/6AqUUkLNV0sbadgyK2tlNvh8sNGOeStuyJHTiZTEDDJLNxrSSLEH08MCwJF9/h1xoo+yeZPHxJc2o4781go5JB52aWUfljGZBAHzjKuHcBVlqZdz7io7gH4aR8cet7rBEnU2Hx5YmjyXN567K8wrKD2hZhTOqiVY1TUGUOCVN99998V5q6mSMSNPNqklaJY4xuxAU3B5dbWtiXO5/aM1zmoDAh62dV691W0D6AYCcuI6NFBDXkkXTfVqZwoItvfbbAWi5L2gm3NLIoPIzTxqfiL3+mNDS0NZlvZupWoCCQZ0kx0NrGlqcKCT8DgRc87VRUnElyeIoirrnmiqELcMbMyK43tzsP/UzLq+tzzJu0JcUyNBNTTvDHGygxhSNaOWO46g8/K25GSqSzySTCwe9wUGnfx2x2DMq5W0SVNQY2GlgrgnSdiLSXU+hGFUrwyhDoVDNc3IDC17WO98QIgMl7XGkkW5m/hiK9Cy7O4qinV5GJdFWOS8Qj1aVCj7Mm1iLdbfLE9XnpMciq6oCojbQpRmUbBbk8sZ2iyqsXK6OrkgcLmFbLDSyRXDfYDhmO5uveJNr/ALPnitzKOrop/ZpzKjjcrKhVx5W5fLFRYvVrNJqdu4De2OV+YyTQezRGzTMsSW+7fqfIDf4YrVpqyeVYKKNqmbQHdYbERqfvSv7qjxJIxydoaSOemRo6ivlBhmmjYPT00JtqSFhzZuRa/K4HvbFei0WadgIaWippJaNxTxQRCQSlJHWNbaXZACR1IJtg+bOsgky+pbKIqY0dFIk1RwYxpkq7DgRoRbe9rmx226Y8gWEERxpG0kjsscaoLu8jnSFAHUnYY3NNRRZXTU2W3RvYnNbmrobrLmTrYRBv2Yh3fW564gmlc0NAsbt9vMWnqG6tLIdROMLWT1UdXJVwSlJ2eRAyHlCBpCgsPn6+WLvNsw40hAa4JJPoP8jGbqmJIPxwE9PmWaSzwxl1LOwW5iQMRzIvGA3lzxrBlxkOqPOswSoksZfaI5XR5LXO6u5PxHTGKo5ZIp0mVtLREFD4MCGBxvKWuMuQyVEkb1FROj0szRgalUStre3iRpHLr54CIZXmchbRNktcAdJ1GBJLjxPcN8RS5LPYmoyOYjq9NJI6fAMrp9cDnJqaqeSfLnqaaIS00cPFuJ5NRCkldWoA7kXHTlY7bKGiipQonr5YdOyxUqCWVB04shYKD5C/n4Y0jDSZNlJ7pjq6d78pIFNv+0wP93A0nZ+j/wBnXxA+Epkh39JV/nj032ihAsMymcHYrW06SA+W9sRO2UOPtKegfa2pIpYjb/8AiuMRXmDdn64E8GWNwBe8ciNf4q38sQPlmexb8OQjxW5+Zsfzx6RLlfZup3Wm0MeZgqYiflKob64Dl7NUqm8FZmEF+ReGVkA/FA5H93FHnvGzWDZhIOtiDz8bKcGUvaHM6Qn3m3U/aSTIVt+yyMpHzxrTkmagkQZtST2+7UOoc/u1CL+eIJMizuxMmUUtQu/fgTn53gZsPIrYe3OcKAjVGYhCRrCVrSLo1XKhKlXXltho7bZwSdfsji508WnjDAdAWjC4dPlVIpIqMpqYDbdkf8hMAcBPk+VtbTNVQ3/3sDsP4oyRjU58p6SyDh2yrj71HRP+HWv5HAebdopa+glpWooIeLLExkieQnTGS2nSxI32+WBWyINcwV1K485Ah+TgfniI5Dm33Iwy8wVZCPXZsavV52ZqdsCUAAqkmIulIj1j+F4V1oD6tpHxxrOG1JDSQXF6GkDyG/OrqBYfmzfDAGXZalNcSaZ5yUkkiUrotE2tVnkB0rGDZmubmwFhY6i6h9fdDlyXaWaQgrxpm2LBTuAOSj+uOTSvlvoax5ggYkmqJOMHhkZE4MCRFHZTw0jCgXFvPHWW4sRgd4TvpYr5A7fLlgJPaar/AImb/vP/AP6wsD8GX9s/Jf6YWIPdCMcw7HLYoikNhjG9vZVhyfL4b9+eSea38MS/Vif3cbN1vsSBey3Y2AubXJx5d21rpc1rcqhoop54xT0scHAjLiWWSSdykYS9zci1vDAQdjqYS19XPe4jgipx6zOG+ioPnjeZnOKOiq6lvdpqeWY+qKSPrYYoeyFE0VEkzoVeeeedlZbMioRSxqw53AUm3nh3bis9nyV4FPfr6iKnUdSiniv+QHxwHmQP9nqZXF3mdEUnnq1cR2+lsdlZ4ZaVlIDwQUsi/jIEw/PDZQSYYF30ix8DI9h/TE2aKseZZhEttMMzQrblaICMfliD0MxwV9GjCWaOlqIkZmg062ikZJLHVYcwL4puy5p4M6roFSWOhzKOailWSxNNPc6Y5GXu+On5YB7P9o4KGA0NeJTThmMMkSayitfVG63Btc3B6XO3hYVvaDLDE8FBXxQQSS8acGin48zAgqGe2w2uQOZ3J22oqs7yuekqKyldTeMlk22ax6YqaNXd40RdcmpFjXqxZgFXbztj0yFsv7WUEUodf0hBGA5GxkVdgwB+uAezfZZx2qy1mA9npmlrpo2BvqgF0K9LFit8Bpe1RgyPsrleRoE4jxwxFfOLvM49WJOK3sx2fytMkqc57QRST0sp1UVJI8nDca7BljBALSMbLf163xfZ72SzPPs6pqqorKYZUhjTgoJRUCFQCyDYrdjfe4sDy2xme2naOOWSLLsuYJSUoaGkEZsndUxPUgDoBdIvieosGYz3MTVSS0NKsNNl8UhaWChVIKZ5gLaQIwAVQd0E89z97bOtNAlxHpNvVV+GJBHVVsyUVDDLPIWCiOnQyOx89PTxxo6TKaDs+Uqcz4FZnCgNT0CFZaaifmJKph3WcdFG3r0gdk1JV5YiZnU04XMKmM/oiKWSONqaN9mrmifvXttHewG53uMczCsNNAIh7guzuJI3LuTc6mRiLnAlbmU0rzzzSmSaUl5ZHNyx+PTFBNPxz3idF726E+JxQRAJ62fu3Oo/QHYDHMygMDhCNxzx2mrFpmR0IBXcYbmlcK+YSqNJ0KpHS4FrjEAq2WNCdg5ZmbSSVt3Ry+OLfKs8qctukZWWItqIBF72texF/pir1KVTRyVQo9ALY4RGdiinztY/TAbuh7UUk08ca0MK1tQxijkSCMS3YG/fNree2NZKKGCkMtQdCxbzVD3ZeV2JRe8fHbHmHZeFZc9oVXVpj4khBJI2FsehdoZ6k5DPFT09PKyunF9q4axKhZrtxHdbdOTYoyOY9oKgVCLeKFYaynnjMIV4q6gYgMEJupta/Qm+9iuLTs9nNFXxtSZjeaeOKapgkgtGzQLLwhFMQOfI+hxmaWoy0aIWbKYoY9C1MVRTmo2H6xoZRrZtW5FnBG3QYKyOLLjm1Y2V1FUaBUlk4VVEI5dLHQgdomZDa5tuOXLbaDWZvXZVk9Nl0skMjyZlUVzRQxGMFYIGWO5aYgWve3U3PhgSDtNkO2r26mZdJPEpnIGrl3qZnGLOsy6gzGplWpp4p0y6CiyyMyKWSIiBaudgOQJaU3PggxUHsv2ddHmjjqKe+uTVTVEiEL7ygB9Q5W6dcVFxDnWUVW0WaUcpOwSaaIP6aKgA4MEbEKVpYm1I0oMIaN9INr/ZMOfTbGMruyDwUWYT0+ZFhSUVTWSR1kET61jTXIFkG4J5DbmR443PZ3K5abKaNXkKPSwxQ6ixJEqIGk38ASR8MFRJWxjb2irQciGcSp8pF/niQrSTC5GXT358anRGPq0YJvilznPKbKpqNHjvTVM5ilqYih0sNm7yhgGQ2Zl2NvXbLf6wZrCKkSJFNVx5lDSpChJEsTI47gUm9yF0m3XzwG9kyjKZ7mTLFaw50snEt+4ST/dwAezORzavZ53iYEgrJT0soU+DIyK3zxPQTQ1kUk1JNxOBM1PUCNmbhToAWUHw8D1wfmE8gymtq2smYZaw4UzLcypoMhglHUEA+mx9boopeyeZkBYMyo5IxusTwSUyX8dMWpfpgCXsx2livalimHjT1MbE/CTQcWNP2uiR+DW0zRSA2LR7oT573+mLeHtDlElvt9J8G2Hza2IMPPlmbU9zPl1dGBzJp3df4o7j64CbQDYkK37Ld1vk1jj1SLMqSQfZ1Ubejf0xNJ7NUgrKlPMp5hxG/l1wHkmkftL8xhY9W9iyz/gaX/tR/wBMLAFtURDm/wAgBiF6uIcgx+JwxKdZLcNKqa/WGCQr/EQF+uCP0dMi65KeKBOeusqI4wB6KWwFfUVHHhngKDRPFJE9iVbS4KmzLuD4Yx+Z9kswzGsFYmYzsx0qFnjYhFAAsjRkeG+wv4742NRmvZ6hBM+b5WrLzSBzM/wEYJxn63txlsdxRyVExGwZKQKPnUMP8OKL2iopqeFIo1ijRFWNEWIs6qosBfVa/MnbrjDdsaPOcyzWnpqOlraiOhpwDwqSZkE8x4jnWqCPYaRu/THP9a88zGso6OOqnpI6qoipzIZAxjEjab8OEIv1xHnEuXZe0UVdV57mc7xmYxmsSlgVLkAtoVm3sdr/ABwRT0/Z2vpZ6eavloaWOOeKWX22upUcojhyqpE0jX9RjkuW5PNVVEkmcNVTTyyzNDlFHLUEtIxawdyv+HEf6apoiTRZHlUJPKSqSWvlH71WzD+7iyyzOszrKbOGnnAajip54lhSOFNDzLC66YgB1BG3TEUJLltDSRRyNlGZ8OVnWKTNamOkRyltWmNQr7XF9+uBGkplBWOiyyMC1u7LUP8AN7j64tM2qTVZPlLsSzQ5jWxbncCSCJ7fTFELczig2mzOppJlmhk0MlivBjWIA35gKcaul7Y00wjaoM9LVqLCro3CSLtvYEEb9QQcYUgYhe4uRe/TzOIPVz2nqamGaFu1KGCaMxtxqCBZwp2PfiK3PwH8jSyH/R7TFpahp8yqWUajIWOqwsFAFkA5WAXpjF1Y4FVXxIoCQVDRKrEkrbYqT5Yg9qddxHHfzvgNfU9qJeC9Lk9HBllKQVYUyqsrg/tSAXxm5qsKW1MSx3O92JO98Aisn1qx0EKb6GQMh8mVtjiORld2ZVRQ24VL6V8hcn88QPeZpDdt1P3f/XDuGmnVbVH1dbhk8nxAL4kjleNgyNY8j4EeBwC4K81lH7w/pjnCtzcfAG+CLUkw608lvugvAx81HeHwv6YiaFlueJCfwuxPytfANUgXA5DD74YLL1vfmeWFqwFnk2YLltbHUP7jDgyEC+lWI7w67dcejsaXNqSKnYK0cm6sJQiuv3k4gNxfxB/PbyWxKStvZAhNvNrYtYZZqJvscyroZjTw1VQIoFenAljVxqUyC4FwCdB3+tF5U9lMzklg1U8fDkqVBCaYYIIEJVYkFwSzc2Nzbxvc40OWdn2ylYqfiU8oEqRVE0TJZ5XPuqRvpW7W+PjtmIe0WZx2SR8tqxpUqsvEopmBFwftAse+LKDtDSLY1VDmFMLEmSNRUwDbmHjt+WCB6ntVW0dV2mpPZUlilzLNW1cQJMiSMV3Q72sBY2/LFoe3GTypTx1NHU068elZw8exiQ6iqkA7bL6jCjn7MZooPtOXVF9gKyMI4t0vOo+hx2XsrlMyhooZoQG1K9HUOUDEWuqOXT6YKNqc97P5nS09Dl8sck2Z5hSJVIAda0FG3ts2odAxVV88aqdvZckp3kDMojL1ARwjM76pXAcg2JO17YxeVdnaDLayWsMtRLIYeBGJEhRUVmGsnhqLkjb4n4adZZZUKcQ8NdwWUFQw5GzbH5YDyyE0GYVeaJFUV2moAb2CY06irmjcCyzhtJYC7DuAne3PDx2cmqYqiajgrKKeji4wbMJkSmlKMF4MU0ojtJvdRc3seWJu0GWV0Mw9sqKqrmqqhYstpqdyIk1NpDOzLpDHoqjzJ2saWSnzOoNRCamauFFVwUnAiaWTivIZCRF1t3WF7Yg23+j1q6kr5aZsukp4Zo4VmmlWQtUTcTTq1nuWAJsAPicXfaKs0Zc5XnmNfO6jxjeYQr/dRz8cLIuzL9mcvqa59Ynq14lPFKVMsUko4UMLiMlNS6jqI5/C2KbtRV00NfQ0kruYctpiQkQDSzShfZY0jU9SRIxPQYDK1NUXllcoveYtzPXHIMxRO66MV/5SCR88DTTxNI5FDOgZibe0qWHwKYHeSjBKt7VE3hIiOPoVOKL5K6hb/aMn4lI+owbFWuLcCtI8AJd/4ScZVTA1tFVCfKQPHb5gj64lWKobdEEgHWF0k/wEn6YDV+313/Fv/EuFjK8Oq/3M38Df0wsBuc8zTt7Tsxq8znNKxAjmodFPAb7BX4Y1KT4E/E4yNTUVdQ16ieSXe5MsjysfUuTj0unzKlnPsWYwJSVMuqLhVDLJRVRIN1p527h6DQwDfnigzvse6GSoypW0qSZaI3Lpbc8Asb7fsk3328MWxIxDWHX8hiInBbQJuGZgwJVgRpII2IIO9/HA8gpE2aSx8Cy3+XPEU2GXhz0kv+6qaaT+GVTi17UsWzJTvvTOlz10yyDACZdmEyrJBSVZiuDxpIjFCBfnxJdK/XFnmGaZYauOeSKjlMDMUSpkacMb6iXjpTptfcAyYDP01HX1dlpKOqqCdrxRuVv5sBb64v6bJq/KMq7Q1mZ8OleogpaGkppHUzzvJUJMzKqk7KFufXEFX2uzqquEqqhU5BKOOGijUeA4YZ7fv4opaqomcvIy6ztqkZ5ZLebSljgLen9nqKE089XFTotdLUcSQO4utKFCBYwW7xNr2wDM9HDoCVAmJBMhWJ0RTewVOIdR9dI9MVzMTszuwHTkBfwvjnoo+Nz+eAJNUu+hCT4nEYnmV0kQhHRldTYEqym4I9MMCs3XkCcM6YgPkQrG92LMza3dt2Zibkm+BTgtzeI/gU/QYENsAxhYi3XCuQunSuzag1u9ytb0x0744Df1wCvhDHdsK3hgO7Y7c+vrhu+FfAd+GOXx2+OHAG0UKzx1ytcArTi45gFyf5DGspZuzldR0EUktQtTDBHSSxxpBUqphHCBNNLZjcC91ve+9rb4+kqTT8XnpkaEOBzIUlhidKaivSKxq+NNEk5lThGJS5JsI3F9vHXgNccjp52lFBX5dNK1O9IYuLNQ1QhfYx8GpDAeVkxXyZBW0Dq81DXQxxwuvEp1cqzWusjy0bMdv+mMQww5hFRo8FVxaQMVY10bcDWLC324eAW5e+PrgyLM81popgYqqCORJIzJQVEqR6XUoxXeWn3BPJR8MWZTAoo60zU0EtfSyJLHDL/akpp3WGZBLG51FJbEEX8L+WGFquklZUhmibXpR6GonpmfcAFYaoH5asXZ7QZZUKkclJQTwxokcUGZU13iRVChVq6bUenMxDBFGuSzx5iI0no6eZaGNY8sqYcwljki4kskqwyHWIzdVsEvtyxUVL57ntE/Clr5IpRYCHPKMgN0NpotR+owdT9q8102kyuKpQDvNlVUktxyuYbu35YT5TRVDMtDnWWSyHXaKpEuV1jahYhgbA380OK+s7L5nBTxxNl0iKjcRKiCCKrdgCbgzUzI5Bv1U9PDEVeQ9tOz5PDqo6imkU+7VU7AoSLHeMsf7uD6bPOzcSscvq8qpg9i/CaKByR1bUqtjDSJXCoMa1Sik/4ap01LoQPdWDMgnwGrbxOGLlftVDm9VU5c1HNSinjpGpY5dNbWTuEWmWFiym4DMSh208jfEG7ftLkFKyy1ebR1HAfjw01JqnLzgHQTbbb1H9cfPWDMKyrzJkKmeUpCGIYx00X2arcbXJBLHFPVZRV5bHRe1gRVtZpeCjb9bHCe6ss4Hu6j7o57Em3U5tEaRxp7saKi/ui2AAqf1rHxZsQlr2BswHINv+eJKnZg3nv9cD3vgGqsRMt4xs5FhtYWGwx3hQncF1PlvbDV9+Xz0t8xiS+A5wl/30mFjtzhYDbUObkxez1Kx1FK4CtDMuuMre9vEeOxGNJQVdVCiCidq6kAAFDUyA1kA22o6hveF7nQ3h7wtjysS1lFJwp1ZGvt4MPEHF7l+bSIV0sRy5f0xvUrZ5hlWR52k+ZUdPT1FbGuhoqt6qnUSgkha2CB1cNbruPMjHntXm+d5dPNSpTUWUyxnS6UVHCktjuCJmDOR4HXvjdU9fBWNFM8kkFagCR1cGky6Rb7OVX7robAFW2+OI81y6jzlIqXMVjhrTqFDV0/6ioO5+wZzcMdy0TG5v3fHCweYVNZV1ba6qpqahud6iV3t6aicQgn7qgegv8AU4sMwy2ryupelqo7OLlHF9Eqg21IT9RzHI4EvjCo9Lt7x+Zv9MLQBzN8PvjhOA5t4YRwt8dAvzwCTYnzVvyxF0xYUkCOK6ZzaKlpHkY/tSyERRoPUm/wwDp2wBZN4V841/LAxOJ/9in/AE74G3wCwlCkG979LWt8ccN8dXrgOEkYWrHD1xzAPuMd54jxLIhjWMN77qJCD91GF1+fPAct4HHN/wD6YaGwTT0tZVBjBCzInvyHuxJ+N2so+eAHvsfUYuKB4Zoo9XshnhielCVwPBljdjIpSQbBlJPO3TfpgP2VU24gZ72JUAxj4sN/ljgjkjJssZvzB1L+RwFu+qmhs6VsDs4YOJVajl03IY6boSNrHUfhgoGqlqqdo6xJpKhoEM1EGjdb6YwHQBRf4dL9d6KOsqqckoJoyefCkOk+qkEH44KhzWESRyyQLxUdXEkP9nlupB3MXc/uYeDW19kpSjCqpo6jhU6uWIUlWc8NS7RgG5N7k9fhjPVlJQRVAiC1EavHFPC0ciVC8KVQ6llkCsD497BFPn9CVmXjzQNOjQF3VpWjha5KNpUqfugHT0903xW1b1E8slQlIlTHIoTh0kzScGJYxGigi8lwALEr089tCB56x5GWmzOnmiXZIKhgq2G2yVoMV/3sTRZvneXNc000Ci32lHJUUyHzHCZoP7mKxKaMFo55/Z3AXTxYZO+xvseVunQ88E0tHmyQ1dZTxVMMVIqGoljd40GohQAQbMRzNumMkmr5e2U0qcKrkEodTY19BS1oUkWDaoTESRz3U4qa3PQTlFNl6yijyyb2peKBHJWVztqeokSI2F/dVQdgOe+IrJV5fmtbWxx2hMVPRToiQzyVrspMbcNQrKF1M1xcd3fexBy9YxM88ovFSxNOwP3muFRfUk7YotZ5aiszOorayTi1QHFqZLaV48gssaKNgqLYAdMNdr33wyPUkZL/AK2RmlmPi77kfDlhjNgIKncA4FvgiS7L88C4gV7SeqD6HDrnDDzQ/iX547fAPvhYZc+GFgN7V0FLVxsjorA7jbcemMnV5dWZc7SJeSEHmPeT8QxsEktjsgjlUggbg42MvQ5mQVF7ctxjU0eZrLG1POiSwSACSOT3G6323B8wQfPGWzPKWiZqikFuZaNeR8SuBqKvZCFYm/LfDRu8wpKSvojT1khkphb2atexqKF/dUVbbXTkBJy3s2++MPJ2ezSKqlpDDM8sZsBDG76lO4caQTYixxo6HMmGlgwJAIs1ipBFiGB2I8ji3osx9gYSwn+xAaaiDUQKZC3IE3+yuTpJN4y25KttEZKLslnb2vRyqNt5iifSRgfpib/UzN+scA9ZE/kTj09eFMiSxHUji6kjSfQjxHUYjlEUUbPOdKk6VG5Z2/ZRRzOIry6fsnnEKM5pVkVQSxpzrYADclUJP0wFS5DmVZdqalYxg240sgiiJBsdLNz9QDj1JhUVHd70UG9o0Nncf/muv5Db1xMlILKLbAWAtsB4YuDzpeymcmmkpxLRIkkyzv35WdiilVUsEtYXPTrgaXshnq30CCXa/wBnKL/JwMeqrSDwxIKUeAt6YWDxipyjOqVCJ6OdFAC6ihKW/Etx9cVjRTLzU28t/wAse+ey9LHfpbn8MVGZ5L2ecE5gKWnYg94usUx8wi7n+HExNeLHw6+mEOuNrX9nMocn9HV8kwN+7NSuqjwAkJB/u4zdZlVRRkiVJIx+3pZoj6OBbDFVpxzBsGV5tVlfZaSaYMbK0S3Qnybli0j7NCA3zfMaalI50tKVrK4+RSJuEv70g9MMFNTol2mmAMMI1Ef7x/uxj16+QOJ/Y62oeOWoDRmqYNHqRmll1G14oUGojw2tjUUH6CpPa+BSGDg0s7UlRVIlfWT1hQ6PsyViVBa7aVJ5bkXtWyZ9DXNI+Ywz01bJFFFJV5eEDERBQhaF9JuLA92QemAqkekpZCFp45nBsPb0Y6fWFGAv6k4mqK3NKrTrkR40Fo4okjWKMDosSAAfLGopM5yqqUQZ1NRZpTqiRwsaRhmOvld2mIkJPWzHF1P2W7I5fDHmmZ0TQowElNQe0zXlvurTjUbA9FUk+Y5C4jI5FRisqqdqylmmpYyfa4aNWE+hlZAys9orDZt5AduW+8lVlkVEI1qIKxlkhSRam4ip317jgFoyGA2BOrc32GNjlxzfN6Sp/Rgo8voE1U9HGsYhgZidLMNA1FV8veNgSQDeSmyafspRZjW1ece3ROY3kililNIZGYKbxEmRma+5FrDfe2JivPGpYAbq8gHTiILH0aMkfTELUav91XHih1H5Df6Y9AqaPs1mCzSGlTL5+GWE1HIGp0dgShmQaZAp84z67YyISWISM6frFUByByvuFddt/XEFK9AUPdZ0PgwI/PERgqU306vNSQ2L9FV0ZSsjaI5Xkdu/Gg5r026Dnvf5QcNDzBUbi/Nbj64CrizGuhOiSSRoyCDHP9onxWQEfTBS5jTSCZamnpdBW6LTGam4h1DuuIWCcr76Pz2nanDKbqrr4jvD+uBWoIpWKxhtfK0YLfTANr6mprI6bTFDFRU14qeCmDCKFn7zFtbMxZuZYsb/AAtiOkTuAHlI6zSDxjjuIx8Tc/u46uV1urTHFNMOTCCNyVPmfd+uD4cozYCzcGAG19bCWWwGkdyK49NxiiF354HeeIWu4J8BufkMHSUGXwH+11TyMNtLsIx8I0u31w0CNNqanCLy1sBHe3m3ewFcxkYbRSAeJGn6HEBJO/nb44tGRjfU1geegdfU4CqIQoLpcHm453HjiAZiLDxBBw6+G+9ceIOOC5AI8N/XAPwsM3wsBug4tzw4SkYC1bDDtf0xsGM6OtjzOM9mmXWLVEC2cXLqOTeY88WhltywxpQwIY4YKOkq2UgEnbF7TVrKUZGsynY7H1FjtbxxQV8HAk40fuMe+B0Pjh9PUWA3xB6BkebJTv7MAvs1QVSBJHISlqW5Jfnw2+5vtbSSdr6MU8kknFlYvJbTdhbSP2UUbAY8oStWNrm5UjS6g2JXnsQdj1BvsQD0x6j2fzSmr8siqZqiEPCxpqhywGt0AIcKBfvAq1gOtumKixSE2AtpFt7Dn5k4ISDlpAN+VuuAJ88pIgVpoJJ35apPsov5ufkMU9Vmeb1IZTPwY22MdKOECPNgdZ+JwGjqanLqL/xdRFEwF9F9cp9I0u3ztioqO01Mt1oqOSU8hJVNwk9RGl2/vDFCIBcnqeZPM4mSHnYcvDpi4iSozTPKsEGpMEbc0o1EIt4Fh3/72ABR3YsblibksSSfMk74JM1OhKhmlkGxjp14rD1I7o+JxIPb5LaI4qZb+9IRPNb8Isg+ZwQyOjYXNu6OZOyj1J2w7i0Xej4hnNrNHTIZv4iO58ziQUUbkGdpagjlx3LKPSMWT6YKCIoAVQFA2CiwHoBtjRqjlyWgqi/9nq6FWVu9SVCB9XQmD9VY9dwfPFRL2azWmJakkhq0vcKT7NUW8Akp0E+kmNoB5Y7oBB2xMNedVkwplNNXUdRG7i5iqY2ha45MpcW26EXxQu5uVYNp+7fvWHxx7DJHrjaJwrwtzimRJYT6xygr9MUlV2YyCp1f2aWkkO+vL3+zuerU1RqT+Flxm8a1rMdkcwy6gzaJqtYWiaOVadp4+JHT1TABJjGbXtvYauvljQdoI84qq6UCaSrqJKZZaSZtJMqn9Z7Onu6l8Pj6V0/YWusXoainzBQCeDEDTVtudhBObE/hc4sDV1eQU9Hl7VEyzKIy8taNSxySqGKx6xyS9ufO/htJARlFP2wpqaOIz9oYljbYE09PEkYGyqK2Em/4S3pgTOY6pYamtzHNsxrpI1CmlWqUPHHMSjGW6IyqeRPBHO1+9tySuo2l4kuX5fJUxkH2iValal3HJxJBMp9LH44Aeoy9pnkXJculq5nLkS+3VTyMxuTpnnbfzIOGBuTZjlNLVSUzUM8wqY0jU9n56layNW3KhipZ+lwSBt16WlVBS08zgNNT0fBGiSrCRZpLOAxtNRQaorHa5ZU2357Gxpsg7V5kvDpBJQ0LWOkIlDFpIBP2FMqk+G674sYOyvZbKbNmmYzVk4uWp4HYJc8wY4mtb1fDBiYeJO3CjpZJnZh3aQMQTzGqEC31GL6l7JZzUDXNTQUcAsWlqJdJUeaKbfNhi6rO1GV5TFwcupKOhjtpRpQplb0jUW+hxlq7O86zH7STimM+7LmLmGG3jHAO+fKy4KtzlfZShYGarlrplAGmlA0c+rCyfU4HqO0WWUatT0lNTwFttCL7RUv5WUYzjWkP9pqZ5+f2cV6aD5Ldz8xhCaOJWWBI4QeYhUKT07ze8ficQGzZpmU/uQcJD3g9a4Qb9VgjucBSNI4+2rJnPLRAogit4Ei7nEJkY3N+fXEZPngO/Zp+qjROhKi7H1Zrt9cRljvzv4nCJ5/yxGzgczY7ep+HPAOuTbET2xLDFUTsEijJLGwLnSPlz+mI54mikljkmjZkJRvZ7suoc7O39MBXypw3290m4/piIbah4E4JlCEoLdSbkknYYjMYPK4viCO4wsP4TftfTCwGm145r6YGMygc/nbEElVa++N6DGkA64geoC8sB8SWXdBdb21tsgO3Njt1GEkOthctIdrqt0QbA2LHvHqNrYmjs03FBSxYsCLAEk/AYZSZXmE7WAEa72L3JPP7o/r1xcUdCO6WAA8FFh059frjQ0sES6bADFwAZb2Zohpeq11BFjpkJCeO6Lt9T9camKCGGNI4o0jRRZVjRVVR5BRbDI2jReYAHO9tsQyZhEpCRBpZD9yMEn6YYghlGBpZIIe9I6r6nr4YiIrp95ZBAh+5HZpPQn3R8zhyRU8R1Kl3PORzrc/vN/LFQwT1EluBT7H/AGlReOO3iF98/IY77KZN6mV5r/cH2cP8CG5+JOJ9WOhhiofGiIoRERVGwVAFUfAbYkscRDfriQG3XFEigWw62++GBvTHdQ33wMSbeGO+GGIWZgqqzMxsqqpZm9AN8S6Y0fhSuzTnlS0iiepP4gO4vxPwxDDTbYdTsAOZPlhSRrFpFTIsJf3I2VpKiS/IRwR9/fpe2BKvOKSh1I06wScjT5ey1FafKarYcNPMLjN1PaCtfWtEiUUb31NCzNUyX/3tQ/2hPja3phq40tXV0lGPtRDTEG6nMCJqq45FKKA2B/GcPy7tRR1ftVNWwvUwwU71QqK+OF5ZArqroYkXTpAN13JFrXty8+YkksxJJNyTuSfG5wfk9RTR5lSioqIIIJo6qnlkqJFjjCSRMu7OQOdsZVs6vMOwrLqGT0s0mkABIEjW3hsLfTAcPaGio2BocpoKc/dNifomkYrKiLKFGqEzVCHlKb0dGfSWVTM37sW/jitmmowCoVXHVI1aKDb9rvGZvi9vLBV9WdrcwrA0Mbz1LdYKJeHEv/VZbKPicUM9XWSE+0Vi06b3hy+zzEeDVD9wfAHActXIyiMEJEPdiiASMeirtgRnJufPEBIniiYtTQpG55zOTLUn1mlu3ytiF5SxLFmZm95mJLH1J3wOX88NL9b7eeICNZPjhuryxCrSP+rUtvz5AfE4ISkmfvMxA66e6o9WOAYXAtqIF+WOfat7iG3i50j4Dn9MT2oYASzgnroAJ+LnbDBUzzG1FTkgHdwLqPWR+78sBwUrkapHIX4IvzO+GlqGAe8Cf+X+bNiT2OokOqqqTc/dhuzf9x/6YesNLBvHGob9trvJ/E2AGNZOFYQRSqpFi6IxYg+DH+WA+IpuASG6qwIPyOLCSS5O5PrgaQI4s4DW5X6ehwATG7jyU2+Jx0Fdr4jmiKkuhJFviMcSUX7/AIcxiCa6eOFhnFh8cLAS8VnYKrWuygsbkKCbXNt7DD2npYT9nC8rbfbVS924sbpCO7/EW54YFA5bYlRSTbpfrijsc6zspeQsbBQGPIDYBRyAHQYuqSGI77YBjyunqQLho5Dyki6fiU7H6YkSKvylmaqDS0VjaeBS+kjkrKdwfX54qL+NUTTuP5/LBCztfTEupvLp69Prilgr4KnSUeynmAe/Y9GP9LYt4SukBbAeAxoEpE0ljUSE9eGhsvxOCVMcalY1VF6hevr1wJrIxzi4IKL88NLeeBjLhcQYoKDj44cGGA9eJUkPxwQUG8cd1Hzw2KOedtEUbu3MhBsB4sTsB6nE6JTK5jJesqF96ChIEUf/AF6t/swOV7X9cNXCiWWVhHErO55LGNTept0xOqQhzEC9VUgAmmy8q7KOpmnP2ajx54ra3OKKnRoZZ0lF98vyhmjpr25VVYe+/na/LGfrM5r6uMwIUpqP7tJRqYof37HUx8yTiLjTVmcUdIrxy1CgkWaiyeTdvKqrzv6hcZ6qzuvqEeCHRR0jXBp6K6K//VkP2jHxuxxTlgu5NsRcdpHWGnSSaY8o4VLtv+HbEUQSF8BtbED1CIVQXMjGyIoLOxPIBVF8FDLZRZsxqxTAi/s9IVmqSPB5PcX64kWeCmBTL6daZb96UEvUv+OVu98BYYCBaGtbS1W60MR3CyAS1bDyhU2H7zDBMT0VLf2OnBl+9VVmmapNv2Sw0r5WA9cCtJc3JJJ33xzWOmAnlmmldnlkd3N7lyST88Ds4FwPjhjSHkMQvIBtffwG5+Qw0PZx0xAzDx2/P0xLHT1Ex2UqDuNrsfhgwU1HSANUSAP+wO/Kf6fHEACQzy+6pAPVh/LBa0UUIDVDgeAk5nzVBv8ATHJMwYDTTRrEv7XvSn4nYfAYAaRmJLMWYm5LEkn1JxBYPWQx3EEQJH35Rf5INvriFRXVgZw4WFG0vNL+qVuehFHNvIDADvpVzexsbHwOLOSoV1p44wEgp4Y4YEHIC2p3P/MxuzHz8sBJDR0anVJqqHG4ao2jHjpjG3zwRJOoAUHujkBYKPgMV/FPjhhl88AS87G9jYeWIC+IS/nhhfbASswxCz4aX8cQs++IEz9MDOBqNuWJCcMIwEdsLDrYWAO/rgiH3lwsLGoLyj6Ysp//ACzPP/29/wDFhYWKjG5T+sPwxsab3RhYWEBBxHhYWNI5jvhhYWAcMSr19MLCwF9Qf+VZ9+Ck/wDmHFdln/u72g//AE7f/OwsLEWMQ38zhDphYWIqCbrg/sf+vzH/AKTfmcLCxPsKo9+T4/ngccmwsLFEbc/hheHrhYWJRGeYxBH/AOJPo2FhYgvqH3k9DiprP/E1f/Vb88LCxQIf5YYcLCxBDUe6Pjg2P3E/CMLCwHevww04WFgGN0ww/wBMLCwDGxCcLCxAzqcI4WFgG4WFhYD/2Q==
";$I4="https://th.bing.com/th/id/OIP.TBu_h-8x9WTzBMjNekyUyQHaEe?w=285&h=180&c=7&o=5&dpr=1.25&pid=1.7";$address="
 https://www.mercedes-benz.co.in/passengercars/mercedes-benz-cars/models/g-class/suv-w463/design.html   
	
	
	
	";$p='
	                            About G-class:-<br> 

As ever, superior off-road performance defines the G-Class. The G-Class has always led the way in terms of climbing ability, fording depth and side slope angle.
They can also be found in the new G-Class: the distinctive door handle and the characteristic sound the door makes when it closes, the robust exterior protective strip, the exposed spare wheel on the tailgate, the striking indicators as well as the grab handle for the front passenger that is so vital in terrain. ... 
<br> <br>  Features:-<br> 
<br>Price :- ₹ 1.62 Crore onwards
<br>Mileage :- 6.1 to 9.35 kmpl
<br>Engine :- 2925 to 3982 cc
<br>Transmission :- Automatic (Torque Converter)
<br>Fuel Type :- Diesel & Petrol
<br>Seating Capacity :- 5 Seater
<br> <br> 

<br>
<br>                                          know More ;- 
<br>Engine Type ;- V8 Biturbo Petrol Engine
<br>Engine Displacement :- 3982 cc
<br>Fuel Type :- Petrol
<br>Max Power :- 576.63bhp@6000rpm
<br>Max Torque :- 850Nm@2000-5000rpm
<br>Emission Norm Compliance :- BS VI
<br>No Of Cylinders :- 8
<br>Transmission :- Automatic
<br>Gear Box :- AMG SPEEDSHIFT TCT 9G
<br>Drive Type :- AWD
<br>Paddle Shift :- Yes
<br>Kerb Weight :- 2489 Kg
<br>Suspension Front ;- Adjustment of the adaptive suspensio
<br>Suspension Rear :- Adjustment of the adaptive suspensio
<br>Brakes Front ;- Ventilated Disc
<br>Brakes Rear :- Ventilated Disc
<br>Steering Type :- Power
<br>Minimum Turning Radius:- 13.51 metres
<br>Tyre Size :- 275/50 R20
<br>Alloy Wheel Size :- 22
<br>Tyre Type :- Tubeless,Radial
<br>Length*Width*Height :- 4606*1976*1969 mm^3
<br>Wheelbase :- 2850 mm
<br>Ground Clearance (Unladen) :- 241 ` mm 

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}


else if( $type=== "Force Gurkha" ){
	


	
	$I1="https://th.bing.com/th/id/OIP.58cTYe305Jgjkr7zkoTCKAHaE8?w=240&h=180&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/Rb26d5e395d3deedfd53b9abd6e9f8c90?rik=rG0AqlKQr%2f2Y3A&riu=http%3a%2f%2fstat.overdrive.in%2fwp-content%2fodgallery%2f2017%2f07%2f36701_Force_Gurkha_Xpedition-001.jpg&ehk=vJRsSnRzHuys9p7mtJlnOUy1Uv9qFf7JsmqLFb5pzMo%3d&risl=&pid=ImgRaw
    
	";$I3="https://th.bing.com/th/id/OIP.Jxaibdz8DhwA1UBHqvBFGgHaEK?w=290&h=180&c=7&o=5&dpr=1.25&pid=1.7
	";$I4="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADpAV8DASIAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAAAgMBBAUABgf/xABLEAACAQMCBAMEBQcKBAUFAQABAgMABBESIQUTMUEiUWEGFHGBIzKRobEVM0JyssHhJDRSYnN0krPR8BY1Q4IlU4O0wkSEosPxo//EABoBAAMBAQEBAAAAAAAAAAAAAAABAwIEBQb/xAAwEQACAgEDAwEHBAIDAQAAAAAAAQIRAxIhMQRBURMUIjJhcbHwBYGRoULBI9Hx4f/aAAwDAQACEQMRAD8A+kANk586g5oyQCfjQk7bUhiiT61OfjUGoG9AhqqT0zTArDvXKAADTO1MABn1rsnzNFioxQBGT612aiu60ATk+ZqQx8zQ1OKAC1HzzTI8jJzStJG9MU0ANycGozQ5rqACzQsT5muoTQAOo+ZqQT60OQDXahQAeajJ8zQZrs0AHqNQGJod6nFAhoNTk+ZpYqaBh5PmanJ8zQ5rqACyfM0JPqant8qWaAJOfOhyfM11QaBEknzqQTjrUDFQTQBxJoSfjXE0JNMCcnzqMnzNDmuoALJ9akZ261AHSjAoAn7agn41xIoSRSGQTmuGagmhBp0IJup+NDioZtz8ajV61kZBFSq12qp1UANB2os0jV61Os0wHaqHVS9XrXZNABk9agGhyajegBgNGDmkgmmCgBgO1dQg7VOaAGA1xoRRYNAEE7VGaIg0DdDQADUFHjNCRQI4GiBFDXb0wGVIoVoxSALG1RU52oM0ASDvR5pYqcknrQARoDU5IoCfWgDs0OTXEnzoST50wCBriRS9R86jV60UAeRQk0JaozTALNcKHNSD60ANBxU66Tq9a7VSoAy1CTQE+tdmmAWagHehzXA+tABODk/Ggw1NYjJ+NdWRi9JrjmnBTUFTQAqpFEUao0tTA4GpzQYYbVODQAWTXZrsHFEq5oAgGmCuKEdKJRSAIKcCjVDRrjA2oqAICURWuya4tSAEilMKaTSjQABzUURzUUxEV2K7epGaAJANGMChzUEmgCSajNQTQ5oAZXZFBqqC1ABlqWTUFqEtTAIkUBIqC1CWoAknrQ6qHVQk0wDzXA0vVXZNAhuoVBal6qHVTCxuqu1UrNRk0BY3VXahStVdqoCxua4Glgk4o1oCx7dT8alcUDHr8ajXis0aLS4qdvSq8bkmmZxSAZgVGB5VANdmgCML5Co0ipzXZFAEaKMKalSKIGgCQo712nyqM1OaAJGod6IGl0VAB5rt+lIuZltbW6un2W3gmlPUZ0qcAHzJ6V4SI+3Nrwy3nPFrO44bd20U8y8Skb3+zilbLaJFw7KFwx8WeoA88yklyNJs93NdWNvgXF3awk52mnijO3XZ2FUZOO+zceotxnhvhxq0XCSYz58vNfMbO2W9kk4lBJfsFnltmfh9hw9LVXUj6Iy3suljjB2QdfPernE4Z3ns+G3d+8HNs5b6Jp4rVRgERmOSK2mEZzgnOpe2B5wfU44y0t7llhk1Z7pvaPgeFML31xqBKi24desrDzV3jVMfOln2m4OvL58d9b8wnSJYo2YKDjUyxuxAPbrXgrfh00TRWcF9xBbRHmke+L2YllkeFUVLeCWU+Hscnz32zT4eBe0BS6N5YcUvpncm0ubLitjb5iwNKyW0oZM9ScMfl1OF1uGXEl/Inha5PRXfthPb3sltDb2U8OovbupuPp7dsaSGzgMM+IY+ytvg3GrfjMd00cLwyWrxxzI7K4y6lgUIwcbb5FfOrLgXtUb2x984TLDElzAJLm4NowiheQBiMSEE+mCM42Nere5s/ZrissMTK/5ShiZIbhGDyNbuynRcQLgE6s4aMj+sKtDNGXDMuDPXUJJFUYOL8PmSNpGa0aTAVLzQgLH9ESqxjz/3CrU09pAYUnubeF5zpgWaaONpTjOEDkZqxOmgiaGjZGGxBHxGKDBpiOzXE0OK6gCDmhJNFioIoAAmhJoytCaYmBvUUVQRTMg1FFio0mgZFDk0ZRqjQ3lTAEn1qMmmiEtTBB0FICuAxogjeVXFhVaPQKLHRSCkHpTgAO1P0CuCjypWOiszDJ+NBqoCdz8agdaYFmM4HxplJUimaqTQDBtU5oM1wNIZJNcK7auoAIZot6EGjG9AHCiqOlFSAF3SKNpJM6V6KoJdz2VFG5NZct5fks0jpaRdQCyR4H9aSQj571le10glbh1lBGkl9LOtpaa2lVY5LgCSWSQRMpKoig4z1IrJPs01pcWEkkyXJku4oI/oYNJJ8ba43QvgKCfr15XUetmvRLTGP9nRDTCr5Y32l41BHZraQ3VrcyXzPBLIt/G7QlcMupELEqf0iDkYxjemjiljbWM6cPkvrjiBt9ENxFwydoo5NAUFfeRGmkdAM+tYXEuLXjcV4nZ2XDJ5UsphAPd5oo7dE30DwLjJwSe9Vw/tRNIii0sbXma2V7h3nbCAE7K3qO1PF0MZ44a38xTzJSdF7gueH2saXPCpZpebPMi3FzbwQQNK2SFGqWUnzJGfkKbBYT8S47xC+b8nQQ2cEF08c8txewQmWMqSF0RHw6RsTjy61T9x46ctPxdI0VHdjaWcYIwMkKWyavtbrw72Sv55nuJbrjGmd2mfEzafFEuY8dML/jo6jpsWO5LeU3QseVy/Ysy8VlRm03aoinCm2sreAkDp9aNyP8dUpuPWm6z8QuHJIAEt/IoOdsaElA//ABqtF7McGAi9596uHVEVzLdS6dYUBsBSO/rWhBwj2egwU4dYqAwGuWJHIPUeKUk11Q/Tenh/iSfUybpFqzuLdZbmOLESBuHsQzAO/MlhYBu5IOQKD20l5fErSMrA8LWN/PJDKDiQxOoKu0ZEukjqAfwrOWxiurqeeTI9zi4dMhUjMhEy4DnGcA7gZ/DNa3tmv/iXDH05PKuBnbYFiOvXFc2LHjjmnCPFr7HQ5NwTf5weQtbrg6IJLC8veENLlSsUi8U4XIcbq0TkTD4EGmSXHGllS7t5rO5CAQJ+To4ruzZX8JSWwdROAfQED0oJ+H8OuWLvCEkP/UgPLk+ZXY/MVnvwi9hfmW0/MIOVIPJuV+DA6T9orq9Ccfhdr5/lnPHMnyes4b7UyQZQrNbhDh/yfqvbJQD/ANXh1wRcR+uhhXrLD2is7xC2iOdFH0k/C2a6RMDczWpAuU/wN8a+VrfXrSrDxP3eRkAEEvEOZbz6sgBY7yEagd9iWxtVq14haBir8hpFkYxrxFWt7qNth/JuLWRWQdNsgg0XKHKN3GfB9ghktLuPm2s8U8YOC0Lh9J8mxuD6ECiMZHwr5s/GJbUJcyG4eUtHFH+UHjguWDtpJtuO2JWJgvXEqZwO9ew9nOL8Q4qZzJBdmyjiOi5vYIon56yaTEksB5Ui431BB9+1oz1GXCjX0kUJBq2QDUaEqhgplSTtU8snrVwKo8qLC+VOwoqC3BGagW4q3kV2fhSsKKwgFHyVHlTs1GRRYxXJWuMA7U0VOaLAUIgKnlimaqgtSsBej1qdNTXZFAA6K4JRZFSCPupgZjY3+NCBQE9fjRA+dbEEDg0wE0AIox8KQB12ajJqMmgYYNTmgqM4oEPBFFmq+ui1UUA8Gj1KoLucIis7HyVRk0gGqvE7hILNg5wszFXPlDEOdIfsGPnUM+RYccsj7G4RcpKKPORy++cfvb6bJi4RahQB3veIESMoz3VQi+lW5b9DJPeSII4OD2M051NqzPcYxnbsFH+Ks7hKueHW88203Fbi44vc57CZjy8+gXb5VncellPAY7aMNzeP8RTmEA/R2rsACxOwATTXlyvRHD3dJ/dl6tufgP2XkaKwa8ktonueKSzXU7Tcx2dJJC0alS2nYY7VeZklurmQRwxCJEtRyVKrr/OucEnzUfKlpPYW6RpzohHCgUKrg7IOgxmqkXE+GpDGGuNcjl5ZdEUzfSSNrbfTjbp8q9VSd2cLi3uaDwSy20hidA7z29kVJIYNctoVk23wNRO/al+0jpLecE4XGBy45bclO2mJfeiPsSMfOn8HlXiF2ksKyiztGZ2eWMosl0yGJAoJ30hmJ+IrNlW/u+NT3gtpxEkNzymeJwNc8qoAuRnZEXf+sa4HkWTq4pvaKv8Af/wvGDjibS3ZaZ2BYDz61572hucPZwczThWlYbjJ2UE4+eK9ELPiD7iB8Z6lWH7QFZPGfZySS3veIm3vDdpGukW7mRjggZ5ILbAZJwK7svU4mqUl/JHFjlF20UOGHiTQT3NveSLCWVLhWbWpihkRwI0x1Y5DHP4V6z20VWv+DyZccqO4wAxCeJ1ySBsdun8a8vwKe0uI+JQWazLb23C9H02lmM+ppGZnXYk9T+G1eq4tP7Pe0UUEZ4y3DbyJDGwmhV0y4AYHcD4HVXmQzr2mcZNbV9jucXoVHldXkaIMa1+JcCm4Xax3bz2lxYExqLmE6VTXhUMmcjB6Zyfv3yWTCh13TGeowB5g9MV7MZKR5couPJzhJFKyIrqcgq4DKQfQ1Rk4TakH3d3tzvhfzsJ+Mb9PkRV0ByMgEg9CCCD8CDioLlc9cr9bY4HxI2rbS5Yk32MyGDiNhLrAk5QYMpsdEsQI6NJaTgg/x61qWXFbO3fmI1xw+4LIr3Hs8zREsTt7xwu4zEf+399RuMHWu+4OrPrQSRQT7SqsnkVQlx8GUZqEsK5WxSOZrk9lw/2m4yIGnuUseMWUOpri44OzRcRtolb85ccPmVScDdgvT1xk+st7i3u4ILq2lSW3uI1mhkQ5V0cZBFfLODXUnD+McLdsGS3uFtZXKGOSSCePCrKQN8bdu9ev4ReDh8vH+GJAoS14nLPbx6yFit7sCZVUAHbr9tKN24supJqz1NQTWX+VznxWwPX6sn2dVrvywm+bV++MSr9+VqlGdSNTIoc1nfle1IYtDODjwgFGz89qMcW4ecaueuRk5jzg+R0mnQakX811Vvf+GbfyqMZ3GRIMZ88rXPf8NQAm7iO+2jW5+xQaVDtFnNRkVWN7w8An3qHAIBxknJ36AZqReWLnw3UBOM7uF2/7sUUFosE1GaUrrLvE6SAdTGytj/CaltQ65HyoGFmu1Cl71GaAG6hXBhScmpBP3UAZwbemAg0jByfjRg4rYhwNGDSAanVQA/PrXZpIY1OaBjc1IpYap1UCCNTml6qnagVjgax+L/ym4a2IYxRWzQyFf6Uy5bfzxgdO1a0ZGRq+qPEx8gBk15CYR3ckkzSBJ2llmiOXyrMdQyEHTpXh/rGZQxxx3Vv7f/Tu6OGqTl4LCcMjdFjmu7+aIIsfJluVWJoxsEZYVXK+md/gaRxC04pe8RtFKRJwi3aHVl4w7qVzKAFGvDHC48h2ro7e7nAZ7xk1kPpRLliGbfSBsAB0xirdtaGKUyNcTSDS6KqwthQxGTlm9MV4azSg9bnqf7s7JQXA+Ph/BVPhsrTfJ8UWr9rNWVhs0xpgtl8gIIwfwpZaEHGm6z3+iVcfa1drTIIinP6zRjNcPrTe7YtKHTXNnaxGa5nSGEOseuTSiAtnAHqd+1VLXjnB7y8msracyzRxCbKyArJHkKXTAzjp1qbuGxvYhbXlqssErDEEzodTqS+oZHbH30NrZWVmSbawhjyNI0yAEKcHTkDpT9SGnde9/QtLL/MjyfB0Pdj+4V3MGc6VAG5JLbffQapMnFvCMf0pHP4CpDzZH0dqD32dvxqLlf8A4FIoY4dcTTQxiBhJM0DpbvvjRmR30dOpHXy7nZkXCeFRqxS2C6tOvDvhtIx4g3XFW0D6PAsGWYyeKLJ1nvsQKo3l7rFvHa8R925dzHJO0PLYTIpyYRqycHufj8ujFi9V1C77hb4RdS2gjg92V5RaAMBbczMBVt9Ogjp6VnN7OezzyO6W8sBdcOlpPJDE3mTGvgye+1WG4uSdrqIDyCKQO/YVH5VY7C+jByBnSAOv6td8MXWRdxv+V/2Tai1uU09k/Z5A4jS/TUBvHdSIykHOVKKKuw8P4dwu1kzPdRwIZJppbmbUcPgFmKpv5Dak3HHIbU5nurnQCNTxGNtIPcjT088Grd08fLgeV3mj984e5MhD6095jYDA2x8qzlfUylHFnbpvvQY1GD1Q5KcM3s7cOVsbyxlfA8OYhKT3yrqrZ+VXeTOp06VB7DUqE/DViqHtXHazcLuboWEIYT2yJcNDGkisX8SoVUHB88n9wyeDWntTcQPcWV5FBBq0w21wHkjfRszMUD6f8HTfavZl6/Tx1QyJrw1/tHFLBDK7kqYfGLLiAW8mFrcobO5m4ik6oHV4w6TBBpzv13/q+RouH20/D+JWssl2LpeO29zKXWIQqs6sJwpAJz1O5Od+2Kqn2h/lEtrxXhS8+2d0aa2YxSROhIOll+7DDNaWuzvRZyR3iTe7Tc+2j4qHDRSYA8NwhV+2DqL1lddkhLXmht5W5tdOox0xZqsN9gfh/rQFSe2B64FCbpUGbu3nt+5kTNxbH15kQ1gfFB8aajrIiyxukkWfrxOsifNkyBXqYetxZl7kjmnilHlCyp8j8qHQcZwcetPOn7Rtvmg1ADBGe3xrp1tkthRVx2+FSUfBG2PjU62HXOe2+1RqO/n8aLYCyCOpP30OSPid8bU0sfTNLI3+NbXzAAgjJG3w2P3U6K8vYRiO4kA/ot4129GzS8VBA/2aLQGpBxlhtdRAg764QAendDt99X4rzh8wys6KQASsngO/xrzfz2PniuxjBGB8On2UtmO2j0oubIgsLiMAEjxHBOPIdfhRC4tD0ni6f0hXmlbcef2UYB9R8aKQ9TNDVufjRBqTq3PxqQadDHaqnVSwaIGkFhZqc1AqWMaAF3RB1GtguceWaAJBqcmqsl/ZJ9VzK2ekQIX5uwAqu3EZj9SOJBnbVqdsfHYfdSckhGoM0QBPTesj8oXhONcYBOchFBHpvS2muJCNUkjZU+IkhAOvbAxWXNIZq38vIsrw5AkaPkoMjOZSE6dema8rPew2CR6pIYy/6U7hFG2cLkjfvVq5mhdAkc8Ltku+h1OnSDgk18x45xE8S4hczamaOHNtbEnOwOGkI823P/8AK8LNh9t6un8MV9z1MU/Z8Nvls9yfaG0PXiVgMH/zV/HJpn5QMkCtFLE0T7xSQadJBJzgptXy3Ax5V7DgrgcCtf6txdIPLHNZv3125ejjijcfsYhnc5bo9VwC5uLmPiEUkkkhhuSqEklgjqGGCd9jmtxVkP6Demxryvs23NuOMqurwy25OhiCSUYb6a9OsIIAIck4x4nP76+L6pac0o1+Ud6pqxqrK26oSMkZA229aIiYdImJ3G2Bj7ar8gk5KSbjb64GB6dKIWrZ2if0zr+6oKVdh6UWALgf9E5PXLLUO0yo7MgGA36Sk56DYUsWzb/Qtv8A1XoZRFBJaRuEi5s4DGUODy40MrEHGOw71tS2pR+5hxQjjd9FwywlMraA0LNIRgsIFwpCjzY+EfOvm7+1lyHYJYwqo2VXldmA676cDPnVz2v4oLm6FrGpESlbl4xuWJ8FvDgHO/1j8aoWXs/GVWXiBJkkQsIDsqas7syndvwr67oOnjix+93OLLN3UQ/+LbvoLO1Pl45d+/nVmy9qJbq6trae1hjWeQRCWN38DMDpyrbYzt1pkvB+G6ce7wKCyAsqrG642wCB0OR2Pw7152eza1mikTWvLmica1dQSra10c1VY5Az0r0VCDWyI65rlnt7qPUsin9JSMfKt7hTz3vArPRyzPbm22mJVGa0nVtLsFJ3C+XevIf8QcFmcAm7iwMEywqRnOTnluT91a3A+L2UVpf29veWryvdrJDGz4Z4ZE8eA2DsRv8AGvN6/FPJGDgveTRuDSbL3tJxy8u7D3GXh8USJdQTyTW917zEqISArqUWQZJG+MfbT/Z3i9o3DbaFry3Fzb8wPDJNFHKBqJBUXC6SMdMSDpWBxG7UySIYIJI3yHCs5BBG+4cisV7PhzBmSW6tyMkB8XCA4zsSQ9U9PPlx6eoW/mJlThF3Hc1OMXIvL/iN5owk8q6CdS6xGix6vGx3OM/WP7qyHhkkuRJa3XJuW5ETiOUrIFwq50EgMMdt6l4LmNuSt9FMGVWaJpjC5yM7JMdJ69nroYnbiFqJ4XjePXKomTSWEa5BQnbyzg/jXfCChDStzEnqdnoYJeMWnLXh96LlmK6YLoR2z4YkE8xNUGwGTmJdu5NPXj3DjIhu0iimZinvVhK1s5kQZKtzNIzjcBm3ByBWNfzCK2L9MI5JLAYwEQHPbeq817d8sWnFIXeB9DLHxGNiH0Z0tDONyBk4IbG/rvyZegwZd2qflbGllktux7qG85pAhuLe61DIjuB7ndkejKAjf4PnV1QGVC30UjAExyFdat3UhTjI9K+ZRR26YPD725sckNyJ/wCWWTHOehGof4TXobO84xDbzyJecPkt4CnLjubkSc1ncgJG7eJeu2StQ9PqemVwlqXhm0seV09j1ewzv6fWHWu8Bwc+vb/Ssq04qt26281pcWt2YTPofEkLRqQpaOZDpI3GPxq2SfX5V6mBvLHU019TjyR0Oix9HtgsR3O1CTFk+Ig9j2pAdgR1qNZOxJ64ro9MmOOgZG+Pn/pQkgdPj1BFLZmx1P8AChyfKnoGM2Px+A/dXZQHxEgedKDnbY1xYsSDn5VnQIfpX9FifLpmuBYHGTj+rvVYMV8/LcUayZ/0paX2At8+LJ8WN+4o+fFths/CqOkkmhaWKMgHJPkuPvPSrWu4WaInHZSfiQKlruKIAy5UHpgaiceQFZJupiCI1Vd+oGT9+1AST4nOT5sSTU5TSGjQk4lKxPJBRNOMsFLZ881UkaWZtczlzsAXycfDtS9S4BwT9/4VAZj13HYHapar4GOAAwME57j6uOm1ToyN2xt2BH8aWrMGBxvgDcjama2O2fu7H1rFsZxjRRknbvscmlXjtHYXyp9aSFoYkLRq0hYgPo1kZwMkgb04K7aRpJZjgb4FY3FOHez/AB+WOCTimm6tVaJEtriMHJPMy0UgIPXsaG7VGo82YXELxLC0n8MsdxLCyWyyQSxnEmF1AuoGw9a8hGCcIis7bkqiszYHchR0r2fE+Dcd4PZw2sPHr2S04hL7gLOeN1QwlDJI+Gcx6VAycY6jFVoPc7NFtbcRgMoVixxLMwJbW7DY79BU1KOHbuzq3y79keXkhu1P82uAMDJMTgfHJFeq4RlOCWoKnxXl2QMj+ljrS7p3VAyyMM7ggnLBskgjAH/5d/tbazXQsLYJwu+kgje4ka4hQNESXJYgHHQg96JTc6Q1jUU2a1heRQoqQiBGaVzOyYWRzFqb6RgdRrRPE7gj66nJ0nxHpj414g2t2ZJ3l4dxJNbtINdldqcFs/0PKrCwWy5DJOhBAHMhuEOMdfGorzsvTRcnJo6YZNkj1BmtwVzbWmcgLlT1/wAVDzrcuw92sgibP9GepHnqrAEVkDhjjOMZYjPwzXNHYjB1jHf6QVmONR2/0abtHoFeyG/uFmTjrobv6aq6C7gik4tLHDDAsduLZ3jDLphCCWUjcjLZwT5DFYPu9uRkN0bGzq3Y+VIuZIbbht5awuTfcTnjiEaq7MsKgAtgDG/fBrcMUW6aMSdAcMAnlveN3iKVM0rW4kPhL4KZwDnCjb5etehhsWERvuKXM1tG9nxO8gt7ZYGuGjsBErpKZMhWJdQq6cjvUcN4ZPI0dnZJA68MsTfYlKxwyXQ8ECylvDu2WxnfT5V3DfZ32gmMFvxKWO2S5u7qeNpZkklK3kZhvEkAOFbwxvgnqO/brbT54Ib/ALnFop7GC+tndrWaJuXNMvKcaGMckUqpkalIwSux1bfWwPP8SWMsSChZogoRFnVxo/pGUlcHqfSvTSKltwsWXvkU54bcCxitraPSllCqgKwyN5JzmaQ6jjIG2N/LX0hkLIJZmGhw0UiFQgBPWTTv51bHGuCUnfJjN9YeFct/SGB9lOikEEsc6RrrRs6GAKSAgrgEUqUKCMZOCRk/W6dcY6V0WTqOdsjHy61Zq9yZs8On4fPdz82AsvIkZI5tS4IZSWBjI3ArTe3sJmEUJuYi/wBXRMkkZHXYXAz/AP6V5d2aOQOpYHG5Q4YDpsRRh2JBErMCMqxJ3IODnNJ7jVLnc+jcHg9m4LTj0PFLQXN1LFzIQ8BaZotOFjiA1aTnfIPr2rzfDbGeTiF1bQA/yW0iDocj6aRhk6W37GsNbu9iKkO23Qknp5A1pWfHrtJo5ZJWVIcnUSC522Rc771zLE42092XeWLfGw7ieli1uxchYlRuUqysCzljhSQD2zvWVHbXACrata3kaEHkKzQyqp3KiGfB39Cau215wb3rXxK3S5tnDBrVpWiLFhsysmHBXqK1Dwr2S4gv/h/FrmxdiCsHGI/fbYY6Ks0eJQPiDVt65I7HmdTRzcuRZbSQsMRyo4br2VgKsSmRIbeQzW78255MiIXWeIRskgeVMYKsD4SM7g9CK1bjgvtdZIzRxrf2CgFmsnh4raaBsXMMn0ybd9O34Y6PFMk5SFI8KgbS0hQ5kUAqr5I9dzSWq9x7HrfZuUvcX67YSzVhv53CqcAbV6Jic9a8v7KZN3xBNXiazRlQD64SYszE4J8OR37+ler0kYyRnfGT1A7gHerwmoo558iSSPP7K7cn4mmlT12/GhKr3+JrfqomAfj0/wB71wYjv8MUWF38Rx5V2lR5n8MUnlVBuDqAxkde9dnvj1/2K7I6YP3UJ2OQTv1BrGqw3Jyfl5ef20Ocdetdn1/jXAkdSM0tYFSe6EMM8sspEUMckspAyQiDUdhQrIhAIH6Ktv5EZzXmeIcetJ7e6toOWRPAsI16nkbLDU+pF0A47Z++rEHH+F827neUCSdrZAiIQQsMYQ7PhvPG1cyyOStl5Y6N0zxh0hMiB3JCqGUMfCHIC5z0wenSnSNbhlCrgHOW1ZZl2wRmvHNxjhg4zLxEPIY3UwxuYyDkRRocqT6U+TjHB3v7O55zcqCBkaRopPrFpO3XuK1qFpPUCSNfrFgcgDUQC2TgYzUJOspuEiMga3uGt5NY2LqFJ0Ab43x8q8y/EuFzSrJ7wCVuLGYpIrIcW0chwobr4m2qTxaMa8C1Yy34vGDXTROwDLKuVKdDjz7UP6gonpWv0AigKq2u6e3WRYo0IkiRnLNJ9YqMEdfwqJZ2tYufIZDGNI+h8RywJGAxA7edeOh4pJ7vyxBFpRr8gG6VWBmgaI4BXHc433PYdabNxoxxSpyITzpI5MR3RkWPkW4hAxpxp36+eaym72HpPYW10Jmv41dgYHdZC4JLIq+JlH2rj0z3rzH/AAx7N3zxi1ueJ28sscrxrIEkXTEwUsS4z36ahSI/aCe1lvQbWNjdNI7ATnSqFZQQDpxjfOds4HnXWXGLtZg6WhdooQvgcAiNpQ7fWUjcDHTO+e1FtbmkquiJ+G3PBjPbvxKS/ARBDE6yoIXfBACuxALDT0Pb02fHNc8HvDbNaQzRvHDIJeWs6XTRhmcNJg+BtQyM4wlMN23EL1b022hllaQ20ra1JtYGcIzAAkHSM/Gjg4nYcNj4abO3tlm4g6TXKQCR4FDsmq2IlLY0sCNsbda4czcm73PRwxSivmZkzGa1tLgRNEJ4Ulx48dSp0kqTpJB0+nn1rEllmAISWVQCSoV30g5DbAevpXo+MXNvMlpIlxJOrLPh5EIji0zMhhiUEMI0xhMDpXmHYHUc56+f4104+E2iU+WkX4eP+1zty4OPcUVz3k4hOAzE+bNj7cVYX2m9u4pYo5ONcVUtIocPKWwNWD4jkV51ZMNkEggsFKn8dquLdOw+nlyuN/CC23oNvvrrk9NbHIlZ6Wf2u9q7cKG43MWcnSjpFIQAfrNqQik/8ae14RpPe7eWPGxexs2XOrT/AOXXmzLbSnD8z+iG6nSOnemy3aiBbWE/yddLEPHGDlcgaWHi9axpT7BddzZn9qvaW4SM87h66GY5gtbeCVzgDDFQCRS7O94nxXiPDTfSApbl9CR4QHKntH1OcZz2H24Suys5UAkYyAMgY2371r8GupDf26OCqLzDsN9WnGAPWhxa4Q1K+WewupuGWnDL6e+4a3ERLxaMRpFdG0jhWxt0cSPIAxO7nbT59KsTX/Fr9bXi3u1ta2sKRXLWEszNJawzSNpe4WQDLS7vHtnGDjC5OjBbe8Q3luFtprwzLe8KFyyLae9SosH0wZdLBBpkC9yuKzzYSWnEeKvxSAfkWG0v7WD32dWu+IXlwY1k4jPpJfU+knJIOCFUADww0qcabLOWmWxV4zDNYT8TiuSJLy+4nfX91yHDCMSBeVEpUAkgAdvwrxtzPznkzI7AkKCRpOV26ADp22rU4xxCWeWeR9SvI0mhkxqWM+DSQfjufPpisDOSfhjPXfzrqitiEnuRKw2yevTPXfsabHJFEuliQ2xyV1Aj0xSWMZYa1ZduoIIPxGP31Y0xwCzd0DGeNp8aXDct8oisTgb4LbeY3PQUfBgux+7soDvEyuPCrKAAN87nuatx8PhlC6VAV2AUR7xhQc56d+9ZaTwbakOlSGHg1KTjoRRSXGqMJDrjGrcQSMNSEEMChON+9RbHTA0xJzY1bmOXOkgtpxnGF096FpFSIwRrGXYkyzDIZhgDlDfSVGMjbrSOZIBpbA/RBJKMFz0BO1RrUbEAeeoED5EbU2x0y3acSv7FZYoTC1vMwaa3u7a3ureQgYBZJkPw2Iqyt7wO4IFzwyaxdjgz8EuWEY75Nnd60+yRay858xnpjDDp5ihIOT22zkHH21hsZvx3JtknuOHcdt5Vijd3gullsL0JjBURuWjY9sLKc56VUjvrTK8iIW0rumswFlRo8b6k6eRrMhCtIoaMOuCXR2ZFICnOWTDf7x3rZPs9x66MU8UlvdR3fLlNyZghCyYw80cumQY7jB8vWsylp5GTCLyWSSSwlCzxZdGE6QSY38SFyM+oz8q9uzySHgd3GILqQRmB5DNpXnvENWWX9I77YrFvPY+y5EEXD7wQ3sS/Sy3LyOl1tuWUE6TnyHpjbNZ9lacX4fc3MPEIZQohlSKWzlR0lcRmQMPGNlUM3TI+dZm7VJ7iSU+5752xuM7ZwfTzI6UJYgDU/XYE6QPtO1ecuPaK3iW4hSznYTc9n50yEKkuNKgoWB2OTv6dqoTcYMyMVs8RSOGbVrkOrW7EqVIAHiONq3qrsTjA9eZIwN3QdBklQCTuBueprgwIOkjbOQPQ4rxx4ndtFEPdYNEckJRsOGxAvKCsrnqdv99NKDi9yLmAyvY6TK4kKCZGRZBrY4YkbHbG9Zc0u4nCjdBJ7E+g/wB5qCOwzvtjtWXxXiVvbRJGVkkaeKOdWt2iYaFk3BJcHO3THeqF1x6KOyMQt71XMEQikcQtGxUr4tSucjYg/Z2rWq90JRs3wVbVgs2k42HQjzoDLCo1FvDkrkKTuO3SvI/lfiTIGbYoriHRbIQwBDnWQ+rbBNXJL/iD2sKvdgO7mUiDh0YUAg41Przn0xWXkrua0HkFNrAQuWYkkghQcnG3r91CFg+ikDHmq76o+W2fFjDavSvQrBLGcSSNk5H1QuPkP3mnASoo3OxAGcZPwrz11dbr8/o9BdPtyebjS3ZYoyhZjJcSyaVORlvCB27VcURH3dGhblxvHylVcgBct4zjpmtoJM+MM3TodlBzj621DyVcqGdTqJBV209z2JxWX1Lbth7N8zz5tuskkiK6tjR4NbBsDUMnPp0pjxKxDmOVG0rGQytqCqMDAIz2rb90hILZTwn640k9evX7KMW8W+WJ7kZ0gDPYmty6tNGvZ77nm1065cl0VmU506T4CSMZpre56fo1IJbLDOyrkkYJOfjXo1t4Cyr4Om2uU6dhv1NNMECqzBIXKDISFtbyNkDQoON/srL61WnQezLyeYVZJQNHLKJCEkMjqsmRkeEt1zVmaAnoJQgZWDqpJwihSGAz8q28xYObGcZYaQ0a5I26DXTAVB0iwmxnwtysZG+esmM+lJ9a72QvZ15KHApYDIC+ZIYLn6VSGXXA4KPnv0JzVmS34jHxaeCWN2jiitvfLqOLTDNE88aiDh6tsIIwcrp3YqSSeiqv53t3t72K2mVIQ6XP0ZVRESCsjBSxON87d/SrclzxO5tkW0hEchQtC9zKzJErrnVGnY4P9H7Ky8yS1ulfk3tFJN8Hm+MTQpM0MJ+itlNuhz4mIJLHI7kk6v41jIXleOGPJkldI0GerMQATXqovZyzYF7ySeWTWSyIeWgGM6fDknO9attYWVt/NrSKFgFIk8GosRuys4J2z93maJfqeHHGo3L7HM5btnlpeBxWskaSG6kaRlRNK6I2kY7LkAn763fc7N7WAQ8Lc3EaJDI/KSOJGVcmYuxGw/fWjPdR200Vu6Ge4k1PIFwvLiJwTlsJucYArAk4vfTyvGsiJEJNVvHIqeBUYspwdzjBNYx9XnzpSpL5mVDwDbezMV5c/S3SRtINYhiliy2RnIcg477aT8aavAOCRyhXTiUvKdC/KIZG64VlMY8iDg1dCPxGbU6zmRULBicMUA3dZMY2yDjHpWnZxvbNqmad3DMypKea5VTnTqUk7DcjSN877b5y9fkS+LcooRSqtzF4j7N2E6xTWFxNFJFBFCsN5brGsjIv1ubH+ke/h+ysv8i8Vt7lZ4dhC2oSu2jJc6cxquTt28/LavSzcQv4ZppopiDArLJHNkDDkkaAgyp6EHrR2PEHnaMQxzxrFaK0zSMDCLkyE5VgpwpG3Tz+eo9T1MIa9SYpYdW5WtfaHiQhNtFw24lmXXGqmMmJDkDOpxkL3OTjfbHbO4jxi/wDxCN00trWMRjlBvFjxHwlh93l5+iluFheUMQXkVWbleCJV6M8skngx5AD1paPaXmYHgjm0BmeMssiatWoHxk5xt3rL/Umkp6NjOiVWtzw8cV/xDmy2ttJNGjBXkGkBAQWy7M3TYknp+FKnt7mCMOoDwOxQXMBZ7aQqTlUcqPw7V7m8spDDHBEsKEGRo+VHGseotqIkAB1L2O4386zJPZ+CVHfDQzr4rhearjUOoAB0jG/fpjp3tj/AFWDVy2JuDPPe48YWFLpbC4e3dFdXjUTxhSo3YxEkH0IFL99tSqrLCplRhpbWwKaRp0lc/dWy/Bb22DC3kuFYMQJIHflli2cKUx86rEcbQCWRlmcx8v+Vwxztp1kgapVPXHn3ruh1uOfDQtFFEXitC8JjA7xlNOxz06Z8871XY4BK7HI6nqd61Gm4e8im84NaZDAlrIy2yMvfUkTDb4VWewluDPNYCIwF5JEijlDSRRkkhGVjq2FUjlje+wpJlVXnzpxn0YZ/hREozMpjIboShx+O1BIlxDtLDImwPiRl6jzIxQwzPExP0bZBzrByQRjYg1ZpPdBxsMRIQwGrAYrnVlSoJ67UuSUIcKwY8yRWU/WGkjDBhsQc7fD7W3bGeYYCD3eGOEKmkARoNiMbHrvVRV3x5HtSir5HL5FuByWRsYAY4I3OSPPzr2HASZOHFNaxtDcTwqwRA2h8NuxJyNzg4FeTiVRp3U4xuDjO3QivT+zyxmwuXMjrru5MiLYYCKuc6Tv93zrh6uScHZ14oJ8o2NUsIVBeLhck82O31Abk4JXJ+2q08WsrIOIKu2BmIkbqyZHLwdwSDVgrGP0rhgBgBsMAuPVc+lCUjYL43wcHUoU429UyflXmQywjuufodHpxqqM4cNtxGye8jDvleWrqir12DA9fjRrZSIrKtySrYHghYhsdCWq4UIBRZZSQuxMUZBIG4DFcZHXvXE4JVpgNjpwAA+3oBVZdVewvSg+xQWxuxq/lMjjfrbsoOfMNR+6SA4DkEdAY0OnHlgCn6WydF0pB07YGQDuB1rijBWxcgb5JUEHzAyrf7xUpZk/H9h6MPBQuOGT3DZE2kkFTqiVgQc7YJG9LThk6xsgnJyBglRhCCTsuutFta7rcIEZemSSG7A+KgKu50FrZgxGlm5gbAG+GD1pdS0qtUZeCPgrCxuQGDXBZChU6goK9uuodfhTFsrtcILrKqCAMKcY26k0YUqMA24ycNqd2A8tIJqR7wclWRwd1KE4I8+hrMszl3QPp490YqXzdSjjIxvqzgeg70SXjMuyMAcr4tROx6YU5+FI1h0IZnyRtpyB/rQ7ABQGbYDc6jt/W/hVtMPBSy+ZrhiAIUOM4B6geYw321LTXwCHlRnJwuFTV6ka2OazxIQwyrL1Gc7/AAwDmjLEgFUAA3JZVBJzv5/fS0RXYLLaPxNzho9BOQxLQeFRnG4znNN/lJyr3SKc7amRVfbIBwvnVTmYP1lycBhqY5A6dB0pic2UoqA6jsAo1EZx59qw6W9UO0WY7fiE8mlZ1k7sYnLPtk/0d/Xen/kziriVuZc4XTqYDOSdyCdWarCznAYysi6GUYBLMxJ3wqZNXeRDEh5iztldQKxrrABH1E65+PlUHnjH5kpZoxK5s7pQ5SZJGBUFDIyyKTvklWI+FNaO3tg3NM00ojU8q3BLHJ3Jzk+g2NOEywiMCMJrZtA0qFO27TMcDJ6dO9cHJVSkcOdOqXmurKZCdsMjDw/LJ28qhLLOW7VIj67lwKQ3ozhoLZFOlFjj94kBIO7gn7csT5Cnprt4WkZmmWOMlnKgyl+4KJt8B2pTMJMLzZRIpJzCigBTvkEZOPU/v2MShYgLcqkbRhuYuouTr6pqB3yf6P3VJ3Lavz6k5SctiGu8w5BKTYTlJImu4fJBUmFM9u3+lEZrSQxsk682NyylyyoBgndQd9HQ5IqrEtpavK7I0cmorLLLdI7MS2gq0ivkZO5AGBnFHBdwkuHlSDKGRBIEbUisAWCqASe3T5+V3hSXuJm9KXAxLSynKSSObtnNuUkUtGoYAuXiVDt5b1b91iUORDGBqLfQwam8ZznP18jqd/LyrAeG7maSZXn0QlJAiARjEr6XjcE5G2O3YU6LiM8TGBPfpZAW0FAxjjTuS6qxyc7nPQj5Vy9LPhSv5DSS2NWaVl0q7xNGApGCNaZOokqzhf1fPrjG1DHOJZHMb3DwTK6oACBnYMRIu23mG+eetVbrhgZ+Zz3kLPG3NjVpmIGA6MQdhjypuuIu8dtLzpmUMiStpIznd2QHB8u23rUVDSqrc0t9hUy7CBWlheZna41HnM3gKBViXL5O5zt99GLeWGFBJHMqSLiJxHMNIA6ydvj39DSDLfJJLbQ6o+XI7yaiS0sWQcOrb4Ofnn5UKPKiGOKa2RIQGPuwmSc6t8YXwZ38/wBHr59ic60tm9L4LbX93bpAJHjEOgu6tCGcnGkKZXOnLfo5+FWF+mZ+VFEzRo6JriURRocZw0YGCT1AORVWyliImN1eO0JbSI0jYQtpB+tqBbJPx69D2u2xEtuhdEBKNGVTKxqCTudLZBPU/h2rmnBNtR2MaK2QMcpjV1izI8YXmuq4t1JXbRqO+M779vtjn6oy0l1HDldEnN8RjRSC2SVx2I696OW2cNNLCYAZJI1PP5fL0hANicDV8c1WhW9C8gHWdakK0IQIoI2SQk58+3+kfSjHd0CjQ4X0oMMTmCRWkzrhMoYr5ahgdOlE0ElyFcudJUAB01NtnGdwPgaiIksk6qCurQupGkkBfIZCoYYB6ZyaZzIkBkkkRIm1NISrgue4GnsNs56Y9ajJV8CMypcKilc8KDOjPldAUMraQHxsRtlsd6y7uyASaNYkhliCu4iCBnySA5bbAx5Z6eZree6VIytwC2kjB93cRlD00kkk569aNRa3kRkiMShHEWnGSW2I1Ejb7dq6YdTkxU5rZGXxckeNnlvhHdQSyPKjRyIj51M2rBGrBBxttkbfOsUrLGw5isPLPUAele9k4baO+gOEwuRoQnIC6RjXv1xWXecMaONHKByiHWcFdJyR4Qd969bp+vh8Pkm433PORrHrDCVU0gPzM9D1+jUbk9hURjfJ88nAq3LZBS7RnYatmU5yey+tUg4Hh753O+QRtXqRmpK4mVFt0WRJpBOxJGBgHLZ7HFfdPZmxk4bwDg1pKksc62wnuEnxzEnuGM7qwA2wTjHavi/CraSaaK7ZT7tbTIQdJYPMDkAAHPhOCdj5V9Ff2j43cQe6LdGGdsAz20cZuDqGr6xJUeuN+3w4MvVY8DqRTI+Ee9CybbHB6bYB+FCxWMFpHjjVcAmR0QDOw+sa+bSSXsxY3V3LN1JaViW1HYgr0P3UqSUKmfH9QYORjt1LdK4H+qpuowv9xLGn3PpT3FjGNUlzaKoOnLSxdemBvVeTi3AYs8y/tBjOTuw8O/ULivmzXAxqKSKupgmskczB0kAKM479qqXMt3MoEc6wgEA6Q7HSMfX1Kx+WBTj12WTrSkUjhb7n0r/iL2V1BffYQSwTeB8aj0B0qfwq7DecGuDpt7vh0pI+rHLCSR03FfKUQ6S+hx3Vgy+MZxnCgY+3euLW0ZUvzy2GyEjYNgDOwXIz5CmutldKNmvR3pM+vGGA9YoDp/qxHAqtdNwa1iMt83DoICQpefkBWY9Fxgkn5V8qjuY2UPHzx4ioR1dZARvgk7URllkOGVhuckg+EAbnDDVj5Vp9Y1s4Iw8MvJ9Vht+F3EaS2sNjNFIupHt44JFYeY0CoNhw4tlrG11DbJgjBHp0r5XC68xWjQx+J21W55T6z9YlkIPqa1bf2jv7YFYr2UocgCduaNjnK8wEij26N1KBl45rg83ZWF7fprsIJbiLW0WqIoRrXqMsR5jtWlH7M8eflj3VE1Z3kuoF2A76GJ+GBSkh0gqruo3OzY28vDinLG4VFWWQIuyqsjDSD6Cud9Vi8M6HOu46z9juM3sSXCNawRyDK++tcQzDBwdcciBgfj2qLj2ZgsbOS7m4zwqZN+XHZsZpZWDFdMIDAHfY/v6VTllgiZ+ZIGcBXZWkLkBumVJzk0g3SummAASSBlh0hcKcYLhh88dar66kqjB/WyPrN/DuCTbWcWuRWaQKX0E68sDjAx8t/uqLW/4g4LGxhjt5NBREYoqg9ZBqBYg9MedVJo7cSxLKwe4ZiXj57woBjAlY7nI+Iq014kSB9UZlAwsSfSE5I0gkZ238hSljuNVbfkm3N7GrFJJLkpCQoyM58ZOOox99AwnCoxZQGJz413JIwe586wxcyM8PvFxcSuCx0bqYmYkADKgYHpjOKuq0emFoI7iaYDKLIQiNpyAXJ+JzXLLpXjYae7GXHLfLclJvEoCLKJHB1Zywft8/nUvpkSOKZLVFYKVTwO+seLmHG5AwRt9tBy+ISwr71aIdYXWI22VRuAwG/wDp+D0QKEMUKPIuVCoqlgo6BdfT7a1aSUSiiq2Fj8mxSAPdLkaiI3YqGKtnGBsQMZHnT2vVRDqVVj1ku8jMiKufrO6jOk9NvhSLeN5VLtBGDOQygSLzIgGyo7j4+L+C5IbyReUirIpdtZMnMcxEHbQAADsT9g7U1CEpe8+PmCS5sqTflK8WRbYWS2oOsm1QKrlmGHk5o1A9NiahOHMji5uJVNxK0awQgqZG0kBsIBuBjbHn606ztoYkjMfEMBpCxQKuoYBGCHGskdTVh3nKSGO9iUlY15/LASOIv1JYFgDuc9T22rslmlq0w2X7mnb5Oi4bblNKW73M5LvIzu6LrySBuTt0B/2asYlhkDz3EoitUKEW8bMsr9CkSR+EnJGfEOgrBbiU8fvPu9zcZlYoX2TUpGDgDpnt5Ui1uri3AaJ5I1D62USPpZ+7YB61R9POUd3uJOlR6T3h5uQqc1F1ZKsjRREr4VWVj49s9NWBTJ7XnIYXMpkkVVtnjUx8zClzGsQOD1yTn9H0qva8Sg4gfd5QbfWGIWPlvHODlCpU4OQOm/8ApWvBPw7h3hIZJZ4CltMzRsQwfTgo5Ax3IA/Dfz5LJjdJUVxvVsyjNw634VbRy3c8UMkmBoR3lcnAOH05XHlv339EyySMccqXlRrqt5LYM6SEnDYkOCQei4HpWVxB7y8uX1NNJGobU7jOMHUc6dhQ2c3EYVVLG5mEkrKqRxQs5LHOSuQenfbtXXjxbKcnuWlpWyNA3YMkcEkdzFBhsyTofEysc/RqCPD2yOtDrBId7yVorAlsSQ8tguRpzyjuCSNuwPUUUMNzyC0sgRkmPOeJjM0jdCrNq5e+d8kH41ZysyRlbuWUqFDpawqocMQCuplCg4HiO9SnNXt+f0ST8CRJassYjmjmUsZC2lo1kXG5Kgg6upGAPLNWLYwlmT3uIKnLcRJMgGRnSsgfB3HY56elC11E/gjhSOOPCu0aMFH6RxkbZ7kH8acRHdytI8HjKLiMBeXr05BZkOCQBk+vby5pN1TX2H2pjIriWX6OITsNDmIXIdlJYZwzRadjtjfvSIZbnmjnSlpGUnlpFMqDr4iB+iTsM56b4xuznXkzYCzQ8rQV5qRwhGOEyhkIB3+O2M0LTOrcrmXi6sx5ZIw0KMCdXMPxwMdqxFNJxrkk9VaVwRFxCRJ/d3tTGHE3Ljjcq8qMuos6yYUnqR1p1tEAQ1uyxOylmEal0xkbMclR39f3Cty8cbGKeWSJSymWVY9OW2/Oqnc7Y0/E10lvdXMjubmRGUIoXmBH65BKhSMev+tYa7LZfySSaWxZGttf0qg4DALE2wGFJLDPfPb8K5oi5jWV8MjFtLDQ7JspZ+o2/wB+tOSS/n5hDGGYu6xyZ18yMN4WbbG++4+6hiubhfztw0qgx60LRLpbJyBnfG4J71h4ZLirDTLlIm44cJC5SbSGzIuqVD49yWOwPT1rCueEwmWOSVWJJLFY20rKDvnb9xFelFw8iF3WCIRKWlIKaVC7ltznFHznYRnkxOswXxh0VAuxDEnG7dvD/G2LPmxGPe4ZgLNHAUCqUi0MqaCTGrHOdSNjAI8jnNWdLnGkTIkWc6Y2BJPTSWPXyNWeVY3FxJAXKXG0joGjbwHbBBxjscn99Cbd1xH4iNRUOmdSY2Gpdz8DiqSyptbbiU12KknE7pGEUPK0ogALBkY+LJwW3J9Rg0yz4g7OS9zC7gIUJibUC7fSCSMdRjoRnGKgJE+oyLzZAoVg+Mt6gMMb0LW/MKzqREynL6kBCg7agAC2eu486peOtLVFlKNVwaE0ayNqSSLTlVXmFsjO4Go5+X8aUx0HcS5z2VlGSDjfOSfPakRa0IbVmQKwdSGCuR+kPM9KNLoo8kb+FtOgKxdlK4/S1fPpXPpa2W5SOSSDMssZUZK6ZNeQGGHXpllGB8P9KXJJEdMs3KGpmVS/M3cjoG6VZMccyqqtIiZV2GzRnBwBsQf9+lQeGwuQdYfxORowSgO5wpPl0pRyY4r3th+rHyU8KQmVYeYZ8pjUd1P2eVSikv1J1JpZMalBJLAkZz9jVeFiCECq4ABYa2098BWxk0w2ES5OWJyT4xqJG3l2rL6mA3lgtmZ5RxkEMW6YjR2A36jJPzqeWdwxK7kD6MMSB56QRWikSrnqBjSRGmkE+WW3z865obhtocqSS7lsMWLdyOlY9dEnm8GRLdvqMatFHpQs5Y5k89s+H76WDOAxLyZkYDTIAngY56A7Dv1/Gq6tM+pQ/hyXIKAt/wBqkda5JJ+Vqa3mZ1OFXQWdskHAzsPXNeisSSpURcRpMfMdriXEbAEqMESBttyAW+G+2Kz7yee4ZzYCXlqVQcoEoCRjdhv2+H79Mxs0geQ5YqxyXxy8/wDTCkeXSpXmhjpkYZ8IYhVVFxnK43J9cVuGRQd8v+hqVPYp2drbW/LknCyzSrKCWXVvrCnBbcjOw27/ADp6wxIwZRDh/E8hVvBjBUBF3z1+Gc1Y0vqQ82XSBqZCBrfSDk5PQdftoGljQMUjlk0FQyrgKARjxEjPXpv91ZlklN35HF3uSXmDIsRjw5ZissanTk/WaRdzny/1pyvJl0QNKIsZkYBLcuGxpG4PxJHb1rlaV48rBM6g6CABnST5gHCjqNqBJo5IOZAU8IdwrDQgkyCQ47t2P8Ki02uBybqjkWa6kkExmKnDRxRSHSNO31VOrc7+VRJbW0nO0oQGOlkkZ3HL8uWo2J+PehWW/EabBEcsrSpDqLquCSpJAz2H+xSpJuIxZFtZkaJG3kOpSoOoh3GDqH4bVuMZ37rSCKa7FzkSA28MHNCxhXkwhCuunTpEpIAVeh2/iYhMOMx+JMiNAZNGZDgsoHXAPlVBvfJpCfeAsYeMJGinKyaSck9CN9t/4ueG7tklZpLiW3eXIYXEZmY6iOmRL6k6e9Dxy4v8+o0pWX2jihicqtqpOCNCiSYFvDkhTkL13yKo3qpMtxA8RRDGuJ2kJbX1AjTOTgDpjHwoYbeaaaF5ZZCmcsJgEEYQFiZJYxqx13x1+NciJqkc26SF2IWSMOI9fiz45SXPUj5VnHBQd3bE0+bPPBplbGiNQM421beZz509TFJJGqphSyiQ9gD1JIH31vvYc2PmPbR4XQAZS8ZfA3OAd9zgdPnRR8PtlkhRWjtYyBHNIsUkzJknU7qMMdugDb13+2wapCVMwUHJl5qSIZJQsaCHLrHHsScjufux2rXglA1SSmW5ucLD9MoaJFGB9GjgsB0yenkTinR2EQnnb6OSONwsMskUkUcwByhePGc436nypslysGFTk6jmd1UYJBxhgXOTscYzXNlz+o9ESmjerAEUmpxphLMUYKmp9BYeHQAANPfr+OxhY445fp5w6xiOVbZkgbAfJUnUCD/S69qpi3kmQyRSl1kYh0BQco6skf0vgc08QLGUMKW8TyM0M5ZhcMCgAzICNOTtgD99SdeS7ilyxoktwj85bh0bC6+UY9DAE6iyAgjz3J9KOJ1mZTFjSrFVe41KpxsxZSMjI8gKry3WjkRRkpIzRrqZFZVxsyq0Tbk5G2Bj1riqHmLKwQaZA0TOvj1eIlmQlcHbbHasOG10C09ix7zdNMISoKAhU1hwMbkEAb+LvuTgDypiySR8xPeJIWfwuIiFuCDt4SQcAd/Tz7V4zbFlSLMupCOWpkwNIBIL7AHrvnpv6VAeQgHIRQGMawx50HHUux1b7b/MY3zJwX0C7dIeZiHOQM69SyTO7lVIxqUSJpx0BIPyorcJcZIUiJeaWKvJrkkA+sxcnIyPSk50uuvx5yHJ3LEAE4J236daZBJbsE5qSoiK7IYpGWIHGjSsTqpJz649KUk62FK0rQbkxaQI3aZgTyYpBpAOGxp2Ph6nc0JmvMy4tQHL+6hGllMk7kDJCsRsB1wxoIJLFklV1e3DuwV8SqpwQPDnOe3Y/wCkGeIzSLDc6UUIOcr8zm6xjDIwBByOx/jpY2lbRHTatkB5lvEWSN3RUk08ggSa06I5Y7jscdAPnTpGWQLK72/L1BpGcpHoOnA1A9T16qDt5VVZDGY25kq81RFnSebNvl2CZ8Pftv5VJmRXZcoR4QXly0jKFwHO2NXb0+VUklKmuTastHh9q/LV43bWu5MeFl0EnYZx94+7FDFZpHqjMnJt8qNDDsqno249e+CcDrtXK3SuJWlXdnYImWhZcbK2o6gMnfI+RpssUphhdbtBIjAIE0kSEMRkoWxjy39O2091s57MhKem9R08Ti4aSXSTGSkTTgrclhuwkYeFgu/rv0FP59rqAkkXYFRpD6AVwmCFGABnBztv1pMctyOask8ZDqrgrGFbBwrKxbsfhmnZeNIHBMUMbgKkYLo2k9ZdeTnqflWZK2lIE1JLYkJayIjohVgmCdJIAJyRjr8KQIgxASSN21MoAwHB33Oe3T/ZqGMMspCzsrSyNnWoZGIwMRMpH7/v2fGmA8epH0eFkAC4BbGRsDuMeu1Ta0LcnSXxFQwzKz7FdtbrJIwBJ33AGNvSlMXZgC5kgBYsSgDdcEAZOx2ztvitLMeQS3iBBUN4gdWwJAHU/GlzW9oxVjGSZHRASxUBycDBH+/tpwzU9xqWl2ysI5ACETr4cMACWJIBCHKnPxoc3MIWMBTpTVIAyjDfWwpPby+OKstakFlhc7BgUZiMHcEZO9LWDJlkkhWLThVzhtYHRtyfKnrTM+qr3JN9NE2pllaIjUcKC6ggZGB3q0L1Wx+dIJ6srLkjbO+//wDKWYY3J0MFK4cMdQB9N96S8LacrrYZIyuMBgMgCouOOe1bi1R/xNFZYWCbofDhgWzuNycedS6q51Z8PfQTjPbbNZaRxMhYgkICSwXOFBxkqNzvv+6pFvHkNzFDMo1GXKE7nsDiseik9mat8WZRtoHbmtNnwbHfB+QHX405jIgIiKhnDBDKAQM9Tk438hmq0P5mb4v+01FJ+dX/ALP21r2WnqpvgIvU9wxK0YDSavEwELYZjqI6uWPXvjcUUbLcPzHZxpUAZAVS2N1GTqHn93fZkn5lf1ZKp2//AF/15f2kpRqUWx0krGn3d7gvE4aRU8UUgfUpGPEzE4x3O/4VDSqjG1LSSDUyOMhpC7EnW2FKnsOu3XHWlQfzrif9zl/zBUw/zxf1h+FX006e9ItFWc6yYMs875SX6OKORgscY2J1Jvq+f3UwzIqKoGpsOQA64OFPVe32/Cgu/q3v9pJ+JquPzg/9D8Gq8YKaTkarUty9btHcqHSJlaA62TmyaskEa4x0PwOMUYXBBzPnQdYfmNKqf1lY4Ofj3HlQ8P8A/qPi37Vah/O3X/b+0K87LkcZuKIym06MsL7vECAdZQ6UJJO+428++Bjv5b17aC7LOwMzYYkO3XOdRBJAOw7Y388De/J+c/8ARn/Yarsn1D8E/wAsVpZnGF+RqT5KemcAJyY9C60cyspZiRqz4Bo3xvsaMoIwheGUBGWQlZX0AgbsVycj0xRQ/mrj+2/+LUb/AJmb+y//AFmuWWV6jT23QNrJJczOkMMpflq8kkx8MSg5UNqyn2UN1eRW8xjMsM0yARoIDJNy+Y2D20Z8zjNXuEfzbiH69t+wK83bfnbn+0j/AGXrpx4oSbfg6Fgi4qRtoVDZeGNHjDMkkxAIJAyGZm2G+1UZuIBX1MI5iymNdLFhGMjJYhcYOwBxscnvvF5/1/1YP8xKr8I/OH4Sf+4WtY4JRc3uTjHsWpb2aONpJIliZWkTlqSGhOcBuWTuM538/Snx8yWGYzXEQt43f6Xw5kDrkthyWPljPn51T45+fu/7vbftCgl/5XB+u/4tWpY4uEZJVZqVqJoxRxhC6+GNk0wOSsRfSNPhYDHfJx5Y+ExuDoDRxsIjq1JK7EqAxOQBg7kDGR2FXOJf8s4J8E/yxVKw/mM/68/7dRUE02zSjdkyTRPE2iZVVxlkYDIK9QcDVv6CheZJBo5is7Rx89CdLHpkCUAEAdAMdu1ZK/zyH+9J/nrV+9/PcS/Wf9o0ekohGPYY7yysWKfRwKRGySYnVVKgnxYHX0GPvpzSWETLLLLGxeTV4ijONWdTYU/wpF1/y3jn95m/z1rHfpbf3VP/AJVSOFTXNdiM29kjd5lk4kWGZGXlnlIAVkVyBuNeV+319KiRY2LKYzpKBpQk4YqV8OMYJ642rGT697/ef/1R1tcP/PX/AP8Ac/8Auo6M2L0eGDk40gWblltSupaQIYpi6DZTklowc+oxTMSLzCsaaVRiSq9QcDC81s4/Hv6Nl+qv95uP31MHS+/s/wD5muLXas05bFVFjZCY5ZYwWJkSSIeJc6fChOgHqAQ3fOPPi0oaURI7HYs0kcYdQDsqqANjtVtf5u3xf9s1a/8AN/uUX+c1PXyx6VJuzOfxO8LNmRBh2lUEAZyYg+sdN84PbtSZHXUoSeWMqm2/OQgba8up9NtX8Of+cRf3u4/Ggh+qP7GP8TXRj2poxoUEmhkMel1lR0kZ8SwMCYtmO+camyCDgCni5ZWMY5CoIi0XMV+ec7aipwc47fdQWX5zhf6x/wDcyV1z/wAwi/tZP2RUpvXNqXghPdlgxykhkkAwnLYBRqJyQwJznfP3USSQ/pNMCJMqEPM3GwJjDDeij6y/GT/MFVT+ft/7RfwFc0ff2ZmMtSSLRaGVX5Tc0MqM5KzQOTltsSoDnptk/GmaXCszHWWYDw4+Okeg61yfWb9Zf2a4fVP9of8AKqc+WkPuAUTVupOg48JYEauhbtkbkfwoWhRG8TuskmApLLvk5zjOPu9KtSfWu/12/Yastvrv/Z//AAFaxLXsaUVbHiJNCMF5hzqUB1BXPmVJwfOlyDks55iIGYBVdzuADvsCcij4X+Ym/Wk/E0riP1Lb9ef8RVa/5XAnJLUf/9k=";$address="
   https://www.forcegurkha.co.in/
 
	
	
	
	";$p='
	                            About Gurka:-<br> 

The upcoming Force Gurkha is the legend among all. You will not find any SUV with a fitted snorkel. Its natural habitat is the rough terrains and landscapes which otherwise seem too daunting to be driven at. It is the manually locking differentials on both front and rear axles that make it one of the best car for rough <br>roads.
<br> <br>  Features:-<br> 

<br>price :- 9 lakhs
<br>Fuel Type :- Diesel Only
<br>Transmission :- Manual Only
<br>Engine :- 2598 cc
<br> <br> 
<br>
<br>
<br>                                          know More ;- 
<br>Displacement (cc) :- 2598
<br>No. of cylinder :- 4 Valves Per Cylinder
<br>Fuel Type :- Diesel
<br>Emission Norm Compliance :- BS VI
<br>No of Doors :- 5
<br>Kerb Weight :- 2489 Kg
<br>Suspension Front ;- Adjustment of the adaptive suspensio
<br>Suspension Rear :- Adjustment of the adaptive suspensio
<br>Brakes Front ;- Ventilated Disc
<br>Brakes Rear :- Ventilated Disc
<br>Steering Type :- Power
<br>Minimum Turning Radius:- 13.51 metres
<br>Tyre Size :- 275/50 R20
<br>Alloy Wheel Size :- 22

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}


else if( $type=== "Mitsubushi pajero" ){
	
	
	
	$I1="https://th.bing.com/th/id/OIP.Ea5VY7RkRWWJaneqQL8zzAHaE8?w=256&h=180&c=7&o=5&dpr=1.25&pid=1.7
    ";$I2="https://th.bing.com/th/id/OIP.P54iDplMFM6Huynzm33XCgHaEw?w=260&h=180&c=7&o=5&dpr=1.25&pid=1.7
    
	";$I3="https://th.bing.com/th/id/OIP.B5ol9uJyAhiFPeXWtLY3FgHaEK?w=303&h=180&c=7&o=5&dpr=1.25&pid=1.7
	";$I4="https://th.bing.com/th?q=Old+Pajero&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.25&pid=InlineBlock&mkt=en-IN&adlt=moderate&t=1&mw=247";$address="
     https://mitsubishi-motors.co.in/auto-zone/pajero-sport/    
 
	
	
	
	";$p='
	                            About Pajero:-<br> 

Pajero debuted in 1982 as an MPVA 4WD, offered good handling and comfortable drive, with outstanding performance on any road. 1991 By 1991 the Pajero evolved into a sleeky stylish 4WD ahead in technology and comfort, enhancing on-road and off-road driving ability.
<br><br>   Features:-<br> 

<br>price :- 24 Lakhs
<br>Engine :- 2599 cc
<br>BHP :- 200 Bhp
<br>Seating Capacity :- 5
<br> <br> 

<br>
<br>                                         
<br><br>                                                         Know More :- 

<br>ARAI Mileage :- 13.5 kmpl 
<br>City Mileage :-  11.5 kmpl
<br>Fuel Type :- Diesel
<br>Engine Displacement (cc) :- 2477
<br>Max Power (bhp@rpm) :- 178bhp@4000rpm
<br>Max Torque (nm@rpm) :- 400Nm@2000-2500rpm
<br>Seating Capacity :- 7
<br>TransmissionType :- Manual
<br>Boot Space (Litres) :- 500
<br>Fuel Tank Capacity :- 70.0
<br>Adjustable Headlights :-  yes 
<br>Fog Lights - FrontFog Lights 
<br>RearPower Adjustable Exterior 
<br>Rear View Mirror :-  yes
<br>Manually Adjustable Ext Mirror
<br>Rain Sensing Wiper :- yes
<br>Rear Window Wiper :- yes
<br>Rear Window Washer :-  yes
<br>Alloy Wheel Size :- 17
<br>Tyre Size :- 265/65 R17
<br>Tyre Type :- Tubeless,Radial

	
	';
	pprint( $I1,$I2,$I3,$I4,$address ,$p,$type);

	
}
?>




<!-- footer of webpage --> 
<footer class="mt-5 py-5" style="background-color:#222222;">

<div  class="row container mx-auto pt-5"> 

<div  class="footer-one  col-lg-3 col-md-6 col-12" > 
<img alt="img logo" width=50% height=70% src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" />
 <p>This is an online car magzine designed to create and improve knowledge about cars.</p>
 </div>


<div  class="footer-one  col-lg-3 col-md-6 col-12" > 
<h5 class="pb-2" style="color:#a2cf6e" >Featured</h5>
<ul class="text-uppercase  list-unstyled">
<li>hatchback</li>
<li>suv</li>
<li>sedan</li>
<li>coupe</li>
<li>sports car</li>
<li>offRoader</li>
</ul>
</div>


<div  class="footer-one  col-lg-3 col-md-6 col-12" > 

<h5 class="pb-2" style="color:#a2cf6e" >Contact us</h5>
<div class="text-uppercase">
<P>Phone Number(+91): 9448724072 , 7022136392 </p>
</div>
<P>Email : pawanbharadwajnp@gmail.com sampathkumarsharma12345gmail.com
</p>
</div>


</div>

<br>
<div class="copyright">
<div class="row container mx-auto" >
<div class="col-lg-3 col-md-6 col-12">
<a href="https://www.facebook.com/pawan.bharadwaj.106" target="_blank"  > <i class=" fab fa-facebook-f"></i> </a>
<a href="https://www.facebook.com/sumbath.vp" target="_blank"  > <i class=" fab fa-facebook-f"></i> </a>
</div>
</div>
</div>
<br>

<div >
for more information go to :<a href="http://www.vcetputtur.ac.in/">vcetputtur.ac.in</a> 
</div>




</footer>


</body>

</html>
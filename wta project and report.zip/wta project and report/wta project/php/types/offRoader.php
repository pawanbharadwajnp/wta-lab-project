<?php
session_start();

$_SESSION;
include("../login/connection.php");
include("../login/functions.php");

$type="";
$v;
$p;
$i;
?>
<!DOCTYPE html>
<html lang="en">
<head>

<!-- Repeated code -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title> a4Automative </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<style>
#he1{
	color:red;
}
#hel:hover{
	color:blue;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

* {
	margin:0;
	padding:0;
	box-sizing:border-box;
}
body {
	font-family: 'Poppins',sans-serif;
}
h1 {
	font-size:2.5rem;
	font-weight:700;
}
h2 {
	font-size:1.8rem;
	font-weight:600;
	
}
h3 {
	font-size:1.4rem;
	font-weight:800;
	color:#ce93d8;
}
h4 {
	font-size:1.1rem;
font-weight:600;
}
h5 {
	font-size:1.0rem;
	font-weight:400;
	color:#1d1d1d;
}
h6 {
	color:#D8D8D8
}

button {
	font-size0.8rem;
	font-weight:700;
	outline:none;
	border:none;
	background-color:#1d1d1d;
	color:aliceblue;
	padding:13px 30px;
	cursor:pointer;
	text-transform:uppercase;
	transition: 0.3s ease;

}
button:hover {
		background-color:#3a3833;
}

.navbar{
	
	font-size:16px;
	top:0;
	left:0;
}
@media only screen and (max-width:991px) {
	body>nav>section>div>button:hover,
	body>nav>section>div>button:focus {
		background-color:#fb774b;
	}
}
	
	
.navbar-light .navbar-nav .nav-link  {
padding: 0 20px;
color:black;
transition: 0.3s ease;

}


.navbar-light .navbar-nav .nav-link:hover,
.navbar-light .navbar-nav .nav-link.active,
.navbar i:hover,.navbar.active   {
color:blue;
}

.navbar {
	font-size:1.2rem;
	padding: 0 7px;
	cursor:pointer;
	font-weight:500;
	transition:0.3s ease;
	
}


 body {
 background-image:url("https://cdn.hipwallpaper.com/m/56/10/d5qDRv.jpg");
 color:coral;
width:100%;
height:100px;
background-size:cover;
background-position:top  center;
flex-direction: column;
justify-content:center;
align-items: flex-center;
}

 

img .one #new {
	width:100%;
	height:100%;
	background-position:center center;
	background-repeat:no-repeat;
	background-size:cover;
	position:relative;
}



#new .one .details{
	
	position:absolute;
	width:100%;
	height:100%;
	top:0;
	height:0;
	transition:0.3s ease;
}

 .one:hover{
	cursor:pointer;
	background-color:#d1c4e9;
	transform:translateY(-70px);
		transition:0.3s ease;

}
</style>

</head>


<body>
<!-- NAVIGATION-->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 ">
  <div class="container">
<img width="400" height="120" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" alt="logo"/>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
      

	  <?php


	  if( isset($_SESSION["id"]) ){
 echo  '  <li class="nav-item">  Welcome, ' .$_SESSION["name"]. " </li>  ";
	  }
	  else{

		 echo'  <li class="nav-item"><a class="nav-link" href="../login/login.php">LogIn</a>   </li> ';
	  }
	   ?>
	   
	   	     <li class="nav-item">
  <a class="nav-link" href="../../index.php">Back</a>   
	   </li>
	 
    </div>
  </div>
  	<br><center><h2>offRoader Cars</h2></center>

</nav>
<!----------------------------------------------------------------------------------------- -->



<!-- types of cars -->
<section  id="new" class="container">

    <div class="row m-3 py-5">


<!-- copy this for next iteration -->
<div class="one m-2 py-5">
<?php $v= "
Mahindra Thar
";
    $p="
<br>Mahindra THAR is one of  most powerful off roader<br>
equipped with a Soft Removable Top and this SUV <br>
also offers a true wind in the hair, off-road<br>
 adventure experience and more. 



"	
	;$i="
https://th.bing.com/th/id/OIP.xcfBMzCVPqPsGDBFyO4tFAHaEj?w=265&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>  
  <div class="one m-2 py-5">
<?php $v= "
Jeep Wrangler
";
    $p="
<br>Jeep Wrangler is series of compact mid-size<br>
 four-wheel drive off-road SUVs,by Jeep since<br>
 1986,currently in its fourth generation .


"	
	;$i="https://th.bing.com/th/id/OIP.bingog81fZ-fZs6crz9kowHaFj?w=245&h=183&c=7&o=5&dpr=1.25&pid=1.7

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
   <div class="one m-2 py-5">
<?php $v= "
Suzuki Gypsy
";
    $p="

<br>Maruti Gypsy isfour-wheel-drive vehicle <bR>
based on the long wheelbase Suzuki Jimny .
"	
	;$i="
https://th.bing.com/th/id/OIP.1T4PD_Jp_bAuusC5Q0O0pAHaFj?w=231&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
   <div class="one m-2 py-5">
<?php $v= "
Isuzu V Cross
";
    $p="

ISUZU. V-Cross. The Adventure offroad vehicle <br>
Pursue adventure and traverse all kinds of<br>
terrain with the brand new ISUZU V-Cross. 

 ";$i="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADkATEDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAwACBAUGAQcI/8QARhAAAgEDAwEGAwQHBgUDBAMAAQIDAAQRBRIhMQYTIkFRYRRxgSMykaEVQlJyscHwBzNigtHhFiSSorIlU/EXNDVUlMLi/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EACwRAAICAQMDAwMDBQAAAAAAAAABAhEDEiExBEFREyIyBWGRcaHwBhQjM3L/2gAMAwEAAhEDEQA/ANQz3G5gYo2HlskK/kwpu/GQ8c49NoDD67TRCvJww+hrhVsf7V5fqyOmge+DOO929P7wMv8A5CiBC2QrK37jBv4U0qeM/wC9DaKMk5UfgM/iMU1nrsLSFaNx1BrgR/em4UfddlP+F2H4gk04tMOkzH2YI38q0WZPkWliKsOuaaQw8zSaWfOfsWGOBtZT88g4/Kuo4lDZAUggEZzn3FaRmmS1QPxVzLetFK0wgVZNgjnPWhsAaNtpu2gAJjB86E9oj+QNTAgogQYooLKhrEj7jMvsDkH8aYba6XGCrZP6wIP06ir1UFPEKEHjy+VFBZnHeWPJeNgfUDP4kU+OaFhyDyAfTP41dzWSupGDggjjrzUW3sZTFGLiOMShcOF8Sgjjg1LQ7JGlCJ5mxHHuEW7N3c90iMDwwKDccemauZb63QAS6qiYADR6ZCGY48u+cMf4VSfovPMcbcn9UEc9fLiq65k0+yJFzqVlARyUluIi+PQIp3flVq1sS6ZfnVNNidpLezklmY5M15MzOSOM4ycflQZNc1eYNsdIVcE4ijAOD0OWy351mX1azVJXhS8uYxgd7bWk3dc8Z7yYIn/dTI9Wv58iy0vJ5G65nZ9voe7tEc/iwqZS07ydD2LxheysrP3jv4cHkvhunv8AlVRc61olqk8huJ5RC5ima0t5ZYkmU42POB3OT5YY/IVD1zU+1MNu1vLPbW+n3KhWFrazW8rRgjvQZJnaUA9DgDPtnIPY2Fvq+nwX97GCixiOxsIxJBp1hErMAkcYbktjxNvyc81y9T1mHp8ayydp7KjfDheV12LLRr2LWFcWkcxMa7jFMhEgRiBuUDxfPGfzq8Ojsqd5PJHbjHWaVEyD0CscD8QKxc2pXPZ65NwkVq5awaJYo1lgh7slX7tSu058J5z5edOj/tB1ExCePTNJQI0ZbYVM7BiRlRIxPHma6sE45oLJHhmWWHpycTaw6bbIHC3EkhdV/wDtreWYYP7WBs+ob+FSvgrOIMj2oWNUUIb+8jhUsDneBHucfj+FZBO2cGolIpL65tJXAxDeZhXawDA74wAQf3R+dWKWNxcIsyukkTciSIh0PybOK0brsZ7F1JqNtEhVdStrdxwDYWzXEu3PQSz5TJ8ztqBc6vpcqssqahfDGNt1OsULYzgtFAAv5VFGkOT4mbny3en7ooy6NESCyrx04zj/AKs1OplbA/8AiSeMbLO2s7dc58CmRt2MeZxn6VGm1XWbriWaYj0CrGoz7AAVaLpsKY4zk+uP4Yp/wkKdEX15FK2GxQBLhjnHp5k5+gp629yT0wPlz+Zq6MY6cD5ChsoFKgsrRauclmPuM4H1ApwtIxz5+w/1qYaYaKQwPw0XnuPzJ/lXe7jXoKJmmE06DUcwtKlmlQOyhHxw3NFqGqptHOZI5lPvtdWB/GnLfa1GBnUUY58InsVU4/xFSOfkKsn0e2zxHj93I/hQzpjL9yWdf3ZHA/DNc+kuwCaxrCnDpp0vqRJNCR81YN/Gjfpu6UAS6axGPv29xE+M/wCCQKfzph06fj7Zj++kb/8AkKGdPul4zEwznBQr/wCBFS8a8DslLrdmB9pa38efPuO8PzIiYn8qImtaIx2m62sOokjmQr89yCq02t4pJ7uM+WA8gyP8xNBeO+XP2c3qAGjccfvAfxpemvArL9b7TZeY721cY6iaPj/upwdd26Nww8ypyKy36Oe5YmWF1yQW75IzuPXAxnitBZwLBEsagnncx4GWxjoKuEKdkssFk4wadkGhKDRQK6DMWK5in/Ou8GgBgWnha6Mc08YpgdQDiqjU9TvYZdUWCeOztNNNnaGVbOO8vNQ1G5QzC3tUlcRqFXqxHv5VcqBWP1iGb9J6pccm2h1hVlI6JJcabGsMrD0OGUH396zyzcMbklbRtggp5FGXAC27Sdp7KRoJ0ivJ7q4MUS6gH3xMR4cGAKDnpgADzqwLf2j3u37WzsYSFLfDQxxzepG7Erfn/vm9RvVFzpdpazPLqwnjnLLJbmOAKh2CSW5OxSByx6ADn2lg3+qWPey6u00m0pMtg9/dSNMoZgs8rTw2gUcZKgg+QrihLrM2NSjUfNpv8IfVRhDI1DguLnSUZhLq2rA7SAY9Rv5ZkyPIpJNGnrx3X0qPHL2NsBLLDeMw3FJDpluyruIyAXtYlA9vHWRit72a8fT4H2vFtNzHIIu/I8O7LxxvtCknkvnkDGaum0zQ7Uxm7uIyqrkpczCNQAccJcSM3v8Adqn0GaX+3NL9FSOWywbtF2bhQSW+lvNLuXZ8S9vHIzngFUkZ5fmcVyXtfqkkY+DsrSObf/ctDdXBWMDlzM3dx9eMYHzqs/SHY+274JJCWKlXa3S4ZmU9RuiVV+eDXU1q0fb8LpmpzJ0VorGIA+WRuLN8qpfSOlTucdX/AE2w1UDv7vWNZWKO+LOE74b0FokQD7WCQRQ7icHI5k8+uRyWy7Qx6ZbxWc122LYuqRp3z7grFv7vZgYOc+n0yXT6hqMokKdnNayw5kwI8AnJCL3eBkdPT6VRTQnU72Z5Y3tbe3WOFUjtZ7lIExxGQjq58ySF6/Ot83Q9PlxrG0tK7I6On6meN1EkX/amS61G3vEe4TuSrQtAsW8Fif7sMTjb+rxnk9N1TZZLW9hdb2ytEuSYS99bQpbzszHlHjgxGzMM4yOME555r7LSdMivLOQXcV0guUEkQtr22ZSo71g6vzgLnODxxVq8kT3t5d7I0S0fKxJzGL6bLBE3c7YwBjJ/VHrW+OEMcFDGqSJyOTlql3HXekm2+HgN8s8JjjlWC+gSURMy8xkZ4I89pHUdCOAW66npb97p1zd2/J8Vo7zwO3Xa8chEgHkfE3ypjBJiTKiSFjljIoYk++RTGgVdr2qyLPGVkSOF2VJApyyMmdnIyOlOzOzUaf25u48JqdjHcooXfc6Z/eLk7fFbkA5z18C/PmtXp+uaFqgUWd4jStk9xIDHOMDJG08H6E/lXm0tw11aJtiguQ+ZQ0h2XKZUYaGcDcD+0CfKpHZebszpWoPNqEV1HfMym0kuHcpAXQo+xM7WJz94FjzSoo9OfaAOnWgsRzUeXUbALauZ02XcoggZcuHkI3BfADz06460pJCq7seYXkquSWCgZdgM8+9QOn3E5HNAbzp0ZmnLMkR2bQY17xXkYYBy6xg7fbOa4be9GC8SRqMs+9tnA8t8hUfXFNIkCaYxHqPxp5WAlg99YopPRJopHAxnB2FyfwprfBE4W4kYgAMIbe525/eKqPzp0VYM5OcAnAycAnA+lDLA7sFTtGW8Q4HvR2+FVFUQ3cgySAywIqk+YDyE1zvEAOy2TOBxJMQM9ORCo/jTSC0R+8T9tP8ArWlRu9m//Vtf+u4/1pUUGxaMgJNMMI9KMcZPI61zisiwBgB4rhtx6Ueuj1zVJCoiNbA+VM+GTzH0qaTTSaKE9iG1uvpT1iAHI6CikmuZNMmweweldxiu1w0COGuUqE83jeGGNppkx3gDBIomIyBLIc8+wBPyoKjFy4DAUQeWOaiAatu8MNiwIG1BNcBt2em/uyP+2s52j17WYWhs9GV1u4pW/SAjEU4R0AdYVmVihBz4l8LDGCOcK1uOS0muluLW0iE91KsURbYpYEtK+MiOKNQXZj5AA1l9cudFuibm90+NO7VIFZwZb+UE+AOiN3K+wbeRzytQ5L2d3SW4lDanLEBPLJIjm3DctDb7BsVB0AUfPJ5p0dsJCEZGkhYEMJIztmB8JCq3JXyziqMXKjKy2+oak9zaWFjHa2vfZa0tiI2O04X4iVlZj68vj0FTNI07XrM3Ma3FnD3jAM7RG8mDwZULEqjbxnzGPStKjWkX2MTRoAdndRS+HPTbsU4+mKJGEVSIY2C7iCI42ByeeRjOaremmzOeVte1UZc6JFaSSPLJqM0lw5kdviYbJHG4klsl5MZzyR9KcLaxiUBdP01X5DNMLq8bB8yWZFJ+lXV1Yalc3ErJHDtXYq754chRwoZULMD14xSh7P66S7C37wjAUxFmHPU5ZVpKMX8nf8+wqdWytF1cxhVinSIrgf8ALWdnDgDyGUY/nQWuZyGDXl/Jk5Pe3kuM/ux7RV//AMKdp5e826bBgBQvxN1HDk+f3VY/woT9hu1OA0kukwksx7vfM2xTwBuwQcVUceJbpL8AovwZt5EfduDSZGPtZZ5B+DuR+VR3KMEHdqzkhECqFYsx48SYP51fXHZHXIRtOoWqMB49lrv/AOgtgUK20QW88UtxfSTlPIQxwbSTyQQSenA+daKUUti9LRFsYmsbe8uwj4iZ7CJg7BQxT4iYyuM4LeBRz0zXY9/w9vb4bK95cPkr4pJCM4Ven41oF0uDvZk003zwXaSLdW7woRAjoFMsJDDH+ItgeFeeKz+h982oCxvYt32rLGVC7lZCI5YsAlscgr8ves2rRpZwT6cu/vbiUSbYyixxYDZ5J3sTx6eGifpDTVIAivHzggJPBtJP7sTN9KyctrdJPdRkFSk0sZB4ZTG5UgnPtzRFxEhU8dOhz4vUAfnT0omzUW72kyGWx70I0rt3cjKwVmbnuyijw9cgjjPUg8WC2kcqsJ1WWNv1XUFSp6cGqTRNO1hkh1JBGtiZGBkn3oXiizvYMF27eoBLdR7VpYypAIOVIDKRyCrDINZSq9irKvMmkXtiQ0h0yS4iMQdy72dyrBwEZ8+FseZ6ZH6vHoVpI87IUlvLhZiHVU7r0yNqhQo9D6Vj7m2ivLae2kwFlXCseiSDlH+hwaL2Wv5ZojZSlu/ibusE+LeMj88H6j3oHqfBqprdRFZh0AQzNFIvfvukwrAB0RhwMfjQzDb4BFtCQV/YDcbAerc+ppridYTnaAl7vfoW3AsuM9cc0g7AgeWCPphlpAx4KJgBMAYGEwo4Yccce1c4IHgJ+759OGFIncMj0J/FVbP8a5jGceRP5Pj+dOxUcI44UcjPJ9U3f61xlI3YCj7wPn0Afiu5xgccY/HxLXAfu9P1f/Eg07GCyfX8qVHwfUUqdgT2PJ+dNz71xjkmmqCSAOMkDJrnNR+ep6Ackk8AepNcEkZC4dTuxtwcgg+YIoEQ79TO+Gjck28Z+4sYJCuwPVm4J9OAKMSx/rFNMbVOmNEkLv3aSxPJz4EkRn4ODhQc/lXSGGcjoSpz5EeRqNdy2MCq94sbkhgitGskrqRg7RjOPI81THUZFdJLWJ7eNYu5SF3aTMYOVLK3hB/rPNVZMvsaDNcJxyxAHqxx/Gsjd63qHCLKQW442ouPUgc5qokvbyUnvLh25OcuTn6UWRRv3urNM754xjyB3H/tqM+q6amQZlP+ZR/E1iIoZJwWeeCNF4zcXEcXPsrnd/201/0VCSst/p4J6Mbl3C/5Y4s00mBsTrVmQxieLeMhN0q5L4yMJ1NQo9es7eNYRJGndqd7OHJeQ8sTgHJJ9qziTaSqiSKSa7ZGHjtbK67sEejb8Zphv9JnklVUmFwvHc3Oy3LHnkNtcH5bqTTTvsdONKeNwj8r/JoLrtTZhCiys6su2U9zJGAG4IBDKfzFVN5rtvaW4tY9OKAoXjhuLJLOFVcZ7wAOZD1znjPr61ks+opE+3ToIJdwaO472MukRG3AYv3YJ6kgZ8hWi0vs/rlxDBHqeora28oQpAwhuplB5Uq8yFU65HQ8/WrWnyYShOPyVEKy7SMkMsk5hhdYu5tUit2EK+HBkaQOGLrxtycUodRgvhGYtM1XV541CmRxcTRqu4ty0kpiA6Y8FaQab2J0lUnezimkSRldr3vbqYMuWI3yNs588etFg7QwSPbvFYTLErbY/hX2RlskeCIKV8ufzp14IKmysO2mGa30nTbCORi+LqUll3cgvHB0981ZQ6XreQLzXrNVcMDDZ2cJUZXO8cF8joMnjr7VKkuItRVZ49YkMcUoWWK3SK4RWbPhkMIUY69FIPl04fcW1ugtmluUK94kMhRtsZaSQRxhUzkMx45HGM5IppWASS3nsbPvINXFw3diVxfwW7Lt5wqmONDg46bvLPzrbXtfeQqi3mmRMmB44Z5I3jJAJUd6GH0z9arNd1dO8WztWC28KgudxcFyB4j6np9APMnOckv4GyZpWc5bHOcbjk9KpIhs9Pte2nZ+Xcsr3NsemJ4i649mg3fwq6i1HSryNmtry1nRF3P3UqExjy7zJGPbOK8PTUFlYQwAD7zF24VI1GSzH2qZpOl6hqzT3cVwLW0EhgEkgbN0R9/u/UJwOvU+1FBZvtU1rQomZWuUYYPhiPeur5wArLhefrWXfXLeeQR6bpdzeTNkKX3SMr9NwjiwPQDJNWVn2SsAyPO7zycSLvO2JpOCAFHO08DJ8wa1Gl2lrb4S3hjRV5QABBt/WBx9KAPLtfPbV7J3vU+HtiCHtY2AGB5yRphePcE9aqL03c8+m3dmJA2oRrGYoGkVlu48RvG7N5cZHOOPLFeya/BDeROu1CDGYwRjnGep6V5hbRmO4vtOkYqSwuLNzKUaO5iwhYY6Flx6dTz5Va4AHb9nZGjUXtxcbnLNKIVhYZbkgSSAsT71Oj7O6Siku882CAFmeRWx87fauKCLi9Hi+LuBjrulY/jmni8uuf8AmJTzyBg/yrK2GxbpBBHbtax24EDQvDsMkjoEZCmPGSfOhW1rfQWtqkrRSyRQlXaKRMHaOOHOc8VCS41AkYlkxjjeyIuTjklh/OpHx0YubW0YLKZhIJZ7eaOWOF1GQrAgHnzOOM+fWppjuyWBKAMoxby38Yz/AIQSM1GgtZ4tSmvE3IkwaR9zLu70Bdp2gdcgt9amiEJ4SMMOPXg8j8sU/aFV2P3UVnbA8lGTx6+lAFyJBLAJR1bZIwznxeHPNd3NVRa6jH8MHjgmmiuR3sZTCOn6pDxuM/nUtdQsSql/iI8nH20Dj81zSKJm4+vzpZYnqaClzZP9y5hOTgeMKc46ENg0cAfjzQAzJ9T5UsmuniucUAdyfWlXKVAFoTgmuAkEEdQQR9KbkZPzrm761lRqCjEttmNUM1vuYx7GVZogx3d3tchSBzg7gfLBxQL/AFiz0y0nvruC8jijIjRXjQNPMwOyKMBycnzPkOfnM3f7/KsnrOt2Mt9qtmsMk02hrGyOFR4xcOVDSRknAZCQPp7cNRG5ruVOrdor2CRWl0/vLqZEkaEzvI8QfOxJREgAP+Hy6fOJNf8AaiRQ2zTIN2AIvtJZsnybk1yLtNpUa9zE00IETL3jREBiBjxFGLkn1xVbNrOmjwozzLtdM92wYhiTyXOfU/8AxWyVdjG7OS/pJ2+11BYy4Ge6gRB8t5YHHvTPhJJpCJL+8KYQDLqruX6Kqgnk+n5+kebUbeQKxhl2MzuPAFDksOeWK8dBxxUd9RkZmeOHDEkhm8s9cBABVUwLA6IJhmKZUU7lPxcg73gnBID4z09uaVppttbXJXEV9cINyLJhLWIr4mecZywHpkD59DG06W6nm3S5MEed6oqgkY/aYHAHBPB9OpqzaWO4buIYbycSIiFEZoIiTgZW3tAowPIsx9/QHuYnsFmCh411PUN5ZeIIpCEQBhhVii8RJ8gFH1poj05iYp4pB1YxQTwW7RZ4GfspXxgZK7Rz1OeAJbSztpYJGtUUfdjiWQq0mDtaR5QxYL1GRgny9QWDShqF5YaPDMqz3lwIZljKtHDh8u5MQO4KB03YyR18nQr8Fn2fsNFE7avfMq2lvJIunWlyZrky3CgHvWICApH9Mk9MDnQT34vGkSPUBvmHeeGzfjawyyhm2+n6v1qPPploiW8Sprcsca93FDZaY6oEj/WLSjgN67fpShW2snjkuLOK1UMqxnU9UAnCqd422toO8znr4aTiU5N8lvFpOkSWS3VzcJvZpV72f4jMsrKGw8XPC8Y48/Pyrv0fpULXZtL+CGWXT5orVZZ5gsN1OrIzBmUoBzt6/rk/KR/xBbWDXPc2a3ErLIEkkZrO3Ecg2iQi4JuCSpx9wdM+dZW71i2WTfbwwpKsaxiHSreW8kQc7h8TfblH+WOmkxWae00y5tLW5je3KGaKJCwVVCwhicq8b7cDpnPr6ZEJ7m2tSUWS3mntLDZBbwzJM4Y4QSKIcjft4z1GfLqMRJrFxdGPvoCyFjFBJf3Nw8KNgrg7sR7R6Y/LoHZdy/ExWay3SPLkGC3duEAydkIIC56eVaqFIlyRy6u7q5uH3d5vZ3JDcck80z4eTgEFnZgqovLMzHAAHqau9I7L9qZXaX9AalNCyuAJUFoCzIcMjXTLznGODVwnYvtZb217eXKadayw2txLAj3hefKoWKosSlCSMjJf+ORLpGdNlBp+nG6uBpkbkKGR9WuYvEUAJxBGy569B15ycYFbqOSws+6hQRwpEoSKFS0jwbRkd2FycevTOc/rYrD22rW+nWaQ2scjF3WWWW9kWGORyBnMVv42GfXPAA8ua651q7mBXvpCm5z3duvwtv4vP7PxnPzFJqyj0G47V29l4Bsy0bEJMS0neHI8MMGW6erjGeMVWDtprQm7wQxvE+4qt2ohjzwSUhtwXyOOSw/0wRnlABXZGjDG2LC5Ged2OT9SamRXIk2A8HB5x14AxSapDNfJ261GRtnc2CMxOBF8WCT16NGwqik7RWnxPxZtxNMPGWV3VcjI5DIvXP8AWKgW6br23GDhp4AP82VqmRSS3+Ec/LO2hDPQmXRStvc3LXim8g+IxGI3RGY5+yZsE+Wcjz9qjSy6WCnwzXOACXNx3WTzxt7sD+dWHYrT9Mu47ya6TTpGi1C1jCaiYCqwi3UsVWdhxk5OB5CqO4ERu70wAi3NzcmEAYAi7xtgGfbFSyXsTVubcH7pP72CTQLiGyuZbedd0M0U0ckjxHBljXA2P4h6YBoVuRlhtzlDjcAeRyMZrT6ebX4PvBFH9n3wYiNSxCnPOBk4/lUt0CY9DFl0QcbUlUeW05HB+lKRIpY5IZYw8UqlJEyRuQ9VypB/Oo8N7aySW5iclLjv4owyYb7P7TBweMeL8KlYH7Y/r61BZFtLZrG3WIyy3KpJI0ZlJDRxEeFOpHhAwTUuGSGUH7YKeR4WDg/Uf6VC1YvHpl86PhlWPaVxnLSKpx9Caz1je3Fst04G5gbRlBDMpLSqHyevKkn6Va33A2EibeCEKnocAg+/Iqbp86ENbHAaIZjA809B8qroLmG5gUttRvu5BJCupwc/zqXYKgvIw+7DRTKNoUncNpGCfrUjRZnFNwPSpAiiPC96fntP8BS7pAcYf3yQP4CgZHwPSlUnuU9D/wBR/wBKVAEhkOTVbqV1d2smkQWotO9vp7lWe8ErRrHBCZCAIiGySRirkryaz/aKO8iks7+1uRG9lZXiLGYlkDd66ljuY4GQMfdPT3qLrk0Hr/xAxU/pGwjOettp27ac8YM8hOfpVba9l7KGS7mF1cmW8LSXLhIw0rMWJLb93XJ6Y/Kqq57QX1lpmn6hearcC41C2FxBZ2yQKSCSB4tvC+pI9gKjW2t9sryPvXuTaQMN0YJdpWHXcFUqcH3NOpck2jQQ9hdABB7m4fBBxtt/wJMRNW1v2J7PjBNjO44bDyOFJ6dI1WvPbnVO3SthLh5o9u3esr7SMkch5M59ai/H9r2eNpmhcIysyTTOVcAg7X2ybsceRp6ZPlibRO1WDTX1TXrc3HwMFn3yWkPdiTvArMm1RM2Bt5Y5Ofw42UfZrsRZ2yXB0CBiIFbfeah3gchAd5UORz16V5fdR6vcNI8zWYZ2LErxjJzxkf1/GOkmp2jL/wAzwoCrsmZSgBz4HUZBqnGT4Yk0ux7EnZjRJWs7rToDpt7GEkRLdikchGCrBFO0+uR9QelZjVNLlsJO6vobgQPJIWkgt2uYGzuAUBXjQt6BwR54PSs3pfavtBo7fZ3QvbIuDLa37tJsLHJKuPGvsQfp6+laV2v0LVkS3mYRzSKEaz1BlBbI+7DcEbGHoGA+VRqnj+W49nwYK2guTLLIIr2FWje3ikSxWeRTJkEt3u1N2PPnGeMAACWezFzC8F1ayanPJtILi0uGKjHiiljhPQ+09afV+xNhqAkl0qdre4UEm2mDd106bTkqPcZHtWGm7P8Aaq2vFsRpN487KSnw0ZkjdM43CRTsx8yK2jNPglpoPcQzWTKbm31HvZXO2G5vJFQ8ZwIVlebb1zuf6039Itb4cmy09DuDLbRIjhd24jdhnJB5GD/qLyz7Ba0wVtX1K00uOTaO6g/5q/kB5IwuFH03VpLbs52O0VEuTp8TvGQRfdpJlG3HRo4DxgdR4BRLLGPLBKUjE6ba3Gqf/itL1LVJnZmFy0Xw9lGc8kzTOAT65J6dDitLb9kbsqE17Vra2iO5zp+lqZ7puQQk02BwPMCPBz1Pm/U/7Quz9urRQ3F1qTKNoh09PhbMDyBf7xH41jL/ALfa/cpKlhHDpsPORZqGl/zSyeL8qjXOXxX5HoS+TPRJoOzeh26SR6bZxRqI0aXW3Vy8bEZCQtlR+1wB06c0L/i3S4w0Vtqtudilu40ez3YHTkqCvoAPMmvO9D7M652pl+MvZ7iOxBDzXt0zO0nJysRk49s/gGPB30n/AAr2QsoiqrbqoZoOC95cyYwZIUY7tx6FzjA6BelZztcytlRrsizim1C6QSSLeQ7kLEajKUmVB1MkURG0Y55IrFdoO1sVuZLTRWt75yrx3d08QaFCcALanduOMHLHIOeOmTnO0XazVNWzbRn4XTn8QtoXyZBng3Eg5Y+o4HtWcV2TGPTAwcYNPH07+Uglk7I6GmBIOcnqcA/nTjjHik+YA8jSk3YUAE5zyPn60MAZJcjC+XUk+nFdNWYWO3RDopP7x/0pCVgwZCV/drseGYqiBmOT4+Bx7Un37eigA4O0Dg+9DCyTbO+959xBi2bW3HIYHI6VBR9jOSAdyuuPLJ86kwH/AJa89cA/kaiyBVdgpJAI5PU8ZoRSL6BwsMKnzLufXJ2r/KjKVBZsc4PJ/wDmgBRiEfspj67jReMHw+1RZm+Sbark+XChScZAJPrV3FdCNLdO6J7tdwwsmC0nXO0YqihVMNxjoMgkHp5VoYn/ALpQDjugc5yp24HIrOTHENEd8ue7jTwuWCoAd3HP580QKv7K9fQUKLJl8ONxScsOARjuwufzNSFVhx50GqMt2ju+71HRrZVG2B4LqZSPC7SyAAMB7D86qJY5VfTrdTbmQSzNGyEd6XZxCoZwc4OBj0qXru9NbvXbu94ksJIi4JPcrGjBVB8OPXPp706O5t5tU06ZY1RrOK6vmjJBBMNt8QCX2gnLA8eQ456nWtiRup67cWM407TGiSGy2wyylFdp5U4f74+7nPz9a1XZ69XU4ra5I2yoZo5QhYbXC4O0g5wePxry1mZ2ZmOWYlmJ6kk5JrcdgJGLatESMKIJFHuwdSR+ApSjsUjerGnnk/N2P86KscWPu/mx/iaGuaKoPFZDF3cX7A/OlT8UqALZh4j0qj1tLS5E1tO7iHu1gmKSiH7xyR3h+eK0HhLgerAfnXnHam+kifRyVZkk1SSeRCBtdlB2cn0Jz9Kzkm6RqicvZ/stNJDIkbTS28cVvGwne57pIxtRAviUY8uKM+ndnllaObUEWVf7yO6uEMinr4lLKw+oqN2U1zTbGKLRIrae91C+nvrq9ntJxFGzEMzBZGAfCqAAcj5iodtp9h3GoXmsaXezXE8jXz3NldRqY7Wa6NnAgWQqxGQeWOfPOOaFFvuK14LldN7E8GXUdM555urVQcexc1ISz7CAeG90g8f+5YMf+5Sa8h1yzhsr2eCK2kthE7RGCeRJZV/XVmZMryCPOq3e5/WPA4+laPE3xInUu6Pb3g7BjCtfaMXOAqFtPLk+WFSImgSwdhoVkeM6M0wjZ0EiWqmQgHABliC89M4rK6boMulNDc69Ytc6ba6bNqMgsHhWbu2MYWQuwSTwF+QGJz7LTu09hoSW133Gma0l3aPaJIb6WI21st3DvHeFZ35bKsCPMYOBU+k75DUvBrdEtux9/BDaXFvok9xMrPMsMdoZ4nJySNqdBwD+NUFz/ZsZNV1IRata2WlRTBU7wNJP4kWQosWQCBn9r6Vi+ysqW/aLRJWYBUucuchRgo6kEsQMevNbjtNrur2M9i2izYk1CGZ2k+HMr4jIUdySrHjnkCk9WNqKd2NVLc2FjpttolnEjavqtxDF/dz6k9vHEgwBtjEy7yPQDPWs12h7Zy2s1vBpOoyOyMZLyWSMxxspOViV2Vd2RkHw8YGDkknCre9p31G1vr86jdvA5kUSrMASAQAu5No9elG1pbeHTtLnEWy+1SW7vnVifsrTPcxRlWz1wSD18/OiOP3W/wBhOWxOvv7RddlLpplvbacshILoDNct5DdLJzmqAm81aG8vdRvp2Zbu1tIprqRmiWScuzlhycALnCr5/jUsBuxg9R08z71eaH2e1ztBcCDT4gLWFt1zcykpaW+eS8jZxux0A54/DoWOMeERqbK0W9yGihjEnfTNiOOEEvLu4AVVOT7fOvRuzn9n0UJgvO0UZknYd5BpMZDMQRnfdP0A9av9N0js12PtGvRMnf7Ss2s3qAyysfvRadAc/j+JPli+0na+91COe104y2unyP8AbeLN1eZOd1zP97H+EcfPFQ5yn7YBSW7NF2h7bWGnJ8DpS29zdQ4jAiA/R1kemFUffceZ6e56V5nd3txe99eXc13NqbzbmuJJB3Yg2EFAuMg56YOMcYoKsRnaoXoMgdTj1NBJJGWYk5AAOTnzrSGNQ/Uzc29iRJawC0+IkuI0uVYILckF3XjBA8uOelRC68YUbvU5P5dK9Fs+yiapo2m3VvdLazXdpFNcCa1hnjnkyclpOJRuxyMmqfVexOp6fFe3bG2a3t4VfvLeR2UnvAhzG43jg5PXGPTp52H6v0k8jw61quq/nJvlUWk14MnI8jopZi2Mqck8HrQs9Bjzyae3h3o2ef8AyFD616qMUPR2RlZDhgePP8jTw0hWTDffJLg/redCFHQAFV/wuxx64OKTA5FJsWYHJLhQB5eYOaC3LDP+EHHtxRI+W8s7TyfIgZrkm0OreROfbGaBovim3YMclFY/M13eoOCD7U8qSW6kq2zpxwAKJHbO7Z2k45yQcAevFYktHYmbnBPHI43An0xWgsTGmTOr/DFSFJSRxvyCNu0H3z8qr4lktmQmSCNj9zvSiEk9MKxz+VWMN5furQ7pZFAZiLdZUVg3k8jqqY+RP51L3BIlpLBvgKYJTMUhUKPvKxAYA5BwPOpBdRvc4VFBd3cgKiAZLMT5CqT4+0sgVeKytSryOY/ie8kkkIxuZIEz6+dUGr678dGLZTL3QYF0TbbwvjpkHdKfbLD5U4xLA6rqsV/fXFzCAIFezhRWXxTRQliHL/eXPOQPUelDeVIp9YdU27NNlt4kJJ7vv3jj2hjySAzDn0oEdlqEtjeatFbRx6bZzQRyuz+EzuRsjTvCXLYOTjgCq8yNIWwuDI2WwTzznGD5VtQhRQNKcAMTnooBJz6c1s+x0K2tzfAzxsLmCIQlTguyMWYANzwPb+FUFpEVt5JhCsqDOGcZWMnz8LBhVrooCxTX7M4dJ1WEkg4kQZYrnPPPPH+0z4GmehqW9TRlZvU1HgYSRxSDgOivjIOMjJGRxxUlRXOUO3N6mlSwaVOxl+vMi/vD+NeearYyahqnY2z3v3dxqF2rNgeJIftHKYGM4BArb3dwsEMrk4J+zXB8RLddv0qgVJ7t7eJLZLiK1nkmfON0HeowHdyZBB6hsGs3KmapFoez2ixRy7bGe4YowWI3TIzlhtwWchOOvI/0rGW9/NaR39rrUV/e6hZNKt7/AOp3MCNHlmVdm9FOOAMcfz2Pd3IVV26ggGP7q8ulPAx13Goc2iaXeuTewXNwSyyubm6uJAWQbQx3nGQOM01kXglxPH7xku7yR8CCKeZmU3DyS90rvyzO25yFzz1PHn5g1COwiu5IrMP3UexNzTrcLK6qAzpIkaeFjkr4ehHmK9fHYLsXdknu7vIHJh1HvCPbDbqJ/wDTXQU8UEuqKR5SG3uF6dMOgP51r60SNDMnoOtTvOw1C/vFt7uFiw0qWBppb4hSIyJUIClQBt6Dbx0qP2p1KCde5E2tvNIY5WXU5dymNFYLle6jzz0PkBW4XsVYxAqJHADRuCNMtA26Nt4zjqM9c1UXv9n+nstxO+r36sEkeQtbrIT57Vy2R6DoBU+tFvkelmB7LpJ/xJoKpHEz/FqQj5KMQrHx4z9a2Hbu7kttQ0i4uIw6iG6gCWsjRFlJU/fYFuCasNB7HaTo11p2rLfXF3dGGRra3MSxpG0ibWkeTcc7QxxwBnH1d2o7PalqV1Df30afo2K3cRfBmWcxMdx3TmPDdcHKqw45wBmolOM5quw0momIS+t7hzbRWd1C9wBAJZ7u4nMbSeBfs9oHXHHln6EXamVZtaltYSph0+O20y2WMZz3KhSFVcnJbdn3rTaV2duZLzTbjSnS9mNwJnzN4LZUUkSySspIGev6xHGOcjXaN2a0Ds4J9ReSC61JC8t5q96FS1tXbJb4dScA8/P35xVxlFe5EuLexjezv9nVxcdzfdohNbW0h3QafFxf3RzwHH6i+vn8utavXu02gdl7WPToILdriFMW2kWZAt7c+TXsick+ZHU/XNZrtJ/aG7me07PvIgkzHcarKMXMwAwVtw33V9D1+VYCNFnF5NJPGrxxmdu+MrSzszqpCkKQTk55Iq6lk3lshWo7Is9S7R3+r3DXN+XlfG2NTKqxxJ+zHGEwBVa95E3Hc8em8nJ+W2hx2d5Lb3N1HCWt7fAmkDKNmSB0Jyeo6DzoUcb7gcEEDcu7jp5/6VsoxXBD+5JeZ4/DiBSCrGNlLkH0YkYyPOkCCSGiszt53gsVHnkbG59KhE555JPUnnJNFt32uMkAcHJGcY9qGtioJNo3mkds7/TLG0tn06C5tLeMQRurNZsqrlgGZy6knnHFTW/tD0q4QxHRphJKjRjddRvErOCNzAICQOp4rFozhGURFosh1jchwX6b+4OU3Y4BqClteSXUghimaVO+ldY0AdFQFnYqMgAV4T+i9DmyPJKO93abX7XR19RDQk9NF3Pqel31nq8MXZyE3t0ySi+tRJsg7tgN0MWzwhucjPnWa2tnjPXFaKPWPh9Dhs7fvYLwzxN3sMhXEMDNKrHb1JY5Hpg+tUjMGKlS7OSwdjjxO3Jxnzr2cFtNNUl9znywjCknYzu3BKZjJ4+6wbJxnqPzp4tpA+05Q7VJIBPDc+VEgtncIdufF55yF6YOOferIWvdAyT27SRKNwaGSaKZ1ZigJULjPHmfKtmjEgWunXdxIFtQkr527QT0PHi9P69aJbaLqdzcJCYu7Al7tnk4VWHJHrng1ZNIs+wKpZYUkMaspSf4c+FhO/63UMc//E2JUkEIk8TSxwpIoDSZXPiPiPI6YHlipboDttaKy3TPdbU+KuUR0MZDhW5ZSwIxnIHFGYaUgUNvmwQTvkcgn0boKbZ6RqeqXM9ppzaessUf2MN1JJC07Lk7LcBCpIAyfEOvoOKPWLPtHpNwbPVLdrV3BkQkBkePJUNFIpIK/KsVFvuMun1K1iP2UcMRCnxBA8gXODyOgqQmndpNRiEq6bfTQPEJ4/ibmK2jmRl3KII1OWz+rxWEZpXOWZmPqWJ/jV9or9upIRHor6q1rC5YLA7i1VickDcQnPmAabjQ0dsrnTnvII9TsJYbUNcm7+GDpK2I/s1G7a2QQc+LnPTjlurposWoxxaSyPZiC1KPuZmaR49zmQuAdwJweBjFEu5e26RjSbg6n3krYe0Ks7yCU98hwMk+ZHpiqWeO6tZ2ju45YLmJl3xyoUkTIDgsp5Gc5ptXwzbFPRKzX6jMW/s90gDkHVUhY45Bi+J4JH0x/tWMijGYzuU5G4gbgVwejZGM+dTJ9WuptMj0jZb/AAkN697E6IwlEjKUI3bsbSPLFQYztIx5c+xNVDZUZTdstwpa2YiJcxqCZO+CjGRnCZBJpQ3Mi2VtEFHiMkgY53KS7hQDnodp8qiiUvbsu1CQAxPOcDk+VNjaQC0YLle7xwSSdkzH8etD3IPTuz1wLnTLZ8YKs6k5XxHhi2B75/o1drWT7GSg2V3CThop84J6A7ug9PrWsQj1rnezNVwP/ClXePUfiKVICVd2qXaBGZo2R96SJgsvGCMMCOflRLeKG1iSGIEKpLFmOWdj1Zj6mlv5NczSNA2751R9p9V+DsJLS3vEivrhoA67GdltncKcncACSRgc56Y5q5XbkFiAoG5iSAAo5JJPFeaa3qDXmrXkzi0BjJjgkjj3R9xA+5Znk2jIAHTBOM8jqLSsl7FVK6SmCNJIwySK5eSQ7kLyfdJBG6RiMnPAwOOaFdwaqO7FnfyqEJAZriWOZuvLbDtzUeSRo44mkgjPgYhpwVct4pTKUU5BJP7XpVaNR1Rc/wDOTnjnc5P5NmtK7kWWkbdqRuMur6jDtAKt8XcyZOcH+7fI/CpA1ftha5263qkyE4DLPO52jhsxTZ4+lUqapqh8AcOzFQuYkZs54CgDz+Vbzs1a2d3pMl3eWsU06yaoLia7hiUQPbQLJFAiA9GPU4B4PTg0pbK2OPOxn17V9q4Xswl/drFDwN1tGUVRxsKlMEeo/obDRP7Q9P3Rrqa/AyGQKbm3SRrOVhz9rbnLrnzKk4z0q5m7HdmmjSW2tjmeW2QGO8mMO2Rwm6Pll8xjH8ucZr+nQaTa6JM5ULcnUnkPeO8RjSZVR4t43eLggVitD2SNck5SlqZt7ntJoWm2BlaayaO5eWWK102eEPfPvw0skoI8JP5euMDy/X+0ura9cdxcMkVpAWWG1tXU2q4PBUZwT75Ptij6Tplxr7iOwswxHileZAI4FzwZJAPPquAT7Yrt/oH6NcpdR2cj79n/ACe+fDf4jGmBj3Iq4xUX7uTJt9jMZ+/gDBxyV5GfIVyOSeMSLHKU7xdj46MoIbafqAfpVnqOnmO1tLmGBlikuWtu9X7juFB2k5OD8wPX5V8CQyXMMF00scQm23D26JLKFBOdgZgpP+bFdSTe3czJVtqep21nqdgjRSWuoqq3CyorNlCCrxsw3AjA6GohkZQd6NnBG4ndz7mpNtHbx3MAvI5jbpLi4jQhZymCCAemf9KlW1vDJJK52i0EyQ7pJEQ5l3FAFY5/VPkR64zzmnTNcOP1ZqDdWVCRTPHPLHC7RW6oZ3VSUjEjBF3sOBk8Cpmn2Xx19YWTMsHxMkcffysoihVjzNITxtAyTyOnWtxFaahbabcaZa3NqumXfNxBNp9pKZWzlWebYGJU4KnPGOOlY2405YJruIMO7tVXvZASVYkbtvP5iqbs7sn03Lj3dDrSFHe8sBqEcezvgJCjPDLscAMskalsHrnH8acNNu7QahOt9ZFIbMO8kF6haTvnEaxxop3ljg5GOBycYqGSY0k2b1DKrAjw7h5cdcEUBRvB8AXLZ3tkcdMAdKiMd9jlyzfxlK64OxxsRwwUBvukZNd7tmEgCb13Ah06ZJ6DPnRUtgchZMtjp+rz0yalW7yMEVYCAjYKRBSWcZww3HH51scf6Bbe2jwjzW+oMjAFTCJAwAJBBCuoHI4/GiyXcEbGO0luDDuQv8UpadZBxjcx3ADrjJHOalRyXcIRpLK4jiEkTzTCWGR9iHcVWNeck4H3jx5VUTSGRu8YAYLEgAcb2JOc/PH0pWMJ3pR5U4fftHi5ZSw6gg5zVlaWGoywrIqYQDeplkRNxd0h2rvYHJJA4/lxH0i0a6la5kUCOJdpZgApYdDV1Lfxp3NvFP4Lc7ozE6+CQncXUc856ZrGc3wioryRIZpYZ4d6MZbWUTGNJZFLsrtujkeJtwBGRkH8jXol12e7N61ZWZd7uS1YLcwBbu4kWNnA3bcuy5/Vb5e1eeSTWzW4PghuLUIlu8ClTPCTjY23gMvLbjyehz5a7s3eCPTmtwMCCd2Tx5LJP9ruxxjndxWM3tZcfAIf2ddlklD/ABd+8Y57mWSPYT7siB8fWr4WMsaRxQ6rJFDEoSOGOO0ESKOiqhhIxQmvTk8mhm+dc4dvxzWLlJ8mipBDp1wbmO7a+tpZ0RY0d7O2Dqq94AAyY/bbPHn7cNl0hJrhbt4NJlu034nmslaQh12HcVcA8euaF+kX/aBzxyFP8RXPj/PI/wCkUtTHsyl7X6bfp2dvT3GmLDaz2Nw3wVq0MmxGMA6SMMDd6dPnXlo8q9nvXTUrDUtPcgC8tZYVKgDEmNyE8+oFeL7XRmRwVZSVYEYIYHBBrrxSuO5jNBVywIPJPT+hVhbhe4tyy/dkngbAJCFyhTdjzJJx8qrVPPn9P9avNHEcvfW7Ip7xVkj3ZZVlTcN372CcHmtG6IRqOx1wyjWFj71lNwJAEG/IZ2wQpGenn/8ANbFL7GN+5fLD25P/APQ1l+y0Hwn6TPOHNsiHKlSqh2zj6/1itQs/Pn+H+9c0pbm8eB/x8ft//H//AMUqXffP8B/rSqdSKJGeT867muDBzjzPlzSYMpAOEz0MhC9P3sUwB3kqw2N9KYTMEt23RYlO8HCnPdePAzk49K8nn6IlzGRHuRpeoeEDfGiPuJ5YbRjnzB9a9N1Z2awukgv44HAUu6s+HQHmIOoxkj3ry2YygRkqJEHeXDr1YSKe7A56jkMfTNaYzOZW3ZUqNqNuJxK0hycAcgcn+hUBs458uPnU27LLJ4x4zhiP1RgbetRJDnHyrZEA0LKe8VirIVZWUkMrZ4II869b7CrcjS9DZZdltJNqMlyWm2q8jSSKEeMttJIQZJHGRj71eZ6TYXeqXD6fZ2Yur26hcWqmbujG0eJnlBZgpIVWAB/a9RUVJbu2lAR5onR/EoLKQwOCCvrSnHUqKi6Z9BazcXGm6fbSWscXN5bRiMwhkePDt3caKOpIAAXn05PGW1XTR2ji7JpcXlpHbWU+oRyyQrDHvhjaMBLa3yVOPukjhcZ6jBwsVz2qt3mktLvU0ty3elYDOysi/fkGAVAB4z5ZolzqWo3dzp6yu8cEbOlrEWZ5IY3jLHbJw3j/AFsAA5rHHHdUzecdMnFmi13tLbWca9nuzccccNtnMsTsSZlwxlMowxk4wTk5yQeOAHs5e3c2ja5AXuF1JU1W4maa4EQk+KhVUYRPgOfC6jnw8ft8Zy2Rp5zHar3EEUhWZzEDKWHVQH4H41OaCe3t2muZYnWN8M8ak7VY4DSBQQPQn5etdGeHR5GunlP3WnZklJLVWxpdRv8ATo9Plt9Vnsjp0sWl2kS2mJL6B3i5lZehKDLceRK58WB57qOkX+mXIgkVZBJmS2ktm7yO4gJOyaIrztYcjOD7VaSXNntgDATmZtkCRxd6ZX3BcIMYPPpWwuNC1e20B1v7ZHaEM1lHasJbix73AaOXwFdvU+EHafTPFwwR6Feyd7k08jo81gY4IJ5HHqfkabdgnuh5AMR9cVInsL2yuFimiKM0aOm7ALKw3Ann+v4jugAsOCCfHnHvjFdGNQyZ0uzIarYDb3F/AwFvcTREkcRSMuc8dAaZPNLM8jSSOxZixLMSWbGCx9zSCsiSOAfNUPPmPE1EtIoJi0bGTvZEZLdUAO+Y42L68nj61hOlJ0Vrk1Vlz2dOm3faC2t3t9tnewS2Rjzko722Aykee8Z+tVPILJJuJQlMNkBSODnP507TDe293FcWpeOeASTxSpwUaNTllPqAc0ZPvXBYMWZGPPiLMQTk48yfPNRe5LHKvijEONwwWPJQL5l/f0FTLZbhe7SOMStHKWdhII03qcmPJB8z1APShBHURvGe7dwsbZXcu5l4JAPUGpcMVyFWJJY0CqAS0AkcKSQTlm2YJ89pptgh9/e38lsLdoIl2ync8MzuQyDdhwyAdDkVSsyHqG3SAnA6Esc9PfyqfemRe+jMxbYxuGYosbSSSBIcAJgYx08NR9Oge6v7GEKSTMgwAckjxYXFK6DllrLPDpunJE2cgLvVCFeaRudpbHA9fYe9C/SEM9okqIrWcOyG7g7pFmtN33ZUdAMrn1qPrkQaK2ul3FSXMm51ARpHYIETO7BUDnHkfSq7SpQt33bjMV3FNbSr/hdSQfmDjFQopqxlk52sY85AJKt5MOoIrQdmHK3UyjO24t3LgsMF4Su0quOuCc81llJEFuXI3xM9u+M5HdsV58ulaDsy7/pGAeHu/tg+cA72jKoVzz6g/Ookho18gPOBUVy3PBqxZcngED/Fj8qG0YAPArnLKsswz/pTS7Y4qx7kN5CnC2X0oGViSSBlxnjnisV2i02SK7ur2CMm2lKyznP91NIctkZzgnkfP2r0tbVMjw/wqLeadbTbUeMMowxDDPiwQD/GrhLS7Bqzx8Nzz+YzU+ymKEOrqJIzuTc2B64xXojdntIf71pAf8uDT4NB0m3YSR2cAdSGViillI8wSM1q8qaI0D9CinWxiknCie4+3kC9FDDwIM+gxn3z61dKDQYFCnbjCnp8xUoJXPVuzTgbg0qJspU9KGQfi7+Y4aaVueAh2r+CACiLDOxyVOfMu3JqcsLnOEOM+Y4oywtwCwFYpsuiqvbN5bO5Tu1nYoNsO1mLEnGVAIORkkV5veKInKk/DP3ptUDklBFGpyDkAbuF688j0r2QQR4KtkhgVODg4IwcEV5trunCx1CW3SVpWacOPiogomXuucbSR4hwDn9bkccb4nuZTRjLk5dmZ9xOefMrj8aiOOOP69qsLoB47d+6KblDKMYHTGCevyqAcYI+ePL8q6UZHIpHidHR3R1IZXjJV1YdCrKc5rkjTSO8kjNI7MWaRiSzEnJLE8/OuEYrm5hkZqkBo9N7QxWNo8EsNw8z2r2JcSr3Pw7kkBoiucjJ8xmg/pe0ivLW+VRNJD3mIl3KmWjKKcyA8AnpWfOTXQPwAJrBdNjTk0vlyW5tmk0L9MavqUenWc8VrJqU888txIgfaRG0jtnBboOAMda9vgt4Le3jt1jjKLDHC5aOMGUKoUtIAuDnqcisN2E0h9ItJ9QvIrf4q/it3tHUkzw2rxlmRy2Au7IyMZ46+Va83ZPOazyKGrZIqN1uHSy0yKaS5jtLZJ5CC8ixrnIwcqOgPmcAflRWkXn0OQR5EHyNQTcjHWhNdD1/Opoox3bDRtLtIQ8ZkX4hrmSxjjj3tBPGqM8W7O4xsDkZ+7jrg4GFgsru+kW3iidptp2qB0GQSxOQB8zXqOuQX2opZfCSwrJA829Z87JI5Aoxnaem0fj145ptD0O/ttQu7q9REIQBGV0dZWkkLMwKHywPLz9qM3U5MOOWSCtpC0KTVhdE7I9n7jSUOovM97dQgSxd9HE9iwkzsjUZO7AAywPBIAGavNP7O9mdJliubOwHxMRBiuLmSSeVGHIZC52Aj1Cipk0FnIid5BFI3GCAhOQQc5yDQDaQruEU11ApOcRTOoJPt0r5eH9Sq/8ALBo6f7ZVsyo7SaD2fGm6nfx2FvBegpcpNGWi7xy4DgIWCtkEnaAMmvP8O0kPhKIrMzByAznGApVc4HzNbntDYvHp11OtxI8SCM3HeTEEoXVQMk46keflWFfxqTht3e88gDu2PK7h6dep/OvpPp/WR6zF6kfNHLlhodDlKuZWDlLaJ1kdk2ksyHLmMHyHlzzRI5bjfK8ZiAYKTlHY7FHGACAOpNClEgjW3HiSUnu36kRrglCAP6zXRdSE7Y4mYMpHiYjgDGdqivQMiLdu8kheRwW8ONq7RtwADgk1adnEka8nmGCba0u7hQWZVGyF8nK8ggcj5VTy95uXepDKuzGD0HnzV5oJwmpE7RusZgx393nKOAuRzk+nn0olwJLciSi4ksO0crhZImfSWjkQYSIxSPCsfJ4IBYYyfXnrVHAxSaBhwVljOf8ANzVtqDK8N27DdNHcIm7uGgJhfcymVPulsjapGcgHPQVV20e+eFR/7iH/ACg5NWuBk4O2b1M5U3cj/XA5FXWhuIrq3dvvLdWzIMZDOCzAH24OapjEyi/kOBi5lUc5yQQpwa0ejx23d6Qe4IuHunLzPv8AtYzI4QoreHwkFcj1I/VrKfA0tzTi5vXbPej3GxNv4Y/nU2KRZQBJhH46Z2n5UFIgOceQo6oPQVymtEjuwBkEEef9Gu7V2g5GD50MKQRyp+R/o04q4XOGAPU4OKBhVQHBAz06UCVQZH9jj8Kep2nIOOnTjPtXW8RLcDJzjJ4z5DNBQEIDSIz0+VF5PGOK5igKGDhkI6AipgXmoh/OpqgkL7gGgVHdp9KVOwaVFhRJPU0q4W+9XM9OtYooIMVX6zpEGr20aGUxXFuTJbSD7u7r3cgORsPnx/oZmR68VwzIvzq4ie55Dq+l3FhJ8Nd280QMjLEruwUhxuDxsfCVBODhj1HTpWblRo3dGBUqxGCMV71eSxTW8iXEMU0DAhkmiSZORyNrAj+vavPNZ7P208xbT4I4IgDmPMjbnPJfxkkH610xn5MnDwYQkYA496Gf51eN2Z1vOFhQ8/e7xQPz5qXB2Ru25uJwueqxLn/ub/StvUj5I0szFbTsx2ezNa6leNbyrHvdbLbFPncmFeYZIHXIGMggdKNF2Zsotp7ssw83Ykn39KnR2Bt8GA7D5bcqfxSspZlwiow8mq75jktkk9c80wyny/KoFpczP9lOCz48DqOWA6gj1+lSi3tistjQd3rEdT9a5vPFNyvlnP410UAPDmiCQ0KnAH3ooQTdmnhznr+ZoQDZFPxUSxwl8kmFsre0Xwo0XUXm3AjuO77tC7PNvGxMAHg85OK88DkNHJM+FXcoUhsZfklgec16fqdulzp2oxFA5FrNLGpZlzNEhkQ5XngivK2MjIdxUF2jI2kMwkJByCAB5VtijGCqKoiW/I9QygTRsFghZpYVOCzZBDFSPI54Gad31yfiDDCx3uXBYNwMAYBOFpsu3G2MlQ00aXETgKELEYdcc4J4JH86J/6kd0arCpQA7iw3bSSoIOCfI+Qrcghyd7IVLgZKlsg/q5yeQavNBWAvcRuVk7y0u+7QvjdJ3EgXxYPPmP5dap5I5kxvZSV+6FzxjnA3Y61baGzrc25bu0QyKJC4YptY7W7wREPjBOQDnyqZcDXJWa3KpNnaqTJ8HEVkuW3B7iSdjcNuVugG7CjyA9Sai6asYmM0nEdsrSsx55HiGQevQ8VbazpczyvLblSkO+O6LeDasbHZMd/PiHHzHvVfaRSGRIYpAbdBuvCqgqysQNjMeDu4A8hWidomtw0hK2VsJGTdM/fMSCGy5MpBPT9atXpMH2nZuGZ2LwWlxcIgcOA8iyBlKkAqVBG4ftHPOeMldmW6uY4YYzJI+YkSNSxaaQHwhR684GP9t1pYaXVLh1AMNrp8EEb7g5JYLFsVx1UbDg9T6nzyyPY0gXoSjL3Wwq0eWOcSA4P1BpuPau4rmNaG7a6FPGOnPHl9afgV360DGhenlSPU8Y8vanYzSwKAGVw0TaKay4HSgAbZNTkPhT90VCYYx71OUEKg2uMKOcZ4+lSA7PzpVzn/ABf9JpUgCuwycUIyGut1b51wAeYqRjNzN51w8AsRwOp88e1FCA9KBMxBCKRgqS2Dz16GrToRFlkEhHBAAAwT+dCMatk1IKA9aaYvQ0gIphx0ANMMY/ZFSSsi1zd5FaQEVox6ChMlT/sjQ2iz0OaAK0oVOVyG6gjr9Kt02zRRvwQRgnAGWHB4qK0RHUVKtN2xkONoI24xkE8nNaRENaJM9MD2pvdeh+WalEVzaPSrERzHIPLPuK6Cw4IqRXQufLj3p2AEEcUTNP7pDyVHrnpSaIKu/dsXHLORt+g65pMDqMoZCcYyM/jXk92kqXd2stukO25nZIYyWWHa5wilueB0NelvcsARDHl8kCSTlceoWsd2otJGnt9Qklk3ShbaXxABnRSy4XHp6elOEldESWxnQ0Vw4LElY1wucBySeSD1IHSkrzuGK4JbwF3faMKxwOMnjNNRWYE7ScTP/dnDqf21HHzxXIhMYpGjkjJhch9w27skYZfPHPpW5mOKNnMjrkFQdmeMHqGJP8Kl2b7JSN4IPnk5PtxURoAj757wOy58KALzggDGc+lOgwp7wIVJKjeMlQBydq9M+tJ1QGsvRMY7XUIAib4e4k7tV7tZkwhR4yOMgKffOc56UV5cXTghUReQoWNdsefNsZqdDdN8PKuUKzABsjdtAYMCnv5GocoLE454/A9aiJTHaJA8M9xdrKBNZxi5BZWO+V5FjA9MckH97PlWp7PR4tbq5IAa6unIx1EcKiFQccckM3+aszBviEfdJuuZ37q3yAVD8DcRjPGR/QrZ2cCWlvb2sWe7hQRrnzx1Jz6nJ+tKfkqJYKT60QUJQaIM+Y4rE1O5pClXeKAOj50ufauADincUCECfSkTwemaXApueowKVjOEqQvHSrJWBVGxwVHn/KqzjIHvVnChaGJhn7oHHzIqbGOyPQ/lSpd2/vSoEBYYJ9zXACa6zckYzzSBB4zj5VBR0sqKzN0UZx51XkgliOhJI+tS7gqqYxkvwuPLGOTmogz5j8KokcK7XBThQBykUQj7ozn8q7SFAATApzg8+mKG0Mq/dzipg2+ddPFFgVx70dV/Gi28kS79/h3AHPuPLFSG2kcgUw2/eAlUJ+Q6VVgPXupPuSKT6ef4GulGHlURreRDnDD0yCMfI04T3aHJOQMA5HX3qkwok7T1/jXVDHOBn144FIzwAZbkkcKnp70B5Xl8OQqeSj0/xHrRYUOe5jQ7V+0cdP2FNRpHklO+Rst5ei+wHSid3j5e1NMdJuwoDj2qLd2lteQvb3KB42IOQBvVh0ZD6ipxQ0xlNTwB5vqVldadLNE6skbmRonQ7kli9tw+8B18x6YqNMymOBTn7KWMAxqpIiI25ORn6civSLmCGeJ4p4UkjbqkihlPuQay2odnsAmz3KoO4RsxZMDyBPiA+v8AtvHIu5k41wZ1102Ikklm+6AQzHB8tgGM08tLJEXIaJGIEaqN24gAHw9c+dKW31C2ky8MyqqldyqJFHyIPSgCXGD45pVLBO9OFjDDyBrX7ogsYWeKSNWBBYqAjkHIAwCQnP4Cim7VlDiNcmJjGpI/a2hmOD14OP8ASq95II8CVldgivI6MQ0shwDEDg/U1daZoE9y0Vxc7oISciHH2roc+D/Cvlxzj0zSddxol6Ja3M0638oxGiyR2+dwdy2FL4IAxjOPnWvhjwAT50KCBUCjAAXACgcADoKmKDWMpGsUPUeop5BpAetPA58qzsoZtpbaJtJruKLGDx/CuUXbSKcD2pWALFNNF2k59ufrTGFIAeRkfMfxqxtt/dDJwA5C4Plmq9VLOFHmat1EaIiBfujGc+eBSTA7ub9o0q5uH9YpU7AZtBJznpTNi+9KlUoAFyTiNfLOaEFGKVKqEO2LgVwjA6nrSpUAd2rgH1xSAHIpUqAOqoyOvWuMBg9etKlQAPaPfpVnBFGIYyAeUDHnqT50qVUAO6Re6f2IIqCqqetKlSQCaKPaePPNCMaj1/GlSoGhyjjzogRTjNKlQM40aZ6UFlFKlQJg2RaDJEgGQPKlSpsRGeCB87kU++MH8RVdcaZpzuA8CHPUkDP49aVKriJkq10zTbcboreMNx4iAxGPQtVlDGh5PU+dKlTYEpEXjrxzREUHr6UqVZMYVVFPCLSpUihbQPWnBR70qVAHdg966UXaOvlSpUAMCLnzoRReetKlQAa0jRpTkZ2jI+YqYyj36n+NKlUgMwKVKlVCP//Z

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
  <div class="one m-2 py-5">
  <?php $v= "
Jeep Compass
";
    $p="The Jeep Compass is a compact crossover SUV<br>
	offroad introduced for the 2007 model year, and <br>
	is now in its second generation. 
 ";$i="https://th.bing.com/th/id/OIP.dg8h4w28-XQaoDE23n66fwHaFW?w=248&h=180&c=7&o=5&dpr=1.25&pid=1.7

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
  <div class="one m-2 py-5">
  <?php $v= "
Mahindra Bolero
";
    $p="You will find a lot of Mahindra Bolero<br>
	plying on hill stations. Itstremendous power<br>
	it generates at low speed that makes it<br>
	popular among people living in hill stations.
 ";$i="https://th.bing.com/th/id/OIP.MGMXU-XS2rsTIy0tFJWyPQHaFj?w=246&h=183&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
  <div class="one m-2 py-5">
  <?php $v= "
Land Rover
";
    $p="A line up of the most premium Land Rover<br>
	luxury SUVs - 4x4 sports, 7 seat off road SUVs <br>
	at Land Rover India.

 ";$i="https://th.bing.com/th/id/OIP.M9Z66SFULAW7LcEEIhAUagHaE7?w=223&h=180&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
 
 <div class="one m-2 py-5">
  <?php $v= "
Mercedes Benz G-class
";
    $p="As ever,superior off-road performance defines <br>
	the G-Class. The G-Class has always led way in <br>
	terms of climbing ability fording depth side<br>
	slope angle.
 ";$i="https://th.bing.com/th/id/OIP.OY9Ew_gZP0O6K5qKiVT91QHaE8?w=239&h=180&c=7&o=5&dpr=1.25&pid=1.7

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
   <div class="one m-2 py-5">
  <?php $v= "
Force Gurkha
";
    $p="The upcoming Force Gurkha is the legend <br>
	among all. You will not find any SUV with a<br>
	fitted snorkel. 
 ";$i="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADpAWEDASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAABAABAgMFBgf/xABPEAACAQMDAgMFBAQJCQcDBQABAgMABBEFEiETMUFRYQYicYGRFDKhsSNCcsEVM1JikqKy0eEkNENjgoPC0vAWJURFU1STVYSzc6TD0/H/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EAB8RAQADAAMAAgMAAAAAAAAAAAABAhEDEiEEE0FRcf/aAAwDAQACEQMRAD8A86p8UsU/PFA2KfFOBUsUEAKljwqYWphKCrbThDV2yphDQD7TUthogJ6U/T9KAfbT7KJ6fpUhH2oBdlPsorp+lOI8+FALspCOi+nTiOgE6dLZ8aM6dP0vTwoA+nS6Z9aM6XpS6VAH0z60umfWjOlS6VAGY6bp0b0vSl0vSgC2Gl06M6XpS6XpQB7DS2fGjOl6U3S9KAMoaWw0X0j5UunQB7DTFPSjDGfKo7D5UAm0+VNtNFmOomOgE21ErRZjxUChoBitMQauKGoFTQVYpuRVhFRIoI01SxTUDU9NS4oHpU1KgkBUgDSUVaB2oGC1NUqarVypQVBKsEdXLHVgjFBQI6mI6ICCpiMUA4jpxHRISpBBQDdOpCP0onp1IIPKgGEfNOIvT8KKEdTEdAIIvSpCKjBH6VIRelAF0R5VLo+lHCE+VSEJ54oM8Q0/RrR6J8qcQ+lBm9H/AKxSENafR9KXR9KDM6PpS6NafR9KXR9KDM6FN0fStPoelLoelBmdH0qJhrU6HpTdCgzOj6VExVqGD0pjAfKgy+l6VEw+lahh9KiYPSgzDD6VAxVqmD0qswelBlmKqmirVMHpVTQelBltHVTJWk8R8qoeL0oM8pUCvejGSqGXvQDkVEirSKgRQQpqelQNSpUqC9RV6jtVair0HagsRavVKigohBQIJ2qwJUlWrQtBAJUglWBamFoKwlSCVaEqxUoKQnpUxH6VeI6sWP0oKBH6VMRUUsXpVgi9KAURVNYvSi+mqKWchVXuT4Z48Kqa70yDma5jiAJA3htxI4OFALfHigYQ1MQ+lSgvNLuJVgguVknZOp01SXcE/lHcowPWjhD6UAPQ9KcQ+laAipxFQZ/R9KXRPlWh0qXToM/o+lLpUf0/Sm6dAD0fSl0fSjun6U4jHlQZ/R9KXQHlWh0hT9KgzTB6U3Q9K0+l6fhT9EUGUbf0pjb+n4VrdGl0PSgx/s/pUTb+lbX2f0qJt/T8KDCa39Koe39K6Brf0od7b0oOeeAjPFCyQ9+K6CS378UDLB34oMJ4iM8UM6d615YqCli70GYy1URRkiUO60A5FRqwioEUDUqVKgLUc0Qg7VStEIO1AQgohRVSCiEFBNRVqrTKKuUUDBatVKdUq9UNBWqZq5Y/SrkjohIvSgHWL0q5YfSiUi9KvWL0oBViHlVqxDyopYvSrFiJIA8eOaDB1l5obQrb9Izu3uRGeKKaTsoESuwYkkgcc8+lcpFo3tHeq729spMM7wXDXMi2z9aLCyRxxvjAU8dsDGPWumv1hvmvZDbwz9Xp2enxSopE97elrKyDePuKJpzzxgHyohtf9nNHht7OS9uLp4YliEiRF5LgpwZWJOcscnP59yD6Doz6fC810FOoXIAuCrb1jRCQkat6Dvz3rcEfp4VzR9uNE56dpqBOf1kjX+04FVN7dWh/irGcnw3zWycfLqflQdZ06cRMeyk/AE/lXGn2znf7tsVGP/c3B/C3gT86qb2lvpeBaK/j70WozfhNcgfhQduYivLDaPNuAPmaqZrde80A+MsY/fXEnW9RJGyzVW/maZZZ+OZy5p21f2hI9x9RX+bBHp9uAPikFUdj1bQnAmjJ/m7m/sA0+5DnaszeqW85H124rg3v/aaQHdPrgHiP4TKfhHEBQM0+sNne2qt+3qt0fyAFPEek7/8AUXf/AMJX+0RUXm6YybecftmJB8SWevKnF43LR3J/bv7pj9agbw2qArHLExmRJFFxNLHLEUO7eJCfeHBUig9WS5V0EixxtEWdBJ9rg6e9Thl3LnkeNQkvo487jZoPWa5k/wDw25/OuB1PWNUt4tM0u1YxixsojOsMQkZ5pgLiRnTDHu+CfMfTNXWtSUjN5GrHwkWWE/1SBQektremp96aM479O2uyfrKyflVR9pNKXxlb4rHH+bGuCXXtU8J438+ndvn+sTRCa9qmPuTkeayRSf2l/fUHbD2n0of+HZv/ALhFz9Ep/wDtRpvhp8h/+7H/ACVxQ9obj9dX9d9rA4+oNP8Aw7AeJI7Ln/1bMqT/AEUNB2v/AGp0zx024+V0p/4KY+1Wj/raffj9maJvzSuOXWdMb71ppTH0xGfxAq0X2jyDnT4ucfxF0+fkFk/dQdX/ANqfZ88NDqa/7uB/yYUj7QezL/8AiLpP/wBS0bHzMbGuW36K3e01BPVJpG/BgwqJGhE/51qEWO24RMP6yCg6r7foM/8AF6nZ5PZZTJAT/wDMoH41W8UbgtG0br23Rsrrn4qSK5Yx2CkGHVBzlf01tE+B3H3Wq2Brq3ljlt7yycqwLKUliWRfFWCk9/hRWnND3rOmixniuhkWOWNJYyGjkXchGCCP+uPlWZPF34oMKSPvxQkiVrTR9+KBkSgzmWqyKLZO9VFKCjbSq3ZSoLlzRKZ4odRRKDtQEp4USlDxiioxQXKO1EIlQRaKjSgkiZomOOlHH24o2OMeVBBIu1EpFxVqRDyolYx5UFKRelWiOiFjqwRigHEdD6g5gtJdrBZJytrEx/UMoO6T/ZUM3yrSCelYOry273ghnYiy0+3llvym4np9L7XdcDxESrGPWb1oOc1K/jsIriZWSOaws0khi3ESJqOsxdOElP8AUWyDnHDSeZrldC0mXVpurJvZSzNlmJJGdoyc1d7VSyzXFjZyIn8JTF7/AFNlX3xf6owuWgY/exEhijAzxtPbNd/7KaXFaWURKjJUYPoOKCqy9jtNAVnhUnvyBWxH7N6TGB/k6celbKsq8CmaXApoyTpOmx9oEH+yKrNrYJnEMfHkBRFzcYZhny/Ksua5780Re62q9o0+goV3hH6q0LJdKOSwH/XlWfLqA5CgceLf3UB0skZzwMVl3EsPOACfTt9aElvGbOeRnz4oSScEf40DzyDBxgD08KxGj+03+mWp+7NcoXPkhcBifgATRs8oAOD4dqCtmC313cHO2ztJSCfBynT/AOb6UHo3slH1bXWNTdRv1PVbplOBnoQHpKoPkDvrYuIrd1YNFG2f5Sg/nTaFZpZ6HoVs42yLYxyS8nPVmzO+fmx+lVTzDB5orl9XsbABiLaAHnkRoPyFcfPBErHaoHfGBj8q7TVXYLu5AZdynzGcZrkLhss+fHPb4VRbpymeKYPz0ZekpPJKlQwz9a17DRLbVYlneS/jdXlgzbSIiYjcpgKykVm6Dhv4QXylgf6xit/2ZnnEus2zJi3t71+i20gF5GZpF3eOOD86gon9kFTITUblfIXEFtKcH1GKyZ/Zu6SYxLeWjssEcwL2xjyrMyY9wnyrtryb9J3/AFFrGuJCL6LwD6a31juMfvoOVn02+g3e7ZkjGDE8yn14NQtTcSG4jaSaN4cZAlcgjjtk1rXsqnd7wPwrOsCrX1wvfqw8ZHiIs4/CgtFtqEjNHaO0zR8XBnMKork5VE3gk8YJ+NUStqVq8S3UMcfUbpo2yFhuPhmI1rRExXV+oJAZ4X4/nQpWXqZ3cnnawbPjxQdf7Lr1NKuSRiQajdCUAnbu2xsCqntkEZ9fjRs8XehfZL+L16DwS7tbhR6TQbc/1a1rhBzxQc9PH3rPlj71tzoOazZU5oMp071SVo6RRzQrCgpxSqeKVBFaJQDiqFomMdqAmMdqMjXtQ8Q7UdEvb5UF8S0bElVRJR8Ufagsijo2OPtUIk7UbGlAkSiFSnRauVeKBgpqQU1YBUgKCmR4beKe5nOILaGS4mP+riUuR8+w+NcVO6NB1NRXK3k11qWrArkDTtPZNQu0zkfxkpt7cfsY8K6H2imbo2OnRLvl1CcSSR8Za2tWV9n+3IY0+teWe1mqF9V1C1t55Ps9lbx6MRHxHdJBL9ouHfB53S5b5CgF0oXGsa3cXtyd00k8k8p8DcXDlmx8Mn6V7Ba7IYYkXgKoHpXlfssY4NsjEbmYyOf5x4H4V38F6ZACv3R+sxCr/SY4rM6jbMw8xVbzZ7H6Vk3N6yIRDLbNLlRzIWCDxJ2qRny5rMur6AJG91q4TexjQ9ZFDMO+1F5wPhTE0bqN2kcn3skqDgd+5FYU9+xyFOPzoO61CGSURrqNrckRIwdZVwFJIClmIG70zQcjSYJI43bchlZc+WVJrUKJkuSecnPnQckxJ8c1DfnjPNRke3g3tc3KwYXcoZWd5M+CInJPxwPWgUjHC8jlckA8rzjDetVb8DnOfTH99Vre2EsiJvnKkndKIS4jUeLKCDn0B+dNcXFnEImR53jkUuGNvsO3OFOA7d/jTBXKdzqCeMjOfADk1CwiWZGWRiq39/bWztx/FmRVY8/tMflVLzBomlAdS+YoQ64MhYYZl57KM5PrRClYDosJwvvRSyFjgAt+mOc/tD6VR3997T6mk7pBY6bFbtIIo3mmnk6SM20O5jIHA8APrUEvluraKdcgOrZUjaVZWKMMZPiD4muYurm3aC4VHQttVlA/mupyKlZ3qR2YQ5JE1zgAADBlZhyfjVmMIHapddVIEAx0oynfO7JzmuYmPvH50bdXhfOAB+JrJkkJY5JPeorR0KTbNqC57x27fTIrf0SdY7rWo/PUOr3wP0kSnP4VymlvtuZ/50K/hzRTXksE2opGxX7R0skAZI6e0jNQdPc6h9oncoQsSqVBUe84X9bJ55rLuZ2M1kxPa3vY8+P3425oZZsIrZ7qPyoeWbP2Q57Ncr/SUH91ArmTOaH058apbc8MNv8ASSRcfjVcsmc1TbOUvbV+2HjP0kX++qN+eQLczn+VDaMP/j2/urKvX3BqJuH/AEuc/wCgjB+TMKzpjnPxFQdv7HShtR1iL/1dNsJwPWJ2jJ/rV09wveuJ9ipD/DpUn7+jXCfEpJE/P0rurgd6DFnXvWXMveti4Hesucd6DLkGM0I/c0bNQUlBXSpZpUCQUVGO1Cp3FGRCgNiHatCFe1BQjtWpAvagKhTtWhEnaqIU7UYHghx1HVfd3cnsmcbm8h4VJmIjZarWbTkCI04otB2rPttS0uef7LDcB5trvt2MBhMbvePGaP69on354Vx3y4/Ic1mnJXkjazq347cc5eMkQgq5aA/hTSE73iH0jgu5T9IojVTe0OhR95L9z/qdL1Fv7US1thsAdqruLmytP87ura3OMhZ5UWQ/CMEv/Vrk9a9qJZbJ7XRIdWgubh1ilvZbCaJra2Oeo1uOT1DwAcDAJOQRXF6hZ3TGJdIsriGERqZJryC5kuZpm5d2G0rjPbJJPeg67UdWgW51DU4popb+QQ6X7OWKOrztKv6OJ2RezO7tIAf5C55GB5S0EzSyRsCJkmeNw57lTsZXKnxOc812WiQrpDTXzWF/day0E8drd3AaOCxdo2XrRW6pklR4lx24x3rEt7S3ttgZlkdD+tcWyZI8SNxP40QTYWOoFR0tItiOM51CeMfTdRd3a6pbRxyNpNmZJXEcEUV/cTTyufCOMeA7sew8+eboNRnjXbFHak+AaXcfouag82oTyXcjSSMboIkqiSdlEaEkRp04typ5qDg+OaoBuby6tjFHbQWsExA6nVuftF2H8Qixq0afQn18qevqjbs2en7ifeZzKzls/rkgsT55P91dJYaXd3EMtwi6XaW0eUV5Y513kHB2KqA49SQM5xnFVzWtva5JazlZJQj9G3uMqw5/0kgFcJ+Vw1vHHNvZ/DvX4/JNO8V8/bnX/hJWZWt9LJU8+7KcHx8O9S6N4pDSRaPGqlct9nldizAttjTGWb0HxOAMjSkuNHBIkCBs8kCJWz3/AFpqF6ns2tw1xLNdSll2mNr61VMcZwMMecCu7gi41SeMR2/2S3JYneIVNyQfBnjUIvwBPx8aiml6y21Wv7SJCQDttwx9SSF3E/OtBNd9mUIC2crAD/6ix/8AxW9TOvaL+po7nngm71N84/ZiAqoyZdG1BPem1OMb3ZEMVsX3AZOeCMcDJ+Iqv+BpwWZr+YopO4pZDJA8V3N9OK12161PEehDzHv6ufzkWqn1ed+F0tYx3IKXf9qa5zUVkXVnCjwwRtLJLcvFC0szFpdrHkE9gAM8Dy9KAv5WlukZQduCRjwDsTx8Bj6VpHfJP9pkwgSOfpwgl5eqymMbQufdGSc7vCh1s45DveOUkgAgowyB4EVNU8cRYsBf20ZT3W68Mx37hncohRxgjzIOfhRK28IRUXUbEAZJBF73PJ7wUkt40ziKQZAHEbDt2qfTQfqSf0GqTYUPZhuBqFgfibsfnDVDaZLzi9088cYkuP3w0dhR+rJn9hqXnhZOPJGq9hl2cc0d2d0bhdm0ttbYT24bGKlexsJw4KBZEUbpCVUFeMFgDWgzDjhhhkJLKR4+tS4P6y/0hU0ZokYADqWx4xkXC4/ECotISqZeDKuT/nEXO4YxzWlgea/UUsA/yfqtNGQSTn3oc85xPDn+1UoId0gdniBQL00WRXd2LrnATPAAJJOBx64OoQvkn9Wsxobrrloz7plJAWRRld2eBmqCbhjuQ+BVlz6hyf30MwLkBcHJA5ZQO/iScUa2BkNjksR2YEE8HiqisB7pH/QH91BseyTCP2lsEByJLTUIgfMCIuPyr0S48a8z9nJFT2n0FsgBpLiPngZkt5EA+p4r0uegyrjxrJn8a1bjxrKn8aDNm8aAkJo+bxoCTxoK6VNk0qC1M8UbEO1Bp3FHQ0GhAO1a0C9qzbcdq2LVCSgHckAfM4oMjW9bvtLure2tREu62SeWSaHqZZ2YBV3e7wBk/GsKfW766eZ7m84mEe9B0ooyI/u7VAGAPjVXtDql7JfyJbyOgaWbY1u7Rlow5to0fqcYAXIIHO4n4GPBcWFpFPb6hdXVxHbSalPIolktxEskUYLi4jEYXLHOCc4GCS2Kzelbxlo1qt7UnazkitI6oaS7g1Oa3l95Vdbi26nv4LBDKCwB4zW2t1rx4HtJqXyubP8A5a81TU5urPJNbWNxLPIZne6hLkE+CBWUAfKjBfwbCzWmjbtudi2Umc+WS9K1isZBa02nbTsu8lufaAj3tev5B/Ols3/4KFzrRJ/7zuyT/q7Ek/WKuVimtNkT3lpZQ/aEL20dpp5uLmSMEp1XQzKFjz25yccDHJBm1H7PO8LaVpTbWwG6FwokBAYNhpMjIIPbxrTLt9uuHn+EbzHpBp//APTVqR6y3e/vyT4iOw5//bmuD/hOJv8AyvTB8I5gf7dKa7R4kEcVrG0hUMIUcsvP3Tkk+A7UHr2k+zuo31rPNPrGqxB2khjWKPS/fTGGLFrXOCeB8Krv/ZbVVX3Na9pJMDAEUsEageRFvAK8euLlpH/RDojC5VUmOWwASd2Rycnjzro7f2b1DZarc3dzb3V20iW5QwNbmVIzKYi3UBzgZ5IJ8BxzUal3oGpIW3XftE+O++4uD+SCsq40noIZruTVkjXndNNOCxAztQOvLeQrIvxrGkXd3p96biO8tikUv+VzERuyhw6Mj45BBHeuysfZiS+9m9K1Ga/1VNQvo5JojPdSSWLl5HWOJskMjMANpzgnjPPIc9Dq2qrDDaxXVyltENsUXXchVXIUeHbw/wAajLJcXKMk7GVGfqMszyyKW8yHYip6hp1vpl3Z28UkrzyQzSXhmQqUKyNGEUMzNg7c53fhUUjupA7C5s4kDHYsxQOVwOeRmvP9XHvaI9dPsvnXfFAtLfj9BbD/AHEf/EDVywhcbdi/sRxL/ZWnKTr3v9PHw2f8tNuI76nZD4Rqf+CurC4CQf6Rx8GI/KnwT3dz8WY/voYzIuM6ra59IQf+Go/a4x/5lGf2bYf8tPQZsU+o9cmpdOMAkgYAJORwAO+azxqKoQVu0kZSp6cluqLICcFQ+0gHHjxR3WjuJGeNY0Q7XEceTFuAAAGQCRkZPFYmZ3MXr5uqpElCdRE95mBIIyQnOBg+Pif8KFX7aXyolBz4ghTwB3Pu1ppbtjLajdBskkpbxHknPG407RljGouJY0ViWkRFMjrtI7E7ee5rSIDOFzjOBu7d6iatMEX/AL7UT8FhFQaGH/3epH5xD8qCk1lakkzvD7kssK5JjiU/ePckrWs0MH/uNQPxkjH7qgYoP/UvT8Zl/ctUZcaXW6EmOSOJTGT1JCx7jC4POaO5qUkcQTcjTcTRRkTSbyc4bIGBx4VMFFABe7IAxj7Rj8loKsHyNROfI1eWi8rn53Lf3VA9Dk7JvUm5fsPPjFBSa6Sw16CaztdE1i1jksmC2gvQ2ye1jJxHIQVIOw45yDgc58eZNxp55Bdv99OwPzAxUGnsTx0pG+LzkfPNWJwd0vsfpscNmlwJjMmP4QnjvQkbqIXYsiOPdDHaFxnjn40T+y+jZZLd7kSMpCdW7yiTom5oAdgyxHv54AA/nVyV1qSXv2L7RGXNpaRWUTHq7jDEWK9Ru5IzjJ8AB4VRm3btBGRjHLyH5d632gbCWdrY+2mjWto7PbR3dk8Ls4kLh7dZS24eZJ/6Fd/P/dXmmgKp9o/Z8KoUfa3bA7DETnxr0yftmsjJuPGsmfxrWuPGsqfx+dBlzeNASeNHzeNZ8nc0FdKlSoL4zzWhD4VnR960IPCg17fwratTsZX4xH+kOeBhBuPI+FYlsRxW3abCVVsbW9xu/wB1htPag8tvZi171f0g6P2cKW2yMrKA7FHx2ySRxx8q6P2nvrpraRG1We562l2EarJNDL+jeVpnhBt41UAbUYhgTkDHbFc5ciOO5vILoSmeK4limP3n3xsUIJPPhx6VRdTxtbQ20W8LHKrHfGAzALtG5+5x4D1oAw6AkGJGIwMsXB4H81hR1vE8iKRbRNC0iq69aRTy2O7N++g8QszsJ0XJ7MrY+RFSEYIKi6txng5d1BH9E0HSxX0ml22pm4uriLUbpxb77Bog8cNqpiiTee0YwOFxnz4rBuJZbhoxciaWf+MaQueq7MBu3FweO1XTTLNtlZLF7zgvP9qYrIVUKGaJ/d3cf4UFsnJLl4ncnk9eLP4mgvCDnEEwHjl0P/DUZFeOSFTG6EqZApkRGwVO07u1JVuTxmP53EX5BqUomM9sGKtI6bAxKuM4wByMY+VBbCTFLE7GTajK+DOGXKkNyp+FekW9/qEsAQ+z+kdHYYwkGiyyxs8nIWSU7SBgjDrkc+mR528FyR/ExDjBBaMntjyrbtda1GO3ggu7m4njt1KW0BuLiKOFuwb9E2DjyxQZPtA8jTxh+mJg9/LPGiKvTmEzQ7SF47IuPQ16m1l7SWGlW9rc3sEOix6db2skVyqAbQgBjHuliT2AArzC40/V7q+hPSe5null1B0DKCUQ73d2YhQPDOa6fVPaP2hnvPt99oWdpRYEuZ5JrKEDGeiqfo8nzye5qT7GETnrH1aWSXVrwmRs2sNvaZYbj7iAlck+Hasq6umiAVTukfhQR2x41bJJKzXVxMAJbmeW4kA7AyHOB8KytxlmZz2ztX4CpEZ4szvrZ0nSZNSc9STuM4ZiO3OfKqLu30qCV41vYH2kqemXkAI8MoCPxqM9w8FoYI2KtdDbJg4/RDlh8+x+dZfurjcQPIenwFaQd/3WO8zH9mJ/3gU4l0oeFw3wjUfm1Z26IfrfRTS3R+DN/R/xoNL7Vpg7QXJ+ca/vNF2mp6apMTRTxbv4qQujqjk494AA4PY8msPdF/P/AKtP7rAlSeOSGxnt5ig7VORVgFZukPql3aqba0M5gIgkbc494AEbgqnwxWjIL9FhjitRJdvKkTwkthCQd3I54rEwGIqsrV7WXtJ42lmn7Tn97iqWs9cHd9OTzzJHx9XoKiKgRU2tNU/WvtPH7JiP5A1UbW7H3tSgH7CA/wBmOqK5BwP20/tA05FReB4/e+29YkqNoVgFORhslR2pxZqAOprEzNgbulby4z6ZIoGxWbqsrJDFCpwZ3O71RMcfX8q0XtLTa3+X6g7YO0GNVXP9MmsPUpN12UBJWCNIv9rGW/OkAmzurS2jdp4esFXCJnBZvAE+XnVDarcsSVgtF7kBYmIA8veY0McFVznCgu391U9Vx2OB5KAK0DDf3h5AgHwhT94qyO+lmMcMyQKMnDxxiJ9xGAGKYyD6is7qyn/SP8jREW+RX3EkrtdGPfg84NB0ns4jL7SaIjAgpd3YIbOV228pwc88V6VP2rzTQbi3g13R728njhgEtzLNPOxCKZLaRQWbk8kgV6MLqzu4utZ3MFxDuKdS3cOm4YyuR4igzrjxrJuPH51rXHjWTcePzoMybuaz5PGj5u5oCTxoK6VKlQWIeRR8BrNQ9qNhbGKDTe6NpazXCoHaMKVViQpLMFycc8VmD2o1NWGZxCqvtKRWMEkbeSu8jlz8iKNeNrm2uIFPvyR4TnGXUhlHzxj51y8NxEglDhsG4jMiv/GLtRkYjHip5HwoH1KZNSvZr15ENxdyM0nTiMEasihc7cnvx4mh1s7jPuXMAweMyP8AvSiNV+wLeBdPeN7ZI7dA8Ubxo8gtYlkZVkd25YE/e+nYBMwbPuhiWz7znknxyPGgM+z6iQ36a0Y5BGJ4xgeoIFIW2qfyLRv9/a/8TiglG0/xQA5+5MwNXdaQIPv7lYgfpBkqR5sDQECy1Zu1lbv8GtG/J6TWOpr97SSfVIUYf1CaoFzMG3NCGPj7sBzjtkhQfxq5Jgzq3KckGPCgfPHh86CP2O8Iz/BXHIxtCtkeals0vssyDP8ABjhvVJGA8/Ej4U1xtfryHwAIIJ77fStW90J7PRbbVd8uWvWgKGOQoYCgeKYykbDu7jHnjgrVGM2wEhoEBGPcDe8D5bQc1EKCRizmz/NSX91UuSt1IR4OcY8vlW7azTFVIVj27AmoAVS/AytheMCMbmhnY48gzD99alhLqu2e1mt547S4XcxlUALcKuEdQzA88KeD4eVEu928bYhmK4IJKPt7eZGK52C6Wz1CzubiEzJa3CTNErqpcochdxBHf0qSLL2U8oPvE7cevas4MEPHZeM/Crri7innnmWMxhmdo487gu7t73Hb4UKpTI3Z2+PHNIBnLkyPnYibj6KvYfP99BMxYljyTyaImuI2iEcYYbmBcsAMgdhgE/GqEjdyABwSAD4c1RGkKLhtBIYxv4ZgjMuNkZJAG8+Ao0aJcFOqzbIQ7hpfdeNo0JXqxYIZlzxwMjny4DJqSMQT8D+FXz2N5bqryRMEZd6sBkFPBvge/wA6FBwQfIg0G1pF5JaSzRqX2XCoQA5VQ6ZYMQO/GRWwmozbmyEK5Xk5DcjzzXPWbNG8M6qGaByNp7NtzwfiDR5vdXZ1a2tRDv7KtrCW3IM53zDNTB0ajcisVALAHGO2fjUGXvx+FYDXHtU3BnlTPPMtpFj+jVZj11+ZNQwT3D3z/wD8Ypg3ikh7K3yBql1YdwR8ePzrDNnO/wDHahDjx/SXUn54qJsbQEbr5D+zblv7b0wbDtFwpkiyWX3TJHu7+Wc1BpbdfvTwD/eJ/fWV9n0tRzc3B/ZigQfvpsaSv6123xljX+wlXBom7sVOTcRHGThdzE48PdFc7lppZGP3pZGZvmc0c0mmg8QOynAw08xyQec4Iqi1USXDsqhUyzKoyQoJ4AzzTBG4XZFx3lcgfspj/CoRWU8jKuCC2NvB5B8Qe340XcgfaljzgQRouSu5S7Dcc/Wp7idkMBITkydMOiOSc525zx8PrQANayKuVZH4ydrDPHPbvStGImRT905XHxrR+z2+2U/bI+orKmxBvyTnJO08AUdoWiRapqtzYzsYZ20+7mtHU/o/tUYV0d8AkpgnOKDGlidZZU590g4zxyM9q6z2Iluln1O2Mji1W2W46Wfc67SLH1MeeBitcew+JHludRUM4TeltCSAVz2eUjz/AJNaFno+naT12tus0kyokkkzhiVUlgAFAUfSge4Pesmc960p2zmsuc96DOmPegJD3o6Y96AkoK80qalQJDRUTUCpohG7UGtA/as7W9PVi+oRxsV2r9pERCspBx1Su05z+t9aIhfGOa0YZB2OCpBVlPIZSMEEeRoOFbo7Rs35DbiGK8jGMAimDRnuHHwK/vropPZk++8E8IiXc46zGPpouSdzNkYA8c1zkSbg3uuw3H7uDgeHegvUW7BRunTg7m6Svkk8DAcdqsEFse17t/btJx/YLVT2OSso+MZI/CpiTHZz6h4n/GgTRICNt1bMMHjbcqc/7UVMqHwmtvnKF/tYqxZIj2uIPmWX+1SZBIMCW3J4x+mTw9CaBmicqBuibI5xLGRkZHnSYXzRLA1wWhXkRtOmwEdvd3eGeKqa3lXJwmD4h0x+BqP2eU9tp+DKf30Ebn3biRh2J8OR2HiKthu2jx75GfIkVTIjKREw9/yBzwRnwqEifxSrzhPe8MEk8UGhLqdw8RUzuVOVGXYj4VlsxOeBz9TUipCqGIAUkgDvk+tRxyB61BE8keXhSPBPpUmXG317evNIKSSShx5c/nVDopYj05PwotFVmWP3kzggqBjgdge1DqNvfIHOSPL4g0bEzLHwwdOQ4xyVPj5fvoC45zaMZV6ayBU99FwZIsFWUAnGecduOe4PFC3FzIyLBEoIjKrnpj9GTjhnwMdvH86jbQT39wbeIbmWNn3SMEhhiT70s0jcKi+JPn4k1vWvs5b3sU0g1WWVYgsYe2tiISQu4rEJPfYDwOBnyoMJbqbpssiExzAEYyqt68HB4yPPmgruFUYSRriKQtsGScFcZHNal7p11pyw3HVju9OuW2RXcIO1iOTHIp5VvMHy9OBpUSWOXpn9Hzy/JTHvLg+vb6UENMOWlQ+SOPkdp/dUJLm4WR0JJKPIoxk9jim004uYxj76yJ/V3furSlcLK6gE8g4VS3cZ/VFBmda9b7qyH4KR+dLF63dX+ZA/fWosVzJ9y3mY+ACkH8auTSdbl+7YyD1k90fXFBiGO6/WYD/az+QqPTfxf8CfzrpY/ZnWZyBiFSfJw5+GFOaPg9gtZlwT1yPExW02PqUx+NVHFGP+cx+lRKeWfrXoa+wITBurkxjx61xZwfXfLn8KdvZf2RgVxcatp6ttYA/bJJypIIyFhiYZHxorzkjAyOCfL6Vs6Nb9SWNcH32UdvzrSl0L2Itwep7V3EpC4xb6YGAYDzlnUn6ViGfT7eSRLZJJkRnRJmuJojMgJAcxRY25HhvPxNQReUy3d7MpfBnlddp9zAJCn5cUba/YrO1k1C7hFwOutvb2bsyJdzFRI/WMZD9NARkAjJcDOAcg2aB+uVGVHv7Rnao3YAJPNehaHpOg6t7MXdreOIbjSutrUtyq7prYyoJ1ZFA3MuxQGXxIz3GRJGnd6TpE3s/7Nx6rZaelzfy9C5v7KG2t59Ka5922fZbqo6asY433DHvc8muHs5bjR9St3u4/8p0DUJILtUJJaHLxyBSDk45KDxzjxrvdQ0S/1K9gjt2sbezvtHutOVbrqmdnuY4pBvCDl42QSjyG3IG7jmfbOymtvaG7W5dHmvtEsLq5eFSqyTxRdGR1Q9smPPzoOqtNX03VYpZ7CWSWKOTpOzxNGQ+0NtIPHYjsT3qqZ+9YHsfiLQwR/pb27k8uAET91as0nfmqBp371mzN3oqZ+9ASt3NAJMe9AyUXIe9ByGgrpUqVBUOKtVu1Dg1YpoDo37UZFJ2rMVqJjegOv53XTdR2IH3QMjAkgBG4LEgg8eHn+fIBWjKE5GFJJXsfDn0/x8q6G/ZWsLtWyRtUgDHLBhjOSOPOsSIbt8e9UBibPULHPiFAx5HPf9agsSWKXlCikKDIryIAr5wNgbBK+YzkeHkWYyDgcklgApRuR4Ajj4HHPoay35J4x6eX1q+0t72czi1iMvSj68qKAx6akAkL38fCgJL5GTGPA524BHn2/wD8qpmT/wBJO54K/wCHeqZF2NyyqWVZNsT7gN43AAjI8fPirZ4ZrZ2iklbcgXdjPDZI24PORyKCBMXfZH2+Hf4eFQkgni6bOkiK4Vl3KynDDI4Pn3FR3Of1ic5HK9896KkubzMbjEbhIo2ZCwMhiXYrEEkZxx+6p/AOHQdkJ+Oc/hSLk8429uO1MSWyGcDAJxwMnyz3pdv1cnxJ5qiPLZxzUQxHb8atUhCc8/Dn8aSNEI5Y3gVnkMRjmLOHhCkltqq2w7s85B7cY8QqLMwwfAHsKJUFgCQwYIuTgBduAgJC/KjNH0hdXeaBL+2trpQXSO6V1jkiUbmZZUzyvdhjtzzjiMce3cUlQojZU/eGIgSznHOO23/CgHPdipGM497g4XjsB+6nZyASRjCn3l7ED4UnRlEZMYB25Bc8se/OaUUTzvFCFIaeeGAf7xgvGfjQXXkj2llb2CHbJdJFfX+OGbf70EB/mquHx5v/ADRjtYIvsfspqJifZLBZScrkFXOxSwYHIOScUcj6NfQ204htbq2jPudWIPsEQ5XHDgjGMAj8ana2mhak+mXs9vcrZqXmlsZIlVreOYhdkiZ2uGCDHHAOTkngOZ0IpqkE1ikTmO/jMGpoOo6pehi0F6mcgbuz8918AcDn7dJFe4tXGJAXhYDn9JG3p6ivSL3XrX7Os86Gwtwitb6VEED26M2xEFvFhQTxkkDv6Yrg78rFr+olRhReNLgcgbsOfzNBnQx3rTSC1tmlkSUORboZJF3A4C7MnHfwrTj1i6tMrGZF25GLqeBiCO+UjiyPrWdFNdQrcrbXE0KzGOO4EcjL1FVc7WK4OM+FWWNpHcXEcTkLApV7p2O0dIHJRSPE9h8aDtbD2s1COxtll9nHu7oq7m4W2vBFMjEshVYyF7dzitbT9Y13UOs32ew0xY1hYD+DY5Jm6m7K5uCcEY5HPcVnJqlhGqojqqIqoiJ91VUbQBjwFWjVrU497NQFapP7aC3jOl6tPNN1CssLfZ7UGM4w0JiCLkc5yfyrnLe51S/lnhvr29MylcC5lmXGSUO4NzjPp410C6hbn9f60Qt3G2P0iny57fWqY8t1K5kN3dJFO5hSV44yrvsYIdu5QccHv86ALls8+OcEk/iTXs4uM9yD8cGkWhcYeOFv24oz+a0HjAIz2FWY4xjz48CQewNeuSafo9yskUlhYEzRyRBzbQqymRSoYMqgjGc5ryRkaNpImxvjdo2APG5TtIHpxUGnppci4RNpbYzDAOPe90hsfhXZ+wem315rF/fIUaC006zbpSKG+0SSW+2ONC2F4weT24+fC2MuJCN5AYHlRtwcAAgj6V2OiazdW/s97TafYQzSaqsebI2wLSfY7hik0mBz+iy2CO3UB/VyKOx1vWr61fRrqGzjiFvpus6lcySJFKIJzpjzRQW8y+6SGAEhxzle+a472mkuJtUVruQtc6d7K6TDfSSsN7XUsPVYt6kuM8V0eiyadf8AspfW2sP9k/gg6e2rSb0lVraCRJljR1JX9IE2FQc5OOe1cLc3c2sajPdyAi41rVVmeInDwW0biQAMfJAB8qg2/Z0tHolgrBlZmuJcMMHDytg/MdqNkkqMs24sc9yTQrvVDSP3oORu9WO3ehnagokPehXNXuaHfxoI0qbIpUA4NSBqAp6C5Wq5W9aFBqxWoDd29HQke+jJkgEDcMZwRWGpKusZJfDsmxsjcT7nj+yDWor0JdpyZ1XcrKwlG0HadhQMPGgyplKOytncpwwPfPrV+n3s2n3cN3EAWjb3kJIEiH7ykjzp51R1Z49gEfusA5y+DjeFbn40IcigOmis5p7uaKURW7yl4VZCZAG52lV447d+cVCSWSdZOo0f3UBdgWkcg5yXOeaEBI8aVTBMFVUsGO/cBt25BXBO7d/hXQ+zNhb6ncTG/ieS0tYshVJjSSdyFVZHUhjgZOAfD64EFvPcyLFCjMSRuIHuqP5THsBXeWT2mnWsNrHLlItzFm4Lu5yWI9ao2odO0CBXSHTLBd0cke5oI5HG9Sud0oLcd+9c5N7JWttb9S0lubu7WSAiKUwRRPGHy/3s847e99cUa+s2SZ3Tpkev91CSe0timcOx+APNByuoWOpQSNPPazQLO8ph6iom7YRkYT3cjx7Vt3l/7OWenaRFZWulXl0yqt9JNbS9QbY1DMSdrBic+J7fWF97RWV3A9vJbNLExDYY7WVl7MrLyCOa56R7ZidiygHsGZTj54oOltNQ9io7CBLmyRrsw7ZxHbyu5kXKhhM7AjdwTjtn05yAwZZMoWO8k87tzmMiNcqAcefw5rLO3yb6j+6jUckDDcEAAHPuBwUJ+n/XNBCQriP3y42j4j60Tp3+c6cd2CNQgwT4ElcE/Og2b3U4A4wCMA8cc4qcbsN+G99HjkRhnI2kjPPlkH5UHQexmlarqGoXphvPsdlYr1dSlk5QKzFFTpngsxzj4fXrJbhwurm2sr9+g/2WKG4aNZ71A4jW5DBAFB95gAOy/On0M6bDpE15DJt/ha9k1LUfu5tRaowMRwewJdhnzHz5nSdfMms6nPeYSHVNiQgN/mwi/iA2ey44Pbvn4gLa6HqUtzf9cszrrNnYZBLfaJBvmOD48BT/ALQrNvZevqWqzgghrm42kHuAxQH8K73VNWGmabPcowNxJHNbaXjb7k1yqiWdCOchQOc8cedecRgBdvYD3m8CAvhQUuzBmG7IBHbzAAqSO44BwPTzqGCSSe5JJ+fNWKtBfHJJxyaOilk45P1oJFolOMUGhHM3GT+NXC4YfrVngkVLfQH/AG+VOzt9akNauU/0mfjWQ796FkY+dB0a+0kqYLYOPI4Pyrm9UkhnvJrqJQqXJ6kqgDCSscttx4E8/OhXY1Vlz/1mgsVyjKQTlcY8FHOcUfBcSJJHPBM8E8PvwzROVkRjwcFfPt/1is5Y52xtRj37jPeio7K/b7sXBP6xx+6g27vVtQv7e3i1HUbm4ggCyrahIobbrBsElYgqk47Egnw8afSMTTyXsmQkKm2s1YDAB4dh8OB8z5cZ8WkXTkGd1VPFYyc+nJFbEUIiVFB4VVVQOwAGAKDRaUHxqlnqncBUS9BJmqhzTlhVTNQQc0O5q1jVJoI0qVKgHpU1PQSGakDVdI58KC4OB405njUckYxyPP0oUq58arMTGgUy2pJaNzG3PGNyc98A9qDZMHuCPMf40T0jUTCeeKAbFID1q8xN5VHpnyoElxLErLEdgbG7bwWx2yaZpp2J3Ox+JNLYfKlsNBWST3JNKp7T5U200EaVPtNLHpQNVqMMFSO4Zc+IzVeKQ4oJsRk+WSR4cdjUkYjaeMHIPmQe/rVZ3Hn5UgcE/wB1BtaVqE1hI+yFbq3mUpeWc3Mc6AffAxwR2+ueO3QNrnsZ0YWi9mppLqIN0oJmto7BXY53yLENz48AwIrio5HQq6uwZTlWU4YH0I5ohbu5UIodPc3bD01Lc9/e25z5c0Bl/d3l5Ot7e7VXH+SwxLsgRM5McC4x6n/oUBK2AwIG+QqzgAe6OcAHyqQdiQwYs4DAdsKScnaB2plt5XJOMZ8D4UFSrmr1WrUtX8SKvW3A8RQUBasBq8Qx+J+VWLHCPD60FALHsDT9OU9lNFAoOwAqXUoBPskzd8CnGnA/ek+WKJ6nrT7/AFoKV020H3smr1tLJMYjXI8xTdT1pupQEKIV7Io+AFS6gHahepUd5oCzJUTJ3obefOlvoCN9RL1Rvpt9BcWNQLVWWqJagdmqomnJqB+NA9Ko/OlQU0uadvvt8T+ZpqBc09IUqBCn4pqegfAptqmnFI0DbVpumtSqVBUYl9KiYVq6lQDmEeFR6NFUx7UAvR9Kj0vSizUT++gF6RpukaKpUAvSNLoA+FE1Id6AYWhP6zD6VatnH+tuPxJx+FED9X5VI9vnQRSONBgAADyFWhhUBT+dBPfS31XTigs30t9V04oJ76W+o0qCW+lvqNKglvpb6jSoJbqbfTVGgnupb6iPGnoH3U26o0qCW6m3VGke1AiaYmkKbxoGpVKlQf/Z

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
   <div class="one m-2 py-5">
  <?php $v="Mitsubushi pajero";
    $p="Pajero debuted in 1982 as an MPVA 4WD, offered good handling and<br>
	comfortable drive, with outstanding performance on any road. 
 ";$i="https://th.bing.com/th/id/OIP.v2kZ8xTbia4o_bg2sKY7KgHaFj?w=239&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='offRoaderinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
 
 






























</div>
</section>




<!-- footer of webpage --> 
<footer class="mt-5 py-5" style="background-color:#222222;">

<div  class="row container mx-auto pt-5"> 

<div  class="footer-one  col-lg-3 col-md-6 col-12" > 
<img alt="img logo" width=50% height=70% src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" />
 <p>This is an online ccar magzine designed to create and improve knowledge about cars.</p>
 </div>


<div  class="footer-one  col-lg-3 col-md-6 col-12" > 
<h5 class="pb-2" style="color:#a2cf6e" >Featured</h5>
<ul class="text-uppercase  list-unstyled">
<li>hatchback</li>
<li>suv</li>
<li>sedan</li>
<li>coupe</li>
<li>sports car</li>
<li>offRoader</li>
</ul>
</div>


<div  class="footer-one  col-lg-3 col-md-6 col-12" > 

<h5 class="pb-2" style="color:#a2cf6e" >Contact us</h5>
<div class="text-uppercase">
<P>Phone Number(+91): 9448724072 , 7022136392 </p>
</div>
<P>Email : pawanbharadwajnp@gmail.com sampathkumarsharmapl@gmail.com  </p>
</div>


</div>

<br>
<div class="copyright">
<div class="row container mx-auto" >
<div class="col-lg-3 col-md-6 col-12">
<a href="https://www.facebook.com/pawan.bharadwaj.106" target="_blank"  > <i class=" fab fa-facebook-f"></i> </a>
<a href="https://www.facebook.com/sumbath.vp" target="_blank"  > <i class=" fab fa-facebook-f"></i> </a>
</div>
</div>
</div>
<br>

<div >
for more information go to :<a href="http://www.vcetputtur.ac.in/">vcetputtur.ac.in</a> 
</div>




</footer>


</body>

</html>
<?php
session_start();

$_SESSION;
include("../login/connection.php");
include("../login/functions.php");

$type="";
$v;
$p;
$i;
?>
<!DOCTYPE html>
<html lang="en">
<head>

<!-- Repeated code -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title> a4Automative </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<style>
#he1{
	color:red;
}
#hel:hover{
	color:blue;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

* {
	margin:0;
	padding:0;
	box-sizing:border-box;
}
body {
	font-family: 'Poppins',sans-serif;
}
h1 {
	font-size:2.5rem;
	font-weight:700;
}
h2 {
	font-size:1.8rem;
	font-weight:600;
	
}
h3 {
	font-size:1.4rem;
	font-weight:800;
	color:#ce93d8;
}
h4 {
	font-size:1.1rem;
font-weight:600;
}
h5 {
	font-size:1.0rem;
	font-weight:400;
	color:#1d1d1d;
}
h6 {
	color:#D8D8D8
}

button {
	font-size0.8rem;
	font-weight:700;
	outline:none;
	border:none;
	background-color:#1d1d1d;
	color:aliceblue;
	padding:13px 30px;
	cursor:pointer;
	text-transform:uppercase;
	transition: 0.3s ease;

}
button:hover {
		background-color:#3a3833;
}

.navbar{
	
	font-size:16px;
	top:0;
	left:0;
}
@media only screen and (max-width:991px) {
	body>nav>section>div>button:hover,
	body>nav>section>div>button:focus {
		background-color:#fb774b;
	}
}
	
	
.navbar-light .navbar-nav .nav-link  {
padding: 0 20px;
color:black;
transition: 0.3s ease;

}


.navbar-light .navbar-nav .nav-link:hover,
.navbar-light .navbar-nav .nav-link.active,
.navbar i:hover,.navbar.active   {
color:blue;
}

.navbar {
	font-size:1.2rem;
	padding: 0 7px;
	cursor:pointer;
	font-weight:500;
	transition:0.3s ease;
	
}


 body {
 background-image:url("https://cdn.hipwallpaper.com/m/56/10/d5qDRv.jpg");
 color:coral;
width:100%;
height:100px;
background-size:cover;
background-position:top  center;
flex-direction: column;
justify-content:center;
align-items: flex-center;
}

 

img .one #new {
	width:100%;
	height:100%;
	background-position:center center;
	background-repeat:no-repeat;
	background-size:cover;
	position:relative;
}



#new .one .details{
	
	position:absolute;
	width:100%;
	height:100%;
	top:0;
	height:0;
	transition:0.3s ease;
}

 .one:hover{
	cursor:pointer;
	background-color:#d1c4e9;
	transform:translateY(-70px);
		transition:0.3s ease;

}
</style>

</head>


<body>
<!-- NAVIGATION-->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 ">
  <div class="container">
<img width="400" height="120" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" alt="logo"/>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
      

	  <?php


	  if( isset($_SESSION["id"]) ){
 echo  '  <li class="nav-item">  Welcome, ' .$_SESSION["name"]. " </li>  ";
	  }
	  else{

		 echo'  <li class="nav-item"><a class="nav-link" href="../login/login.php">LogIn</a>   </li> ';
	  }
	   ?>
	   
	   	     <li class="nav-item">
  <a class="nav-link" href="../../index.php">Back</a>   
	   </li>
	 
    </div>
  </div>
  	<br><center><h2>sedan Cars</h2></center>

</nav>
<!----------------------------------------------------------------------------------------- -->



<!-- types of cars -->
<section  id="new" class="container">

    <div class="row m-3 py-5">


<!-- copy this for next iteration -->
<div class="one m-2 py-5">
<?php $v= "
Maruthi Dzire
";
    $p="
Maruti Suzuki is expected to launch the dzire<br>
facelift in the coming weeks.The model will <br>
receive an updatedfascia that includes bumper
"	
	;$i="https://th.bing.com/th/id/OIP.QPeKl8Cz3KR0LWFu29lRkwHaFj?w=218&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>  

<div class="one m-2 py-5">
<?php $v= "
Hyundai Verna
";
    $p="
The Spirited VERNA gives everything you<br>
have ever wanted sporty sedan and  more. 

"	
	;$i="https://th.bing.com/th/id/OIP.nPupax9RJrgofrOUg08AqQHaFj?w=203&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>  
  
  <div class="one m-2 py-5">
<?php $v= "
Ford  Aspire
";
    $p="
The Ford Aspire is here to set you apart from others.<br>
Its powerful, BS VI compliant engine propels you <br>
ahead in life. Its  design leaves lasting impression. 

"	
	;$i="https://th.bing.com/th/id/OIP.HQ2dbxufQ7Ismu7XxnwjAQHaFj?w=222&h=180&c=7&o=5&dpr=1.25&pid=1.7
 
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 

 <div class="one m-2 py-5">
<?php $v= "
Skoda Octavia
";
    $p="
Octavia is best in this price range. It <br>
looks stylish and gives comfort while driving.

"	
	;$i="https://th.bing.com/th/id/OIP.Uf_me-cyywMQOk97GpiWoQHaE8?w=240&h=180&c=7&o=5&dpr=1.25&pid=1.7


"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 

 <div class="one m-2 py-5">
<?php $v= "
Honda Amaze
";
    $p="
The Honda Amaze is the most economical <br>
subcompact saloon by the Japanese carmaker 


"	
	;$i="https://th.bing.com/th/id/OIP.jUXukV32rog_9jTMTGN2-wHaFj?w=206&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
  <div class="one m-2 py-5">
<?php $v= "
Maruthi Ciaz
";
    $p="
Maruti Suzuki introduced the updated<br>
version of the Ciaz in 2018. This is<br>
the first comprehensive update for <br>
the vehicle since its debut in the country. 
"	
	;$i="
https://th.bing.com/th/id/OIP.0ufkLRJ2EYFedBK87AN2ywHaFL?w=241&h=180&c=7&o=5&dpr=1.25&pid=1.7"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 


  <div class="one m-2 py-5">
<?php $v= "
Volkswagen vento
";
    $p="
The Volkswagen Vento has received a mid-life<br>
update with fresh set of cosmetic and feature<br>
upgrades. 

"	
	;$i="
https://th.bing.com/th/id/OIP.5y18rgSGXdS243f-25sJ1AHaFj?w=217&h=180&c=7&o=5&dpr=1.25&pid=1.7 "	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
  
  <div class="one m-2 py-5">
<?php $v= "
 Honda City
";
    $p="
The all-new fifth-generation Honda City<br>
was launched in India in July 2020. The<br>
car is available in nine various trim <br>
levels. 

"	
	;$i="https://th.bing.com/th/id/OIP.TmxO4Ze_QMVqMq7EFktu_wHaE8?w=237&h=180&c=7&o=5&dpr=1.25&pid=1.7

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
    
  <div class="one m-2 py-5">
<?php $v= "
Toyota camry
";
    $p="
The eight-generation Toyota Camry progresses to<br>
the new TNGA platform with an all-new cabin and <br>
host of new features. In India, the vehicle is <br>
offered in a single hybrid variant. 


"	
	;$i="https://th.bing.com/th/id/OIP.p1mbtGob-qyS6LFX24zIiAHaE8?w=225&h=180&c=7&o=5&dpr=1.25&pid=1.7

"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
   <div class="one m-2 py-5">
<?php $v= "Tata Tigor
";
    $p="
The new Tigor exhibits a confident<br>
understated and executive-oriented<br>
design that comes from the IMPACT <br>
2.0 Design language 
"	
	;$i="
data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADhATcDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAIDBAUGAQcI/8QAUBAAAgEDAgIECQgGBggFBQAAAQIDAAQRBSESMQYTQVEUIjJhcYGRobEHFSNCUnLB8BYzRGKS0SRDVIKiwiVTVXODk7LhFyY0Y9JFZISz8f/EABsBAQADAQEBAQAAAAAAAAAAAAABAgQDBQYH/8QANxEAAgEDAQUECQMDBQAAAAAAAAECAwQREgUTITFBFFFhkQYVIlJxgaGx0TLh8CNCYhYzQ1PB/9oADAMBAAIRAxEAPwD1uiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCiiigCij88qPzyoAoo/PKj88qAKKPzyo/PKgCij88qPzyoAoo/PKj88qAKKPzyo/PKgCij88qPzyoAoo/PKj88qAKKPzyo/PKgCij88qPzyoAoo/PKj88qAKKPzyo/PKgCij88qPzyoAoo/PKj88qAKKPzyo/PKgCij88qPzyoAoo/PKj88qAKKPzyo/PKgCij88qPzyoAoo/PKigCiiigCiiigCiiigCiiigCiiigCiiigCijI764WVccRAzy4iB8aA7RUaW+sYQesniXHPLoPexAqBL0i0aInN1bnHYJQx9kQagLiis1J0u0lM4mU+ZILhz7WC1Al6aWK54Zbg/dt0X2cWakg2lFefydN7TJOb31YX3LiosnTq0H1bw7YwWlIx5/paYGT0rejevLj040zm0Mu3aySMffKa5+nWhZy9vv3taFvfx0wMnqW9G9eYr076M/WSIfespPwzUqPpp0Wl4VQWbu2QsawSLI2BnOGGAPXQlJy4JHom9G9ebv0vWVgttp9qicQRS3WHLcscXGq59RpxNc1xiTHaSjORkSdQNjyHE2fdXF1oo9GGzLmX9uD0TNGawkes9KV8mGPB/11w7kf4CPfUlekXSNATJZWT4BwBM6k4HIZQVG+iXeyrhdxqru5is7e4upiRFbxPK/DuxCjZVHaTyA7zTkLSPFC8kZikeNGeMsGMbEAlCw2OOVZKbW7m88D8J02bqILiO6dLaaF1nMYLRh+PB4QcN6VHrtI+k2lnadLu3Pb10DldufjR5FXVSL6meVjcR5xL2io1vf6fdjNtcwy+ZHUkernUjPpq5kcXF4aO0UZooQFFFFAFFFFAFFFFAFFFFAFFFFAFFFFAFFFFAFFc/nUe8vbLT7ea7vbiK3tohmSWVgqjuA7ST2AbmgSzwRJNUup9ItM06RrRetvNRC8QsrEK8yg8mndiI0XluzDzZ5Vn7/XdW1TiS1M+l6af6wjh1S7Q9qA7RIe8gt5lqqTwe2jMFrEsUZYuwTJLuebyOxLMx7SSTUZydGlH9XMsrnWdduiTNcpZwk5FtpjEsN8jrbxwHJ+4iemqyW5ck5eRj2l5Hcn0knNMySd5z6KiSTKM4xUnNvIt5e5d/RvUWWdl55FNSXHPeq26u9+AEbbn00IJUlzz3qDJc+eoUlye+mWkG2Tv3UBIe5571Fe48/sppnXfamHIPLb4UAt5z30w0x76acsu55dhFMl6EkgGWR0jjUtI54UUdprS6Xp5AEaDjeRuGWQEjrGGCVDcxGvafP3thYGlWLDBbKyyJxysVyYIDjYDnxNsAPOB31rHlTSrYOiKLqZertYm8ZYkX6zeZc7/aY+zHVqOUtET6zZ1lC2pO6r8/svyLudQ0/QUSNUW41AxjEYwnVIdx1jAHhU9ijc8ye2s9ddIOkF0zYu3tozsI7ICFQPO28n+KmjBLK7u5eSWRi7u5y7sdyWJpQs5O0AV2hSUVxPEutpVq8npbUe78lfJJeTby3F1ITz6yeZv+pqShaGWCYsxVHCyZZiOB/FJOT2c6svBB9pfV/wD2kyWY4CvNXBUkjsIxXXCPPdST5scm8JSNzBNPE8Z6xTBLJGSvaPEIpMGu9JrfHV6rdMByW54Lhcd30qk++nLYs0EJfy48wy558SngP4e2mXtuFmA5ZJG3Yd6YXUsq1SPGMmi1h6WXwYG+06zucb9bas9pcDzg7r8K1mk9N7ZmSJNQeJjgC11scPF+7FdKSPax9FefeD1w2+QVYAqeYIBB9INU3a5o0K9qNYqJSXie82ms2U7JFKDbzvjgWUgpIT/qpR4p91Wfqr5+sdS1PSOFYpQ+nk8M9rd5mtlDHZlB8ZQDzwfP2V6N0e6Vx3JFuvWCVFzLp9y4a4jUc3s5TgOg7uzzds5a5h06dXjSeH3P/wAZvNqKZt7iC6iWaCQOjdo2II5hgdwe8GnhVzK008MKKKKEBRRRQBRRtRtQBRRtRtQBRRtRtQBXKDgZJIAGedZnWukot3fTtI6q51QpmWQkNa2CNykuGXm32VHP0c4bSLwg5vCJ+s67Z6QsUfBJdahcZ8DsLcjrpsbcTE7Kg+sx29PKsbO93dXCX+rTJcXaEm2hiz4FYZ7LaNub97kZ7sCmUVLczytLJcXlyQ15eTnM1ww7+wKPqqNhTTS5yx33OKjDfMvKcY+zDzHpJi2ckjO/nNRJJgM9lNyS8/51Bmm571Y4Dks/Pc1Bkn89NSzE5qG8nfQDs1xwhmOcAZqoknJJJO5yTSr2fZY87+U34VXNLzoSSOsLN6N64zk9tR428s57gK6SaATLMQSq7Y50wZpPtH3UiRvHf0mkE0A40nGEBO4Y59FTNPt1llad1zFE3iKd+sk5hfVzPqHbUOGKSaRIox4zkAZ5AcySe4dtbTRNO4yZEH0Nmh6ksNnuMZDMPMdz6u6s9epoWFzPb2RY9pq7ya9mP1fcWVhaR20Ty3JwsObi6fGT1oHkDv4M4H7zHuppxJdt4Q4w0oBCH+rQbLGMd38++pOpukS2+nxk8MYjnuCdyW8qNG8/N285FNJdWFpZrJdyhMO6xoo4pZO3xE/E4FVt6eFqZ325eOpPcQ5Ln8f2Gha+bf3102zMcn0cqgy9JYskQ2Z4RyMsgLH1AYoj6SxggS2TEd6SgH3pWo+bwTPBPNSxa5QgjYHPqNTrC6sdSR2tusBjx1iSLwsmeRzyNTfBwM7c6AzCwGK5uYSMLNGlyvp/Vv8AAH11ISESgHtwD/Op2pW3VyadONh4RJauf3Z0LL71FFtFiTB5cfucZoSQza47KQbY91X5thg7Uk2o7qEFEbUEEMoIIIII2IO2Khpb8MngzNIs1twzWsyOUmEecJIkg3DL5J9XfvqPBR3VC1C1CC0uwN7W4jEh/wDt5yIXB9BKn1UJXgXfR7pBeeEC1u3VdQCIY7jASDUY88IWdRssvZkbHs54r0KzvIbuMsuVdTiSN/KRsbg15bZ2MU2s6JBIF6oC8vdQ4l4lGn20eZBIO5m4AP5itfBO8SQXILKwROs4jljG2PLPaRn41zb0s9GlB3UMP9S6mtoqLbXSXC4IAkAGQDz84qVtV08mGUXB6Zcwoo2oqSoUUUUAUb0VCn1KxhyOs6xx9WEcR9beT76hvBaMJTeIrJNqJqV6unWGoX7oXWztZrkoGC8fVqW4QW2yeyqu51e/eOQWUUCSHARrnjcDfckJj1VU3kGq6kqLd3qKqkEIkQkTI5MUkxHn+4arrRpVnW6oxmq9ML3WiIonuYrY+NdSRr1iQJkAIOqYKWOe1wPwI7zULaNrXTej16IVbiea6dmkmkI3kcQoVJPaePYeitQ/R5J1C3Orai6BgyovURoGG3EFVcZ9VB6MaQ+815q8p/8Acv5M+4VGqOcnXs1bToXIzjS6szANpVwqnYv1qDh8UEngcA8+VIlbUQAI7ckk48dkVVHed8+ytJ+ifRb60d4/37yY/A139FuiI/Y5T6bu5/8AnU60UVjVZinTpC+cmBMkfq0iON+Q61jUV7LXGyTNOxOcZnto0Xz4RCdu7Nb5+jvQ2EcUlqIx3yXlwufRmTNQJ7LoHAMm1lYc/FublR/FJIB7jUbyJdbOrc8GFk0fpCc8N4zkkkq5ABJ82cUzJp+vQxs0yDgT6ySqDueWACT7K10g6MdZwW+gXkygbyC/uVXJ7BtTkNlpU5HB0evB93U5T8Aaq60VzOkNl3FSOYpP5oxJ0nWZMO1jO/EA2RLbknI2J4sGmpNEv8A+C3cbbeUIGQ9+4lzXpkXRvSJBmTTb+LztqWAPOcrn3VybRegdlvcXkgI+pJeoW9iIWq28ic/V1fOlLL8DyxtKvEB4ZPG28XgYEn0rkUxNp2qRgs8MjLtugZx7q9Mlv+gdrtb2l3ckcirzBfWXZR7qit0gtBtY6FYRb7PckzN7MfjVHXgupspbDup81g80W2u5DhLed27kjcn3CrKDo30inXrDp88EO2ZbweDxjz5lwT6ga3DazrkiFnu1tYeR8HSO3QebiUcXvot4prqXrpOueMLhXuS5klYnPEA5yB3Z557q4O691Hp0vRvDW+n5FBp2hOn0abs5AnuGXC8I+rEDv+fVWuBtdHsJZJYyYIYykaqfGld9ljPnYnc/yqVBbcIHinlWf6W3Dr4DZg4UK9y/czfq19m59dcY5qTzI9e4dKyt3CiuCKYai80ryS5eWZ2klK75cnfHmHIeYCq2+afwqbiXiDEPG/Bu0TbqD2bcvVUOTjBOCRzG3EMg+irPS7Ca/OHe6jThYmSGzlu2LDGF4FZeffxdnnr0VJJcz4Dd1Kjyk38iCnXMyDi4AzKCzA8CAnBY8IzgearaNNPh4eLW5pOXF4NYSnHo651qb+jGoM30MV3LHjy7hIbMk57EaRzj11Lj6I3bAdYbePnxFp5JCe7AVQox6ah1I953jYXEuUGSNBt9Iub1Zba91iee2jlmaO6hiitst9Crjq2O4yRg/hWoMaLzKD0kD41W6Zpb6VHKkD6cHlI62aa0a5lYAbKDNJwADmBw1YiS9AI+c5E3JxaWlhBz7isJb31V14miOx7mXNJELVYRJp12YgZJITbXUaRKXdmhnRuFVQE5xnspuPT9SaQGOwvmVlIDC1nCkqcjdlH5FWPHO3l6hq0mM+VfToN/NEVHupp4IHVsxvIx8YGaeeXcbj9Y5qnaEaI7Dq/3SJZsrlQOOFo8jJ65oogO/JkYU2YYVyGuLBCMZD3tp2/cc0ykFrgMlrbAEcQ+iQnfftFPKHGyhVHciKo9wqruO5HZbC96f0OBLU/tlkdyPEa4k9nVRGkXFpZXFtdQm62nhmhPBZ3Z4eNSoYcSruDv6qe4ZDzdj666I+/J9NRv5dx1WxaK/VJkWGNYBcECWS6v1tre+u5I0giSztvGEFtHxtJ9IxLOSe3zCrFrmJw6Z2dGQ4HIMMVGlNrbRPcXMsUECeVLMwVM4zgE8z3AUq2ubG5SKW2uLeVJV4ozHIpLAc/FzxbdoxtVHOUuLNlC2oW8dEOJOsr5ikTHIdfFfGcrInikVorfUYnAEpCt9r6p9PdWVgwtxeoBzaCYY75Iwp/6asE6wclb2GukJtGK6tadXjyNQDncHIxt3UVSW2otbskDQ3ExdXeNLeNpHRUIBLAbBdwB5/cVqTysnztSk6cnFl3mmLm7t7ROOZsZyEUeW5HYoqhu9YvZbSG4ic2wvPFsbeNQ13IGBIknkZSiKB4zBVJxybJqnDPGqrJLPM4B45rh2eSRs5JJb4DlXOpU0I12NjK6eeiLe61Ce7JUngh7I1Ox++e2onWKO6q97oDtqLJe47awyq5fFn1tDZ+laYouTcKO6km6A7az0moHvPqqK9/Kc4zXN1l3m6OzW+hp2vVH1hTTagB9YVlmu5j2n20008x+t76q6zNUNlrqjUNqSj64qPJqZPky8J7fFVs/xVmzK3a3vpBlx9bf01R1ZGmOzYLmXDTQsW8YFmzxMY4y5z++Rxe+koLCImRhGmcZJ4FJ9OBmqOS5CKWaRUUc2LAD21DF41xJHFaxyTzSkiIKDxPgEkouDIQO3xatDXJ+ycbmFnbx1XEkvualtZ0y3z1cJmccjjAz96Tf3VBuOlOpsMQCKBezhXjb2tt7qql0zW5z+oycjKJc2ETZJwF+ml4sns2GagXwuNNupbO70maO8j4F6q7ZZHy+OHfiZcHI9tao0Kj/AFM+erbbsab/AKcHJ+PD7/gk3OrX1ySLi9lcH6rTYX+EED3VE62Hc9YnqyfgKsZZ9Ps7m5s5PnGSW1kkhmaxisIYjJGeFxEsilyM7DO57hnFX1r0dOo6Lc6za6pfRpbGTrYJ4LRpAI+FmUPESucHu55BGRv07KurMT9Jai4U6aS/ndgyazWm5adAO9g49ni1NhZWIEIDHOAcozEjnwop+NWBtoYntkSW8nklEn65g+OHhwwC4G+aXb2lvPqTXMjNJDpyNaxEHAlumH0uMbcKA8O3aT3VSpbxhHOTVZ7duLmqqSguPdnh4jaJdIyutsnWAYEl3JxOPuqMY9QqYkety44ZwoPPqIM/43wKs0aGP9XEi+fhGfaaX1kjjdj6qxn0jTfD+fT8lb81Xkm9xeXRBwSHuOAepYhn30NpmjWsbyTeOAQSAskjknbYyMasgo8+aWsRIJ4Tw9pxt6ydqsm+hxlGGPa/nnkzEmoWUTg22mwDh4gGlAcnPLOBjarvSb6/uopZJIYo4sgQlVxxY8rbuG2Kbuf0ai6w3M2nRycJxxyIz8X3EJPupB6SaBEiiN55cKPFt4Cqjbs6zhHupplzYnWotaILiXHFMSd/ZRwOeZNZ5+lQO1tpc8meRmkx/hjU/GmzrfSmY4t9PgjB5HqndvbI2PdVvmccvojTiIZ76cWE9in04NZL/wA8XGzXTRKf9X1UX/61BpJ0HWrg/wBK1KV/M8sr/E0yiMTZb6jq8sD+D6ZbR3M6OVnluHEVtCytwtGCzLlhyJzgefsdXWraNesuzZQBRHxpDfRXUyszBSeriXPCM5O+fNVZH0XsDEYrk9buWWWMGKdCeY4xkEelTUlOjmlIAv0pQEEKWGNuWcczVtXA4KnLVxHv0l0CIMBNPLhmK9VbtuDv9fHnplul2mjPVWd7J94xIPcTT8WkaShkHg6HhcgcWTtgHtqUtnYJjhgiGP3RUZZ23cSnbpZct+o0gnuMkzN7kQfGmj0i6SyfqdNtV27Yp3+LVowsK8kUehQK7lOzFRljdx7jITnpJqkqvdJCjxIFtxJaB7ZTkk8SniIJ+1wnlvgb0+g6YxxSQg8LsoCtaraxRK2QcgxxcR/iFaniFcaQIkj7fRo7+tVJqdTKOjHmZMQdMpQW+cb0BxwsyzOpYKSOakHHPFMSaX0gbJlurx/vzTH4tWzgj4IYUPNY4wfvY399ddedOIUIckjNaDPf6Mb+YFCZ2hhmMsRnnUKrPGF4jkKfHz6B5qKkapDIyI8XEJFmKErseBgSR6MgUVojN4PDurSO8baJGpX+n2V5JJd+DdbMsToks06yoPBoI+XAVGygYyMVXtruik7SRgd6S8aj+8DiqDWRezOJ5etmZxK9xKHdSXcAlnIB577HaqRerUcKlgCBgSv1UhbPPq1yrDuzitMqUZ8WeNb7Rr2i0QS+aNsNX0iXyblMeZg2PThq54fo7ft1vnPk9dGWPoAcmsYyhCBJhSV2WZWs2IPYEgyD6++tvoMVq56PaNZLqtrf6pZve3V/YzWdqZTwvKwLLG85VOHgCiRRncg535dlh4noR9I7uPJR8v3GGu9Gxk6hZg9xnjBz5xxZpDXelgZ8JgK/a6zxMd/EBiouqy2t7Be8MOrNd6ddwW4uNRGn3k5V3eM27zLFG7McFlDZwFO4HPOq0IJw0PGCQAs84kz5o5BwZ8xOKdkp+Jf/AFNe/wCPl+5phf6S2y3dqW7AHdifQFQ0iS+0yLh6y5tlJ3wy3APq4oRWfdXVYzKsipx4JuII7aPH+8tsyUglGcCIozcJ2tWkuGO/2bkZ9lFaUu4q/SW/fJryRe/OWktnhnibH2IblvbiOmpr2MbQxxtlSUd0YKD2HhO59dVttbdZMrXVveNEAQA0HUhidvqMuMc8583bs+I7VWnRcQw/1KdZ10rOM+OwUkji22ycVPZqSfI5y27f1I/7i+CSz9hq4MspDrwvgAKzhSUkP1SNgB6uVa61lt7Kwtfm5lS3uzHa61qTxLJqMbuisYJEciNFBBCKpAKgEFjnGXS0u3PFDHKWAIDdXwIQexutwCKsrYCxk665uLmymlQIeoWOe3kQ+UknESpHmKHlnsro6kILB5vZbms9covj1ZqRLY6WJrOHXtQublBHcJZ2elmRHlZeKPygzqTnYjbByM1m+ll1x9JNVuJmDvHdwjAwW4bZlwvi+jFPXGvSuHUa9rUgI4StrGbdGVQFUFgU2x5qpSYWJ6izY5OeK4dck95Cg/Gqdoi+nmdVsyu+Sz8OJclYBqN9fwX+lNb3VxLeQNLeRxzcLOZoetikTiGM4cc+ePO7c6tcLYJYWk/hkskuo3F5PbcYtAbnqo0UyOkYJAUk4TA2FVlvbXszbPBCDseqhDNj0yHHuq0i0fT1PWXPWTuSCeubK5H/ALagJ7qo7qC5m+l6P3VRZfBeP7ZIOmRahcNKYZXWNjwTX3MKq80tQebfvch5yNtFFFDbxxxRKEijUJGgycDnuTvntJ89JEvCAP6tQACoxwgd6js7sUcRfGN88sdvrFYq1Z1GfW7N2ZTsovTxb5sdDZOKlwxk/wDaqabUY7fiWFVkkGxJ/Voe7bc1Vz6vqGfpL14h2BXWEY8wXFc4m6q1jng2nVjsyD6aodc0ae+US28ztIi4a3mlYQyDvTJwre4++qeLXdUhIaO769M7pMVlUj08/fV5a65a3sTbdXcqMvCTkH95G7R7/TzrqpaXlHnVaMa0dEnwfcUUOg6uLeW3Sw0yOWRnxc3EiPOocFSFKBsY7PzjSWtlYRW9sDBBxrDGHbhBywUAnJqqutRlBJDkYOdthVYNTkAA4jtkD21M6jnzOVrY0rVtwy2zZA2icuqX0cIoN3bL9dfVWKbUnO+TTbai/ea5m546m2OoWw+sT6P+9NnVLccs+0ViWv5T2n202byY9tSUckbU6vEM4A82TTTayOwL7zWMN1Ke2km4lP1jTBR1Ea860cuQyjJHIDsUCm21qT7fsArImV/tGudY/wBo+2pwV3hrPnmX/WH20DVpDj6RvaaynWP3mlpM4I3NOA15NhDqMrnyzz7e2rR5OsgRefXtFGcdzNlvcDWOtJzkZrQWtwJWgXORAjOd/ryeIvsHF7ajkdYrKwzQKwNKYgiqK913T9N8SVnlnxnqIeHiXzyMdh8agQ9MLORws9nNChPlpIs3D5yvCvxq6zjJmnKEZ6clzPsx85PxoqHNe27xJJHKjq5yhG+VOTnfeipSOM3Fsda1tyerMYZPqYyrJnfCsvje+oVxoOny5JmjVm/tKRvt3B1KSf4q5FcXMXi8XEB2PhvjvW36LFLvTtRkltYp5Ir2VI0ZIizkW8ThFMvijJPacb1NByctKeBtWFClb72pBS6ePmedHoykfF4PPZqG3JivJoSfVIJB76laZbaroksc2ny2sckXW9Wz3drOFMoCyFBNFtxbZxjlWtj6WaZ4LDdT9GuqS6W9FisT2Mz3ElrPFaEeIuArSOEU5PacY3Lj9J7CB7ZJ+jsGMweHPa3OnXEdp4QbgwhWRcOxWJ3bHIY3Nb9M+/6HxzrWb/4n5mIv7C71ORpNQeGbimmueqF7bW8AnmIMkvV20I8ZsDJJJ2HdUYaLGo4WktmTkVl1GaRcdxVEX416Xo2s2et2ep3VtoFrx2T2yqgnsZIpuuhS4P8ASETgBRT443wdudRYOk2l3AiaLo/ZpG9jDqLS3tzp1tDHDNM0CdZJKmAWI2HbVWp+99DtSlaP2lRbx/kYCPRLJCDEdOVs5HVxNMw9Bnlb4VIaydBvc3GO6LqoFx3fRKD762Wr3mmap0O1vUbawt7YxXcVqkkKwOHMV9DG0kE8SgFTuARWTlvYyWxG2MnmRWOvKpBpaj6bZVGwuVJuik4vHF5ID2toDlo+M98rPIf8ZNILdWMRRov3VA9wqS1wDnESj0mmjNL2KorNmT5nvKnQp8IRS+RGY377L1uO5Bwj20gafdyHLcC558b5PuzUrrZz2j2V1WuH4gpO3PA5eypKtp8DkWkRggyTk+ZEx72P4VNjtLCIDK8RHa7HHsGBVbLdpDs8ig901wqE/wDDjy9Nx3pkkRQ2n+McfSJdY3P2mxU6ZPkcXc0YNRbWfiXRubaIYTgGOxB/KmDecbgDOCcZJrl3bwRwrLG6BxwcaRt4rZ7VBJNV6tuDtsQfYaokaZSa4MvUcY571FurjhPUxEqWB60qcAAjOAO/vpHXrw+IQSRsO0VR6rcsCtnET1s2OuI8rhY7IPO3b5vTXSFJzlgyXd/G2pOcug1c39xNKLTTVLuTwGVAWZj2iIY2Hn+FRjoOqy+M8kJkbchpGZsnvIBHvq4hji06AQQ8DTyKouZlIPE3bGjLjxB6NzSkt9Wmi8KjhkFqWZVuZnjgt3YbkRSzMqtjtxn0160KagsI/Obq8q3UtVR/LojMT22o6c6ieOSPJ8VuaP8AdYbVLtrtyVdTwyJuCOdaMy3NsW0zXbKY2sy5aK4QrMinGJ7WQ7HGxBBINZq/0+XSb9rYyLLDJGlxaTp5FxbyDijkX08iOwgjsqlWmprxO9hezoTSb9llhLdGVQTsTzHnqLxGkgnCnsIBrhPOvO0n2m+ykK4jXOKk1ypwcnUYvirnFXKMUwiNUmdyaM0BaUEPnoSoyYminBE/2TSuplP1TUZLqmxoUoCnltpj9WnDbOoyc1B1hDAhJCnKnzqM1urcBxKeTfZOPK9XZULiwSfs/HsppImu5uqJwgAaU9uOxR5zV6dNzeDNeXqt6bkhofOF67+CwTTsSWd1VnYknck0y7X1rKI7qKVG2JWZCjY82RWxsJNRQiz0a3kaVVMj9RGG4FXynZm8UAdrMR6e9WoT311Eln0ghMkNwpazu2RGkjK+L1ttPF4rKPrDiPbyNelu4pYPiHd1nLXqKOxu2jUqxJjbx18zduKKi2sUkE13Zz444HxkHKkd6nuOxHporFKOl4PqKFbe01M18vSXRhK8XgTNwkglZIi49KY9fOtj0Q13o81hfs2oWVk0moysIbu6t4ZgPB4Y+MKX5HBxXkF3D4NMQSojdpCrMTH4y7EdYg498g45b0xw54XZfEY543jWNTknld+UfZWmnSgsSieHe39xV1UKvJM9ofSegLwadDHr0EB022htbOW21e0SWIRXIu1kHFlePiAJPD2ctqbXo58nwyPn3iiaLgaBtatupaYwNb+FMo363DPvnm523rx0ICshCcSAHxhAt0nIftJwR59tqUqoSnCFfAY4DrqIG3bEACPTXc8k9ufT+iTWL6ZbdIRZ2T3V5ctFp+q2kIY3ZLPCSAT1YyeFfP5tkronQgSxSjU4WSOfTZkgbUrZrfh06Ew28JQ80XJYjO5OSa8U4UzLsFOTlVuYrHs7bZwT796SUULH4kYOV/ZjatnH+vfxB7KYLqUksJnt/TC90pui2sRW95Yuf6DwRwXFvvw3kLkKqtjlXmTX+n7kM2Mnf6ID2l6zrAEgsudiPpWjvl59ht8EUJxqXEbSIMgEW9xHZg7dsU/jVyqUo1Hlm6z2jVs4uNPHHvNA1/aqOLq5CNsHigHPlzeiO9tpWKYkjk7ElABYfulSRVDBb+El2fqurRszySq7SfdEgPCT5x+OKure3CGKQpwFcC3jwAVGMB3P2u4Z29J2z1KNOEcnuWG07y6rKOFp68CQWXDvIerijBZ2OxwKoLm7ur7rWWQW9lG/VqMt4zYzjhTxi3aamahdKQYxgxxtwgE7TTDvA34U7dudV6/qIQgz1TOHALFl4jxAniAOD6Km3pLGqRw2xtFyluKTwlzx9iXpOk30/hdzZW9zcx26LHKwiRcM/jhF8csXwCcAE4Ga5ctlI98EzIp5AcLhlO/Lurb9D9R6OW1hpYmaQ6hbXOqs8cZUNHNPki5BfClSgVFOdj7Rm+kEtlc32tXMLAW8kss0ZVTGHwBhimTuTW3B8xnqJUmSGGXteNC/3sYNJbY7cjRZvxWpH2XkHoyeMfGlcPEBXkTjiTR+kW1ZzpRm+5DiPHDDLPJ5Co0h84XkvrNUllJLLdTXbn6TiaQEOVPWMdiuB2VL1iYRWkUCneaQA/ci8b449lRrBT1Y5+Me4Ae2tlvDEdR8ttu4dSruuiLiO1vJbLWNRjt/CItKto7mdX3RjLII1DDmQN3cdw/e3rG1W8vujupW91K8kltrFpe27tuc3dvPBMnmB4UIA22NT7ttb0ptG1C3t5kgltHkgMkbNaX8NxlZreT6pyowy5zjcdhCIdKi4YhapM+narrejta5Qu3VBblpLZ+HJMke6sAN8Zx44zqPBJslzc6t0g+aHxJFcyabpkAyS9tNDbR2/WqByClSz94BBznaDqEbz6a8FwALzQ7xlBVuIC3mfq5UVhsVDgMvmY/apE040me8k4z8+XpuWnIyfmuG64g8bFedw6sVYDyAxG7n6GwubC+tDaJfW0lrJqmiSssEoKSKqccSB0HJvFQ47Nu3YBnHEzcLDgUH6uR+NKODypoH2kAn04roYjsNefNccH2drW1U4t9w5ilBCaQJCPqH209HdmP9nRvvFvwrjiRvjOl1Y4lrK/JTUuLS53xsfRimk1q5jxw2lpj95ZG/zU8Ok2rptHHZR/dt1z/iJpoZftFJcvsWEOhOcEofWP51Oi0LGM8A5Vn26TdIDyuYl+7BB+K02ekXSI//AFCQfcES/wDStNDId5T6Jmri0RCqk47ew9hIp9dDTuY+hDWIbWNefnqN7gknxZ5F3Jz9UimHu9Uk8u6u3z9uaU59pqdBTti6RN1PY6bZoZLq5hhUZP0jKGPoQHiPqFZXUtTglZobJWEAODLIMSSegdg/Pmqp6udtyrk9+GP4VIisr1wJPBpzHnYiKQ8ZHYu1SoJHOV1OfBLAgxzcI4Y5CMcRIRiDkZ22qRYhkiXAy8rs5Vc5J5KAD7qYmaZOMPxo4yeE8Skd2xqy0hI3urFHmigj4gZLiU5jt1VS3Wtk8lxmtVuubPn9sPDjFMnu13pWq6Pa9arWd7ptw0pt3VorpL20lhnLOpIJjOUx2GPvO7WmyXF83RrQ5ZUS2fSmWVpW8W2BlutQ8KycAcKkE+b07sW9ldWoltJ7qzuFt4dRv9Jure4621nZ4Hhkjhl/fPCcEAhkwQC1LmjYT3NhpXVzSeDW0epahxNHaW1nHFHGsIlfGIzgGVubnxVBA+l1HhFVflke1uCMSNG9rN9+EjBPqO3ooqx1W1hlleG0uRdRB7efwjq3hErPbqsjCOXxgOIHGfxorPP9R7Fo3u+Y9eWq3AlEYmGSHhkijMkkU0eVUsg3Ksp4Wxy4Qd6qfm28RsqqK4z9IILxXP3uKMp7q0E+h601zcI2pRGeJ2jlgtLmCIwsuxjMfW8WR6KafRddiGWub5V5ZExYe1WNIQqRWOGC91Wsrio5vUm+eMFGdPuycsIGY8nY3iOO7ZIwn+Glm1uWK9ZJbPgNgO7QkE7bNBGp9pqyNvqcezardpj7TvgUkNenYa+cjmDKCav/AFO5GXTY+9LyRX+B3GGAmsVySQpeCbGdv1k6mT30GznwoV7QEY3N+JlxjH6qYcJqxxqJ5a6v96Rf5UkjVOzWoT6XQ/hTNTuI3dl78vJfkrRaTq2TJZE8JGYriG1O/YfB9j66Fs+J8zT2vAWG2UupWA7FlZc1YFtVGw1e2J87w/ypMkutyAceq2rAcuJ4/wAFqc1O4buy/wCyXkvySYooYghKooT9RCAPE/eYDt83Z6Tty4acwzGJXMhHlAZIBOCVHfUJZNQjPjyWc33JOFvUwH4U+t4Obh4yMZLEOv8AEn8qxzp1G9UkfTWl1YxpbmlLHx5/H4lPcR3DSYjt5iiBFjyrKAAM77Bsk5zvSUg1ENxLbzKeHh+iJBxnOCZS1aDretAxEkw7GjlQN8aSGlHk20g3+tJFt7Kt2iS6Gf1JQlxc2/IrbdNSzIZoJcYAjKLBxc9wx2p14biSKWPweXEi8JZnhDLuDseKrMAEZbxfSQfgaS5RcYkQ+khce007RIt6jt48XJ/QZtY2hjKuACzAhVbi4QFVACx5nbenvEHINnJ5kH8KSXQf1iD++v8AOkGaAc5of+Yn8648ZPJ6UdFCmoRfBFLrMnHdxx74ihRced8uT7xUq0BCpsfJzud6q71xLe3TqeJetIVl3BCjhBB9VWdmy5Tu7fR569GCxFI+Gup7ytKXiSLvXdZs7u4tDdXFxp0DiJtPvJJJLF4I0VRH1ROB+6Rgg4IIIzUsyzW93dwxXkunRafPJdWiXRLXEs8jR27NCcJIJOEjdU4vFBxts5f3XR/TGsLu1hu7rXZraK8uJLyRDYWEnDwh4YlQM0gwSvESASPKIwr8KWcZ02O+gWe+TWrAawbiRmQJqkEvBZMnlEpwhpTkHiZh2VczFZbzPp8Ed7Bpxha4uLqL51DF+rkV8CCzD/qmI3JbLnsKjmuGYubViJAY57oM0jMzHKRsclyTnvqMyT2BudQ0WWRbMuLfVbGYLceCScRTqbyJxwSQk5Eblcb4PC3lWV1JZSxaa1np0Fi4064luYLZpXjkuZC69YnWszAEBcLnblvjNAjNxOFU5RHyeb8WR7CKX1vdHH7CfiajdYoB8VsKeFj2Z7qcjJkEfAHLytwRpjdmzjY5rG6cmz6SF1RhFR1D3WOeUcf8ANLVbt/It+L7sGfgK3kXyVa+yIz6tYxsyqzKIp2KEjJXIIG1TE+S3WhgfpIqDt6u3m29H0wpupE9uoLqzz5LPWm8iwuG+7Zk/wCSnl0rpK/LTbr12oT4qK9CHyW3hx1nSm6I7Qts34zmnB8lVuf1vSHUHH7sMY/6nNN1Iq9o2/iefjQ+lR5WMo+91Kf9RFK+Yek/1okX791ar/nr0Jfkp0b+s1fVm+6bdfihp1fkp6Ljy73WHPf11uPhFU7mRD2lQ7n/AD5Hm/zLrq+VcWkffxahbj4PSDpeoLnj1TTl9OpRZ/wk16mvyX9DVxn5yfHPiu8Z9PCgp5Pk16Drzs7l/v3lx/lYVO5ZX1pS908eltJYwS2pWb47I7sufcKhMcE/SluzILEe+vdk+T7oImP9EhsHm91eN8ZKyHTvoVoWkaLc6rpME8UsN3bmZTPJJEtvKxjIVHzyJXG9Nw+8j1pT6RPM5CQo57so7+3NWlsryxXMcau8stpPHGkYLu7tEcKqruT6KoQzNux32xzwPRV7pF21tPZ3CSFHgmjkWRQMoVPlAHu5iu8I6Vg8q6r7+eolWmnX1jbxW15BI0scz61caVcLIn9CtYVMst2jZ4QRuo4CSBkg7AquFmt7m706+nm025Nwt7bW9w4bS50kiQRlZcsVOBhHPEuNvEwaXFbXdhcWkOosZNQ15ppLjrGZ5TZMksaPMzbnrnJbGeSL9ukxdZqtxpOmylCmqWlo+nzuMG01ExGBxnB+jleMiQcstxcx41zKXXR/SZm1uSx1S2RprfTRNJE7RyKrOY2RsxMUPittgnZqKvPk6thPqet3TDMVvZ29kuDlQS+yg+YJt6aKjCJTaKjp50ZuNNvJ9ZE3hNvql/cPIBCE8Fkk8dUJycg74PmNYVmI8ZAcgYUEsN+Y5d/4V9KalYWWqWV3YXiB7e4jKMPrKeaupPaDuPRXgvSXo3qnR2eRLpWe1Zj4NeIn0M6nlkjYP3g+kZBqSDKtcXLMxMsnETny2x6MZrTXuvT6vpek2kdnYxvZf+sktoEju7hlUqjyMg4ioHPA3POsvKASWGMk+NjlnzUgMwIIJDDkVOD7RQE9I7hgygXBkV89Y4ZIQg+0XxgV0C4nnt7KyMk080scK8GSZZ5CFVEzvjPL/vUPrLiYqhklkLEKi5ZiWOwAHfXr/wAnvQ1tLkTXdbEcV6U4dPtJSqyWyuuDLKudnI2A5gE53OEA1em9B+ilrYWFvdaVp91dQ28aXNxNCrvNMF8dyzb7nOKfPQvoQ3PQdN/uxY+Bq4a9sE8q6tx6ZU/nTbaro6+Vf2g9MyfzoCq/QnoP/sLT/wCBv50foT0H/wBhaf8AwN/OrBte6Pr5Wp2Y/wCKp+FMt0m6Mp5WqWnqYn4CgI69DOhS7DQdN9cIJ9pOaf8A0X6KcJQaPYBDzVYQAdsbgU03S7oovPU4T90Ofwplum3RFf2/P3Y3P4VGEyyk1yY+eh/Q089C03/kLXP0O6F/7B0v126H41Cfp70TX9omPoiP4mmH+UXoquwa5bnyVR8WphEOTfNnnvSfoXrGnapePYaXLPpl1cSyWXgETT9UjAP1bxxgsoXJA78VQS6H0gSKUvouqoojcktY3AACqWJJ4OzBr1p/lK6Nr5MVyceeMfjUd/lQ0PcC0mYbjDSxgEcuW9SMnh6EebGB/wB6sbWTAXHZt5himNWFiNQvH08MtlNK01tGxDNEjni6okfZ5Co8UoU88Z5HmRQg2dsuki2utYuw0s+i2vHZWvDxQ3dwz4gM+N+GNiHI5EDB2GGz0Elw2l9ILl5HaYX2kXLSucs1wXuTlmO/EcsfUam6dfGBgcI6Mpjljfxo5Y2G6OKvAnRGfSprBRcQJLfDUJR1vjh1gaCOPPCQVTLFd+09+ABWW6rB0sknaImyuLrrb6Jh9HJp19EJ5o2UH7Lkj0A91M6jcQpDfPEJI4pJFtbUFuOWOH6vE22WCqOI95qz1K/t7hoUs7ZE4bWzsncEmS4FtGsSySs23YCQAOQznG2Yv5bedo41mcpBxjKqCryMfGcEnzAerz0A3xwS+PLBbSSHcyCV4+MnfLxr29+MVuPk96PTatqiapcJ/o/TXVuLh4Y5bpMNHBEOXCuzP6AO3bAKlspBLOwHMEAAjuODmtZb9Puk1pBBa2k1vb20CBIoba0hjjRR2AAe2gPf67XgZ+UXpef20+qNB8BXf/EPpaf2t/Uo/lQHvdFeCf8AiD0s/tUv59VLHyg9K8/+pl938qA93ruK8KHygdK+fXykehcfCnl6f9LM+XN/Cv8A8aA9vrleKr8oHS3f9dj/AHKn/LTi/KB0r+zKf+An8qA9nqDq2nQ6tpmpabNgJe2ssHEfqMw8V/UcH1V5YvygdKOfVyH/APGSnk6f9Jz+yTt34swfgaA8tuba6sbq6s7pDHcWs0lvOjA+K8bFTv8ACn7SXgYA9p/7Vo+kpv8ApFcDUBpN/HqHAsczRWMipcquymThJ8Ycs9wHdVCmhdJw3Euj6mcbnFpOdvUtAaXTILXUtT0y6uLuOOe1hMeLpnCT+DQMtoiMM4IbgVh3AHzFVzp9lodjpguLiKXVreC8hfwdxJHGklw8qS8Q+sQdh2Zqqg0vpNsraFrWcjH9AuTn/DitLovRnWhc291f6PdNDE6yrayqsYldd163DeSDvjt5UB6B0F0mTTNBgadOC61BzfzgjBRZABGh27FA9tFSY9T6SsN9IVdhzlA91FAUEsXyjHOLtv7hiH+Wq65sflBuI5IZp7mWGUFZI2aBo3XuZWGK9RwKMCgPBZOgmp5J+bpgTk+Ixx6gDiozdBtVGf8AR916smvoPA7q5he4eygPntOiOu2zrLBa3sUi+TJGHV17MhhuK6+hdKznPzoeflPOc+2voPhXuHso4V7hQHzq2h9JhzTUPX1ppttE6Rdsd4fVJ/Kvo3gTuHso4E+yPYKA+bm0XpB2w3frD02dF17O8N17Hr6W4E+yPYK5wJ9lfYKA+aPmXXd/oLr+FqSdE1v+z3H8LV9M8CfZX2Cu8CfZX+EUB8yfMet/2a4/hNc+Y9b/ALJcfwmvpvgT7K+wV3hT7I9goD5j+Ydc/sVyfQppX6P6+eWm3h9EZr6awO4ewV3FAfMn6N9I22+Z9Qb0RGuDop0ubPBouokf7lq+nKKA+boei/TaPH+gdTIHLhhYkeyp0HRrppIwVdA1RSeZeNYl9bSMBX0HRQHiEXQfpZKhWWxaMuOFvpo+R5jINPR/JtrB8q3UemVfwFe00UB5AnyaahtlIh5zIT8BUlPkzuPrNbj1ua9WooDzJPk0H1pYR6FY/E1JT5NrQY4px6ox+Jr0SigMInydaYPKmY+hUH4VJToBoi+U0p9YHwFbKigMqnQfo+vOORvS7fhUheh/Rxf2QE/vM5/GtFRQFIvRfo6nKxh9YJ+JqQmhaEnk2Ft/y1PxFWdFAQ00zS08m0gHojX+VOra2ieTBEPQoFP0UAgRQjlGo9Vd4VH1R6hSqKAMUYHcKKKAPZRRRQHKKKKAKKKKAKKKKAKKKKAKKKKA7XKKKAK7RRQHK7RRQHKKKKAK7RRQHKKKKA7XKKKAKKKKAK7RRQHKKKKAKKKKA7XKKKA7XKKKAKKKKA7RRRQH/9k="	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  
   <div class="one m-2 py-5">
<?php $v= "Hyundai Aura
";
    $p="
Hyundai’s second shot at giving us a <br>
small sedan is based on a potent recipe.<br>
Does the Aura have it’s own flavour

"	
	;$i="
https://th.bing.com/th/id/OIP.GnjGRFrpP8HKAxypzt69JgHaFj?w=200&h=180&c=7&o=5&dpr=1.25&pid=1.7"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
    <div class="one m-2 py-5">
<?php $v= "Skoda Rapid
";
    $p="
The ŠKODA RAPID is a masterpiece in <br>
the truest sense. It stays loyal to <br>
the brand’s timeless design ideals<br>
 simultaneously incorporating avant-garde elements

"	
	;$i="
https://th.bing.com/th/id/OIP.booqcEj3TQ87giS1MKT0xAHaE6?w=297&h=197&c=7&o=5&dpr=1.25&pid=1.7"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  <div class="one m-2 py-5">
<?php $v= "Hyundai Elantra
";
    $p="
When you’re bold, the world is full<br>
of possibilities. When you dare you<br> 
reach your goals. 
"	
	;$i="https://th.bing.com/th/id/OIP.924DkilwrX6FjRNGbmzb8wHaEo?w=225&h=185&c=7&o=5&dpr=1.25&pid=1.7
";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
 <div class="one m-2 py-5">
<?php $v= "Toyota Yaris
";
    $p="
The Yaris sedan is offered in the C-segment<br>
to compete with the Honda City,Verna Maruti<br>
Ciaz. 
"	
	;$i="https://th.bing.com/th/id/OIP.Db1AjSwDd42lOzrWT2_5lgHaE5?w=275&h=182&c=7&o=5&dpr=1.25&pid=1.7

";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
 <div class="one m-2 py-5">
<?php $v= "Lexus LS
";
    $p="
inspiring, alluring and evocative. A cut<br>
the rest. Our flagship model is a world-class <br>
vehicle that is the pinnacle of luxury performance. 

"	
	;$i="https://th.bing.com/th/id/OIP.G-NdS_M5y8Qpwjqzy2I-gQHaFP?w=209&h=180&c=7&o=5&dpr=1.25&pid=1.7
	
	";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
<div class="one m-2 py-5">
<?php $v= "BMW 6 series GT
";
    $p="The BMW 6 Series is a range of grand tourers<br>
	by BMW since 1976. It is the successor to the E9<br>
	Coupé and is currently in its fourth generation. 
"	
	;$i="https://th.bing.com/th/id/OIP.qSrAA1IjTH9jWO8ZebE93AHaE7?w=236&h=180&c=7&o=5&dpr=1.25&pid=1.7
	";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
<div class="one m-2 py-5">
<?php $v= "skoda superb
";
    $p="The Škoda Superb is a large family car that<br>
	has produced by  Czech manufacturer<br>
	Škoda Auto since 2001.
"	
	;$i="https://th.bing.com/th/id/OIP.jUNuZxiOQ8xSYnWNRcEGCgHaE8?w=240&h=180&c=7&o=5&dpr=1.25&pid=1.7
	";?>  <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  <div class="one m-2 py-5">
<?php $v= "Audi A6
";
    $p="The Audi A6 Sedan Innovative technologies and<br>
	exciting versatile equipment options: The Audi<br>
	A6 Sedan combines these values into exceptionally <br>
	sporty and elegant symbiosi
	
"	
	;$i="https://th.bing.com/th/id/OIP.y163zQnZD5LX8f8GrjFLlwHaE8?w=227&h=185&c=7&o=5&dpr=1.25&pid=1.7
	
	";?>  <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  <div class="one m-2 py-5">
<?php $v= "BMW  5 Series
";
    $p="The BMW 5 Series is the embodiment of the modern business sedan.<br>
	to its dynamic and simultaneously elegant appearance, it convincingly <br>
	meets the expectations that are placed today on a vehicle of its class<br>
	";$i=
	"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADmAVcDASIAAhEBAxEB/8QAGwAAAgIDAQAAAAAAAAAAAAAAAAECAwQFBgf/xABSEAACAQMCAgcFAwUKCgoDAAABAgMABBEFIRIxBhMiQVFhcRSBkaGxIzJCFRZScsEHM0NigpKy0dLhFyRFU1Rkg5PC8CY0RFVjlKKjpNM2VuL/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAJBEAAgIBBQEBAAMBAQAAAAAAAAECERIDEyExUUEUBCIyYaH/2gAMAwEAAhEDEQA/AN1vv61IZpd5qYFKzehjNME0qdKwoeT4mnk+NKiiwolk0ZPnSp07Jolk+NAJ8aVAp2Ilk08nxpUVSZLRLJ8aMnxNKirTJaHk+Jp5bxpUxV2SPJ8aMnxNKirskeT40st3miiqTEwyfE0snxNGKMVSZAZPjSyfGiiqTJoN/Glk+JpmliqTELJ8TSyfGme+omrEw3pZPiadKgkRJ8aWTTNKmIWT40iT406iaqxUGTvvSyfE0eNKnYUBJ8aWT40UqLJoCT40iT40GlRY6Fk1E5qRqJpDIHNFMiikMyu8+tSFR8fWpCvCs9ih0UUVNlUOnUadFiolTqNFVYqJ0UqdOxNDpilinV2RQ6dIU8VSkS0PaiiiqTJaCinRWiZFCop0qpMloKVOirTJaFSp4oqrJoVKnRVJioie+lTI50qtCFSp0qoloVI0zSpkkaRpkUjTEKg0eNKmhCooNKmAUu+g0qAoDUTUqR76AKzRTNFSMy8bmnR3mivn7PdxCiiipsdBTFGKdFhQU8UqkKdicR0UUxVCxHTwaVOmiMR06Qp1aJcR0UCnV2Q4ioNOiqTM6FRTorRMWIqVOirTIaFRig0VdiojRRRTsmhHvqNSpGrTJFio4qVI1aYmI1E0zSNOyaFUTUqRqrJoj40qke+o07FQqR76ZpeNOxEaKKKLAKRp0GiwogRRRRSAy+80UzzNKvnT6EdFFPakAUUU6AoKdFOmIKkKQFMU0Kh0UU8VRNDFFAFSxVohiFOgCnVEixRToIqzNoVFOiqRIqVSpVaZLEaVMilVpkioooq0xUI99RNSNI1SYqI0sVKlVWKiJqOKkaVOyKI0jTpVVixQj30jTPfSNOxOJE0qlUadk4iNFOjFFhiKkadKix4kSKKZoosVGWeZ9aVM8z60V8+fQUFFFAoGFPFFSwKBBTAJoqQFMKEBUwKRKqrO5VUX7zOQqj1J2rUXHSTTIpDb2wa6nHNUyEX9bhBYD1A+daQ05TfBjPUjHtm5xTwBzrk/y3r14ZTbRRRwxSvCXAhCs6bMEaUuxwdiQmMgjupflTVLUiW9IktuMCbswh40JCmSN4Qv3eZBXlnw37I/xvWccv5XiOvAp4HiPeRWrJnAmEQDSdVK8SkngaRFyFON8HYVx354au4BW109AQDhhcOd/wDaVr+SK+mP7JPpf+no2B4j4int4j4ivN/zu1v9DTx6W7n6yUx0t1r/AFH/AMsf7dP80fRfql4j0fA8R8RSxXng6W6x/qP/AJY/26f536svOKyYeUUq/SSn+Zei/S/D0PhpcNcAnTPUQQGtbTfvJuFHvPGayB01uVwHsoD4dXPLv6ZzS/PX0e+/DtitIrXJxdM1bPFYPtueG4U4HoyVkx9MdMbHHBcr446psfMUbD9HvL6josUsVq4+kmiSAHjmTP6cDY+KZrKj1bR5fuXkGfByYz/7gFG3JBuQf0ySKiakssTjKOrL+kjB1+KZqWMgMNweRG4PoRUu12UqfTK6VTIqBppjoiaVSIqNVYmhGlUiKWKdk0QNI1MiokU7CiPjUanjnUcU7JoVLxqWKjtTsKImipUqLChUjUqVFhRE0UyKKLCjJPM+tApHmaBXi0e2OnSqQFFAIVKgCpAUUAwOVYWo6pbaaEQpJcXkx4Le0gHFLI5BbfwHMnyGdhvVOoalOk40zTFSTU3VWlkkybfT432Ek5H4j+FeZ92RpNJtIWmudRDy3D3Ba3tp5iWluIlb7S4wNgJGGVAGAqrzyS3TpaOXLOHX/kYcRLpbbU9SdZdXuCkQ3jsLNysaA90sq4YnxC4Hm1Y9+wt4orDT0jgeeRIYViQIiyuC3WELt9moLnzA8a6L2Zkjd3Xjk4T1cQZVy2NgWJxWptdH1M3jXVwsI6q36u2xIrkyztxzyNgbckQeQPjXoRSSpHl5ttyYo4YbaGC3hXEUMaxxjv4V2yT4nmfWqLtBNb3UJG0kEqY/WQit5DpknGTOEaPhOArNktnmeVQurCzgjmuHaWOOJC7KMMMAd3EM/OrbpUzJN3ZPS5eutdGuG36yC0d89/HEAfnXl18htb7UbY/9nvLmEY8ElYCvR9BYHR7Hf9466L3Q3DqPliuM6VWwj6QavtgTNBdDwxPCjk/HNOTrkuMbbRpQ9MPW407ozc6lax3UN/bxqzyRvG8MjPG6NgjZsHuI9a2D9Cp9+r1OMnwltmHzWQ/So3Y+hVHMh/Wph+Vbl+iGuLnq5rGX0kkjJH8pSPnWLJ0e6RxAk2DuB3wSQyfABs/KqU4v6BhqSeVTK7doDFUMJoXeOVJIpEOGSRSjqfBlben1rnmc7Y332qxMvjhBOQORxudvnU2AQ4ZVzz2FY6NIxwDj0zWZbyRRMGmtILrHIXLTcIHgBG4HxBqXJIai2JZeHHCcDyrJimuJDwxrJIcZ4UVnOPQA1RfyWkpjuLa39n4hwXEKMDEsnc0XeAR3Y51XaXs1rLHNC3C6sD5HyPkeR9apO1wS+DaJcSQsoZGifu4laJsjwyAayo9R1COQz2d7JFMQoeOctNaTheQliJyD/GUg1u4pbPU7SOUxq8UoPEknaKOPvLnnkeX7a1F7o0kYMtiXdfxQMcuB/Ebv9OfrUZqXDBNro3umdIrS+kS0uk9j1AjswyOGjuAPxW0o2YeWAR4d9bogHlg+leYM0U6GGdOJcnY5DI67ZUjcEVutM6R3WnlINTke5sdhHfHtTwDli7VRlh/HAz457spwrlHVDVvs7IilimkkU0aSROro6K6MjKysh5MrLsQe40YrI6Ur6IkUqmajg0WFEaRqeKRAp2KiHjUTUyKRFOxUQpYqRFKnYqI4ox5U8UUsgoj7qPdTooyCiJop0U7Ci08zQM0d5pivMo9UYpilUqKAYG9YGr6hLYwW8NoqPqeoSm2sEf7qMBxSXEg/RjG591bDkM/857q5WGf2/pBrV1uYtMt4dMtiDlQ0mZpmHdnbBro0tK/7M5NfWx/rElPbrZ2Uem2sjtc6rcPbzXLbzy8al7q6c888OQPDiUV0Nrax28aKqKvCioqjGI0UcIRceA2rRQzKdUurqQoEsI47C3EzBQZXAuJ3GceKL/JNbRdXiP4A/IYiLt/RVq6+ekeTK2aTpJq7abqdtHLqN9aW01qjobNIW4ZFJVlbjRjkjDD1qu36SaTJj/phfo3cLm1tiB6l7L9tR1XTr7WnndrCZ1lngKF4JR1UKuONoyyjcrsKxpOhVpISYtO1CMHOzS2wA7/xvmltzfRr/RLk6G01ixaRSeldhcx4P2cken27EnvLqiN8qlrl0k9g6RSwyByEzDJG4PZJ5ox8a5degcWcyW93jPJby1jOMeIR/pWu1LoTdW/sz2ziNJGkU+0ziQ5UAggxRL4+FGGpHsX9Gdb0YlRrK7tiw447h2K75CzQo2SPXirW9LtL1e+1DSrrTbWS4eTTequVUoArQyEjiLkDkw76zuiWkXelWt2bqZJWupYnXqyxCoiFBkuAa6V4wWjkRmRlV1+6rKyOVYhg3oMEEV0JZx5MnLGdo5Lo5ba5pyXcN7pN6iTSRyxmOS0kVWC8DcX2obw7q6M9aRnqJx6ouf8A0saycyD8SH/Z4+jUcTfxfgRS2IkubbswzIy84Ln3QufpVM18sMc0iw3LyxozRRNBKgkkA7KlmXAGcZrY8Z7x8D/XR1nmR+yj88fRZM8qntdWmlmmmjLyyyPJIxeMFnY5J7R+FRTTtTYj/F2wTjPHEQPg1esEhhvhh4nf61Wbe1fPHBA3jxRIfqK1xQZM80h0/URkm0nHh2QfoasNperzt5R6qRXopstOP/ZYR+oGjPxjIqccEEP7y1xH4hZi6n3TBhUPSTd2aLWaVUeeWtvIzzwTq0cNxbzRF3BCpIBxxsfRgPjWrFveZI9nmz3gI39VexLLHjDZJ8SiD48IxQTGeQjPkUX+qqWml9M5Tcvh5volxeWMrrPb3fsso7ZW3mfgcDsvgD3H+6upWeJgGDjDDIyCM58QwBrfHg74oz/IQ/sqBjs2zxW0BzzzGu/yqXpXzZNnL3+mW18OsUiK5xtKg2fykA5+vOubmju7KXqrmMo2Dwk7pIp70bkRXpRttNPOztz6Jj4YNVyabokwCy6fbyKDxYcMQDyyBxc6cYtfR2cDpup3mkPxWuZbFmZ57EtjhLc5LRjsreIOx9dx29tq2mXdn7bFcIYMhGJBVkk5GORTurDvB9dxvQej/Rg/5NjU+KSTJ9HqMPRzQLaeS4tkuYGmXq7iNbh3huE5cE8UuVI8KzlpfUbw1XEzkZJFV0OVYZU45jxpkVCKxFvbLbWd28QQFYmkjjmMYJyBhxggchmoxWurrIpm1GK4hGeKMWdvCxONiHTfb0rN6fiNY69vkspEVd1MnlUTFIOYHxFRhLw33IelJqNWlHH4arNS00Wmn0RNKmaVKx0KkedOkaBUKiiiiwoVFFFOwpFveadHeaYrlo7rHUlBPL31BpIo14pHVEHee/0A3rFk1eCNcQ21xMScAgKik+pyflVw07fPRhq62PC7NiYi6srNwLwk8SHBXbGeJttu6sODSNFgDdTbIeNusY8blZHP424TwknbfFae/wBS12aPht9Jjmj2DwyOcknYMWOBgd+BWTFN0hWGKNIbeLgRQFSNSF25DiJrtUopUeY4ybtm7SCyix1dtbpjlwxoCPQ4zVjzrEjyOSqIpZuEFiQNsKq7k+FaUDpG2MzovpHGPotRntOkU0bompPFIVOGUkDPcG4MHHjvV7nhG2bO01GO9E3DFPE0RXK3KBWZWzhhgkdxq9pABzrQ2Gk9IUV2v9XaWRuEKIcqiqMnO++T3+lZp0yf8V7cH+WanckPCJlmZRzrAu0gnk6ySWXIACplSigdygjv76sGmeN1cN6uaR0uDG8sx9WNLKTKqBBbiKJY0DEhM+A4s7b1cl6kjcCxuSfDBpLpNiCCVYkZIyx8qyxbWUcUqvGDGyFXG+WU7cII3ye6mpNCxjIihSReNGVlzjKnI+NRauYvek+h6I3sXX3M0sZKyJbqkrR4P3ZHYquR4DNbPS9a07VojJaTcfDgOrDgljJ5B0Pjvg8vOrWrFuiHpNKzYmsae7hhkMPBczTgAtBZQSTyoDyMnD2Vz5sPSrpevMU4gkWOcxSLBI68SxylSFcjyNcTJp11Hb3cpu2S8t2DXlqRItwpY/v3GGwyHmG8+47VonZFHSS6tJExU6TfhwBkTT2Nu+DyypkY/EUoteckiXSdQAyArQSWM58wyiZfdjnWm6NWmoXV5ZzTXM7WskkcUKm4d0eWWUQEyJxfgBLYPM8PdmsfUjr7319JYCS3tVkKwWzTWNyUEeExIs0pk4jgltjufKsnqJSxLWnxZ1H5d00fvsOrQ92ZtNuCvxh4xTXXujrbHU7eMnuuVntz/wC/GtcbZal0gkuoreZ7fBdvaGe2TMUcal5D9jw5IAOBnckVu9Uu5LOe2gS3SUvbQz3AuJJI+qa4UTpEG4mUlUZeI45nyoc/lhgdFFeadPjqL6xlzyEV1bsT7g+flWSI5MZCMR4gEj41wYutOuM9foaOc7sjW8nw44h9auhXo+GHDa31qwO/s32ZA8uouVHyozoWB24BG1TKMuOIcORntkL/AEsVxs9xdR3dvFY63qFrZmyM7Nqs7xtcytKyGOF5uPAUDchube8aPVrrTtNvptPOmQanfRCL2u6v5Z2t+skQSBYFidXYYI7bPv3ADcp6lK2C022enAJ/nIc+HXRf2qmI2b7uG/VIb+ia8bGuWpEZPRno9hyVx1V+DyVuYuPMVIa5poBL9GNHHC3C3VS6jEfxbj7Y+Bqd5FbLPZOon74pP5jf1ViXzX8FrcSWVqlzdoAY4JZDEH37QB23xyGRnxry1OkGlRl8aJcQlCOI2Wt30J3IGRxK3iKz4Ol1vHgR3vSm0HCGw13a6nEARneO6Rcj30bqFtM7K31nrbiztJLPUBPcKescWN1DDbuFJ4ZTMMY7shiOXPu3GGFcr+eqWVrp813bnUre9Z0tr7TWW1SVoyqvFPbTAlJlyOIZwQwIODmqNV6TXtjcSw32qrYTAqxsNN0+C7ntUYcSpcz3HZ48bkBjjPIchW4nyLB9HZB5B30GQ94rzr88oRnOv9JDjYldP0oD4cVP88of/wBg18Y59bpOkyAZ8RxCnur0NtnoPGTQeBhuPeOdcJH0xTP/AOQgjwvuj8Y382tJc1trDpILksS9hfwoMyvpAuYruAZA45bK9wxTOAWV9s5O3I3IvhhjKPKOhaP9FgfXnVRyDgg5rBl1W4UlYtJuSw77m6tYf/SnWH5VjnUdenBEVrpMQO3FLJe3JXzHVqi5pPTUv8m0deS/0bQmlmoqeJVbnkcxtvRXO41wzrTUlaHmgmlmgmkVQ6KjRQBftk0/CoZ3NSzU0bZB1MUrZccWNgPDxxUxb2cTmQRL1pyOI5JGRjC5OB7hWNc3sNjbS3MrpHHGpYvJsijlk439BzOa02ndJNP1OWSKC5LyDJ4JIzE5UfiUHmPfV6dLs49duUjpAVxnbxpdYvlWvM7Y51AzHxq+X0Z0l2bTrVqQlTJ3/wCRWn64+NMTHffvNOpCygbgzr41A3K1qGuMczUPaU8T/NNFP0Vx+I3HtC0jOu3LmD8N61IuEPJxnzyPrUuuXI7S/Gjn0LXhtesiZkcqpdAwUkbgNzxXP9LtbfS9NPUtw3V0xgtiDuhIy8o/VGw828q2cTgkb7V5x03uZLnV7eAfvcNtGsY33aVizH6D3VE7SLVPo5YAscknckk7kk8zWy0q+l0m9t72EuQjBZk/zsLHtoR4+HmBREvVW8sicXVrhWMZQSzEkKTxOpwozgDGTmo3MKRqsyMSpbgk4gAyP4OF28cHv+mSKPYoJluoYp4nBilRXjYblkYBgfDeq7i1t7kJ1oYSR56ieNuGeEnnwP4HvBBB7xWg6GXpn0s2zklrOZ4RnnwH7RPhkgeldKa6YytHNKNM1cGn6nYyh7JrZ4+tEziI+yyMwKtxdUyvCHyAcqVG3LfFRvdF029u57wWmqWMs8jzyKkVhewq8h4m4CkyvjnjbvrcKM1NTnOCdjg58aT5dsVtGFY2+i6NaFYLOe9vppiZbm8sp4OqgOOxGF4h5DfvJzV9z7NdJayprYsp1tkgnilF3Gh6slYzlRjPDgHbuzWTvTy3ifiah6af0pTa+GkmGgafDLdXV5Bq1wdobW0n9niYj8VzczEYA32AzvsD3YMWo9NLpw8FjpsFpk8EVvpdpwohG3VSX3CzY8eEjzOa6jGTk4yORIBPup43JycmltL0e4/DhtT0vpJeW0EjwXs+qxyHidIoVgkjdiCoVZSgwMEAKBsfHbnrtJ7yK3uJYzFqGkez6fqsTDhf2ZXWO2uGVu5don8MIfx7etjbmM1g32k2d9IlyrC31CNGjjuljSTijYFWhuIn7DxkZDKe486b018COp6eMq0ixRnJykpx48Jj3G/6tWO7j2tVP3LniXyBdh/xV20/QUzM4gmSxIYuVIlu7F9iuIXQe1JzOzo365xvgS9BteXrWjutIl45A2BdyRHhDBtxcxJvt41i4tdmykmcy8hBuwORjhlXIH3vsXOagzbkYGGtg2wGxVGHw2roJOhnSr7bgtLaTKRopi1HTWJCqik468Hu8Kpl6KdKo1kd9OZUWLg42ubELvxg9rrsd9Kh2XaA8c+k3y3BUR2/SjoxdRjA2ec3MUuB4EAZ9B4VqtflZtd6SvIoZhrWoO3F+L/GXHC3yru+h2i3VnDeLcxR8M54mbhWaJZQpjQIxBRuDLEkZGWABODjjdW0jWG1DUma3d7ie6aWaNOHrRI7cTN1eeLhJyVIBBBG/cKcXRKkro0vFGBJlAeGSNz5qcdmpMYQJux92aNifGM/hFZjaJrx6wjSdTIJVMrZXJBxjJBCYoOh9IGMgXR9VJPAABY3ZOBjJ+5U8lWYbG3HWdgnhuFYjPOM/hrddExMNctrmCMM9gt1dkM2EbKdTGjk7cJZlDeRNY69G+kr9c76TewRAqWmv4jZW6KvMvNd8CD413PR3o5bQWkgnBljuGEk8g66IXTpnq+qB4ZBCmSVJALE5xwqM3GLZMpJI2UsCyWiXkWum5tJXMcdxA94qF2XiEZAUkbZxvvv+jgW6jBE2lWE1xPPxvcwCC6hidesV7ZWdgOJD+FWGe/PicZNvYWdoGW2V0RgA8Msk09rIoPFwyQTOUI+BGcgg71kPe6jLCbaex0KS27HDF1dyEXgHCCFzzxtz8qtR1E+eTHKL/4T65bvT7ecyGSV5CQxUKxLRI75A8+0Bn8VYmRRIb+TqeBNMt0hV1jSCG4KLxkcTcLSgE7Ab+FJl4SBnOwOSMfKrcXXJroyVtD2pGo586M1FHSSoqBNFOgMjvNSbZGPlSHM0SbIPMitMTPM4Dp5fSGTT9LiY4Ki5nVT95iSkYPzNcpZvJp89rfR7tBKG4kJ4WA2ZCSMYIyMjxrZ9JWku+keoxqw+zaO1QnOFWOMBuXv+NYJZ2gt45ZDwS2zYUfdyH7BAG23dt31h9Ibs9R6xGjSVTlJESRD+krjiBrGeSU/d2937TWJokjXGi6S7H97heB/9i5QfQVkPKByU/Gt7MEgzN3v9R9KfbPNth7/AKnFY7XD9ygeuTVLyMwAJPMk786kujLLQDm+T6/sFLrLbwHwasHNSBoCjOD25Oc497VPiibADjPiMVrwasDfSgDbQSop6pnAkcMsQPNiRk491eYatcS32r30g4E6uc2sZ4sAKrmJSS3xNdlaTm46QtHniTTrDB57T3EkQPwXb41wMkgjvJ5WUODdzF1PJlLEEfM1E3aKiqLO0sV7C33kcqQMnHBwnHu4ajH1krXKggR+z9riJxxZ4kA8yTgepolb7Rt8kqvE5O0gx2JD6g4alBN1UZcDtB+FM43kYcOT5KucebVmWdP0JuSt5fw52nto5wPFon4D/Sr0BWyQK8v6MP1Wt2Kg4Eq3cDeGDGzD5gV6OrMuDnNax6MpdmyjQnkM4BJ8gOZJrXydIejEMhhfU7cupw/UpNMinwMkSFM+hNcz011ea3t7LT0eRVuoZLiZUbhWXEnVosuNyowxx4+lcZZw6lcoXimhjVXWP7TAySudgFOw76HNLglad8nr8esdHpv3vVbEnweQxH/3QtZ0bQzDMM0Eo8YJopP6DGvIlsNXaPrEv9Lkj4xGDxDtk8WCoMYJzwt8KkbLWI24SdLMgTrGUSMrqoj67tYxjs774pbiHtHrrRuv3lYeoIqNeURan0htWVYLhxgr/wBU1CQL2l4hhXJG/pXT6RqfSy7WznmuY/Y5AsjG6S3nkeI74QxKGBPiTt4GqU0S9No7E8sjbcAnwB76kECsvaOGbBDEnuzmqRd2UcUck9xbwrIzopnkSMMygEgcZHLI+NNL7SMjgvtPzyBF1AdvLLVZnyReWQsdyoH3Ry2861+r6pd6daRzQrG8jzLH9sCyheB3OwI328a3a3tjjKXVkxA7P+MQf2q0PS0QS6XE8JhMi3cRbqXRyA0cinZCTjJFPTVzSfVg3S6KNN1u81IgTrp9u8lw9vAqW0pibqoBcOXZ5sg4yR6VsbWe7uobe5tzYmOdFkiLWtwjlWJxkCY8+6ud0e2sZwVlKR2q3k8hFxNHHLgwQhSoY5wSCD5E1ubBprY6XG09qIYIUWVFuLcrhRui4bHFnatf5aUNeUYdLoejctNOXYJ0jZk4yV3EXUrJZaisk4kl9nXqFDMW7XZ8qsl1Iz2cl7cxac9nCH4zcLdq0ZWXqSnVSxM/FxdkDGcmtVFa38o0xChtvZFt4TMLq0ZwWvXuTPEEc46sEHfvFZMtrI+l6XA9nO62+oRTahbWNwntEwhMpM0MhlyeJysmeMHfyrkUmzVwiui6SawgnitZrDTo5pWjSMAzpGzycRVTL7L1QOxOC4O1EF/o88NzcwW2nvBbKWuZY7lQkShePL9ZCpx4HG/dmsRU1hm0GO7tNQlmsUiknlzFPaTwywSG56zO3XjsxqQDzO/aNYs0eq3NjeXEOmzi5eSCe8s54JbeKKCyt2NnZ24kU9YqMAXwBxEY2BqshYnQI1s/aW2hVo2KjsqShGG2bh8x4Vmo4deLvOc5Od/fWJaRSNFNJcL1cz3DGRDvwSMqcQJ276zEi6sHtZyd9sAVasylQiKjircAlB+kwX3mtVLr2kR54TczAErxRQ8MeQcYEkxUVbddkpN9GwxVE4IKnB7wK08nSu1BxHBbqPG4voRv5rH/AF1Kz1yPUXaBjZmRQZI/ZJePYcw4LE+hqck+DXTUoysz6RpE1EtRR02SzRVZaiigszwRk0SkYQZGSTjPiBmoA71G6BaEEc45Ef3bg/WtJdcGEZcnkmrOw13V5u1wLf3Cs4BwCxIGT/zyrEQyTNChJEcfDyGeFQ/3VUbkk4AH/I2mpJKL/pH1cdzh72VDJCvWRNxHi6uaM/EHu+mLaWVx7JqF5wNGbaKLgLpJly8oVmjGMjCnmRiuM2Ow6KMZNHuEP8DfTrjyZUk/aa3Atus78bZ+Nc50MlJi1iHiwFnt5lAxjtoyHn6Ct/JNPE3Y4cDOCVJyPMitjGnZZ+S+L+EoGj8R3l5eArFOp3q8lh28Uf8Arqs61qCkYSAZ/wDDkOfnSbRol6bAaID/AA5/m/30xoS/6Qf5v99a38vap/m7f/dS/wBqpDpBqg/gbf8A3Uv9qpyHSNl+Qh/pLfzP76kuhpkcV0wXmx4Rso3J51rR0g1T/MW/+6m/tU21rUJY5Y5IYgskbxPwJMrcLqUOCGyDgmiwpGl6LP19zrl7zFzfRCMnnwozPj4MtcjNHD7ReCaR0VJbjHBHx5brSuDuPrXeWFtBYqkdtB1UYk6wqCzZY4BJLEnuHfXJTo0WpayhaSI9dOylcAlWlLrlWBGDkVNAuzVoquxWJ5GCglCYyCDgnkpPPlzrPuNLtbe20m5urpoWvopZGVIesMZV+ECRCykZGCOec1BWbKiSWabJUSordXGHIyY8LjJ8eQFTu7q+gMBWQCVxi4YJGftlOOySDtjAGMDap+DHordXq2kOOXtyJ/Pyv7a9NUnNeVWcnVXdjISAI722fP6soOc16iXwT5E1cSJHD9OXJ1e1j7o9NtAP5ZeQ/WufjnukK9XPKmDwDgJU45+Qr0HVujA1+6jvYtRhtpVt4beSGeMtxGLIDq3EBgjGR5eda/8Aweatj7K/s3Ayd0lwfduKjFsaklwcr7Xf5dTeTAFxKQ8jDL79oBcjO5x61Yb/AFUN1pv7vrJFaORpXIDoU4CrNk5BG2COVdKOgHSJOLFxZdodz3EY8PuiMiqz0D6Qpw8L6fkd6STRsdu8mM/SjF+Dzj6c5He6nEHaK6lAbh42UKy9gdntEd3pXadE7gz6Y8TEF7S5liOCGykh61Tkd27D3VrouguuPJieeyiVjkyKZZpV9BwqCffXa6N0e0/SYZY4hJJJOVa4mmILyMoIGAuAAMnAx38zVRhIiU4+mu1fTfytpt5YKoNwSt1YZ/0qJThAf/EBK+vD4V5OUIJBGGBIIYYIIOMEV7y+ms+TAWDDcZzz8iNxXMar0V0jULyWeedtM1CY8U6kolvcSd8qFxwhm5sMjffvxRKLCE0eW8PiMfL50xldwSPMZHzr0L/BxcOcw6gXHcVihl+ccn7Ki/7murgdi6YnzsnP9Fz9KnBlZo4ANJj77eA3b68qksjDLO8h3AwHb37iu1f9znXlziZSf41tcr9AR8qx26AdIRxDrLYgjfKzoc+WUxRi/Azj6ctLelwAlvBCQc8ULT8R/nyEVWk9zviWUbE9lm7vSumfoF0iXk1qf5cg+qVWOhnSOPP2dqdmX9/xz8crQoNfBuafbOfF5fr925nH+0Yftqwanq6fdvbpSOWJXH7a3J6IdINx7PbcuftCfLaoHoh0k3It4ef+kRftoxl4LKJjQ9KOlNtGsUGq3SRqThQVIyTkncc6vXpp0xX/ACpKf1o4W+qUfmj0k/0aH3XEP9dbTSOht8LmOa+ERWJgyQRMZC7g7cZAxgeHfTUZCcoHTaHf6/PCs2p3RkKwmZkEUcfCx2QEoAc7/KuP9q6K3E07XcVwGM3G5SNnQh5S0rgBhjOdsDbz4jw9/Np922n30Fpwe0mCYZY4USsjKiFuW2d9+Z8q8jlhltpHguEMM0ZKPHJlWVhtjH3v2U5JrsUGn0Zt+ugi2n9k4Gn9pHUSIJYw1qM5Z45c4Y7bBjjB3q7ovwN0ksTCGWLiu2UHnwdRJsa08mCuMjskkjbbccwNh7q3vQqPj1xW/wA1aXUnplRH+2pj2jR9HpBFVkc+dWNVZrtMrIGikaKAM4HerhggqdwRg1ig7mrlY0WYnmOqyTWuoa3bB+Afla54mSQCR8YIRCNwBzZvd64zzR2tvCSJOuuAerkikKSQCMPwAA5yrcTcQO58dqyelSCLW9dbGGNxHcIcblZokf4f11rNQZQCp5xmBEH6IEQJrmdJujpXKNv0Qn4L2/iOwmtAwHiYpAP2130Wp6DCgFysnGB28QceT8a8ft7u6spUntpDHKqsvEAD2XGCCGBFZEmt6zJ9+5+EcQ+i1GY8T1dte6Hj7yye+zH9qqG13oRvmN//ACX/APVefaFaarr93NbLe9QsVu87ytEHAwyqFwuNyT4/St8/QXVTnGtQnn96GVfoTWilJ8pENRXDZv21voIeccvutGH0eoflfoEfwzj0t5R9HrmJeg3SQZ6u+sZB5yzIT7jHj51jHoV0s/1Y+Yu1/bQ5T8Co+nYflHoI3Jrgf7Kcf8VP2noa33Jrkf7KX9tc7B0A1Nh/jOrW8Z22hSab5twVd/g8l/77/wDiN/8AdSqXgXH020z6Z2TaSu24zxrw4HvrjNbJTV7krj7SCNgTyUmMHib0xmt9/g7f/vz/AOG3/wB1anXei0ugW1peG9F5FLc9RKDAYjGeAsucu2eLtfDzpNS8KUo/DS28qcaHfhU8MYPeBvk+ZOSfQVKRkkW4JBwrkHAyVdSTGx8iCVPoKxiBHLGvMcYIPiCP76JQysxJwZuFsZ/DjOTUWURP73nJ8u7eu5g6RaW9tBJNdIkrRqZU7XEsmMMMAeNcQQOFV8T4D1rHIPMciSBUKQ6O+/OjRU/h5D+rE5+tH53aOvJrj3Q/1mvP96eCcnuHOnYHoB6aWCbI95/IXA+bil+fag4SW+Hmx2+HEa8/pgEnApBS8O5fp9fj97ln/lxQN9aobp/rx+7O6j+JFbxn4hc1qdJ6M6rrEM09t7MscUvUs08xTL8IfChUY7ZGfWtovQHWiO1c6eD4iWdh8OqFWoyfRLxXZiy9Mtbmzxz3T57nuH4fguBWDJ0i1KQFeGLB/S4m+prep+5/qGftdQs1HfwJM5+YWrD+57L+HVof5Vs6/RzQ9OXgKcV0ckdTvichlH6ox+2pDWNVX7t1Mv6skg+hrqD+59d741S1PrFMPpmqz+5/qn4dQsD69eP+Cjbl4GcTQL0g6QJ9zUr1f1bmcfR6tXpR0qT7usakPS7uP2vWyk6Ca+meCbT5R3cE7qT/ALxAPnWP+ZfSfOPZ7cDx9qt8f0qMZBcSodMOmK4xreo++4c/WrB016ZD/LF4f1nU/VauToP0gZgGaxjB5s1yGA9yKT8quToHrBdBJeaasZOGdJJnYDxCGMZ+NGMhXExh046Yjnqk59RCfqlWjp50t2zfOfWO3/8ArrUavo13pF49pIRKOFZYZoQSksTZww7wdiCO6sEW1024hk/mmk20PFHUr086Sfju29eotW/4BWVH02v5Bie/nwRuoSOJT5ExLn51x3sl4f4GT4UeyXmCepf4Urfo8V4ekWnTmONUjaC2eNRgCMmN/E7gkfKsw670S1F1e5tJUmAxxdVbzj0ySD8q8q9lu+XUyfzTVgtdQQZEcwA3PDn9lNTkuLJenF8nqJ/NB/uWrsM8X/VrVBnx3zWRYxaQnXSWFgkGfs2l4Yg74OSg6tQMcs/3Vz+idHj7Lb3GpXN+s0qljaCcxqiZ7PWEdvJHMZHP4dQvUxIkcYVY0AVVGwAFbwTfMjOVLok1Vnvpl0/SHxqtpIwCeIVtaI5A0VX1sbcmFFFoq2Av7ME/bD61Manp4P78Pga4gX0BKqocDfw2q1b6MkqAcb45Vx77N9mJna9aW2pajb3kLRSxPbpBdRu7xktGx4WUgeGPhWiuej+oXEzyK9sqlVx9o7MxAAy21bFb5e9W25H+6pnUlXh7LEgE7nnWctRvstRSNK3RnUsA9bbnPPtNz+FSXovfE4M8A/nGtwuq9nePJzjnVo1NcY6s59aWQ8TM6M29tocV4JX6y6unTiZBhVijB4VGd85JJ91b5tYt1xlWx3muS/KaceerJbkN6rbUOLsmPYHPOrWq0qRL0k3bOyTWbYOCyOV78c6rOtQLsUY7ZON65H8oyHYIoFV/lCUAJwjJzk0b0rDaidf+Xojyhby3qJ11Rw/ZfPauPW7lyQB7qDduykFQAKN6XobUTrj0gbIxDsfOsPU9Sh1O0uLCaHsSmNwVO6SRtxKwPy95rnva3CjYedQ9rkySAMfOk9WT+jWnFF40nTQOAKCcDBbtMmDxdlic4pHRdLYl2DE/iJJ5+41St1Jk42zzqz2mTGAAAPnWeReKLY9O0s5DQgjcAkb4NP8AI2k8S4ixgEDGe/v51ULl+yNvGrvbJF4eyN6VjosTRdFVQWgDd/a3+tOPTtHUuqWybnJyo93OqWu5mB29KrjuZQWPeadhRk/knSeIt7PHtvjhXn8KgLDTlfsQoABjko25+FQFy+Tk86g0zc6VhRt7W8a0jFtahVjDM7Bdsu25Jq59Tu1GeLu8TWgindCxxzptduc5GcVebXFk4o3ialevzbn61I3t3nBf61pFvnUABamL5ycEb0bj9DFG49tuuXGfnS9tus7OfnWp9skPIVIXcgByMUZsMV4bNry6UcXGfTNL267YDtfWtT7W5ODyqS3TLkYozfoYozDf3fGQWOO7nUXvrnGesrAa5LE7VS85xjB86M2KkZ7Se18DS4bq8hCRuAd8UBIRnsrtWDHOyKQAd6l7SxG9LKx0jMAjycIvwpKqcRyi/CsQXDY78VJbv/nFFhRkukfEuEFWIEBUhF2II9RvWKLsE+7wpe1gE4FFoOTbe1TfpGoPdz9zVrDe4Bqs3wqs2TijZG6n/Sqt7qYjBasA3qgcqqN6rUZMeKNgLmZRsxx60VrvakwMmijJhSNfGT97Y4zmr0YAKxBAYZz41jqBw+Hmd/dVzbLGMjkNzyrMokZMgEd55d9TQ8RJO+21RBBBGFOO/GN6iMqy42G+aAJNsOIHAB3HfmroyD2t8nlnwqhhkc9thU0Zc75wNqQFrbEhcHvNJGTDjBye+oEjI4e8ULnfGNhQMBse/wAaizlO2FyQcVNW7Ryc7VBiO15HfNAEo2ZiW+VJmABzUl+6x5Z8KrcjYAZJoGWHhJUZ2xUZCFB8BSQ4yT3cqHOcbdmgCUbBgCOffVrHsZA3NUggEYxVgbtAeVIYix2wO6rFcMo8RtVLbnPfTyQq4233piLmbYeVQzg+oqLvtjvqpnYUDLyxAHD96meLgHFzqhXBwc71az5UZoETHKoleHfxqIbbyqfECMbYFACzxZxTA3z4VAMA21Mty250AXIy53oklBO3IVQxC1HuyaALVk7Qq1mGCcd1Yy4zS61uJhQImpJJJpkqSRVbMRy9aSEsaALQTgg1HuNMkYqGV3zQImrDGKrzucGq2OG51b2eHNAEFL8RPdVoPPNIFQpPfVbPzoAbNmq2oA86TYHfTAiWwKpBHFUnOTUQopgWNk4xRRxgACigRMoULLkEgkHwODjamzA8Gw3wKKKQyW+ffiiQ4GfEGiikBFZCQqjY4zmognfJPabeiigZbxcOBzz41YrbnbuoooAQzxc9qWAC+d8miikMASUbfkagc7HvNFFAEgDv50OCFHrRRQA+EbHvxUhniB8qKKAIAHtb+NS36sZ8aKKAIsM7+GBSG6tRRQAsAY86swcL60UUAMjYjuqCsQSPI0UUwJc/fTLEY5UUUCE6kkZPnTxgUUUAR4ip9c1Uc8WfHeiigBgnJHkati5H1oooAG2FVEmiigRFuVTQnh91FFAApO4qtsj40UUASyaTCiimBQ33qkP2UUUARJooopiP/9k=";?>  <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
   <div class="one m-2 py-5">
<?php $v= "Mercedes Benz E Class
";
    $p="The Mercedes-Benz E-Class is a range of executive cars<br>
	manufactured by German automaker Mercedes-Benz in various <br>
	engine and body configurations. "
	;$i="https://th.bing.com/th/id/OIP.gg7OmQGWrwCmx-Xl-3NX9wHaEK?w=307&h=180&c=7&o=5&dpr=1.25&pid=1.7";?>  <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sedaninfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
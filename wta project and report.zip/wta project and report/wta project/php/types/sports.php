<?php
session_start();

$_SESSION;
include("../login/connection.php");
include("../login/functions.php");

$type="";
$v;
$p;
$i;
?>
<!DOCTYPE html>
<html lang="en">
<head>

<!-- Repeated code -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title> a4Automative </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<style>
#he1{
	color:red;
}
#hel:hover{
	color:blue;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

* {
	margin:0;
	padding:0;
	box-sizing:border-box;
}
body {
	font-family: 'Poppins',sans-serif;
}
h1 {
	font-size:2.5rem;
	font-weight:700;
}
h2 {
	font-size:1.8rem;
	font-weight:600;
	
}
h3 {
	font-size:1.4rem;
	font-weight:800;
	color:#ce93d8;
}
h4 {
	font-size:1.1rem;
font-weight:600;
}
h5 {
	font-size:1.0rem;
	font-weight:400;
	color:#1d1d1d;
}
h6 {
	color:#D8D8D8
}

button {
	font-size0.8rem;
	font-weight:700;
	outline:none;
	border:none;
	background-color:#1d1d1d;
	color:aliceblue;
	padding:13px 30px;
	cursor:pointer;
	text-transform:uppercase;
	transition: 0.3s ease;

}
button:hover {
		background-color:#3a3833;
}

.navbar{
	
	font-size:16px;
	top:0;
	left:0;
}
@media only screen and (max-width:991px) {
	body>nav>section>div>button:hover,
	body>nav>section>div>button:focus {
		background-color:#fb774b;
	}
}
	
	
.navbar-light .navbar-nav .nav-link  {
padding: 0 20px;
color:black;
transition: 0.3s ease;

}


.navbar-light .navbar-nav .nav-link:hover,
.navbar-light .navbar-nav .nav-link.active,
.navbar i:hover,.navbar.active   {
color:blue;
}

.navbar {
	font-size:1.2rem;
	padding: 0 7px;
	cursor:pointer;
	font-weight:500;
	transition:0.3s ease;
	
}


 body {
 background-image:url("https://cdn.hipwallpaper.com/m/56/10/d5qDRv.jpg");
 color:coral;
width:100%;
height:100px;
background-size:cover;
background-position:top  center;
flex-direction: column;
justify-content:center;
align-items: flex-center;
}

 

img .one #new {
	width:100%;
	height:100%;
	background-position:center center;
	background-repeat:no-repeat;
	background-size:cover;
	position:relative;
}



#new .one .details{
	
	position:absolute;
	width:100%;
	height:100%;
	top:0;
	height:0;
	transition:0.3s ease;
}

 .one:hover{
	cursor:pointer;
	background-color:#d1c4e9;
	transform:translateY(-70px);
		transition:0.3s ease;

}
</style>

</head>


<body>
<!-- NAVIGATION-->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 ">
  <div class="container">
<img width="400" height="120" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" alt="logo"/>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
      

	  <?php


	  if( isset($_SESSION["id"]) ){
 echo  '  <li class="nav-item">  Welcome, ' .$_SESSION["name"]. " </li>  ";
	  }
	  else{

		 echo'  <li class="nav-item"><a class="nav-link" href="../login/login.php">LogIn</a>   </li> ';
	  }
	   ?>
	   
	   	     <li class="nav-item">
  <a class="nav-link" href="../../index.php">Back</a>   
	   </li>
	 
    </div>
  </div>
  	<br><center><h2>sports Cars</h2></center>

</nav>
<!----------------------------------------------------------------------------------------- -->



<!-- types of cars -->
<section  id="new" class="container">

    <div class="row m-3 py-5">


<!-- copy this for next iteration -->
<div class="one m-2 py-5">
<?php $v= "
Nissan GT-R
";
    $p="
The Nissan GT-R or ‘Godzilla’ as it is<br>
famously called is currently in its sixth <br>
generation model. 
"	
	;$i="https://th.bing.com/th/id/OIP.ZuSVxqvJTJ7M-6BciRoQqgHaE7?w=231&h=180&c=7&o=5&dpr=1.25&pid=1.7
"	
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>  
  <div class="one m-2 py-5">
<?php $v= "
Lamborghini Huracan
";
    $p="
The Lamborghini Huracán is the perfect fusion<br>
of technology and design. With its crisp<br>
streamlined lines, designed to cut through <br>
the air and tame the road.
"	
	;$i="https://th.bing.com/th/id/OIP._a0x0qr2yM6H_NRJRH7nHAHaE8?w=254&h=180&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>


 <div class="one m-2 py-5">
<?php $v= "
Ferrari 488
";
    $p="
The Ferrari 488 Pista is powered by<br>
 the most powerful V8 engine in the<br>
 Maranello marque’s history and is<br>
 the company’s special series sports<br>
 car with the highest level yet of<br>
 technological transfer from racing.<br> 

"	
	;$i="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADhAWUDASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAAAwABAgQFBgf/xABTEAACAQIEAwQGBQkCCQoHAAABAhEAAwQSITEFQVETImFxBjKBkaGxFCNCUsEVM2Jyc4Ky0fBD4RYkNER0kpWz8QclU1Zjg6LCxNQ2RlRVtMPT/8QAGgEBAQEBAQEBAAAAAAAAAAAAAAECAwQFBv/EADURAAICAQMCAwYEBQUBAAAAAAABAhEDBBIhMUEFE1EiYXGBkcFCodHhBhQjUvAVJDIzcrH/2gAMAwEAAhEDEQA/ANpECZSxJB5cqOLzW0AVu6Dsd486pi87IFB72oobXXiC01s5WW3ukkOOW1Ru4u9cCh2By7aARVLtDEA06ksQKFtmpg8Q+ZRO5EV0VhzdTKd4g1zOGQjK0bbDqRWzgzdDTrB86xI2uhbe04JPSq9wErJnpWi8wCN450ABi0ZQRPSKIMzHWOp8KhlJ3mtR7YLZTp+kV/EUK7h2A9bbpW0ZM4kDQTQjBOxNXigUklwI60J2tiRPuFCFdHZSJBgeOtWkxDzqTyIIifdVYkEwB76QVp02qg1Evm4QpJnfSI86th1gBmiOm9Y4LA8o2EaGKmt11YMhIbaDrWWio2FdG2dZnrqffTPfKTCO0b5SJ84rKa/dMS50k7RPuqxhcRbzA3GJbYGRAqUasMcTjGYMva5Ig6KeflV9e+gmQxUHXeoIAYa04Pnr8am2cCRlidt4qFGyQee8edOy6QWYecCo5mY6EFgdzED8aIYbKTB0g770BSeQTv51We2GOh138K0yts6xNVykloEeyqiMzbisvOhq7jcx5CtG5bIHeAqq1sb6VUzLRFWzEAsZ8qKrkaFviKqsSmxmfhTq5nUA1QXSxK+t7abPoRoTyNARjqc3sFEiQSI60BNbpEidxqTQ9SxidOdMJEmKcXFHhSgFXxNFBA5mgC4nUU/aHlrUaFlkXDyJqJZutV2e7ygeNQljMk+yrQsO9yPt0Jrx5MfYKGBPL31IqYqkBvefr76rtcc8yTRipJM0Nsq+dCDB16XPaV29gqSsg+97xQSzcpphmJqkLDOhEd73jWoQI+3E8itRAPSiyABVBDvaxMTpJ1pUQBSJpUByIdgTM1LNPI1ojh8xmbz029opzgrEAKWJ5+dYsqRQRC0QKvWMKTEg+yKsWcCUIOwnnWth7eWAQp9grLZtIjhMMQoUJ0gncVoolu2Nd/GmUkaAAeVIrzJJrBomzzIGmmlBFyM0kk+G1EAXfxoTW7c6FiTvMRWkRkWv90GNeYnegm+pmQYnkTtRDa0bRTHSKELak+rHma1ZkG+VpyyJ5RNVmtvMa+6tZLUesilTsVImim3YKyAJB6a+2lk2mKtht4Pup+zuidD7K2BbnUBVAMa6E1Xu2rk67eFLLVGeCRoZpwDvrVnsAT40RcOeYHtq2CqCQIIB8/50oSZyir6YWeQmmfChd9DUsUQw+K7OVgBfAVY+nIepFVTZA2NQazzoUvrjLBI3HnNGGItHSTqdxWPlbwqYdl0NBZti5bgad3rNDzoTAJ35Vn27gICnMPEa1cQbRMRppBrJoe4hffXyqpctRO9X84G6+W/4Uw7F95mOdAZDW1EyKCQeQgVtNh0OoAjxqncsQTWrM0UhI560QFjsPdUjaPSpLbI2mqZIZbh5mmNtvGr1tHO4Ht0qZtgaMB7KWDPVT/QooyjmfZVs27Y/u50JrU/YgUsAiQesU9SCKNINS7M9KoBga0UKDvSFsDWanloATWp22qrcsgbAxWiFIpiisNRUsGTETTTV65ZGsLVZrDSaWQFMc6jm+dGNhoEEdKh2NwRpVBIHTelUlQKIYCfbSpYKtjB3m1ZnA8SasDCrbIIljz5+6ii5eG4BHhSzsetcjoMDdG1rT31IHEkQtqBymBTg3DsTTjPznxmapSSLi47zIPnRVzKdbk9elETsynOagQJ0HvoRslmneI6UxKiQFifhTgkRpPgamAW1CChOoJVcmIU7dQan2IY94beMmpZ3EjKB76gcx1nWqEP2dtRorztoRT9oRyI8x/KkCwB1Hkd/hU1K/aUH20opAywkFZ59dfPSkMO5g9pvy0/Cjqoie7tymm7s65iR0MCoAAtsJ7oOsVKCPsecVYGoJCqJj1m1pEv0geBFAV88aQwPlUgmcSc3vone21pxPP5UFgDhnOytHXSonC3QPV+Iq2Cu3TwqWZfGhTLfD3BuseVC7N9stbfdO8RTZbM7D3UJRir3TqCKs23cxG3jV42LDeHspCzaWNZj2UCAhLzCYgcyT/Kl2baSrDUag71ZBtidD+FIsDyj2UKVGt3eRaCdgf5UhabofbVgl+pHlTy/U0IV+zj7FIWZMAAHfWrEtGoHgSR8YpERuNTzUzQFfs3XdpHSKlOX7tFAXUAk9c1MVUHVR+Pwq2SgWYH+4VHsw3M+2aISJ0HvNRJPl5TQhDJGwpoM6jTz1ogMeNS0bl7qoBhV6VKB4eFSgDlTQDQEfrOQBqBa5OqGjADrSYRsagAFkO41qBysCAINGJboD5ilPl7qgK3YvqRFBudqsiB7qv51HKmJRt09tWwZmS6ZME0q01IAgKN6VWxRVCGIa2A3PKakAF+zrRo8KlE8qyVlciTIEUxzcifbVjJ4CnyD7o91AAQ3NINFEndR8ZqYWJ7op4Y70KRGUb5vbUxBiNPbUSoO4NOEH/GaAdlG+pPOmKkch4VNcq8yPLalKknT3GrZGDy1MBfuj20+g1O1IMhOjD30siJB4EBQPEVCib/d9lNlqFI040NTCjmCafu8ln20FECzHmaXeqWUdDUhl+6aFohrU1E/308+A9tPPs8qFFC8xSAUdffTamlQDwOlKPL3UhNKTQEWnpTa1OT0pT+jQgPXrTy0esanoeRpgB0nzoKYOlRYXp7qjHQUJREGDNJsra5TTxTgRyFADIEbU0eFTJFLTxq2Qjl8KcAipCP+NMQTzPsgUstDae2o6dfdT5fGKePOoKIExsD8KizE8qLHhTZB0NBQPXwpALzBmp5B40+UeNCA8gpjAIGpnoKNApR50NUDUabDfnSqXYoZOvvpUKBi6Dtp4VMBuYpzEoNe+zINNJUE60iRlzAgrkLzPKNPfsKEF7DUopCdJDCVzQQfAbjTnUgOooUjFPFSil7KAjFOFHSnkjlUZNCDwNopgq67CdKaDM0okn8KFA3UAMLOU+Mj3ULIelXMi+fWl2euwiqSiqAwj8KMlxxpuOhowtrrpJpdn+iI86ESEGnca1Pao5Y229tOVncH31DQ9Khd6RMadan6wAIMj1daAlS051Xv4vB4RZxF+3b5hZlz+6NaxMX6U4O3mGHslyPtXTA9wqqLZLOizLUq8+xHpbj2Jy30tDpaRB8SCazbnpNxJj/leIP74UfAV08tltHqdLTcx7xXkp9IOJn/ADy8P3p+dST0h4kpk3hcPLtUUgewRTy2X2fU9XlfvL7xT+7315UfSXih9a4pHRC1se5DFW8JxfGYssE7bMr5PXLBjEnKfDnWJR2qz04cCzS2xlyelCDtrSri7WIxvZm72vcBKtd7RLdgMN1F66wUkfohqmvFryeriyfFGxbj3rh4rCd9EXJp4wdOaOxqJaAYE1yy+kF5IzX7UHftg6/G4iVa/LOJxNi+mFGH+ktbYWbyAYu3bb772bLyQOkj4UOTxP8AC0zZa45ME8thpQzmMan2mvP8Rj/+VA9rcwPE+EY6yv8A9vw2Ga8P1rN0aHwzUHg/pX6bC7xC1jcFjeJXbfY/Vpwi9bfCzmBzCxkENy39WtI5ShJdUei5SY60e2pIDEtI5E6Vxf8AhR6Tf9WOJf7Mxv8A/aq7em/FkxaYBuC4kY507VMJ9AxZxDWwCc/Zi/MaVaMpHoBUTPXnS01riP8ACv0n3Ho3xP8A2Ti/xxFP/hV6Tz/8OcS8zwjFn/1NSinbRSgVxX+FXpRy9H+I/wCxsWf/AFQoB9NuMDFJgDwrEfTnTtFwo4Xf+kFIzZ8n0uYjWlA7zKKaBXG/4T+lP/V7iX+x7/8A7ypD0l9KD/8AL/EP9kXv/eVAdhA1paeflXmnEfTfjy4l8OLK4YWZS9bNp8PfNyAe+DcciOQDc6fh3pPxHHYuzhbtzFJ2q3Cj28Zf9ZBmykGNxPOpYPSSY5c6aZ5GqnDLt65gMEzu1xyrBnuHM7AOwBJPOKtm5bVWdmUIoLFpkZRrIiqCazHPelTdrbUCTE6iZ1FKgMUr6QWh9XxPBXSCqAYlTq7a6wCZ6Cn7T0kEi5h+FXlDQBavOjFV11mFnwquq8PRCqri1XtM+UdvAeI0nC+VPlwcBpx2ZszaI5gvE7YYVbMlJ14zc4xhMcqYlB22HbF4bDY+xetm1bXKwWyrBidAdq30xeHtvcJwuNtlm7Rs2Fu96F27pOu9UUw2EvPmP04FUyhltlSNMuh7EHarVu1aWAt/HCTzkxO32eXKnAQ54phFBnEWkMCPpNnEWdYPrSI1o9nH4S6FIxeAZoGYWsQp18A0GoMDJ/xvFARA7isFjp3Y1ody0jMuYm6pXvB8JZb/AMRWoWwv09hir2GbB4lrSJ2n0qyq3LBkKQog5p1+FXRlYKwGjAETvBrHvYG1aVr9jDJ2iEMttLQR2I00Nojery4i8iqoUMFhR9TeB3jfaloFrKKaKCMRekZrWhEyA4j30TthoDbPzqWUnFKKh2yyRDeZG9SDzyPwqgfUUpao5zyUn286bOfun4UBOaWb41n8Q4nY4els3Ldy7cu5uztWiq91IzXLjuQqqNBPwNcpxP01ZUNvBrbtMZD3VYufJCwHyrag5dA+FZ1+Mx+AwCl8VeVWiRbEG43kK5TiPpdeYMmHIw1oyAZm6/kd/cK5PteKcQY3WZlRySb18klvFFOpqrxAW7HY4Sz9bjMRlN27fYDJbB0BJ0UHc+Hnr1WNIzdlu9xTEYq72drNcuXCYLH3sx6DmaN2dq0FuX7oYyO9cHdzfoL8tDVTDImFs3WsfWNkd7+LuW3CXMqlosJAJXpqB50Hh/Ebd5sTdxAsoyhBbe7dAc5g0qCxjp6qiupn4mnN67oFyJ966qlyP0bcQPaT5UG4OE2Stq+bK3LgzfWTmYTlDMVGlFHEeFJE3mdo1Wzbd9emYgD41jcRuWsXiTfsi6qG3bSLoUEZBGmUms7kaoFjHw30hkwg+qTullZmFx+ZXMduQoQLHnSCRpFOSViB3m0UH3knwFYcixhKUlGPLYa2ly4621JzNEwJYAmBE8zsPfXXcLw9i1h+1vKDgwWsoisQcfdTRrasO92CHS432zp6o72Bw3BYi6MQbFtrj2rK37xUhWSzcuCxnB6sSQOgBPIV0BtXbhth7bZURbKBJCoiaBEUGAByH4muMf6r56H1dQlocfkR/wCb6v09xpHGK4S7cUXGH1ahgFtWVUd1LaKui9ADSXForICLIDqQrAHRl1IObqPlWPiMTwLBi5h8ViriYgMrhLUXHXSIeDA9poC4/wBHri/V4y92iMrJ2sDMQRKyoI2mu/so+dDBmnzGLZ03a2mMFkIGxXu70uw4fe/OW7Jbk5VTcU8mVozAjrNVbeCW4iuDcFpgGR5RgyxIIiTQymDtTnvsm+lxkU6dJ1qtJnBprqjXwnCsDjyEv4fDtftswa8Fe3fKrKtku2iryDB1bZhWZh8VifylxHhuFxWOw2MwONGEt2OMZb6X1uLduWLlvE2MtwC4EaAc8aaHNIlhOI4TCteVFvYpLogouZVcujWXQ3G5EZDIB9Txq3iLvFuI/R3xhscOwllxcsF2KZWVGTMLzQ5YAkfZ32M6eeSVntx4s3D6X6/oEt8d4nYv3MJjsGy37aB2IZL1lhMQt+yR3v0WtqfDmcyzdtWvSniHpHcMpiOH2uH2sOsZ7QUW5fOdNSDpHOoXuO+h/ClKWzc4lfWYFpQtgN5mFj31z/EPT/GA5LHDsFaSe6oDOwHi0gfCuDmrpM+yvD5LG8uTHwu79n8uX+R6bZ4vwy9l+vFssQB2wyiTyz6r8avxt47HkfKvE19O+IgENgcI3KMpre4J6U8YxqlrOETCYdNnVnNu43RUJAyjrp0rqkfM/llkntxdf89x6a727YDOyqCQoLExJ5aa1weFx2CX/lF4hfuXAFx/DFw2Be6pt5rqLaUoguRqcjAdYq6ePYgjLfx6DrkyiPAdiPxp0x3Bb7g4h7F5tBmuly4EzoXk1ltHo/0vLGNy/I6x7txQv1L6mD3kUKPvEs1C+mWR3Wu4e3OkPiLWaSuwAY89KyL2F4NirYuWMStrEbj6UDcU6bMHBpW1vWMua3w42j/nGHtJ3ND66rOnjFTcu54npZq2vp0ZyPp5gsP9Kw3FsLes3BiQmGxq27iMy30XuOQD9oaHxXxrm+DXez4pwtiYAvlT0AZGBr0/i3D34rgMTgXxuFtW75tMrLYLZHt3O0VtIJ6b865zDeh1vC37d1+LWbvZkjKMNdSZGUmddY2qtHks6XAcQu28HhLVvhmPxGVCwuIoFtw7HW2TvVr6XxpgBZ4Tat6ZQLzggKNvVYaUGMULaWlxS5Oy7FAq4jugDwT2UrlrG3c6jHG2r21TKlnEtmgQSZT8a2QHeu8Zd/8AGBwi1cUBcly4gcDfUM80qA2AYEtcxjOX1l8LiS2gAglqVOCWX1fHZdMOgfcl79kDyhS1EBxsDuYWSZebr9fslUNVe2I58533npUjfXqCTpvsa57EWy2rY0k5jg1WIGTtmO/jAoilhvdWOWVGn2yYrPN/xidoO5pvpOwnn111q7ULNE6lT29xY5KqgHzBpwUETcuNG0lR8hWZ9IJjcdevhUDiWBjMQRvJgdatIWa5exzZ/wDXI38RTNfw6KWbKqrqz3GIVfMkxXNY7jWFwogsjPIgsxKA9IWWJ8B7xy5vE8exN5j2WmWWFy6ELJ4ohm2vxPjXVYu8uEerBp55n7K4O/fivD7Sdo7WrVr7Ny/KK/7JT3288sedZl/0q4faDdhau3yN3bJh7XvaW+VcCbmOxlu9ibToQAS+OxzuMIsGDN1puOfBVNZ2LPB7Xexx4txO4P8ApEu8N4YCdQEGXtj/AOGii5K4nvlg0undZHvl6dF+p21702uM62reI4dYZjlVbStiLs+zMf8Aw1dTifGXTtL+OxNm3E9piVXCIR1C3Ap+NcFw+96Q4yzcbg9jAcJwElbuNww+hYe2NsrY2+rXnbwUk+FWPo3A8ORexTXuNYpdTf4m1yxw5W5m3YJ7d/3mHlV8tJcskcqyPbhxqvh92dpY49au4kJh+MYrHXVTK2GwVt8XZQ/fdrFoge28P537/FjYRS/EsOrss9kMMblwTyOVgs+2vLuK+knEiqYLBluzCjuYayLWFs66JZsIAk+JFZOF4VxXimJIIuXLgAd1Fx7ly2o3e87nIo6lmArFpcIzLBKcq238qX1Z2fEcTg+JYq5dv4u9dxAOUFcQ6wF+yqKcoHUDSs+5hMKSD2mIk+qSykz0ErNAsYfg/CwRcxl3F4j7VrhrjswelzG3VPtCJ7aJ+WuIJK4JbGCTacOpa+R+liLxa6fePKtPJt4s+nh8HnmScMa+Ns0k4d6SXgGtPxUW9Ie6tmzaA/WvhRFV7vAJuPexnHeG2LzkFmvYu3eu6aarhgeg51lk8Qx95LZfF4vE3T3EzXb1xp6LqaLi+HXOHKq4m7hxiywnCW7i3btlYJzXzblFO2mYnXlFc/Ok+h7l/D+FSUMs0m+yv9fsXDwfgLtOI9K8+8mzgMXenya4wFR/J/o4hizi+LYgjZjZwmHQ+w52rJzsSIPuqZfswGdmE7AesfIE1mU51y6Pbj/h7QQdzk3/AJ7jYt8PwTQEXEH9e8hPwtxVv8hM6KbZug6kklHBHIAAA1y/5axFtuzw7nOD/ZqruD4u2lXbWO9LBdVUxGIW+wzpYONRbrLJGiEZeXWvL5uW+DxajT+FY3tVX8/tZo3OC8TE9kbTRO+ZH8tZHxqra4TxJSzXcFfJClmBKQ0SQmYMdK0cD6X4rDXvovHsG1yU7ma0mHxRM6MjrFpl/qa6cek3oh9HWwt0u923cvWs1vs2tMu6uz7NpoNZ9onM9RNKpcHDBiw6aXnYMe73p2l+/wATnuBXcfwy/jruKwdy5ax2Fu2r72mtQsoDbKqWHdUhY10FZfEfSe9aRrVlbVu4wIa/bDG4Bz7EsYHnHlTekfE71qxbw1g2xZxIXE2rtliwa0WzIoYiCJmdOUVx9m1jcZfYKHvXmlgFHeJGvlXfHkaXLPFn0uKM1OKlNv1f7GpbucZvJ22Gw2Je2ST2iWWu5mOpJZwST1oq4X0mxjAHDY0xpN4CzbA83gCtT0av44pjhj8RiURWsCz9LZxAKsCED8hpMVtXMfwq1LXL7NA2QMxPkNK8888oyaPuaTTLNijkVq+1E8BZxWGweEwt/E3GuAEFLd26czEk5VA7x6bVo3MLguHqL3FcVYwIIzJaZRex9wfo2ZJHtPsrAf0kxVtGtcIsW8GWBFzFZQ+OuTvFwyFHgvvqjhuG8Q4jdZu9cuOc1y5cYliTuWLGTXSE5SPdHw1tucqgvXhv9vz+Rt3/AEstWA1vguByHUfS8f8AXYgjqlsdxfjWJfucb4o/a4u9iLxmZvPCL+qphfcK6LBej+FsjNfdi43CrrpyGbSj4jiPAOCvaX8n3sVimAcKRmdLZJh2LgqOewrrV8sRzabSv/bw3S9fX5s43H4S/wAPw9nE3LRZHPdn1GIbYFdaoj0gspo/DMKYP2QPhmBr0Xj+KT0j4HZW1h3sMxL2bd+Ld62ysUBfIIhtxp864KxwqzwrNicaVu4pSeztkd222/dVhM+JpFwTaZ8zPqNfq3BwW1d+9GlYWxirPbYrhuGwyMAwV1t9pkj1mMCAffUr3F7VtVt4e2hVAFURFsRtAP41h4jF4nEMS7GJkKJyj2fiaGqEmWY+U6+2seY+qPYscYf9jtl67xPHO2ZiI5BABHhAof5TxNoqXYIW9QBc1x/JdT8KBfxX0a3K+uwK215T94+AqPDsHcvE4q/ivo1lnKfSCBcxGJcAE28Oh6aSdhW4py5Pm63xGOD2IdTXTj/GMMLRdsQqlwQMdh2S05IGgcgeHPnXR4Pjl6+tt7UW7mnaWjD6yB3NNQeVc9axOCZbt63jcbdR+ztXhxTJfw9zKGCpdW2BcUdSsxpvFH4RfXhvElsopFq+GFkuVZ7TgBnsB10KEQyEfPbE4t8Hgx+LKmssbPSMDdu3MNZd7alwup+qBIJlSOUR/WlEcWjq+EJPU27TT7pNZOBxbzjFBlMlq8AdhcZyjMP1pE9SJ3Otj6STA5+J0rrDlHwc1Oba7ltlwgEHB6HWDYUgHqcq1A/k4GTYsxGs2UGWORLLQe3fky+/al9KxA2bTlBMfOt0cWy1bs8MuKHNrDa7fm1032pVXGJvHdknxAPzpU2kszfpYP2hMSZB2O+9IYw7nUTEz10EjeKwRi2Md/kI016bU4xQ03gzJnU+dWjJvnFiAJ0mBB3I5UxxIGh0iBPMc9awPpTAsZidgfWjlr1qQxTEqFzMx0yrLMZjpVrsDZbFBQWZgoALNm+yvWelZfE+L37WHHY2wbjkQLhg27ZB+sdObHks6bmdljin+j4dHvhTcvBrqJMqqAlAWjSTrWBeuG+z3LzhLaQbj3JCqW1AMaknkBqfASR6ceJdZHqw491SYG2cRi72Z7jPcdwhURcvmQW7tqQAo5kkAVLNg7JHbFMbdBJCL/kNojYwdbjeJ08DQWe9iy2Hwlki0q5rhbIrMg+3ibp7ir0GYDzOtQ/5uw0wqY2/EZmDjBWz+hbOVnPiYXwNJtdz7uLDln0XyX+cGkL17HKMQ6BbAhBisZdKYcFT6tqBmb9VF91M+JwNmAqPi7gMq2ODNYVvvWsEWKz0Ls36orJuYrGXmz3L1x2ChFLnMUQbKs7DwAFQBumDmb2f3V5smo7I+tpPBud2S/h+5pYvF8RvhL+Ja6yg5LTXCCE55ba6Ko8lFZzXCxkksTzMn++pZTABmOWY/wA6gLSYi6mFVrqEuo7W3Za+o6ytkF4HgK4Ke91Z9TMo+G6d5NqT9y/X7lxbGBsKt7iF4gxKYPD3kW+/hiLmqovgJby3od/iqXba4Vblqzg1M28FgUcWCR9pgJZ2/SYk1dPBnwtlrn0PFiyglr97B3bCHxz4nJJPlVfC4DE8QxmGtYRWa8M/ZgMtsKmhZ7rD7I867zx44K3Ln3HxdPqdZqJPIsKpfim+EVLbq4DKlzIZAa4uRdDEDMZ+FdBhuA5LKY7jOI/J2AbW2pUNjcT+jh7J19prTu2+Eeiq2ndE4jx24na2jdBGGwoJIFzITPWOZjdRvy2Nx+Jx1+5icdiGu3W3LHRR91VGgHgIrz0k7f0/U+3i1WfUQqMqj/dVX/5XZe937kaWJ44tq1cwfBMP+T8I8rcuKc2PxI2+vxHrAeCkCsUhVGd5ifj0A60F8UiDurPi2in2Cq1y5cuENcMxsNIHkBpTzKVIy5QxXHF17vv833L5xCW0nKvaH1UEGDyzR8axcTir1+4bdss7OwQ5Zz3GJChEA1jwqWJum3bMHvPKjwHM0fAmzwzC2+I3ZGKxrXbGBYDvYeyBkuYkA85ML5HrVgt3Mj814rrnD+jB8vqHtcM4dhIHFsXcOJyO5wGAKtctgIXK37g0BI5D8aJh7noreZhYwF+2EV3e5bx11LyW1Ukt9YMvh6w1NYjHE4PEktHb2LouSTmzkd8NPMMNfEGtduG4ZbfErVrEKj4h7WRHtvFu2bf0wYfNtmbQT+hHPTs16n5gsY+49/B3LFjG38XgLOW69vE2lXHYIgaOQPWXlINZWHv3FZrdwI9xBoXAuI46nWDHWi4U4jCKWYoLi4i9h8CzqrMXWDcLkHVQIWOrHpQsYltGs37S5bTgX0WSTbUtkuWd9lbb9aucoKj26PUSw5E+3ct3bz4k/WW7Ow1CBSI5DJAqdq6cOrLZIthiMxES3mTVedRFW7DWLFlr13F2sPdusEsG5hfpTtaSc727fq792T0rybXN0fsZ6jHosfm1bINibrnvXST4tNSt/SXLCyly6REi3ba4ROuuUGjpiMa92x2GOxd2wGPbG7hbeEtXGPq2UQEzm+10EnlTW7eJvW7jpg+JXOHWlY2Hwt/6JhmS3PaXrjssksRM8tBy02tNyeJ/xFJQ3KPPxGc8RsKHuWLtpSYBu2mQT0lhTLj8YplbhB/R0+VVhkW0xRWQYt1v5GdnNuwmYWlLNqSZLT4ih1XHa6R78HiebPj3z4s0141xldFx2IH77fian+XON/8A1+I/1h/KsrWlJrLTZJalmk/F+MOIbHYog/8AakePKqz3rl05rju7HUl2LH41XmpouY6+rzjnRQs4ZNX5cdzZNcx9UT5UZLRJAYxqIAgn37U40gAaeyk7m3bu3PuW3YeYUkV3WNH5/P4nlm/Y4MvETi8emHsEw923hLBJnViFLn4mrnEmK3bVyxKYfh+XCWF1hLQJKXTP3zObx86z+FXDbx2HvHU2LeJxCgkiXt2XcajXetnB8Ss2lxDJhlS8cGbudTdvpeFolmsYi3fZx2ZkkkayAa7LhUj5MpucnKTtslibJ7bhuF4ernEX8XfvMhVWC3nS1MBf7NQW38ZqYxFsm29khkwt7Dvhm1H1SXNNBpoQw15XPCr9h+2wOMxtm296O1a9bs3LVvEXwoR3FuzabOF/6Q6wBAEjuZX03E38C18fR0WMZ2drDWbNqyjWrlm4uREHKeZ5+NJK0SLpnqD2cNh8DcvWbYV7tzDI7SSSp7S4AJMcqpds0A69JmrXGlfBYDhmGvlfpGIuvibiIZFtLaC0qA89zPjWKrzAUxvAJ0JnbWucE0uS5Gr4L4xDbGd9mipdsZHwg6TVEG4NwPw+FTEkqVA21y66a8zXQ5F9bzARlY85EEUqqrMbJHLSNPfSoQ5Q3oA11HsmfKkL5gd7UHqPlVHtNwDynbSaRuba9I0rQL/bMOZ1M9fGRUlxLoVdHCsveUxJE6EkGBWZ2qj1jt8aGb+ZgiLmLEKoAlmJ5AUTp2g0n1NSzxXBYzAYfCcSxgw/EMJdv2DeNv6tkzllYBRliD4beNEscPwmS59G47wZrzk5L2Kcq1pWXKwRGYoCfvRPlXOjsmxb2iFc4i29t4AYKyd5SCPLU+NUL9lrbhlJGQiR5VcudxdSR9nRY92PfB9Oq4OtfhOFtWhav+lHBFtKc+S09+6M33itpYJ8TQDZ9FLX530iNzwwvDrp9xvXFrmL4t6mN6pZS7Kqj1iB8a88Zbz6mfXZdLwn/wDP0OyGJ9C1ZUt3OOYpyYVbYwlnMegEOasnGcEt+p6PsYHrcR4sV96WjbribtpLVy4ghsrEBpmR1BFCKDXT5VtQj+I8EvGdQ+j/ADf2aO4/LqWjNjB+i+FI2PZ2sS4/evm5UG9I+NX27K1xgksYFrh69mD4KtrIPcK4nIOlSCj3V0WxdjzPxLUPuvovvZ2N3B+kl4h79nGL0bHAh/dcM1b4Tdx3CMV9IYpcDWms3U2LISG7saSCAYkTtz0yuG+kOLuLbwePv3bxUBMPevOWYADS07Nr+qfZ5XrmIBrDfPQzLxDUyW2U216Pp9DS4va45xk2MTbThZtLaK2sRh7t8PeQGQjpdmCDO+01x9wYpblxLqlLiMVZGBlGG4INb+G4newhcJcK2rsdp3FuZW5XFRtJHPqKfE8H4jjy+KucRw95nSbBtWciOm6iZgDpvXOUN3K6n0NL4i4ry8kqguiOdlQA3rHnO9OCDrEdP76lesXsMzJfRrbzlKuDy6HaKZUuPAS3cafuo7a+wVwo+3GcWrvgzcYxN3IPsgKPM61r8VsYJ8bZwzYxEtYDCYbDm32V5iq21DPLICJJJkjr4ViYksuIvZgQy3CCrAggqYgg1o43CYy/xDGMlm6yXoZbkQhzIGHfchfDevXHhH43VTeTNKT9TUy2PyZrOKwVuylrEYrCXDburca4xt2Cl4E5dgJWYBjaKQs2cTcvXiBbtl8PiMtzEhriuo7IKqWCXJ37uh11ii4D0cxmKwNzDoFbiPEr1gYRbV9Ws2reEztdu3mQlIWQCSdNhmJhd3hXo3jOF2eInF8U4ZhsbhHt4XFDG20NvDIwd8PbttiQoJuEk5gIgQDvHSPL5PMzm+KjAWreDv4mzfZ0uOmFs4R7OHtWLMi4EvEI4LEkkwTvqSdaqY5wcK7JZW2LeJAC5meUxlosZLRzEjStbjy4JsJZwuNS1gcUcW1+0+CDYnDYi0bYQmyqtIBJ17x1mNqzOLiymFuC2zH/ABrDWCHtG2VbC4c5pEnr1qepbqgdlVfsA7ZEfsw7kE5FMS0AE6eVX1uNh8RfxFjidq0bipZQWcE90pYtkBEU4iIiNa6jhvo7wQ4Tg97F24+kcKsYlzicUba9owQnTMvXarLJ6A4PR7nCMy8p+kNp+qHryRUo9GfodRqMGoUVJSdelHH3sb2oS3fxOKxSEXxcuXOytXF7ROzAsqMygAT5yfYJLeHuBUtYLH4gKAFS7iL1y0ANQDasW1EeE12DekvobhPzFt3I5YbBW7Q9jXcvyqq/p3g82XDcOcnWDisWltdOZCLHxq2/U4t4nSWHp6s548N4zd7a++BxQVVe7duXLJtW0RVkkloAAo1j0f47iEt3EwmW3cVXQ3rlu2SrCQSpOb4UbH+l2NxaLbK8Nt20upeNm3bv3xea3qi3jc7pUHWNtp2oH+FPpBiQwuYziK3HOgwVuxbUlth3EDTPjWNqPXLWz2peyvqXk9EOPMMzfRUXeS11v4Uj40130aXDJcbFcWwdvIpJQZMxPIDM4PwrDvN6Q33yYpsVniYxdy6WM88rE/KhjheNuQWcA6bJzPurooe48k9dNcOf0Rqvw3hSXbFleMWXLAvfu9wWbajTKhnVydhO2pq3b4Nh3UdhxOzcGwyJac+5X/CsQ8Ixqa/SLqADco0ddDMVZX0c49cKFUxJM5VLYYqxMxGpBJ0NbUWux5cmpjlVOX5I1TwO+v8AnafvYcj5PVLiHC8RYwHELpxFplt4d2IFt1Y6gGO8RSwmD9IWtXbuCxtrLh8var210OQROZbL5pHWP+EcRe9Ir2Dxdhmw10XbDowWzDurDUKYAnpW18Dyya7NP5HN8PdExuD7Qns3c2Xgwcl0G0dTpz6V0PDsbwbCJijfwRGGXssLiFS7cfFXw94F8L2l6FUMFOchRoD105NYLQZB2BGhDDaZrXa3d4nZtNhsou22Z8fZzgXDdaE7dFO4IjbYz1qnA6/ifF+CYbA8Gs2OFYdsFdxV+5hL6I+ExtjBAW79nLctNlNxCzhpBmAdySc6+2Ju2rdm6cOXxT4ZCMNh7FpA2MxYxHdyKP7NMzeYnrVC1Yu4y/ct4tLww9h+1wtuQEyWUFsW2djlRW0LHwPOrOGu4W9iLZW8ow2BFxbTohC38VdkXLqjfIghEnlVRPgdbxbiDcWxbYu6AltB2WHtgn6uypJGvMnc+fhVHIJ7jsTzEGI6iaz89qR2WKdTuWYd3roN6muIcQDiFInmAc3OoZ5LyhtYa4pB70lssGjdpiEiFzCYGhKkbg92qiYi40KTYYdSCIPmDzoouYq3+aRILbKxjT9YnSoA300jQ2Sx5lWAHumlS+mOI7TCXM0a5DKnx0NKoDj+0AG+/jrIobXeg3G533qBB1EECDtv76G2gA2BB8Sa3YCqLt64iWkd7jEBVtKWY+QXWtDsxw6UxJt2MQ9g3XFy9aLraaQQDbYwfDesN7jjRSVidjEzVZy7CGGnSOfjXTHk2O6I47lRpfT+E4aw4wlxjdxEG87qe0VRqLS6QFHxoV/EYfFWbd20wN4qRftsQpVhpKzuDWVquxYDoNR7jUZJ5If3Y+VcpLde49WDPLC7iXsLYbGXwgBKoue7HIDSPMnSkEW1dv8A3lOVRyE6mg4bF4jCi8tsALeKdpkbKxCzADe2pri0Bk2WnzBooxS4GTI8srkJkzmTHs6VA2lohxtg72yJ8qmty2wB7NyPBlHxg0MKLl0K3ZeBqXZ6jYT95gB8asHI21g/vX2A9yxTjKIi1gk8WXtD77mao2jaw5H2AWrVp3FvtMxaV+pDOU/SMCKtPj7tsm2zLca33C67Nl0kVF7jsjK+JJTYraUhPaFhfhQM+AU95HfwLFfgon41HJG1ppfiaXxYQ45z58q3eCcZXDWcRbxnbdlmVsPkQMwJnOIJGmxHjXP9uh0w+CiNiA595JqYt465ubVof6zfCfnU3NdD04tNDu3L4L7s7E+kXCY1XFEAc7doD2S9Af0t4KpgJjGjki2x8S9cuMDa0N1nun9I5R7hr8aOq4e2IUWlH7o+J1rPmnf+QUuns/OzKx19cTjMbiFDBcRiL14BzLAO5aCas31fF4PB4lMzNhkGExCiTkCn6t/IzHn50HHlDeBRlYFFnLG4kcqfA467g7yXU12W4hMB0H4jl/U9E75PlZYbJuJbxGLu2LCcLs3WXD2lb6UFaFvYhtbkkbhfVHlNbnEuLXcVw1bN7El8auE4I3EVy9828KX7Nsx0LKHWfPWsu1wrh2NdL2BxIjPbNzC35DopbvSZzQPI+dG/I+OTEXsTiGVjca4b0zbtdm7ZWBdiNImNOlapnIbA3lxuKFx8JGGsYkXcGluAoxGQZbLFtO+QGeOesDNVTil0XL9rDBs4w+ftmXXPibpz3SI6beyrnEOJ4PDhcPw82y1kPasNZB7DCo27WyxJa4ebE/3c+t68hY23Zc2hI3Os71X0oq62X/8AGrkRbYwAo7Q6ADYAGprhcWwksFHhNUO0xr/2l9v3m/CpDD4x90uHX7RP41zUUel6nI+LL4wdkfnL49rKvzNEWxw1dWuWf37oPwFVLfDcW8aAT1NGXhV2Yd1HvPyrVI4vJJ9WbuEv+gdmzYOMOMuYkBu2GE/NOe0OUqWIjuxOm4psRxj0XV8I+AwmJtNYJZjcGcXGDB1JDPuNuW+1ZA4Woibm/wCiQamvDbI3LdeUe8UfoYvudLxn05wHFcPgbScMuWb1gHtLtt7SByyhSEABIHMCapN6b4lQOx4Xw+13CkhdSCBPLnH9TWUMBhh47xJOtGTB4XSFSeYjX2zWIY4wW2IctztksV6XcZxmbtLWEOZ2uGLRJLsNTKkf0ai/pb6X3mzjGOr92GS1bDDKIEMROm1FTDWBoFA8wANaMtpBEKNxroAK2kiWYrY/0kbNkxOITOCrdiRaLDeCbYFVzh+L3vWbEN+s7H5mumNtDmymOUBZ+NMh8tBrI0NCWc0vC8eT+Z1P3gPxNWF4TxIQ8qjDZs4U+9ZrpkGb7Pe+8YPgYP8AW1HFsODBEiYC6fOgs50cM4peBS/iWZSAcr3XZW6SIAqzb4TfQKC65VjYGK2VtNMlOg3UmDrsDRUW0wIysImOa6xMEc6oszLWDtLo1yNo+6edaVvB2I0JIBKkiIEedSNhAZ1lmMAARlHOFqK2l7pVnVxIkuygg7yFPzqEsMMImbRQp0hjqCY8OtWLF17ZNu4VUD1WIHrfdEDaqq93K1y8WU7gySB6p1Enpyoy3kcqO2VZKnvoCC3hpQF0tigT9daAJLDNYaYJ8DFKi2znUMpIknMBlaGGh1pVAeZtfcgQdeWlDJYmTJ118PKiC2oMakgSdNqUjkumsCRuPGqAcEbqesRTqubTrzp5I3nUGddAR1qSK5IIU/hp1oB/o9kzImeZ/lUfoVtiYkDSDpr7KtqDPeUExyNT8NAScwM7ACKtCyicAoJGaPbJn2UNsC+uUzBE+6a0gGYa+Rhdgdt6kFJKqDDfpQs+FKFmK2FvchImkqYq16pI6wOVbeSc2omQAOvlFR7NCYkZjy8qlWajNx5TMjtMYOc+aKfwpdri+iHnraT+VarLa5TA13A15RUezVgTlbkJG2utTajt/MZf7mZfa4qTC2gT/wBkkHz0pZ8WwM5P3bdofhV9lA1gAGY10/40kALKCAdefXoaJV0MvNN9WZsY0nR3joNPlSNrG8zcM67mtzswNwNuXjoNBUlGvqDcbDQ1aRnzZ+rOeOHxJmUun304wWMb/N723ND8zXRaAxEjLIg86ZrkSCzbQBDE6aDbWqZcmzn/AKBjTH+LsJ1ElB+NTHCsadMirP6Q9+lbZYbtmzRp0Gus61BriZTAOsQRA08aEsyRwvEk63bYYbEEkz50U8KvNHa4qRykM3zNaduDAzjYFo1A18KNkUEEETlO3QeNQlmfZ4Th15u55yNAT5VY+iYa2sm2o9x8KtBV5PqDuNxyjWp5VgwRAAEmJjlvpQWUciLJyqIIM6e7SiayAQY0IMiAT0qdwaljB2BAiSenSmAIJUydDl7wAB6UA3qtBABGhBOtEQhomNgRrAY+J3pwxIB0LgKrSBqQalEmYBHnG1AI29ZzAb7HpTC3mAOmoM7z11AG1ElW1BhIykgEiemtTVVDQFaAe+dCV6GTpQA+yVg2VoLbACTtFR+jXoWIbYTp3jtEUYMpmCwBEiVJJ66A08h4liQRIIJA00AMa0BUKX0MScwJjKdiOXsqSPfGaAG5ZSus78qtcjkDmILAyF0EanwpC2TPdAgdYLHqIoQEuLdT30WNdRO3tpXL6ypyANE8oPM1PsgxYQf1hG4HUcqZ8Ncy7SpA7+p20G9Ck7V1TBUAnUJrqDGsA8quqxIJXvADNIbwmDGsVjm05OiDNO2mY6cvKiWy4PebciRcEj3CgNSQwQAGQMrahT1GWaJbJZhIEExryjygVVS+ysoe3bIIy/VswMxIJ1PyogxGGVjnV1DZd80b6wZ/CgLyHIGAZZIkwgABPKATUnGYOAG78kFDsxEEmNIoFu6zCLLLCwYygx46UXtbkAkrHMkKO6DB0UbUANVZQgPdADMO6pkDTciafKsCWM7ZiF9UdZPLWjBoQNnDC534PeDAnRmk+FM2TQgDMxkqVykc415896Aa3NkFFOkzpJ1IFKmGZlUyR3RpHMe2lQHDEj9wakDQk+JmoyW1kTyA1Ap4JIlXgEgBR7YJqSqBsu+kAydedAStWhOZjMREDcnzqxlELObKCPViJnmTUVIy7aAaTI15+2nzg6d2BEgDc77nT41oE1bQDvTPemfL3VPmO6uYhiQNtOXShd0EnWBBWIkA/CiA2zvsCYBG42oBT6umWRBzayN9qQMbnXlA28ppyUEHpoJ5iNoFQZliducgmSfPpUAmjUallOUFiB8qjqJB1PhynXSN6iCBDTJackc48flRVGsmCxIhZJMk++gGRMwHKDoBrl5SfCpOmUCIzNmCGSNB4+2phgJzMsCZkQSOhI1ihsxJI5nUBdqACyPMwBBMCenSiWlhjp4knY+FTAghZJJjkJ95oihQCXzQGJPQDrQDgqIUqB5co1p4EMWBnWdtOmlRYmE+yDrKk5mE7aa+dSFx4nJoAQcmkmYgfCgEoAGpQTEjXbXeKkSgkM+swNT06DlUC4GwYTGbMZHkTQXughwA7Zts0KVQbkkGjBJihmAoLoGGade9GWhZczRJkSQfLoKiS9xmYEKrAAR93YAij20GkMG5EDfTSNRUAZLaKgAk6knQABhrrNIL97LtpoTJGsURbdzaNSJGsaDkCan2Z1E5W1kcumooAOTvCVJAJ0GpgjcRUlVzlORiAh30kT0o3YiAGYSAsAd0dYn2GlkGZD9+SoIMgiI+dAVXOhhDLfdEgnqaD38wgbA6wRtrHsq+4GqqScxJQiQdDrrtQjK7FhlBMkwGGxJHjQABlkXFGh0gyQW661YTYlRplDAtEkRrvrpUT3e6v5tgcoJYlQNSJ8Khl1ZTJbQiSSAd4YDrQFjVWPdQgsA6hp0I00mpIdgWHrZW2iD0G80BQhmRGTRgBoCORO9WFyQxUMQImXAMGNh7aAmEYbqc05ZGxzQYEVLIoIMAAkNuQQANYI09lLQgFGzFSIDZYKxB0Oum2gqWijvwVDrmKkkKd8qE8qAcopjMVBOoVW28SCTvzpKtsFlmCQT7J+0NR8acG0DrctxLMAQWPdmJgc+R/nS+qVmIzKNAwCloZidu9E70AjbInvICGyjL3FA31PP4Up7rfnCWLKCRpEzHP30bKpCv3mUA5pIEcsjCfwohsDuyWAMfmxDmFksNOVAUXtlirHKCdBrKsRrNCa0MxyKVbUSolSTqVPjWkuFtuzQAVg8zKgjxgfD+6IhO5KuGIDFs4kCSra79PbQGeg1IeS2xzQACNZ/oVYS3edWRhIJ0zKdSdfW6eyjdkzZXXvXApRVM68xnIMxypaoqC4GVmgwpY94zJMwIG1AVDaFs5G9YaKVzFVgg6Ff50S3iMRbJC3QUk9xpI0OpgiPjVq4y5UGa6z5SDlAKmDEbAz/XPSORgrOgttmCwQrBjG4PyOlAJMaZutctQSoQZFjMI2Iq0MThHNtbl4j6rUvaIAJ115mOoqiLRVpe2SF3ZTkgyO6WAj3ikbVwgs1qQCZgy+neJGUzHTSgNJWsMMytacSRmZxJjSdx8qVV8PhcO9ssw1ztMBSPfNKgOOBzGAMxAzsBIhdRGuk0ZUGXLCyx9WO95k6D4igWpUhgDEGBO/sOlEDGcwOkjUcxvsBVAUIrMXzLoSOckx0iacqYEbH1jAgttUMzjNl3BlTrMx1GtRVh3hqDrMd6G5yNPlVATKBqV1B5Hl/OoFlUkMQIkwDz6Ck9xxO0jXXnUGcsWIA1B2A251CEhdBEkGBoY3jlFRDqSF5xpz06VHPmMTmJ7oB1286sIqqqsezk947CB+lQoyhgUIGsHLpIWfPyog2cHXNPOOfOKIVtkqItqGYyWklpjKrHaBr76i2UjuoJjuzAjWND0oCBkkACTqsb1JAVysVnpoN4JJBqK5xmYNEGRlM6Hwp4uEAhjKqNSI0G4oCYfvFymg0MEj2a0QFoB5qCzQJUHaBsfOmRRAaAYUhu8eQnSnzdmEGkMMxMctgCCN6AaeZ1JGmWdgIBIOtDuMYBCwdMwG87cjtRCZOhUnQp1J2Mjbx3qqxAJE8ye7ynlQBCy96UUHeZYTPd0FRFsMykEkt3YO/9GoZI72ZsxIG8laOneym4IJ0JAIHKYAP4UAgkQFjUEQdPfR1HNjEAEK6kFo2C5TtO5nlUMgMnLC6jLME8gw8aKivDEaR9pyglQPEVAEGYoDmZ2GoOkQTpvr5aVMBwXGpyksR9oScpJMUwDhc4aFzr3RE8zA/r50Xs0UJLqGOd1BkBlUc59vuqgGd9Cs6KQywp0IlYJphmYABzmDQMobKT0161Yy2iGASGnyCjLIZixiBv/wAagEskJlAeIYsAxHL7G/jt86gINmmFyqqgZs5zZjM7xPuqL27kAtlVTGUEjlJAUHXxq5b7TNGTuAEdyMpkQM4PXTWKhdSy4UPCspOY3O+CSCAcw1zb9KAoQpgZlzAMV72jqeQqYAKIMwBytIDKxOX7JjXyqw9iyoJEyQ7FSG7sye7OvLrQuxdwXEh7cM2gJhSBJIoAeTRLmZc2YEqNJ0AzGNPA0VA5zy8IgZ3aBJG2h6U0qGnKCD3e6dBzIB21+FOVCQc7KkFkzchIJEeFAWUXcXM0XMhi5CKGEa7xUrlnDXMs2gzDKzGSAvMamNommRFm00A65VN4k5jGYSB3v691kNJtoptkx3lBIgbjNvpvFABazm1LBUClky6g6ZwqlojymnNgW8pHdaS90akoz7CG67+2is17KQqjvDdmVlGp1B2I9o+NOEHrNDXLaksrHuXVbdGE68oPs50AAo2W6WLOA2bunL4RBj260YKSwgtI0MQ0lh3Ss+yfKpr2d1LSsWGaBNszkJieY8B/woy5yrkW8qNcKNOzNpsCaAqovIsAqrqHB1k66b8utCuI6Q6uty3qoaVAbSJj1unvrRFtGEFrZ1UDMV155ZmdN9+dRyZlS2xVQTknPCvm70jSY0/qaAopmCtkA7QmBqYJ0jMdxM0bKt2Va5Bt5kIdliByuEiR4Gk1uO10YkAj1f7PMAJJ0K/yqsyWAAGuszqtsnYM8x3oEqAeRk0AS4XVWCuchULGhIA70EdDvVdb2U5lcDs1JzHNqZ2IHtomU5ezVysJmdoMoGEEGOXX+pibBKqXuL3Cq2DlIGYnVgBOnX+pAsW7qKVkoQ+UsDlYFiIGs5h4iatWrNm9GYEmVYlRIkwoEsd6xouIQM1tmjtJAaSGMTr85rTwrHugOs957gIhhHJgRsdOek+8DTGHQ7C10i+md18CaVCF+1bCppoBMHc7SZEzSoDiRbskZyAWJEAAgGRy0G9OLVrKy/aksDIgA6BY86uDDYM5CcbZtk20LIqM+VoDHLpl013/ABpfRMEnaf8AOFo3Vchk7NyuU5SIK8xJnyqgpC2RlI1B5xpMbGoObiElQfGDInxGtXDYwuijHWAoVRIS4TJzEiCNgY858Kr3rVpAgt4pb+YOHZQ1sIdIBz7zqR5UBRdtTlIJJXPoRvuIHKo6wQswSeh0G00XVsqqIWScpBzR40RcNaRgrRJ1BGvd/doVAkQquaSGMzOjfH+dFVoJOmsREHNGmpp+zsnKM0FiQDqQdvdSayrH84BAghhrodAIoQfPM6qDLEZpURMwKctBJJnLEAiAWOgCk0srMoU5QMwbKWKqDtttJqJDDUISQRIAzTlk6HwoCWaTmlSSe7tBPUKImiqwLQSD3TAYkFfsgmBVaCQJBAPeULOoG3hTpkiDCwVgakQeW9AWQwAYqd2QgEmSQBrou1OXdS5Nq4YaWKjMdNAFmPlUA5HeDEEaDMIEdJp81wqXUsIkMV7sA93QeO1AMWvAMMoUlV0Ouu2+g8NqjJBX9IQVEgBeXhTuBmWWbaQxEl5IOh208d6ZnBJjNBJDAEkMKAQMkQ5CyrHTU6a6DaOdP2itkCkkKAVbMfMsQd6GCR3dO8NZMkDadoqenZsoBAkT/dQFyy1lx6rRlIEGPrDqNJiD1qyr24XMMw75ZYkSTIAO2uxHjVK2qAGSUHqAbrprVvKgWbY0lWboRJKsFA5T1+VAHBUklc0ldhJ0G8jlUldH0k6nM7AAc/OT/fQFt5u0kAkhLgUCQRGkSZIogykWWJAbdUIRyYI0aBy3qAfLnUlnBTQQ5CiGOyjeTp7qVsXC2VmVGWRk07jKRlDEa6jX2+FIJaKlXiUOcjcDYlzO1K462rltmRnIU5e8FLA+cDU0AUHMyakyDGUKpDmIDfGI2oiqgi2bhnMGEgkZxBhYHsO9VkcBiyJFvuSysGzOdgEIHt8xvNFyhT3mLyNGuG60HNrqsxuZ2oCRXMA0KVeWVpGaNyDzB/rlQWtIhBZRK7oc+U5TsOg9tWQRlyompEOBKZgNSxMz4/1rAsJHcKhkW4GLmMoU90BhMk7UBXZSMzjVCAhyQOzJYHWemnMfzi1wp9WTbhwGUuubmVDIQPZvz2oyvbKPbY3SM5ZRIIBjfQGoqNStoKxSMrGCWA1AOkaeVAJbl+0bNtigyi4hAQFez7yKCcsTsF0MUlfE5HVUNwLu2XKsTvJjrtTq69mCC0mFVmTMXABOhAB023o8pDFl1JDs7XO+JXMA4J1PXePZQDJceFV07qgsUAJEk8yux168qmGuBSLStCMLqO7hwmkwC2vOJ5Ty5Sy28zI/cyyLbKwKgAggzIXkZMcvGjyrBDN83GylXKbqWIJWY0jSOUc6ACUusxRQnaXQpt6gAAnPKMx1nXT+ehUt2wplhBzNLBh6oDPrJ9sE1LI5VwWLd9ye8SVIyqVRNAB7anas3SMqgDMyKoYICSZPd1Jkcz486AEpu9oWtsGK/Vg2e6RMn7cGT/W1FAYkWzshZrYdmZZIgcozdNPlU1WyWCWltHKC7ZNFVJ+y20+7fbWaIl67ZADSxDEXDPqIRJK5RueVAV7lpxDZVDHvkBBERGmxjprQeyQokxmCEkMQq66SdiY9tWXmIUqAJVXUBwJHdVhrpB16eFU3a7my3AxNssXKqcmWcrd/x0jz8KAh2ZHde7plcOFJghNYDaanSBUbjKyBkIC21UlGabUTlJYEgjodKLC3CxS0CQFBVj2ggyYhYlvbQAbxYgLN0iAbqMytACd7KdojWgHsW7Ny2wNpQ9pc6Iw10nWPlFHtrdJiSuWGh7ZjYRkIMxvNTNq4ttbmUq6A5dwWkkRzEaaHrpQrdxWCaXAQSWDKGGYk6FiJk7nQUAUPdUKBcuERMraGs6yS2s9aVTW7aXMAxIn7ZZo0AIBnalQHLNtf/UT/AM1DG7f95/uzSpVQQ5n9RPm1DHL9U/I0qVAS+3e/ZD5GoH1rf7MfxClSqoE7nrL5rUbn2PIfOlSqAmfXP7MfMUc7Hzf+GlSoCD+pZ/ZL/GKrp6y/q/ilKlUAd/zb/rXP4lorf2361v8AClSqgjf/ADdr/RsP/DQMP61vyu/hSpVAMPU/cPzNHT803lb+dKlVAU/mf9b51ct/5Lc/0HC/7ylSoC5Z/wAusf6N/wDsodre37P4aVKoAa+ve/YN/uzT3vz2D/Us/OlSoB03tftj/EtWcP8AmLn7G9/EKVKgIP8AnbvkP/NT4n1MP5r8jSpUBDCfnB+ra+ZpsF+cP+jt8hSpUBP7OD/WP8S0HEcv+/8AxpUqAI3qe1vkK1sPtw79Rf8AcNSpUAI/mX/UxH+8o6/msL/pmK/hWlSoB8N/kOO/b2vnbqK+td/Z8M/3RpUqAmvqH9a//ElBuf5IP2T/AP5TUqVAVMH6939qP4DVi1+axH6tn5UqVAWb/wCY/exH8SVQ/tcR+3P8BpUqAHyXyb+I0qVKhT//2Q=="
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
 <div class="one m-2 py-5">
<?php $v= "
Jaguar F-TYPE
";
$p="The Jaguar F-Type (X152) is a<br>
 series of two-door, two-seater<br>
 grand tourers   
";$i="https://th.bing.com/th/id/OIP.eNGuMHWJnB4sIaMyp6H4vAHaE6?w=236&h=180&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
  <div class="one m-2 py-5">
<?php $v= "
Porsche 718
";
$p=" Porsche made some radical changes to<br>
 their entry-level mid-engined roadster <br>
 and sports coupe with the new 718 series.  
";$i="https://th.bing.com/th/id/OIP.aznHYeVi4GFBshk2Uxk75QHaEK?w=281&h=180&c=7&o=5&dpr=1.25&pid=1.7";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
  
   <div class="one m-2 py-5">
<?php $v= "
Maserati Quattroporte
";
$p=" The Maserati Quattroporte is a four-door<br>
 full-size luxury sports saloon produced by <br>
 Italian automobile manufacturer Maserati. 

";$i="https://th.bing.com/th/id/OIP.JwHimTzMToY7v8iIDqAEMQHaE8?w=207&h=184&c=7&o=5&dpr=1.25&pid=1.7
";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
    <div class="one m-2 py-5">
<?php $v= "
Ford Mustang
";
$p=" Hear the roar of a Mustang as the<br>
 ground starts to tremble and your legs<br>
 start to shake. 
";$i="https://th.bing.com/th/id/OIP.ZlVUqLPB34rYeR0yC1NujgHaE8?w=233&h=180&c=7&o=5&dpr=1.25&pid=1.7
";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>

   <div class="one m-2 py-5">
<?php $v= "
Bugatti Chiron
";
$p="The Bugatti Chiron is the new epitome of<br>
 automotive engineering by creators
";$i="https://th.bing.com/th/id/OIP.UKLPl2LSYEGRCCPa3JZKmQHaE_?w=270&h=183&c=7&o=5&dpr=1.25&pid=1.7";?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
     <div class="one m-2 py-5">
<?php $v= "
Mercedes-Benz AMG-GT
";
$p="For all its powerful performance, the <br>
Mercedes-AMG GT R always watches safety,<br>
 too. 
 
";$i="https://th.bing.com/th/id/OIP.55T2ynhTShjSSbltZ8OP-AHaE0?w=238&h=180&c=7&o=5&dpr=1.25&pid=1.7
";?> <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
    <div class="one m-2 py-5">
<?php $v= "
DC Avanti 
";
$p="The DC Avanti is a coupe styled sports <br>
car produced by DC Design, an Indian design <br>
firm originally headed by Dilip Chhabria. 
";$i="https://th.bing.com/th/id/OIP.QnOe31f1rm4Atx8uZHeBTAHaE8?w=232&h=180&c=7&o=5&dpr=1.25&pid=1.7

";?>  <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
  
   <div class="one m-2 py-5">
<?php $v= "
Aston Martin Vantage 
";
$p="Aston Martin Vantage is a series of<br>
hand-built grand tourers from British <br>
automotive manufacturer Aston Martin. 
";$i="https://th.bing.com/th/id/OIP.Bl_KDpUiHXlKzN2imznaFwHaE8?w=232&h=180&c=7&o=5&dpr=1.25&pid=1.7";?> <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />
	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
    <div class="one m-2 py-5">
<?php $v= "
BMW Z4 M40i 
";
$p="Think of roadster, and Z4 will definitely come to mind.<br>
 Roadsters are great for any driving enthusiast in India.


 
";$i="https://th.bing.com/th/id/OIP.mfV5GUsQwTCZjNh2-GtUnwHaEK?w=281&h=180&c=7&o=5&dpr=1.25&pid=1.7";?>  <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='sportsinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>




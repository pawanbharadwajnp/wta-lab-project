<?php
session_start();

$_SESSION;
include("../login/connection.php");
include("../login/functions.php");

$type="";
$v;
$p;
$i;
?>
<!DOCTYPE html>
<html lang="en">
<head>

<!-- Repeated code -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title> a4Automative </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<style>
#he1{
	color:red;
}
#hel:hover{
	color:blue;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

* {
	margin:0;
	padding:0;
	box-sizing:border-box;
}
body {
	font-family: 'Poppins',sans-serif;
}
h1 {
	font-size:2.5rem;
	font-weight:700;
}
h2 {
	font-size:1.8rem;
	font-weight:600;
	
}
h3 {
	font-size:1.4rem;
	font-weight:800;
	color:#ce93d8;
}
h4 {
	font-size:1.1rem;
font-weight:600;
}
h5 {
	font-size:1.0rem;
	font-weight:400;
	color:#1d1d1d;
}
h6 {
	color:#D8D8D8
}

button {
	font-size0.8rem;
	font-weight:700;
	outline:none;
	border:none;
	background-color:#1d1d1d;
	color:aliceblue;
	padding:13px 30px;
	cursor:pointer;
	text-transform:uppercase;
	transition: 0.3s ease;

}
button:hover {
		background-color:#3a3833;
}

.navbar{
	
	font-size:16px;
	top:0;
	left:0;
}
@media only screen and (max-width:991px) {
	body>nav>section>div>button:hover,
	body>nav>section>div>button:focus {
		background-color:#fb774b;
	}
}
	
	
.navbar-light .navbar-nav .nav-link  {
padding: 0 20px;
color:black;
transition: 0.3s ease;

}


.navbar-light .navbar-nav .nav-link:hover,
.navbar-light .navbar-nav .nav-link.active,
.navbar i:hover,.navbar.active   {
color:blue;
}

.navbar {
	font-size:1.2rem;
	padding: 0 7px;
	cursor:pointer;
	font-weight:500;
	transition:0.3s ease;
	
}


 body {
 background-image:url("https://cdn.hipwallpaper.com/m/56/10/d5qDRv.jpg");
 color:coral;
width:100%;
height:100px;
background-size:cover;
background-position:top  center;
flex-direction: column;
justify-content:center;
align-items: flex-center;
}

 

img .one #new {
	width:100%;
	height:100%;
	background-position:center center;
	background-repeat:no-repeat;
	background-size:cover;
	position:relative;
}



#new .one .details{
	
	position:absolute;
	width:100%;
	height:100%;
	top:0;
	height:0;
	transition:0.3s ease;
}

 .one:hover{
	cursor:pointer;
	background-color:#d1c4e9;
	transform:translateY(-70px);
		transition:0.3s ease;

}
</style>

</head>


<body>
<!-- NAVIGATION-->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 ">
  <div class="container">
<img width="400" height="120" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" alt="logo"/>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
      

	  <?php


	  if( isset($_SESSION["id"]) ){
 echo  '  <li class="nav-item">  Welcome, ' .$_SESSION["name"]. " </li>  ";
	  }
	  else{

		 echo'  <li class="nav-item"><a class="nav-link" href="../login/login.php">LogIn</a>   </li> ';
	  }
	   ?>
	   
	   	     <li class="nav-item">
  <a class="nav-link" href="../../index.php">Back</a>   
	   </li>
	 
    </div>
  </div>
  	<br><center><h2>coupe Cars</h2></center>

</nav>
<!----------------------------------------------------------------------------------------- -->



<!-- types of cars -->
<section  id="new" class="container">

    <div class="row m-3 py-5">


<!-- copy this for next iteration -->
<div class="one m-2 py-5">
<?php $v= "
BMW 2 Series Gran Coupe
";
    $p="
THE  GRAN COUPÉ is a grand car<br>
The body style is a two-door<br>
lar-less coupe with iconic suicide doors

"	
	;$i="
https://th.bing.com/th/id/OIP.ZGnoF8hesuUUp-_j1nk5nwHaE8?w=234&h=180&c=7&o=5&dpr=1.25&pid=1.7
"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>  
<div class="one m-2 py-5">
<?php $v= "
Rolls-Royce Wraith
";
    $p="The Rolls-Royce Wraith byRolls-Royce<br>
	motor cars and it is a devil of the street


"	
	;$i="
https://th.bing.com/th/id/OIP.TVonr11m2Wnnt4FSJHaBDgHaFj?w=207&h=180&c=7&o=5&dpr=1.25&pid=1.7
"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
  <div class="one m-2 py-5">
<?php $v= "bmw m2
";
    $p="After a long wait M2 Competition haslanded on shores<br>
	The M2 is the entry-level M model but is a cracker of a <br>car."


	;$i="
https://th.bing.com/th/id/OIP.2McZvw1mC2ITLsRJ4UOZkAHaEK?w=324&h=182&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
   <div class="one m-2 py-5">
<?php $v= "Lexus LC 500h
";
    $p=" Lexus LC  is inspired by aircrafts and aviation <br>
	technology Its aerodynamic proportions, sculpted<br>
	air-intakes and the unique rear wing speak

"	
	;$i="https://th.bing.com/th/id/OIP.LMfDFhIrWyg3xHhVdI8T3QHaEK?w=283&h=180&c=7&o=5&dpr=1.25&pid=1.7
"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
   <div class="one m-2 py-5">
<?php $v= "Mercedes-Benz S-Coupe
";
    $p=" The Mercedes S-Class defines luxury <br>
	 While it has made its mark in the sedan segment,
	
"	
	;$i="https://th.bing.com/th/id/OIP.Z_SyPIj1FSdU8NpWBcmXWAHaE8?w=228&h=180&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 
    <div class="one m-2 py-5">
<?php $v= "Ferrari Portofino
";
    $p=" When you think about fast cars, the first name<br>
	 pops up in to your mind is Ferrari.
"	
	;$i="https://th.bing.com/th/id/OIP.iFWWHYmJFUweugbt0YxKcQHaFj?w=235&h=180&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div> 

   <div class="one m-2 py-5">
<?php $v= "Lamborghini Aventador
";
    $p=" ach and every detail of the Aventador<br>
	bears the hel of the House of the Raging Bull.
	"
	;$i=" https://th.bing.com/th/id/OIP.KyIgdW40fgEMlUMQS5YF0QHaFj?w=230&h=180&c=7&o=5&dpr=1.25&pid=1.7"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>

  <div class="one m-2 py-5">
<?php $v= "Lexus RC F
";
    $p=" The Lexus RC  is two-door coupé
	"
	;$i="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADpAV4DASIAAhEBAxEB/8QAGwAAAQUBAQAAAAAAAAAAAAAAAgABAwQFBgf/xABIEAACAQIEAwUFBQYDBwIHAQABAhEAAwQSITEFQVETImFxgQYykaGxFCNCwdEVUmJy4fAkM1MWQ4KSorLxY3MlNFSDk7PC0v/EABoBAAIDAQEAAAAAAAAAAAAAAAABAgMEBQb/xAAsEQACAgICAgEEAQMFAQAAAAAAAQIRAxIEITFBEwUiUWEUMnGBQpGx0eHw/9oADAMBAAIRAxEAPwDj0srbUtmVs2i5u6T1AmmuEqpWMmXQKdSPGrxtYUW0a5ce32NwNlcLndJ0ZBtpzrRR7OKe7h8N2dyzfS2925dtr2sruyxSYHLtqCJPKTTq5WMozAabbCrd6xhkvX7S3DlzdxyCAQOZG9RiyigEZmkkEgQNPOkBYwt/EYAviMNiDbe4mRzbaDlbcHnWja4pcxSW7WIs2Us5/vbqWybjToSWJJrJt4d7rKSVCHaK1lbDWFAW2kQBBMyepobQzfwPBuA4u2zWXGJdTIDsQpB5FIqTH8J9nAyrfxAw+UKSLeQbDaINcw2Ivgk2nNvr2ZK/SqtztbobM7FjzzEknxNQTFRsWsevDExC4HEMznETbvBYXsRyhtZ66VX4lxziPErRs37xNosGKLopI61nWrThQLpAAECDJPnQtdZHyJbzHSCRrQOg4vOgVSw0gEk6DworOHK6sxJ8akAun3xBjaiVJ5mKj2MNAq6lyaIOs91WNGLatqRoPiamW2I7qfGaQESW7rNmIAHXpUuQERJOtTJaDA52HkDpT5lQFUEnqKjYwBbWdDtRAg7ggDSKiJbXQZydCfypFW3LNPMDQVGwDLeXnNRduJ0Op0g0ipJGhJo0VUO2vUjal4EQ9ndchmOVZ93r50RtW191hrvvpUjsGMHcmCajOVOeviKSbYD5UUSsz1n6U2c905ROsf1oSzSPHwmkQ8FhuB0qyhg5yxM5pnltTEAE60ypcbUmAdxUnZ21klwDv507QEYZmMAx0FMSI1kHrNSr2bHfXbQD5mguSSBAAGmkRTQiLORBJY9BNMpdy0GN95qQI+ggEDWaEB5MsAJ0Ip2Ayrp3iZ5CTSIMzrpyGxoibZjV2YbxQzJEAgA9KYBrkTUZi5127o8DTakkuZnkNB8aeSugBPwFB33bWFAGw1pWIMhABCxP970iCUgAaa6RQ5TGu3nT6CNT0IAosARr7xHKdNaI9mTADE8qTMgIECerflTqz6kL3Rtz+FFgINezxG+2YwDR20Yk54XMYB8aRJZe8JA1E/MRRpctsI1ygz0g+E0rJIlvgKEUAs7EKAp+cmorWHstcNy5aLOD3JJgEHcirFzs3CkFc0Q7anKvgBpNHmUWxL5BsDGnrSRbGNAEqmYsxGhJBOUAetDGHfK11mAK9xQYAXqApqNFF25mLOcPbaWKHV25aEbVft4MYgm5fZ1JHctwsIvLUdak3Q/Jz+PxNvEWcKYMoSNFQAKTMHLrUGE/zQ1piqnQ5WOo5iqgzgJaRcwDZiTpND94LoNqVBJnLqoneKtbM5bxV3Dri7rC1bcLbKLLMACR70DmKr4cXrhDuxABMKZipfs6Mc7CST8fOrKq+nIARtUHICO05M2ySMm2hg+U1KSsjTvU4UwQdfGKEPbkgKxA0mDvURhE3CpyqD8aJVuQJAGmtEG00WPMU4W6TEaeAoAfsxG51pBVU6DU86mWw+UsRy0nnUlq0BLXN+QG1K6AjW2zmBtzNTph0TVjtyNOXyDu5RrvzqNronmesUrAnlF2XXkaiNxyYYgDw50DM0DWAYp+4rKZDee9RAlk/wAXhTa7TAHQUBY5p1HjOkU4doyliwP7o2FIB8uUjcneSZ0os4mM8aTliaCYKgAkEwZOtMGAbKywPM6+dABTqTrE68qC5cJBCHTqNfjSZkM9R7oBOX4VAWM5SNCdQD9aEgJE8ySeZpErmMxMec0GZZAyxHM05a2ddJ8tKkAmuLoqqwpZxr72nMUptjXnsJmkT1OnIUAPmY+6dOWbehm42jRptApd1tpn4Ua90zOsUxDd9dFC97cnQihChdW115GnuOSCTGnxqNLhM91vDSKKAlLBTmUaRzJPyoC2aO7J5E6elIjmaHOCB3efXU00gJAoAJIy+C60w1PmNiKEqx72sctaRuOIGU+Z/rTAIoSQXO21NIUkd0xrPOgJuHceOtCFJfYGR+GgZKXEHKN9Z8ajnQsxipcgCidDzpslszmXbYtsfSkIiJmCJ08JJogzj3dOcdaOFGgGnpRATpA6RSoYdo3iFzElTrIOs1IbILMpykCDJJ058qPDq4UAKTB7sxJmpbhtpNs5nLasZgeS0i2MQUurlcZLa2BDElT2jkeRqmTcxtwtothGhjdzBAo/eJEEnoKuWDadu8LhtoDA1RRygmDNWlsIQrHMLaOWZCMw8Ndqd0WVYFnC2ltI5tsgJizaXuqf4oqdrotZbaEs6g9prEHpNPnY52AOZiF0mEB/CM1Q3mt2mFs2E0EkqMxJPMsKXkDlbeGuZi0PrHdOwq0mGCzJCzrA61aLmO712G1BI0LzHgKlZm6AARRCjXmTTeY9alTKwOSJnY6GpBZGmYwegpsCvBI0Go60LYfEOZtgzOutaS2ragkTtzpLcRdAdTz5ClsBXtYQoB2jEnc1NoIVYpnuAkqNTUP3snl40u2BYkldSJJ2Bk1EWKmJJ5U5MajKW6im5AyCecUgGYos5mBml3I0gUzhQZPPTXagK5iMuv8AfhR0Ik0YQdgdOtNKzAXXeTzpwmUGdJEaTNAzFAxBMiI0GopDJczAjuyI5GfjTlyvQdOdRdqWUABesmoiLhBMinTAmzu2sGmZid6G2j6S0eVGUJBIJMaaxTSECJI+sU2ZDuNOtNEb/AGmhY205yZp0AL3VG0fnUa3CxYdIgwYqTKhPIdNKMqqsszqKdILAVmPj0o17Q6xMeMVMFtxpy3pTDlFPjvzooAfvDE5QNZ5xUSK0uM2x9YqS6l1j3dZ5rFRqjByG0YjWSN6KQD7GCZA1pBhOikk0mtqrBS8kjkact2QGVQRz11mmFBqhJ1XSmtJbDuSRpqBSXEDKM2hnlrvQFsrM2YFT0BpWOgrugJBkToKEZjqw05Aml2ymY6g7aUF0szKNYOpGwFKwodmWYG/OkXkKQACraxUcRmy25aYEkxFEncnuqDOoGtNsKJYaAW5+7rvSV2BJNoXIPukwsedROxZlykCORB0FSEymriOirFIKE2ZgCAok7dPCisEu2Uq0pptvQlmCgKhkEQVgkz0mtG2qYdBdvZe0cSOsxtA0mk2TjG2K7et4S1mu5ARtIZoJ2XTWTVHDWOKYi5ibl9AouZTatyoIA8JgVadbhNq7dRmvmfs9kIDE/jYgDXpViyRbyriEYOxOaO807xIMz1oT6Lq9IjwVoKLqM4W6DB7O5LTzAgEaedaItO4KKzIQAJLe6P3iNielV7Js3sxsoFtqxBywpMdefnU5csGs2ywtrGdmRxn8FJGtRJeOhXbHZA5SCqqTN2Ac3NjHOs82MTeM27wAA5qWHppNWrsQtsBjJmGPugbCKGXByjsyRuGI0+NNCOdNzEKcvZgsTuDKxVq2AQc5DPvlH4R41LdbsFzBBI12mqNlzexOYSJHe0j0qyjLZcFmDIMeW9WFgBZgsCdyNKAMBm1I6eNLNpOw56VCrATuWaNo3OtMgtryY76gVH26l3gjQAeBpmZwrC1mkgiV3B86dUIG/iOyKgJ7xInSflTq5JBaNVjQ1Vw1vEXWdbqOuTZmG5POrE2gwUXkEGCIMjympNDoiv3WBGWZndRpFWROUSWE6n+lLJ7uUZp3JBpm10DEDypMCPEXOzt5gjNEmR+dQ4S9efMxmDsD+lTXAzIUzAzpvGlPbXswFCqIGhGutHoKCe5JksdfgKjcB1MHbnzNEwDGD3nPJZJ16KutW7HC+I3YFvBYkgjQm2UHxuwKkk/wJlG2sxBB5HWjhySFUaaAiTWzZ9nuLjT7MqqdzcuoI/5M1WR7N4of5mKwdocxmZj8ytSUJPwhWvZgBToDOakxyLrMttXSrwLBAAXOJLI/wBK1M+stUv7H4Go7+IxdzrEpt/LbH1p/DNi2RyQUnvH3aYANOUgjrXUtgvZVB30uMR/qYhx8u1H0qM/7JoI+zWmHi7v9Hap/BIW6OeFkkAhkkHUzM+gp2Ugd4gxzGtbvbeyq+7gFP8AIlz84oDe9myI/Z91Qf3c6/S4KTwS/I90Ypa3lEhoI1jQ0C9mBlW20akljrW4qezznuYLEkn92/cUjym4RUN7A4F/8v8AaNmT/vbVq+kHxVlb61B4ZoammZK3lEQhIG5XQUJdSSQijymR5zRtaIuth7LrcuLqbYVrd4gcxZvBXI8gaqlXa6BngqTmXKdCORqtx/JO7JGc5lgCCdZGtSKzEOMviJMgCo5fOMwB56abUJvlmZSzLB0hY086QyRmsg2zckzyHI+lTkW2CgAZY22mqZuIQRl0Gobr503aZjLbLAWDvToLLZt23tglQpUyAp3HjUXasJGUFdgdzUTNfBEKWB6H86kBuaTpm5GkAxYnQbyJmY+VM5d7hVVYwBO0fKpYt7LCxufGp5QWyVEHYnQTSsKKvZEg5myaCAsy1HlcAEQqqO6DMx1NDIW4DlJnnvHjWjYtDEMGIOQkLCiSx6UN0NK/BHaVLNntpOYxuCBPXzqxasPdK33C5171lbhYoJ5kDWatX7OFtWlD2TcuyClosMieJFR2s5CgFi7SWAgBfEVH9l6VEiIUJto0uxz3SYMnqSNfKpRatWNVHefvEwZjoOlNhbdu2GbMCzHvOecczNT3WD2XJGVQO4oks565hSJeCBITM7sSTJAmPypnu3CQzKR+6JB06zUKO1zXKygGCWIM6bAihuXcoysWOoG5ECdhFOiIC6tceT3icgnkPHeqfbXb126uHIYW4zuQ+XN0BAqd7eLxWJGDsC7btsJu3QCYWJjWNTWnZs4HBILNpVYL7383OZG9SQGCq27zNmfujmSalK2EEoFEe6wGp86rk5B3EYgnvE6fACjtvmju6EESZgCmzNRKpUCWysQJBHKhe4j7L3flUVy5dynslgDQmIBqFRjGB3eAdoUKPOhDLIs2hcLE6GOlSZ7duQIMfuwd6hy5EXMxZYJyoRr4TQjKwAlVJElZkkUmIc3i8opOs1SGDZmZ3ZswMiSRGtXmvZBCdmbkQF39TFRtfuKqAnNcb3soBFCsBK5SEDZiAJiSalFu5eyWbSO91z3LNhS9x58FFWuE8OxXFMT2WGUWrdmDi8SyqUtA6x4seQ9dhXV28XwnhDvgOD4S5juIwPtHZBXuAkAg4q+xVFHSWHgpG9kYOT6BtLyZnDvY/iuJVPtjW8KhGqIO2xEeOXuD4mt617JcAwwAvpiLzxP+Iusqt5KkCoDh/azGkHEY3B4RGEizh0u4ojwLO1u18LVWbHD+L4ZXa3xIXmE/c4i1ktXT0YKxUeYUEdetqxNEN0Svwy3h0Y8P+zWTlJyPbRLYgT76wB6g1zNz2h7zobt93VihTCoApZTBhkIBjrJrfxTtisDirdsMn2nC37aoxhrd1QZtsRzDCD/WvLRj3S3dVWYMzzlUBfemZYCalxsjm5Ql6DNFRqS9nS3faC8WZbeFXMOeIuFiPMD9agbjPEju+Htz/pIv1ImuVXEXDcQOSiTEpyOwmfnWhlQqJL69T+grVJ0UKzTbiuLb3sTePgHKj4LUTY12/DmP8Xen5TVE/YVnO4DDcFzmnyFEr4aMy7AEhlJMeO9QbsZM2MvfhtKD4AQadL2McEsMg5Z2gN5RWe2LtCJdZOvMfWnW+jbFTr50rGaCs+udgpO0OGHrFWO0tts3TmayC/Od6dmu2yM094BhSbQqNMznCguBEyDy8Kmt4jEWZIutl28x48vlWUmIJyqxIggqehqyHJLLIJBkkT0nWqpSlFk0kzQuYjC4pBaxli3cWQVJEMp6oeR8iKje1eWGWcfYUaLccJxC0P8A08QRDDwcHzqi1xg3u6EQY2qexdfXKdupjSmpxkqkLVx7QSC22e7hyb9q2CLyZCmKw559vYbvDzEjxFUnAYuyjKnImCWJ6RWky2sU1u6tx7GMtf5WIsHLfSNhI3HgflUJu2+0FriK28NibkizjbKH7FiW/wDWtqJVupA9DvVUsWva8Fscm3TKeTJDyRoF7w39KPs7RkwBGqhQACa3+G4Hhl3trfFbN5Ly3V7C5bvEWGssgIuW2tyrAmdQT6VPjPZvAsC2FxhtNGYLiWV0YdAyAET1g1jfIhGWrNCxTktkjm0UW1Jz986rynwoMrFswdjvz5mpbxyXGtkBTZYo2sww0MEU6hjDtAUkzpE+VWXfZUQPoyieUjx8qmRS1uSToZhtKkCIYMSdyGBmKsrbtm2zDQHSWO1DaGiGxhnu5g2zRly6GOlbFlEwdodzKQCRBGh8RO9NZ+y21ARg2YDM0FSxA1ieVQXr6MwEHutAUZtj1UVF9l0Y6kRdy74h3IBEZQQSAKQAvspBu20UBs3dknyINNrdY21JuAayJQJ5t0FTWlfvKQP4TJBIHPWpWSLFty+YAqBsZgkjx5UDEDPKyiidzJPUk1Deuso7JDA3YgkEzyqO45IQZWIC7lSQPjzoSE2SllykkgtHdQGY/mMxVW9cZnspbRWeZh3K5T1MSflRWy2Z8mZXI1YOVCL58qAsDLAlmzMpctmI03Yx85p0Ky39vt4aybGEJa4xP2nEMCGLHcLM+VDadQWknYa3Cf0iqSYe+23uTJZe+SPCNKuLZyIo0HlaW6fWSI+NOgszg+aJ2JhVj5miFxklSUGoAj+tTXcHbtOUs3DcuGID6ZfTeqzpdtSrhe1A1grGvKlRTQ74hxAQ5hPeYCPSoydAGlJMwDGerOEsW7zJ2tzKF7zCYB8Cd6kxItdsWXK1tYVQEkacl8KBqJRTC4u/zmbgW2mwI6kiixfDcVauWy1y1qMp7NjK/wA3OrNsFFv3SIJhbXeCwx10WplwjWUbFX2t3Ll22cq3GllY8xFFkqRnjDWlVFW4FZ2HaO091at4bANxDHJgcBAzAG5dALJbtDRrpJ18hzOnlHZwPb952gdoq5EGZ7jEwEWDudq6DEYPG4RMFwHANcs4zi6HEcTxyRmwmBWVyWiDozaqmnU7nSzHH5GQm9V2H2gezf4TwO42E4VgS6Y/iVuGv4rEyA9nCvsXP431C7CSNJuGjC4JBYw1pbdo3GfmSx2zMzd4k7kkk0OMuYDC4PDYHBWylvCImGtKo0GQkEADUknfqfOrVrh1x7do32eyEAUJbXPcgD8RPdB+Nb5Sx8eF5HRiSnmlUTbt3SxtFSp21mB5VLiVvA5kYISOe08iKy1AswLaNI/FdYs3w0Hyqe3jnLJZxFwBHzBCFUsGUTsNYrmY/qeCeVQhff6NcuJkhBykQhLyHEB2BYt9rQ/vEFUuCNv3TXmfF8KMFxvG4cKBbvObtnMcoyXx2i667GRXquK+z4ayuMuXQLNq7aDMSYIvOLGQxrrm/uK432w4VdvW7WJso738Ixs3BaUs7WHOZXAUT3Tr61bkksXJU/Uuv8ix/fh19xOFxCXxdyZYB5jVQOsxViziBh7SXL9zvHN2Slg3dXTM2ugora4/EgL9jxfaarKYa+UYjeDlqe1wDjFx1deHXwVZWD32tIAQZBCuw+lbHOK8tFTg30kZV2xj8rX7mFxS2z3zcezdVMrEQcxEaz86hS+1uVGqEyQTzrs14J7V4iRdvHKQQRiMdcYEHcFbSsKJPYnFP/m4nCJ/7Ni65jzd1Hyql8jGvZL4pP0cQc1xixEyYE6eEUwLqe6SCOlehWvYHCmO0xWMfwtpbtj0hWPzq/b9huDAlrmGxV5iZY3r93UnwDKvyqt8qBNYJHm1vEXQGzEQqlzPQVYt4y1dCobiEbgM0fDlXqVj2S4JZIycLwax+K4i3G/6p+talrguCsgdlbs2vG3Ytr9KrfJvxEl8P5Z5FbtYi6ctmxibw62cPfcfFVIrTs8M47cylOH48MBl71rs1Ycie0Ir0/7IgMZw4EzuB8ZipBh7A2VPmaqlyW+miawpeGecrwP2hugF8H2Z/ivYdR8nJqUezPGXUA/ZUadzca4R6Kv5135UchaH/Cx/OlqNnA/lVR+tZny6LlgOLs+yvFtC+Jtgj/TtN9XdRV8ey13E2msYjE2RbfR+0UMxjYqlomD0OaujJXWXc/8AEB9BQhkUhl3GxLE/Wl/Pr2H8ZMy8B7Irg7ZsftTFvZL5javLaKE9VBGh8Qamv8A4UGKticRbIkAZrrD0XNV1roOp1PUnWgdwzZjqdBJM7edVT5ODI7ceyyOPJFUn0ZH+zPC+XEcWNZn7Op1Pmab/AGZwcnJxO74C5g5A/wCVhWz2lLtfOj+XFeEJ4LOavcCxeHJNtftVuSQ1kZWH8yXIPzNV73D1s2F7btLV677ttwRpOo7w+NdcLh/vnVa1fD3cTg74W5bUk2xcAMKdcpn5VNcyLXaF8FdnIXsTbsns174UAZZ2PTlVVWu32OVSEB7zEwAOgNb3FvZ+2ZxGCBkHMbDMSpjU9mdwfAz6Vk2EZEZypS45IyN+HlCgVphkjNfaxOLvsP7tbYfITakAKJm6fPTSpZdLZchU8dYUHZQsyajXPiWy21g2yAQSTHU9KG52JuZe1z9kMp7whjzIWIirEhNkRAc6mSZ1fugT1ij+zqVnIrwJENB84p86MIyKF1AIET41EuS8QoEhJnLIX0A/WpkCUYe0tq4We2UO6ro3wGpqLEYp1tW0FoIqjKrFcuZempiPSnuXiECqph+62QAGByHOqrnNcVQbbXHBOUiWt205kDWkMsYdrshmLKBLa5baII0CGgfEFmJN1FMnXs2I8tKkuPmtm3bVsxALBWAEeQE/Os+01pgwcAkEiTmg+FMRpDDYzvuVHaMdWusVMdZOtBdsXUUFjagafdnMSeskVFcv4skKVidOZ+ZpgMawAHdWegP1payq2VbIfLmYLmeesaL8KnezaySl245XugNAHjtRdhfUoWfRh7ywKiuYW8T37nc5SxH0pK37C/0BkYRlSI5yN/Wgc35BdlBke+wiNhuYqxds4a0ltnuoA3dHauqifNyBXQ8G4TwFRZxWIxOGxmIYB7FlGBw9qdmaR3iOXKlSl5Ydkns9we7bYcSxaRcAK4O02oWdDdIGknYf1qzxKzew/GcDxFbZa22CuYPEkK5eEcXLZGUHYyNxW4muvbIW6B0n0E1IXKgkloykk7KAOc7VphNYvBCUd+mcdjGxt/G28Vh8PcRkupdBt4bEsQU2IGSJmsziPtTj8IBaxNnjIuJINq7gruFAn918zKfhXf4XG4LEh2sX0uqpCsUaRPnVglbmmYR0O1Vchw5SWyJ4oyw/0s8mT2oweIJFy5j8OxOvboxQHxe3PzArSwt+6LtvEqLt9EDENbD3BlYFZBUEV6QFtqQctsiddDBHjXKWuFcbs38RYtWJwaXbptXs9sr2RJYZFzZp2EEVycvG/jyjlwq6Zthl+VOEzL4pjbuPwF3C2uH47XOCzWryKrdmwVx92ToTNb3CcTicRZ4c2LxNm2LmFtXL9kkC412MhkXVncabUQxosBbdpybVtUQdqIcEDUSfGiv4zD4ruNhrKggr2lwm44/lOkVfn+pYs0VXVeivFxZY79pmjewod7L2ls9nkdWOzGcpB2y8taH7HoCFt9QQq60OEwdpbS3bVy5aaGzZWhRBgkDandCVAS8WuCfeGQMPDXerdnLHu41ZGtZa2NkdNYXTqgIoxcxCCQlsjwUflVUdoDGYzzGunnNJu2XVTlPKZKN5gfUVzZcjU1KCZcGJvEagT0GkfGmOIcfva9Dr8qorfFzMPddIzqSMyztrzHQ1Il91Pe1B3HOqf5km6baJfEvNExxLbEN8aA4gnl86s21w18d4jyAE/HegvYJRraZhIkLdWAfI1KSzNbRdkYvHdNEJvnp86Y338Kja3dUwyNPgJB9RQkOBqpA6sIHzrC8uT2X6xDNxm50Oc9TUD4jDW57TE4ZI/fv2V+rVWucU4RbnPxHB9O7dD/8A65pJZJeEwuK8l4uetNnNZD8f4EpI+1s5GsW8NiW+ZQD51Uf2q4IpYKMW5G/cs2h8blyflVseLnl4i/8AYi8uNezoC1Nmrl7ntjw1TCWB1m5iQY81sofrVS57aL3glq0I1XJYv3CR1m46D5Voj9P5L/0lb5GJezs83jTgs2ignyBP0rgbvthjmB7MYgd0uMgwlgR4ZUZvnVC97RcVu5yxYrCsRexGIuAqx1OVWVdPKtMPpmV/1NFT5cPSPTHvW7IJv3bVoAH/ADrtu38nIrPt4vC3MZev2cRYuWVgXLiXAUUBO8zMYEDma84binEA2abHdZ5RLFtQ4WCAWAzwf5q6q4uAXC4NcbaW7YdyCrNbUuXLXAue4QoWRLa7dY1ul9PUElt22RjyNrpG43HkxGa3wiwuNIDzib7PZwICbm3lBvXI091QP4qzsThMUmG7dnW9jmD4m4mRbaXEe4ylraqxgg7CfrVPC8X4Zba6i3UuszIClsKQi5ycxeVDNAUCAeetPe4hgTcxF+xdW7jBgrxsjDh77/aUu2LlpO4SJhWneJjnXUxcXFhxvTt/kyyyznNWVcHi3tLeDqXfENKMCQUXfVjTEBiMpJBOozd3N4xM1p8WwXZXbeMUG1YxCBsh0Nhzq1rKNonadKqp2Ni2r/d94mDBJOkyx2qjHNTimi6SpjMri1Bb7zm4GUBeggUMEpbYnuzCkKxJbqWGkVH2hZYWWJkgAwonmc4/KjzWey/zWGXyANz+UcqtEQ37l3tFCZixEKAYLN1quuHvG7Ja52l/ulmyi2I1IknWnfD33xVlIIN224DAd0CPxHQfOrrW0t2FJYPdUFEIGZVIHITSsCjicYlq3esdmEdMqggxJJ1KwI+dVxcuh3gZlhcsoTAifxmpsVbLorgZQ9vvELILDeJM0hhjltlbjksisVWGj1IppoiaTWruUsdZbQidqks2rrL3mlOWv1rRyIi5BBjkYqDIEJMoq776VmshSAuWiFEHWNBvUFom6+RxqvI1Za9bAJLSF6daiN60zSndMR/FNK+h2V+K4c3MJ92mdgyDJrBJYCSo3ia6ngXCcOLNi5Oa3ZUWrVpFgZkAk6GsDCLjcQzXCHGHtN2bXshydo34Z2JFdrw7E4BbSYPCZ0a2vdF4ZWdedxTJmTvQtXJKfosTlr0Z3EraWpe2uUNKsp3BUg1Qs4gq6k3r9lcwzPZchh4xsR1FbPGFDWrjiNGtkx1IKmudCMQTy0NYOVNwy2masUU4dlu3jMVZuX2V8NlYqF7KyFDqs95zlGpnpVpeKYgAFrSEdVLL+orM7MgDel3xt+lZlyJx8MseOL8o2l4wkgMtxfIhh+taWGx9tgOzZbnUA6jzG9cnJ5gGnVmUgrIIOhB1rRDnzi6kVy48X4OmxCcNvYjtTZxC3YAdEyqt1mkHMIO46RWeOFW/vR292yudmRrhVlVdwrGNl561nYnE8Sv4W9ZsYkW75CrbxDqzPaHe0XKQefWq731w+Gdr91zh8Lhi112JLEW1GsHmY+dSllwzW2tt+hKE436SOiwWOwYw1vCHEWziA2UkBwjwTojsADyo3Ou8axXlFj2r4viMayWuH4e7hpnsEUq6W+rXydD4kR4V6HwviFrGWLa5nLshayGEXWymGt3Z2ZevP5nS/kxxUJql6/8ASqOjdx8m1EhLoOdBC96AwjSDXMfszFPjbtluMcQwmKvvduYe+MQ/2a7JLDMjSJA0IEDpoa6QJesgyylLmVgEkqy9Qx5jY6U+J4fg+IWCrKMrmcxZsyOOYYd4HoR/5eObxyvW/wAoU1sqs5jF8O9qeHXbDX+PvetKGUXBhsOSWZMzKxdTtpAg8jVS5xH2jW/bw+CvYXiDuxA+5wqoBMCWDW94M9PWtLH4vH8M+ypird/EYZVGDxV23b7S8FEhL2UArmX4HqMxBzLeLuX1u5bOIxjuD2OTD4xTbuQRmKpZyxOsTz3rdDHxM8d5RX/H/Rmm8uN0myxY4x7UrnZ+HcNZEE3GS/etMoDBNYNwTOlWrXtK925dTEWDgHRirXr7HEWMy6HJ2aqdOZYAVg2sJ7cYlgbuDsoocsr32uWWY6DM6WG3/wCGaNfY+9dvnFYvEWbVxjmYYZLzHMdSwfEXdCfKseZcOCqLr+xfD55Ps6q4/wBotJcxF27ibb62zdujsyOtu3ai3HpWHjuD2rg7TBBhcksQzdpHii3dPnV/BcLwGFuGzhsRxEOba57eSzdwzNOtwWsNBzfvHL8d60reFNyRbu2rpU5SLLHOD/FbaGHwrnrLkxy2xu1/Y0uMJKpdP9Hl2MXi+Gum1fxF0QJDWkS2y+MBM3985qo74wwDiL5OpE3nCOPA5t69dxnA8JibJTHWw5kC3oVdG6rc96a8v43hcBw3GXMLhsS15YZiCEUIJGWCGEk6nbxiTXc4+f5ftkqZz8mPXtO0ZTKNmLEMZBZiWU9Gk0EJJlRuQ4j5iiuPqJnbLzEjfYqP+3nvUZYEaawQDGoA8YJ+orWUmjgeHfarV/EXWFvDYUoty4342uHuW7YkAk6neAATPI7f7E4Ra4Rg+JYj7ULuOxF5MDYt3LCA4e3ocQ7OnM7DnI16YWDxtlcLjOHYhilrE3bV+zdBjsr9sMoJUASGBIO8deR18Zxq1ijgBfwFm4MDh0wmGX9o31w621A17Oxb7SdNdv1nFJoi20Y+Nwn2RrZR+0s3FS/ZuAEZrV2V1B1BBBVhyI+NLP3Ao/jRd5Okir/FeI4fFqluxZtWrdu2lu3bsqeztqrNdc95nOZmYmJaABqCYGT3yGOsEqx7u56EGD8T6VBklZKLyLctM5ITtUZmUZoEDNEH6GvSuFYezxV8DYw7oyvhr2R2trdCkWiwfI2h1Gkn6V5h2N1jlgloI1PJdRvr9BV3hfFsZwi9aIKtYz5jbfvLlYQwg6QeelZs+L5Er9F2Oev+T1O1hRbVUu2uF2LoUB0t5sdezRr91hFyj1uVb+4tITdOIbuwis1nDpMaHsMMSY/muHyrEw/FRew9q5YZVtOoK5ABB5g+NQ3MXuZJOvPWuHPJTahGv79nQUE+5OzRv/YRgRw7DoRZRPu2uHM/ayWzsepJM+dc6CpFy07ZYtjRjIB33O1R8Q4quDWwzE57t1UtJMaAjM5PQbeZ8KmunNdV1CsjqGAYCCGHI1fxtsfUvfZXmafgp5rjISmSBGqFmYx4CpsG9w52uyQSwBZTEgbdKjSyqk5F0YFmYNJmdIipFGVACQsMXhpEzpMTE1v3RmsnDkuUDKQokPDd6o3W6MwFwOnvGUIJ8J61A4go6uCFOq5th/w1I95shzO2WYiSNKr2DYkQfdhWZGAlrbNqyz+ExvULs7BFN1jlEDs0KiOkTVS5iWXICANSVcc/TY0Ju5+8zNr+6I9aLYti4uIvguzsZbodPSmOKuaAtIjYHvT48qAoo0OvqTSCr0FdFceCM+7GN++SYUa6CSdPQaUjdxZ0zhQRlJUQQDoYO9FHShYb+GtWfHFLpC2Z1/GeL4LB8EJsqbX2SznFplJRbiLltqDzkmfTWuM4BxC9hbiXr+Mxd3GX2N+72twtZV9wqKT7w2MCNSOVXfad7l7gRZdc1zCZ+kExr61g47D3cNhcDdTPlW0byMxAKs6rfK+YJYelYOPH5dnkX6NOWTg1qz1XE4i3fwGHdP8AfkMD/LqfhNY9wkEAdIqhwDG/asCEJMoEvKpnRL4z/WRV+6NSa4PJuOZxfo6OKnBNAC4w50Wc9agLQfPWnzVW4osJs58KcMOlQ5qfNVbiOydWGv8AKPrXPe1uIazwi7bWZxOIsWdNyqzdI9SBW4rd5fEMPoawfacx+wpEhMXiL8HYtatKyz6xWjiQvPFFWZ1jZk2MvCbVuzYyG+htnHXHCv8A4m4J7NVbTu7EmegG5rT4LxsXcUis8PfMLKhJvWzAIC6eB0G+3TJuYVu1wKoT/icHdF5nMD7XhXa5d1PPescC7atYS4lwLcuNca0ykSjC4Tm+lenzQ3xvG/DORjlrJSPa7GPYKguDNbeHCkwfMHqNq2cK2Fus722Ou+wkH95RpNcRw7HLiMJhmfVbiByU3t3dQ8eEgzWnavXE9xzB0lToYrzsM7xvWfdHVljUlaNviwwIsTc97S2APxqx1U6zArEsWOF2w/dN3MSR9pe9dySAIXvjTw8ak4jjLLoj3PdsWLl28xJg5QWJg1z3DuLWcZbBsYm1cc6vbaBcU7xkbWo5JS2c4dDhFKKjI6QJwvlgOHnTd7d0z6ZiKbseH/8A0vCfXAWWH/WTWYuLI95EPWJFIYtIGZTm1nKdPgaguRl9SJPHH2jWT7Nbg27HDUZdjb4fg1I8jkoMcxx9zDXMRfYtYfODaW1aLiCMlxrahivOJ5VlnFWjtmHnFEHUpcum5ltW1Z7rtoEVRJJoebNNU5WChCPdFni/GU4bwq6TcdrrnssOWuM7jNoRbzkmeQ6TPKvLXTFXjdxN4wbr6n7wJO2UGMsAQBrVriXEbnFcbcvEkYa1KYW2SBlQaZiG5nn51TZoA09SpHz/AKV6DiYXjgtvJy809pdANh4nvIywCGQ2wCfJcv0NC1u3zuBhp3mmQSJ0Vln6UzGZPj4N8zrUczmHiOvj1rWUkmWyA5XtXUDM5VW7q9WIO1H9nvzYRcHfLYh0t4dGUg3HeMoRSBqZEedTYDHDAjEFrZZ7j4Z7TZwvY3LXafeBTKk97QFSN9NZWNsdaXF28dZtZMUuMTHFnuteTtUftQFXKDlnXVieU0dC7LNvhPGrt+7hbeB/xFhxYvWmdc9q4TGS5qVB8CaqYlL+GxGIw13s+1w117N3soKi5bOUhWHQ1dse0/F8Il5cE9jDteu3b969awtpsTcu3GLM74i+GuT01EVjteZizHMWYlmZ/wATEySTuTT6oXZK1x4eSSCcxDEmZ6yPzoXUOsDltIGgPlUJuMdhE8lnMR5HQUSkhWZioC/iI7q+o3NQJmnwLiTYa8cJfaLN0gAn8DbA6/P+ldPiL1uwl17py27alrh5wNMo8SdBXnTXZuF1mAZGYyT4k10GOxd3F8N4WwJKh7lvEZT715FXsy/muvxrBm46lNNe/Jqx5motMoY3FXcbee8+YTpaQDREHurP18fhXVYK/wBvgOHuYLG1k1BPeQxXINBAyhvEzqT0FbvDLn/wu1bJj/E37a6wRENAPrU88Ekq9FcZN3Zsl377kAMNyR+goTcVkEzmBkQNh4jeqtslS0XH3GgY6DzpXrjAsSSDG4/Os+oiQOo0kEjXQChzm47p70KSRmj5j6VSW73jnuGYBBAmB5UBcscikhSddCST6VYkIlvMzKiqQACdBuB0Bmo0Vrg9wMFkS7g/SiuW3yCGbNECFiZ8KOwhtJBiSdZbL+VTrodM0IiZp4FLXpr400dZrqmURyihJnlT0JoAtYwfaPZ/HKTpbtoW6AW7qsT8Kx8TiLF7A2cFfN1MRg7uIt3VGRxdOc3LZVCQ0GdxtPPYbmAi5Y4jhWMi5YuQDGxUg6HyFZF+1hbt3G2MXacW8I2Hw6PhriW8ReOlzDgBkaZDEDYjryrFhjrOcTRkdxiwvZfFi3iUtEuA/wBow7C5o2cHtRI+MV2LjMOdef3LowmOu3FWyjWcSlx+xaVNxf8AM1+VejYSw2MGZHAWFMnX3tRoK5H1PE/lUl7NvEmtGmZ1xSPTWgBrcfhdwQwuK3gwZZ+orNxGEvWGYPau5RqHW2zoR/MgIrHpNLtGlST8FYMKKajJQfjUHbvSv/dFIEHRSCf4SD9KraJWTA6oejD56Vk+0dp7trhmTVvtbWRy1vBQNfStNZBWQdxvVfi6dpg7fIpjsAwI3E3OzkH1FWcZ654v9kMqvGzm8PiLWJwV6y4c8QwnELd6wkGbiuos3IOkTPyrKcYNnTEHF27mHwy5TCFLr3Gdgp7PVY1nfl41q2m4bdxGHa+ly5ixcxWAx1mymY4m3G6R+Mb+njWfhV4VcXH3r1q4MGXe0yoAb2bsyVdbeYhSNTvyNer9nG9G/wCy2KsvZxmGt3GudjeF4M8yRe3ifEfOuos3ezYGAy/iU7MK4XgiYPA8Vwy4e5ca1jsPcVC+gfui8pECJEEGuzRtRXmPqGN487a99nW40t8aKPtRjQmAxnZyvbCxgkGgPf7znpsCK89M2yGGW206OrNnUjplkium9qb2YcPtATmfEYhhPQi2s/OuYcgZNUTSNs089zp8xXT4EKw2/Zj5D++l6NjB+0fEsNlS+ftdkQJbS6B4Nz9a6HCcWwGOX7m4RcA71txDjxgVxajNEqzSwJO2g8K3LPCgycOv2VvWcReNo4e4PddhluORmGwGrQY+NSzcPHJOS6DHyJJpPs6exbuXnVV56zyA6k9KzfaziK4PCWeGWSc2IC3cRBg9nPdUnxOp8hXarwlcNhe2zN97kuOOSqRsZ1mvKvantX4k95s5F03I7sKvZubYRY6AD41g4eFvLcl4Ro5E6hS9mcmJtkEByJ2zgZvjQM7zKs0dVlz+lVAjE+6fUEVoX8OLNx7apnRB3XXEIyQABmGVpPlFd7tnNK5Zm5yZ5GW9TtQkfHnO/wDzGjyXO7BQjabkW1X6mmgEEZ5YHaQV/wCUa/OmAAUwCAfQyPUmnAHgPXKKsJgsXdnssLir0x3reGvEA+ACxVheEcT0L4S4umrYp7FkL5dqw09KAM8xAPL4ifAUM6iIE7DZz4AGtMcMZSGuYnh1o6kn7RcvMPACwrD50f2XhVoE3uIsxJBIsYTUx0fEOp+VAzJIMBcrbyR7w10lmH60rthmXSBlMSTlk9FU1rdt7P2drWKvGZ+9xFu0s9SthCf+ql+2sLZ/+W4fgrZ5MbVy+/o15o+VK0HZl2OG4y+RktuwMTlBy6/xHSultYD/AANvhd23cS9dnsrjFTYF6cy66HU5l/4qyX4/xO4CBeuIo5WzbsiP/tLPzqBOIYoXFuly1xScrXHd2UkbjPInxioS7VEl07Nu17MEOqYjGA3TtYwiq90+e4A8TFbGL4ZhOH4DCWMOB91eLstxx2tw3F7za6mIHKuf4dicdilxLXcTft2Fyqq4ZzazudTmZe8Y0586urcw2lu2hLMIYkOxb+djr865s45HL75ePRf8kEqih8wA7kRrMSSTUbqSsyRqD3jv4VbzCzbByKo2AG5+OtUs9y/cvKgPdA72yKTyE1NXf2oqCsYDG4m4MiwC4kkqu3gTW/a4bhMApuPDXzpnbUAn91azsMVw65TeFskjudnne4f4XJ0FWeJX7dvDhGuFXIkKXDOPHVqudlsVSAa/hyzjOghiIyiT5TTnLCzaJ6FVkEVz8XC0wzO5EaErHUxWmMYbJNuzN0qALnZglFboJNFDUr8lvnt+dMQddqI6bCPKhJHh6k11DCDHjQkTpFSSP/G1NvOmketAD4W52GJtOSAjEo5PIMImocff+w8e4ZfV27O9gsOEe4giZawe/sYgQehinb+5FQYtMRjcHhsJZCNewOJbF4dWKqWtN3nVWcgb671DT79kNy6oyuIiybyYi2RmxuGXEX0AhUvHMjgAeIP9mun4HxK8cBgrlu4Rctp2F2DrNvu6+Yg1x+McC7dTOjrbBUNb92WOZgDzg6TUGG4jxDBq64a+bau+ZhlRgTETDA1j5WF5lS8mjDP432eoL7QcQmALBC83QktHUggfKrdv2iTbEYUjTVsO4/7X/WvJ/wBvcaUaYlf/AMNj/wDzW3a4pcGHsHEYlDda2GuQi+8dYgCKxx4ubxZe8+P8HoX7Q4DidGui2x/1le0SfFllac8NwGJAay9q4ORXsro+K615w/GgDpdtxHumyD8wwNAOP2lg9mM371tjbP50nxJvykNZ4+md9jMDawCW7jMitcaLSAOrMObZZ2FZuOm7gcaqauLPbW/57LC8P+2uV/2ktswZ7d9jESbwcwOUuJ+dWbXtPgFK57eJAnUBUYEdPeFZnxMsZKUV4LVmhKOrZWxN3DYDGcQxQcMxv2eIYa2VjM160RGboc0+lXUxlixYu4y/fV1Szw21icNbsW7S2bWMVy3Zqvd7n4QB+En8VUcXhrfE+GWcfh3L2uGOcJfQqFu/ZGduyuEa7TlOtZiFrzcXs6lbuGtNbn9/C5WX5TXfTo5jJlGM4PjLWHu96zavWsZh7omCisCWTwYEz513ocAk/CuFxGKfEYDBo/eUZltMTDqAO/aI3iSCPOtlPaLhluzYS6MT2yWraXcqKRnVQpIM7VyvqGGWSnFWbOLkUbsbjvCeK4m/hLuHwr4hEsZD2bKShzs8kEjeflWans37R3QWTBhQN5v4cGD1hiflW7hvbizg0y2MPduans2uKqso5rIkxUeI9v8AF3CTb4fhlJ/Ew1+M/lUcT5MYqCj4/wDvyOaxSlbZm2/Zri9tkz3MDZXmcRiVmDvAj866rAWMDgltdvj8NduWrS4e0HvoyWbAbN2aAHmdXPPyEVy1323448hUwqj/ANoN/wB1ULvtPx26TOIRZ3CWkX6CjLi5OaOsnSCM8MHaPXrntDwi8i2r1xQO6T9nc3Pd6Ap//VcDxvEYBsViQ9m9ew9y721hwFdhIhsrZhE7kQPWuRvcS4hf1uYi5ruFMfSqheTLS09T+dacGHJje0nZVlyRl0kdC2M4Gui4BzH+rirS/JQTUZ4nwlYycPwIj/U7W6fWFUVh5rY/APUmKkW8q7WLOnVAf+6a19so6Nf9v2kGW1hOHKRzt4DDyemt3N9KE8e41cgWBeUf+haW2PTsLY+tZ68QxCCEFtR4Iv6UX7Sxp3f+/Siv2BbfFe0WIBzrinn/AFrtz6O4+lRjBcWuHvPh7f8AM4J+CA/Wq/7Qxf71IY7FjZqdILL6cIzQcRxNl/eFqwz/AALOPpVLiWAt4Uq+HuvfskAM9xArq/iBpB5U323F/vU32zFkEFhBEEEAgg9aVL0FlCH6/CnCkkSZqY2yxmInko0ohYJH4qAI9B/fOpLNu7fbJbWT+In3UndmP0qVcIT/ALtj5yatW7eLACrmVRsJIUegp0I18N+zMNYSzlvXCvvEwodjqxMGrS43AqVNqzcX9/RWDeQJ0rFWziY1OvmYqdLN2NW+tQ+KPkadGw/EsI+QJZvIA2Zkt9iFc/xEgmhGPwsMi4R1U6lUdBr19yqC2201+dSi1qNoHwqaxRHuy0MdhgO5gQGjLLXM0j+KVk/Gmu4xbxUtg7MqIGbMQPIf1qBUAiQN/H6UZVTMAAzqIMDyp/HEW7FnuwSiWVB3yrPxNOucbpZMjmh/IilECIXU8gKNZG4HwAPwp/HH8EdmEWadYEdB+lIvET01oSD4TyMUoPONt9Zq0iOLg8/LehLaxGvnTRvqAekChIYbAiOa7/SkwHYt8Nt6r3kdxlDMrbqykhl8iKmyuCIB118PWnhgZE789aBmBc4bjmJANo6kyXIn0y1F+yMYfeu2h/KGb6xXSFWJ1Ak8wKQTSCBp5fnUdR2c6OC3NCb0nwUAfM0TcLuk63WM+J/KuhKbcifAzTBBprRqFnOfsu51+JNAeGXhPdH9+ddLkXpSNoGI1J11pahZy7YC8I0+FAcHcH4W+FdSbY2geoNMbI12g70ahZj8Jxb8Pu3EuIXw2IU28RbMgOh3U/lVo4PAW7hxdjH5bZYuLJs3HcLqMile6dNNSKtnCAkiAPSqtzha3CStxln3oC6nrRTCzLd7PaEWlZbFstkV2zMBM95uZPP+lVWMknqSa2W4MxAAxDAfyJ+tN+w7XO9e/wCgfQUqY7MWQPoPzpEeIrdHBcOD7zE+JH0o/wBkYccjS1YWc9lp8prohwrDATJ8u6D86L9mYTTVz6/0o1CznOzY8jSFtuldMOHYIHVGJA2zfWiXA4MR9z8SaerFZzHZNRrh3PI/CuoGFw6xFm2OfuiaNUtg6Iv/ACzRoFnMLgr7bW2PoamXhuJb8Hx0ro49PLnS05jTx2+VPULMFeE3juVHrP0qVeEjSXPoP1raIBjT+/WnyydJnyp6hZkjhVgHUsfOAKkXh+F/d+JrSygddPgaeAeQmjURSGCw6/7tfhM0Yw9tR7oHhl/pVqNvypc/6madAVxaXTTT6fCi7JTAymetTwBpJHnNI8z8DToCIWxzHqBT9mPD86ljTX5zTjLsC3ToTQBFkHUem9IKsc4+HyqSRoQNjGgpyFkkfSmBGQunlSyjlNSQpjalCjrHwoAjC8tfzpBT5/GpCV6GYjQ0hp5cpj86BCI8V38aQA86bMBJ/QU+cSIkn0g+tACgHr6cqfLoDp6mkLiz7wGkQKcMDzBM7g7GgBipncSOhilk58/75URcZm17x6nWTTmNJ+hPzoAHLPLXbT86YKYPhpR68vlNLWBPLUzQAEHy036flSy6SZI5nTQ+lGIJmduppoHjH970ABl210GoinCzv8jr8DR+e/KOQp4MT8jA060ARZAJgCOfX5Usgjn4QYHwqSAIG533pEHfUeZn5CgCPs9iSR6TSyjXUz1FHv01686Wwg6dPH4UABG/9/Omyt5eVHIjafDWPjSB0/h250DBgaHwOhilpp/5ooj+xPzpaf0igAZ20HwppmYAo9Igj1pZRuCPHU6UABr0pGOmnXl6UcKBqdTy5U2Uaxz/AL2oAj16aeFON9vPSTHlRQfTwpHMB4T60ADryAEH1p/DenOsECNOW9LKQJInziaQDSNAJA6bUtNT9NafnH9aaNuk60AP3THXbw+dMSOhB5EHSlpO8ieY/Sn+QNAAj4eM08a670jvE0xEneBznSmA5EbCnBA6eu9D4Ajw5Ux0nUfP8qADnkDSkGBDEDkDpQg8w0GdjJn1pQZJ/MUAFMCIgeM0sx1A2I1gUHe1OnpoaWo660AFI/uKfTbnQa+h5mYpagzv6UAFyJO4Pr8qcZDv9YoCTroRPl+dIFtPLmBQIciSO6YJ8KfTXT47k04Ugnn6U8DnQABEfhEjoKYKNYBE9BGv0owI08dRSI5dORoAGCABr4GnJaAJPqaeI5kz00j0pQ2umnUyQfWgAczgnKQdNj1p850kSecxHpSAcAjkehApe7G51jSgY8mNQBpsKbNl2Ek7mQPpTMHEQJnqNqQB6CeelABB53+tFnB56+H51HB1Mil3Y/M7GkBJmkyPlSzVHFsAzI8NI+dMAp1VoG/dMfOmBNMzJ+Wg9acmNJ18NZ+FRA9OnPWlLDX4zQAYI08fOn8tqil99+hjakWJB7rEzvm09RSAkjSCDp0Ip/j0OutQDODqRrtE/maKZI0jlIG5oAkEHkdPOkJjTf1+dBLAQCPr86UmBI8qAD8ZPqI/Klp5n40OcgCAJ9flypBm3Zd+m9ABtOsAeYOtCJAggT6T8qFmEmQYgeFIMsaA9fCgAgJBOgIHX9abUDcb7zQ5jHur60+bb8tKAC67fOkIPKfKZps3lPIdaEsB5UAEFMmJ8f7NOQIBgR5UGYHw56jlTyIJ1PlQA5Iidz4b/OkczaR6DQ0IZYmfSKcMnUeWtADQZ1mBoADt50cHlvvEihkAn+/hTZ+eh6zQAQGo0gb93SfGmOnM7+X1pTpIyDrqc3wpsyEbQfM60AOSRGo8JExTGT6egFMCBz5+Y+dFCg6HTxBmgBx/OmnItpQltd9OcCQaWnXXpG1MWAHvTNMBxmMRHrFOsievpHzoehJXyk/Sn0nQgCkAbBdTBEdetIBiILRPifpUrf5jVHzapCEo8iPClEGANPHWpU90+VB+IeVAEcZdiR5Hb0NEOZLHXaAJoj73pTD3m9KABJGxB2mVP1mlpoNdpmDNL8XrSPvUgG5jr/fWnkUbe6vrTD3TQAHKe9rvTFR4geEUa+61CNmoGPC8h8aRgaACD50vwimPLyoAEg8yR0/8U2TqfHnR/pRcx5UgI8i6mTp4jWhgDr56/OpG/H50v1FAAqGgg6j6/Gl95ERA6c6kblTP7x9KAI/vdIOnh+lI5tARPlRLuaM7HyoAiLDugCCPeMg5v0p9dY59RTCnPunzoAGTGsDwjfzFMSSdNF6CBRj3/hQv73xoAUqAT1phJ5adIpfhb0qQe6fIUAQkNM6x0gUjHU/SpKE7mkAHej3gPPX5U4YLAnU9NBQtu1GuyUAInaAB4nWhLOdPiRFJvzpx+H1oARLGJJJ/i29KXe1kj1p22Wl0oARzeaxypttZjzFSDnUbe760AINpvPwpSeUyNTuTTJuPKpF3agZHJPnSlgDv5ACB60w3H8xo/wDU8qBAhlggg+dLMo1AJ8oofwj+ajs++38v50Af/9k="
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>
  <div class="one m-2 py-5">
<?php $v= "Ferrari Roma
";
    $p=" titched together with leather and swathed in <br>faux-suede"
	;$i="https://th.bing.com/th/id/OIP.iJc7cJXxZ089ukLvdA79nAHaE8?w=262&h=180&c=7&o=5&dpr=1.25&pid=1.7
	"
;?>
   <img  alt="<?php echo $v;?> img"  class="img-fluid" src=<?php echo $i;?> />

	<h3> <?php echo $v;?></h3>
	
      <?php echo $p; ?> 
	   <a href='coupeinfo.php?type=<?php echo $v;?>' >   </p> <button  class="click"  > see more </button></a>
  </div>































</div>
</section>




<!-- footer of webpage --> 
<footer class="mt-5 py-5" style="background-color:#222222;">

<div  class="row container mx-auto pt-5"> 

<div  class="footer-one  col-lg-3 col-md-6 col-12" > 
<img alt="img logo" width=50% height=70% src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAABJlBMVEUAAADrHCQGBgYvLzAREREgICDyHSUyMjLh3NxycXdtbHJHR0fzHSUWFRjj396xr7BeXl7U0tCqp6alpKeKiY9/foMkJCVdXGJAP0O5t7iAfn+dnZ96enqVlZjmGyPDwcLMy8mvFRvWGiFvAAAzAAAkAACjExmWEhd9DxPCFx5+AADscnLsZ2fsU1TsTU31SEnsNzhnCA1MCQwsBQdfCw+XEhdDCApwDRFSCg0WAACPjYxQUFNVAACYAAW/AArTIyr3W1/zi43ylpj3h4jSY2a/UFKYMzbwk5S+QUSLIybscXCyKy7sYWC7JCjwSEr0MTOPAAK0DBQ7SEhUYWElODcSJCQyBggAFRSGEBT/bHH+g4jcSE3kNDewOTuEJinXTlB0JSddGxzdYKaRAAAIY0lEQVR4nO2ai1/aShbHEx4hQSSE8AohzwoSbRUQRcGudru73btVWFtrua3du/v//xN7Js+JttYHgbb3fD9tncycOXPmNzMnD8swCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCILcYuP42Rbh2fHGqkNZPRvPXv7lZHr6/NOrN38lvHn1evtvf//H6M8qzWDrojd9/skV4w3hVcjr7bN//na46gCXzdCyd0+3XwPbIf8iPA84O9152z9adZxLY2jpu6fuvANevHix4wGFoLgz3b0+76862GWw19Fn00CC6W6vN9NZrkDBsrNeyGymWwerDjlhRg7X61378wUxOCKHbjsX/956Rtjaennh2FDHsQFcwe6uOuzkOJrr3AxWXmd1d7JcgbWtrcPs5bv371utZrPZarXy799dfmA25pYNeoWysJ2rVQefCHBoosVniR77x0cf3rlqtCjIVend5cd290IPtwvHXvx6R+jKYqnjwOlW/yh1uVa6g8nlR6Z/EfbiOGew6kkslD2LOggFvTNkUh8aa9+l8SEF560QdvyFVNmzClRqsIYM87GWuyc12CxOoApbcH6NE9SO9oh3C0llsrXsvallU8yhE+0V6xfItvtRRmCtQ6LIw0kxQzvy0ln1lJ7IPLzXcPrmHlSkHgfDdClPP/PzSt8OM4E9f7K3TpRW7J/1BXEYKcKyi3hvObCpZNtegMMl057b1BMabPjRIrzuU/evp2+8pdLuOmxMETKJ/UV4PrBDhwV71B+Nuj6j/vDw4Grvh/i4kOoe78UqBu6rCnubRSSBo+GclrnARfgv1fbJyfnb30aDlYrz8vdPv599/nx+7jjOycmMm31FjjAJDB8/znG3c37d293tfdt/wAzMdnf++PKfJwz3JA6mn7afn52eTnfJt5A7FHFV0Tcf/CDaHoIavVnv+95pdBBm5/T0jy//XcG33fb07JR8EYOI7xMyx9n3lWVv0N/snHhflu50zd0iEma68+Lzl/8lK8EtBj33Y5kXNfkkogM2oLuw7kc0Ln7w9c43U8tRe2PQ7252zk+u/e9sX5u/99HJHcB2HMvqAPubhH0oWRcOjE4GJvLAhpnuLFeW0cwPHIZ39keHV7HsloIpDof9UXe+CbECnf15t3+4cSsFQva0bPt6ujMFIB24B+Xm6tu2c2FZxMNwONho351H2wM4dBeQ7wuuMNdvl/eiZHnbunDvI3EHRwMQr2M5EUTDOdxov6LifdkY7Tusu2WekuIfhPvAUHB+8Iftq7mjw4GzF/Lk+D3acK65n+P147BjgypL2Ct9ji1YyQ+zIAYdveDsfd/uacy5wmbSYyyUkV1I+k3JKizkPWaZHDh2sk/+jpOo+2Q4sBLNKs4P8Sb6YIZJ3hVW9Zr1VFKrDuBPSCaXo67SuezNq1o6hm+QCitqvnE2l07f8F2LWiMvGc86fQPiILfO1HK5DO0CBszEQ4hFmAxGsShGV3xRpdqkYpNhlCJPUxxDg2DyxQCeL7sTHxf5Yinmeg2sXd+1Mk/ZS8SDdsOrRBxA/1yxaNIuikWFYcTizQASpVWUJD6aisRrVKPJgyaiFAdCykMnsexj8LxJlnbMQ2NsDU2oKMPPjMnzRmAuwgUINb7h1WSYJk8CGfN8K3KhSHyDYcox02aigsB+NU0D/lDToFfBlCA8/zd6pqRm3ALM35CM9ciq6YXZlExTorYco5KKsmdAe4UZlhjXVzbTkqQ1bwBYHlIPg5pmeHpKkqS5nqTSevi7xdjZSgDVNCct0wylN0w6esNsMV9pSUlUPUNm4c7cNMFb1FAyTVExyVEsmyadadKmGW7GvGmG6QziIJoIVDiKpw+J8nHzewQTw4CgRcMIUqFi0DtTMQSqHGqSM4xY4lAMOPNMyzByMvz1K7MGeC0bmtdOr21GMcKkVYo6EAeu2ygcqHED0Axj7dFzfChlRYHh1xQlWDhRoTURlTxVDltyihLTRFTIkWkpSqOmKGW/UiVGsjL22mOaiOFwTElRQk3yiuLuBgjHkz+rKN5ZHENNMyTZs5MXRXcdmqLo782ySJ+KsliiypEmobmHLBIhBFFsMCXRNwPXMDGV/ANdyzFNZDHccmAfHqt84HYsKo1YWGORQkn0XpyVZc2PUla9Z0NZpjVR5RJVDlvSshzTRJXJWcjLMix5RZbJNs/Jbp0mN912OaaJKleCckmW01R5EvjXvB++XVOmEBPVpKmqk2wNyJZU1TslmpqnDDS1RJXD3JKGfkzMjEwBfIAmKVXVMqSKXDBjtem2qzFNNDXcchNVjTRRVT9r5N0BmmFbS1UbT5zrPWloMdzxxxqdKcZaNPeKFqpV07RYyqtoZD1LmpbzvFaZvOb5qWqC267FNBlr4ZabaFqQ3omDwO1YGxNHwYiCpi1Jk2olhrsNKpU6ZVGpTCjrOlVPWzFe30ml4spar1TyvjfoRKYlVCo1yjxNdV+jmsBBI6qeQHiBkuCPfgFJjkm16p0c9/TUq1USkFCtpjP+f6XJrFWrUShCtU6Vq7nAKpWBrhPPXzporVazVCfwk8+G5jUhMAQagaXnoEGN4Hl1ISM0QpKTJysIdOrICIIAabYhxKAs8kK0Z3LCDTOSoCeC4C15DWoaQae69yNOpC6Ml6XK4XTTscHr3+i9aCb1Or2hmVy9TibSqOcj6tQTvNcchExb5SfuHm/U6/70GvUgL0y8UmpCm8cdRWNABNHj7oS+ANcUy3ukjVj3ufvZaP1+ZgGZ0B4/CCEIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiCIy/8BZUAT1+cUlVIAAAAASUVORK5CYII=" />
 <p>This is an online ccar magzine designed to create and improve knowledge about cars.</p>
 </div>


<div  class="footer-one  col-lg-3 col-md-6 col-12" > 
<h5 class="pb-2" style="color:#a2cf6e" >Featured</h5>
<ul class="text-uppercase  list-unstyled">
<li>hatchback</li>
<li>suv</li>
<li>sedan</li>
<li>coupe</li>
<li>sports car</li>
<li>offRoader</li>
</ul>
</div>


<div  class="footer-one  col-lg-3 col-md-6 col-12" > 

<h5 class="pb-2" style="color:#a2cf6e" >Contact us</h5>
<div class="text-uppercase">
<P>Phone Number(+91): 9448724072 , 7022136392 </p>
</div>
<P>Email : pawanbharadwajnp@gmail.com sampathkumarsharmapl@gmail.com  </p>
</div>


</div>

<br>
<div class="copyright">
<div class="row container mx-auto" >
<div class="col-lg-3 col-md-6 col-12">
<a href="https://www.facebook.com/pawan.bharadwaj.106" target="_blank"  > <i class=" fab fa-facebook-f"></i> </a>
<a href="https://www.facebook.com/sumbath.vp" target="_blank"  > <i class=" fab fa-facebook-f"></i> </a>
</div>
</div>
</div>
<br>

<div >
for more information go to :<a href="http://www.vcetputtur.ac.in/">vcetputtur.ac.in</a> 
</div>




</footer>


</body>

</html>